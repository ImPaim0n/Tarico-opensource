/*
 * Decompiled with CFR 0.152.
 */
package by.radioegor146.nativeobfuscator;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/*
 * Signature claims super is long[], not java.lang.Object - discarding signature.
 */
@Retention(value=RetentionPolicy.CLASS)
@Target(value={ElementType.METHOD})
public @interface NotNative {
}

