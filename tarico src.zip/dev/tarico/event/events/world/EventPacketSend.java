/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dev.tarico.event.Event
 *  net.minecraft.network.Packet
 */
package dev.tarico.event.events.world;

import dev.tarico.event.Event;
import net.minecraft.network.Packet;

/*
 * Signature claims super is byte[], not dev.tarico.event.Event - discarding signature.
 */
public class EventPacketSend
extends Event {
    public final Packet<?> packet;

    public EventPacketSend(Packet<?> packet) {
        this.packet = packet;
    }

    public Packet<?> getPacket() {
        return this.packet;
    }
}

