/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.NetHandlerPlayClient
 *  net.minecraft.client.network.NetworkPlayerInfo
 */
package dev.tarico.injection.mixins;

import java.util.Map;
import java.util.UUID;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/*
 * Signature claims super is byte[], not java.lang.Object - discarding signature.
 */
@Mixin(value={NetHandlerPlayClient.class})
public interface IAccessorNetHandlerPlayClient {
    @Accessor(value="playerInfoMap")
    public Map<UUID, NetworkPlayerInfo> getPlayerInfoMap();
}

