/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  dev.tarico.\u4f60\u4e2a\u6ca1\u901f\u5ea6\u7684\u5c0f\u5e9f\u7269.\u4f60\u4e3a\u4ec0\u4e48\u5728\u8fd9\u91cc\u8000\u6b66\u626c\u5a01\u7684.lillllllii
 */
package dev.tarico.\u4f60\u4e2a\u6ca1\u901f\u5ea6\u7684\u5c0f\u5e9f\u7269.\u4f60\u4e3a\u4ec0\u4e48\u5728\u8fd9\u91cc\u8000\u6b66\u626c\u5a01\u7684;

import dev.tarico.\u4f60\u4e2a\u6ca1\u901f\u5ea6\u7684\u5c0f\u5e9f\u7269.\u4f60\u4e3a\u4ec0\u4e48\u5728\u8fd9\u91cc\u8000\u6b66\u626c\u5a01\u7684.lillllllii;

public class illlliilii<V>
extends lillllllii<V> {
    public illlliilii(String string, V v) {
        super(string);
        this.\u6211\u73b0\u5728\u5728\u8fd9\u57cb\u6c70\u4f60\u5462\u5c0f\u8001\u5f1f(v);
    }
}

