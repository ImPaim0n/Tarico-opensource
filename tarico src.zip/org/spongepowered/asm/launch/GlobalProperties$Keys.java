/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.launch;

public final class GlobalProperties$Keys {
    public static final String INIT;
    public static final String AGENTS;
    public static final String CONFIGS;
    public static final String TRANSFORMER;
    public static final String PLATFORM_MANAGER;
    public static final String FML_LOAD_CORE_MOD;
    public static final String FML_GET_REPARSEABLE_COREMODS;
    public static final String FML_CORE_MOD_MANAGER;
    public static final String FML_GET_IGNORED_MODS;

    private GlobalProperties$Keys() {
    }

    static {
        FML_LOAD_CORE_MOD = "mixin.launch.fml.loadcoremodmethod";
        INIT = "mixin.initialised";
        FML_GET_REPARSEABLE_COREMODS = "mixin.launch.fml.reparseablecoremodsmethod";
        FML_CORE_MOD_MANAGER = "mixin.launch.fml.coremodmanagerclass";
        AGENTS = "mixin.agents";
        FML_GET_IGNORED_MODS = "mixin.launch.fml.ignoredmodsmethod";
        TRANSFORMER = "mixin.transformer";
        CONFIGS = "mixin.configs";
        PLATFORM_MANAGER = "mixin.platform";
    }
}

