/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.launch;

import java.util.ServiceLoader;
import org.spongepowered.asm.service.IGlobalPropertyService;

public final class GlobalProperties {
    private static IGlobalPropertyService service;

    private GlobalProperties() {
    }

    private static IGlobalPropertyService getService() {
        if (GlobalProperties.lIIIIIllIIl(service)) {
            ServiceLoader<IGlobalPropertyService> serviceLoader = ServiceLoader.load(IGlobalPropertyService.class, GlobalProperties.class.getClassLoader());
            service = serviceLoader.iterator().next();
        }
        return service;
    }

    public static <T> T get(String string) {
        return GlobalProperties.getService().getProperty(string);
    }

    public static void put(String string, Object object) {
        GlobalProperties.getService().setProperty(string, object);
    }

    public static <T> T get(String string, T t) {
        return GlobalProperties.getService().getProperty(string, t);
    }

    public static String getString(String string, String string2) {
        return GlobalProperties.getService().getPropertyString(string, string2);
    }

    private static boolean lIIIIIllIIl(Object object) {
        return object == null;
    }
}

