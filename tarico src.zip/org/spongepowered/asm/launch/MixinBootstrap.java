/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.launch;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.GlobalProperties;
import org.spongepowered.asm.launch.MixinInitialisationError;
import org.spongepowered.asm.launch.platform.MixinPlatformManager;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.service.MixinService;

public abstract class MixinBootstrap {
    public static final String VERSION = "0.7.10";
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private static boolean initialised = false;
    private static boolean initState = true;
    private static MixinPlatformManager platform;

    private MixinBootstrap() {
    }

    @Deprecated
    public static void addProxy() {
        MixinService.getService().beginPhase();
    }

    public static MixinPlatformManager getPlatform() {
        if (MixinBootstrap.lIIIllIIlIl(platform)) {
            Object t = GlobalProperties.get("mixin.platform");
            if (MixinBootstrap.lIIIllIIllI(t instanceof MixinPlatformManager)) {
                platform = (MixinPlatformManager)t;
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                platform = new MixinPlatformManager();
                GlobalProperties.put("mixin.platform", platform);
                platform.init();
            }
        }
        return platform;
    }

    public static void init() {
        if (MixinBootstrap.lIIIllIIlll(MixinBootstrap.start() ? 1 : 0)) {
            return;
        }
        MixinBootstrap.doInit(null);
    }

    static boolean start() {
        if (MixinBootstrap.lIIIllIIllI(MixinBootstrap.isSubsystemRegistered() ? 1 : 0)) {
            if (MixinBootstrap.lIIIllIIlll(MixinBootstrap.checkSubsystemVersion() ? 1 : 0)) {
                throw new MixinInitialisationError(String.valueOf(new StringBuilder().append("Mixin subsystem version ").append(MixinBootstrap.getActiveSubsystemVersion()).append(" was already initialised. Cannot bootstrap version ").append("0.7.10")));
            }
            return false;
        }
        MixinBootstrap.registerSubsystem("0.7.10");
        if (MixinBootstrap.lIIIllIIlll(initialised ? 1 : 0)) {
            MixinEnvironment$Phase mixinEnvironment$Phase;
            initialised = true;
            String string = System.getProperty("sun.java.command");
            if (MixinBootstrap.lIIIllIlIII(string) && MixinBootstrap.lIIIllIIllI(string.contains("GradleStart") ? 1 : 0)) {
                System.setProperty("mixin.env.remapRefMap", "true");
                "".length();
            }
            if (MixinBootstrap.lIIIllIlIIl(mixinEnvironment$Phase = MixinService.getService().getInitialPhase(), MixinEnvironment$Phase.DEFAULT)) {
                logger.error("Initialising mixin subsystem after game pre-init phase! Some mixins may be skipped.");
                MixinEnvironment.init(mixinEnvironment$Phase);
                MixinBootstrap.getPlatform().prepare(null);
                initState = false;
                "".length();
                if (((0x6B ^ 0x64 ^ (0xA9 ^ 0x8B)) & (0x14 ^ 0x61 ^ (0xF0 ^ 0xA8) ^ -" ".length())) == -" ".length()) {
                    return ((0x7F ^ 0x5B ^ (0xD2 ^ 0xC3)) & (0x36 ^ 0x7D ^ (0xFD ^ 0x83) ^ -" ".length())) != 0;
                }
            } else {
                MixinEnvironment.init(mixinEnvironment$Phase);
            }
            MixinService.getService().beginPhase();
        }
        MixinBootstrap.getPlatform();
        "".length();
        return true;
    }

    static void doInit(List<String> list) {
        if (MixinBootstrap.lIIIllIIlll(initialised ? 1 : 0)) {
            if (MixinBootstrap.lIIIllIIllI(MixinBootstrap.isSubsystemRegistered() ? 1 : 0)) {
                logger.warn("Multiple Mixin containers present, init suppressed for 0.7.10");
                return;
            }
            throw new IllegalStateException("MixinBootstrap.doInit() called before MixinBootstrap.start()");
        }
        MixinBootstrap.getPlatform().getPhaseProviderClasses();
        "".length();
        if (MixinBootstrap.lIIIllIIllI(initState ? 1 : 0)) {
            MixinBootstrap.getPlatform().prepare(list);
            MixinService.getService().init();
        }
    }

    static void inject() {
        MixinBootstrap.getPlatform().inject();
    }

    private static boolean isSubsystemRegistered() {
        boolean bl;
        if (MixinBootstrap.lIIIllIlIII(GlobalProperties.get("mixin.initialised"))) {
            bl = true;
            "".length();
            if (-" ".length() == " ".length()) {
                return ((173 + 107 - 278 + 172 ^ 121 + 109 - 223 + 134) & (0x4D ^ 0x22 ^ (0x65 ^ 0x29) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean checkSubsystemVersion() {
        return "0.7.10".equals(MixinBootstrap.getActiveSubsystemVersion());
    }

    private static Object getActiveSubsystemVersion() {
        Object object;
        Object t = GlobalProperties.get("mixin.initialised");
        if (MixinBootstrap.lIIIllIlIII(t)) {
            object = t;
            "".length();
            if (-" ".length() >= 0) {
                return null;
            }
        } else {
            object = "";
        }
        return object;
    }

    private static void registerSubsystem(String string) {
        GlobalProperties.put("mixin.initialised", string);
    }

    static {
        MixinService.boot();
        MixinService.getService().prepare();
    }

    private static boolean lIIIllIlIII(Object object) {
        return object != null;
    }

    private static boolean lIIIllIlIIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIllIIlIl(Object object) {
        return object == null;
    }

    private static boolean lIIIllIIllI(int n) {
        return n != 0;
    }

    private static boolean lIIIllIIlll(int n) {
        return n == 0;
    }
}

