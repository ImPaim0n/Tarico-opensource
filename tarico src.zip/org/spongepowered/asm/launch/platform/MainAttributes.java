/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.launch.platform;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

final class MainAttributes {
    private static final Map<URI, MainAttributes> instances = new HashMap<URI, MainAttributes>();
    protected final Attributes attributes;

    private MainAttributes() {
        this.attributes = new Attributes();
    }

    private MainAttributes(File file) {
        this.attributes = MainAttributes.getAttributes(file);
    }

    public final String get(String string) {
        if (MainAttributes.llIIIlIIIlI(this.attributes)) {
            return this.attributes.getValue(string);
        }
        return null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Attributes getAttributes(File file) {
        JarFile jarFile;
        block16: {
            Attributes attributes;
            if (MainAttributes.llIIIlIIIll(file)) {
                return null;
            }
            jarFile = null;
            try {
                jarFile = new JarFile(file);
                Manifest manifest = jarFile.getManifest();
                if (!MainAttributes.llIIIlIIIlI(manifest)) break block16;
                attributes = manifest.getMainAttributes();
            }
            catch (IOException iOException) {
                try {
                    if (MainAttributes.llIIIlIIIlI(jarFile)) {
                        jarFile.close();
                    }
                    "".length();
                }
                catch (IOException iOException2) {
                    "".length();
                    return new Attributes();
                }
                if (" ".length() > -" ".length()) return new Attributes();
                return null;
            }
            catch (Throwable throwable) {
                try {
                    if (MainAttributes.llIIIlIIIlI(jarFile)) {
                        jarFile.close();
                    }
                    "".length();
                }
                catch (IOException iOException) {
                    // empty catch block
                    throw throwable;
                }
                if ("   ".length() > 0) throw throwable;
                return null;
            }
            try {
                if (MainAttributes.llIIIlIIIlI(jarFile)) {
                    jarFile.close();
                }
                "".length();
            }
            catch (IOException iOException) {
                // empty catch block
                return attributes;
            }
            if (((0x73 ^ 0x6E) & ~(0x20 ^ 0x3D)) < "   ".length()) return attributes;
            return null;
        }
        try {
            if (MainAttributes.llIIIlIIIlI(jarFile)) {
                jarFile.close();
            }
            "".length();
        }
        catch (IOException iOException) {
            "".length();
            if ((0x8B ^ 0x8F) > " ".length()) return new Attributes();
            return null;
        }
        if ("   ".length() > 0) return new Attributes();
        return null;
    }

    public static MainAttributes of(File file) {
        return MainAttributes.of(file.toURI());
    }

    public static MainAttributes of(URI uRI) {
        MainAttributes mainAttributes = instances.get(uRI);
        if (MainAttributes.llIIIlIIIll(mainAttributes)) {
            mainAttributes = new MainAttributes(new File(uRI));
            instances.put(uRI, mainAttributes);
            "".length();
        }
        return mainAttributes;
    }

    private static boolean llIIIlIIIlI(Object object) {
        return object != null;
    }

    private static boolean llIIIlIIIll(Object object) {
        return object == null;
    }
}

