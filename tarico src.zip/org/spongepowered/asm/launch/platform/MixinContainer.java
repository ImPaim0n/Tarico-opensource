/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.launch.platform;

import java.lang.reflect.Constructor;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.GlobalProperties;
import org.spongepowered.asm.launch.platform.IMixinPlatformAgent;
import org.spongepowered.asm.launch.platform.MixinPlatformManager;
import org.spongepowered.asm.service.MixinService;

public class MixinContainer {
    private static final List<String> agentClasses;
    private final Logger logger = LogManager.getLogger((String)"mixin");
    private final URI uri;
    private final List<IMixinPlatformAgent> agents = new ArrayList<IMixinPlatformAgent>();

    public MixinContainer(MixinPlatformManager mixinPlatformManager, URI uRI) {
        this.uri = uRI;
        Iterator<String> iterator = agentClasses.iterator();
        while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            try {
                Class<?> clazz = Class.forName(string);
                Constructor<?> constructor = clazz.getDeclaredConstructor(MixinPlatformManager.class, URI.class);
                this.logger.debug("Instancing new {} for {}", new Object[]{clazz.getSimpleName(), this.uri});
                IMixinPlatformAgent iMixinPlatformAgent = (IMixinPlatformAgent)constructor.newInstance(mixinPlatformManager, uRI);
                this.agents.add(iMixinPlatformAgent);
                "".length();
                "".length();
            }
            catch (Exception exception) {
                this.logger.catching((Throwable)exception);
            }
            if ("  ".length() != "  ".length()) {
                throw null;
            }
            "".length();
            if ("  ".length() <= "  ".length()) continue;
            throw null;
        }
    }

    public URI getURI() {
        return this.uri;
    }

    public Collection<String> getPhaseProviders() {
        ArrayList<String> arrayList = new ArrayList<String>();
        Iterator<IMixinPlatformAgent> iterator = this.agents.iterator();
        while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
            IMixinPlatformAgent iMixinPlatformAgent = iterator.next();
            String string = iMixinPlatformAgent.getPhaseProvider();
            if (MixinContainer.lIIIIlIIIll(string)) {
                arrayList.add(string);
                "".length();
            }
            "".length();
            if ((" ".length() & (" ".length() ^ -" ".length())) == ((0x57 ^ 1 ^ (0x4B ^ 0x53)) & (0x42 ^ 8 ^ (0x67 ^ 0x63) ^ -" ".length()))) continue;
            return null;
        }
        return arrayList;
    }

    public void prepare() {
        Iterator<IMixinPlatformAgent> iterator = this.agents.iterator();
        while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
            IMixinPlatformAgent iMixinPlatformAgent = iterator.next();
            this.logger.debug("Processing prepare() for {}", new Object[]{iMixinPlatformAgent});
            iMixinPlatformAgent.prepare();
            "".length();
            if (((0xB ^ 0x5E) & ~(0x72 ^ 0x27)) == 0) continue;
            return;
        }
    }

    public void initPrimaryContainer() {
        Iterator<IMixinPlatformAgent> iterator = this.agents.iterator();
        while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
            IMixinPlatformAgent iMixinPlatformAgent = iterator.next();
            this.logger.debug("Processing launch tasks for {}", new Object[]{iMixinPlatformAgent});
            iMixinPlatformAgent.initPrimaryContainer();
            "".length();
            if (-(6 + 103 - -46 + 42 ^ 21 + 5 - -72 + 95) <= 0) continue;
            return;
        }
    }

    public void inject() {
        Iterator<IMixinPlatformAgent> iterator = this.agents.iterator();
        while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
            IMixinPlatformAgent iMixinPlatformAgent = iterator.next();
            this.logger.debug("Processing inject() for {}", new Object[]{iMixinPlatformAgent});
            iMixinPlatformAgent.inject();
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
    }

    public String getLaunchTarget() {
        Iterator<IMixinPlatformAgent> iterator = this.agents.iterator();
        while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
            IMixinPlatformAgent iMixinPlatformAgent = iterator.next();
            String string = iMixinPlatformAgent.getLaunchTarget();
            if (MixinContainer.lIIIIlIIIll(string)) {
                return string;
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        return null;
    }

    static {
        block1: {
            agentClasses = new ArrayList<String>();
            GlobalProperties.put("mixin.agents", agentClasses);
            Iterator<String> iterator = MixinService.getService().getPlatformAgents().iterator();
            while (MixinContainer.lIIIIlIIIIl(iterator.hasNext() ? 1 : 0)) {
                String string = iterator.next();
                agentClasses.add(string);
                "".length();
                "".length();
                if (-" ".length() <= 0) continue;
                break block1;
            }
            agentClasses.add("org.spongepowered.asm.launch.platform.MixinPlatformAgentDefault");
            "".length();
        }
    }

    private static boolean lIIIIlIIIll(Object object) {
        return object != null;
    }

    private static boolean lIIIIlIIIIl(int n) {
        return n != 0;
    }
}

