/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.launch.platform;

import java.net.URI;
import org.spongepowered.asm.launch.platform.MixinPlatformAgentAbstract;
import org.spongepowered.asm.launch.platform.MixinPlatformManager;

public class MixinPlatformAgentDefault
extends MixinPlatformAgentAbstract {
    public MixinPlatformAgentDefault(MixinPlatformManager mixinPlatformManager, URI uRI) {
        super(mixinPlatformManager, uRI);
    }

    @Override
    public void prepare() {
        int n;
        Object object;
        String string;
        String string2 = this.attributes.get("MixinCompatibilityLevel");
        if (MixinPlatformAgentDefault.llIIIlIllII(string2)) {
            this.manager.setCompatibilityLevel(string2);
        }
        if (MixinPlatformAgentDefault.llIIIlIllII(string = this.attributes.get("MixinConfigs"))) {
            object = string.split(",");
            int n2 = ((String[])object).length;
            n = 0;
            while (MixinPlatformAgentDefault.llIIIlIllIl(n, n2)) {
                Object object2 = object[n];
                this.manager.addConfig(((String)object2).trim());
                ++n;
                "".length();
                if (" ".length() >= 0) continue;
                return;
            }
        }
        if (MixinPlatformAgentDefault.llIIIlIllII(object = this.attributes.get("MixinTokenProviders"))) {
            String[] stringArray = ((String)object).split(",");
            n = stringArray.length;
            int n3 = 0;
            while (MixinPlatformAgentDefault.llIIIlIllIl(n3, n)) {
                String string3 = stringArray[n3];
                this.manager.addTokenProvider(string3.trim());
                ++n3;
                "".length();
                if (((0x26 ^ 0x64 ^ (0xB ^ 0x5C)) & (135 + 11 - 136 + 141 ^ 37 + 68 - -4 + 21 ^ -" ".length())) < (145 + 109 - 237 + 136 ^ 36 + 137 - 17 + 1)) continue;
                return;
            }
        }
    }

    @Override
    public void initPrimaryContainer() {
    }

    @Override
    public void inject() {
    }

    @Override
    public String getLaunchTarget() {
        return this.attributes.get("Main-Class");
    }

    private static boolean llIIIlIllIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIIIlIllII(Object object) {
        return object != null;
    }
}

