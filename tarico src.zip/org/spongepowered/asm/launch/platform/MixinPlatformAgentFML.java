/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.launchwrapper.ITweaker
 *  net.minecraft.launchwrapper.Launch
 *  net.minecraft.launchwrapper.LaunchClassLoader
 *  org.apache.logging.log4j.Level
 */
package org.spongepowered.asm.launch.platform;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.launchwrapper.ITweaker;
import net.minecraft.launchwrapper.Launch;
import net.minecraft.launchwrapper.LaunchClassLoader;
import org.apache.logging.log4j.Level;
import org.spongepowered.asm.launch.GlobalProperties;
import org.spongepowered.asm.launch.platform.MixinPlatformAgentAbstract;
import org.spongepowered.asm.launch.platform.MixinPlatformManager;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.extensibility.IRemapper;

public class MixinPlatformAgentFML
extends MixinPlatformAgentAbstract {
    private static final String LOAD_CORE_MOD_METHOD;
    private static final String GET_REPARSEABLE_COREMODS_METHOD;
    private static final String CORE_MOD_MANAGER_CLASS;
    private static final String CORE_MOD_MANAGER_CLASS_LEGACY;
    private static final String GET_IGNORED_MODS_METHOD;
    private static final String GET_IGNORED_MODS_METHOD_LEGACY;
    private static final String FML_REMAPPER_ADAPTER_CLASS;
    private static final String FML_CMDLINE_COREMODS;
    private static final String FML_PLUGIN_WRAPPER_CLASS;
    private static final String FML_CORE_MOD_INSTANCE_FIELD;
    private static final String MFATT_FORCELOADASMOD;
    private static final String MFATT_FMLCOREPLUGIN;
    private static final String MFATT_COREMODCONTAINSMOD;
    private static final String FML_TWEAKER_DEOBF;
    private static final String FML_TWEAKER_INJECTION;
    private static final String FML_TWEAKER_TERMINAL;
    private static final Set<String> loadedCoreMods;
    private final ITweaker coreModWrapper;
    private final String fileName;
    private Class<?> clCoreModManager;
    private boolean initInjectionState;

    public MixinPlatformAgentFML(MixinPlatformManager mixinPlatformManager, URI uRI) {
        super(mixinPlatformManager, uRI);
        this.fileName = this.container.getName();
        this.coreModWrapper = this.initFMLCoreMod();
    }

    private ITweaker initFMLCoreMod() {
        try {
            try {
                this.clCoreModManager = MixinPlatformAgentFML.getCoreModManagerClass();
                "".length();
            }
            catch (ClassNotFoundException classNotFoundException) {
                MixinPlatformAgentAbstract.logger.info("FML platform manager could not load class {}. Proceeding without FML support.", new Object[]{classNotFoundException.getMessage()});
                return null;
            }
            if ("  ".length() < -" ".length()) {
                return null;
            }
            if (MixinPlatformAgentFML.lIIIIllIl("true".equalsIgnoreCase(this.attributes.get("ForceLoadAsMod")) ? 1 : 0)) {
                MixinPlatformAgentAbstract.logger.debug("ForceLoadAsMod was specified for {}, attempting force-load", new Object[]{this.fileName});
                this.loadAsMod();
            }
            return this.injectCorePlugin();
        }
        catch (Exception exception) {
            MixinPlatformAgentAbstract.logger.catching((Throwable)exception);
            return null;
        }
    }

    private void loadAsMod() {
        try {
            MixinPlatformAgentFML.getIgnoredMods(this.clCoreModManager).remove(this.fileName);
            "".length();
            "".length();
        }
        catch (Exception exception) {
            MixinPlatformAgentAbstract.logger.catching((Throwable)exception);
        }
        if (((0x94 ^ 0x99) & ~(0x3D ^ 0x30)) != 0) {
            return;
        }
        if (MixinPlatformAgentFML.lIIIlIIIl(this.attributes.get("FMLCorePluginContainsFMLMod"))) {
            if (MixinPlatformAgentFML.lIIIIllIl(this.isIgnoredReparseable() ? 1 : 0)) {
                MixinPlatformAgentAbstract.logger.debug("Ignoring request to add {} to reparseable coremod collection - it is a deobfuscated dependency", new Object[]{this.fileName});
                return;
            }
            this.addReparseableJar();
        }
    }

    private boolean isIgnoredReparseable() {
        return this.container.toString().contains("deobfedDeps");
    }

    private void addReparseableJar() {
        try {
            Method method = this.clCoreModManager.getDeclaredMethod(GlobalProperties.getString("mixin.launch.fml.reparseablecoremodsmethod", "getReparseableCoremods"), new Class[0]);
            List list = (List)method.invoke(null, new Object[0]);
            if (MixinPlatformAgentFML.lIIIlIlII(list.contains(this.fileName) ? 1 : 0)) {
                MixinPlatformAgentAbstract.logger.debug("Adding {} to reparseable coremod collection", new Object[]{this.fileName});
                list.add(this.fileName);
                "".length();
            }
            "".length();
        }
        catch (Exception exception) {
            MixinPlatformAgentAbstract.logger.catching((Throwable)exception);
        }
        if (null != null) {
            return;
        }
    }

    private ITweaker injectCorePlugin() {
        String string = this.attributes.get("FMLCorePlugin");
        if (MixinPlatformAgentFML.lIIIlIlIl(string)) {
            return null;
        }
        if (MixinPlatformAgentFML.lIIIIllIl(this.isAlreadyInjected(string) ? 1 : 0)) {
            MixinPlatformAgentAbstract.logger.debug("{} has core plugin {}. Skipping because it was already injected.", new Object[]{this.fileName, string});
            return null;
        }
        MixinPlatformAgentAbstract.logger.debug("{} has core plugin {}. Injecting it into FML for co-initialisation:", new Object[]{this.fileName, string});
        Method method = this.clCoreModManager.getDeclaredMethod(GlobalProperties.getString("mixin.launch.fml.loadcoremodmethod", "loadCoreMod"), LaunchClassLoader.class, String.class, File.class);
        method.setAccessible(true);
        ITweaker iTweaker = (ITweaker)method.invoke(null, Launch.classLoader, string, this.container);
        if (MixinPlatformAgentFML.lIIIlIlIl(iTweaker)) {
            MixinPlatformAgentAbstract.logger.debug("Core plugin {} could not be loaded.", new Object[]{string});
            return null;
        }
        this.initInjectionState = MixinPlatformAgentFML.isTweakerQueued("FMLInjectionAndSortingTweaker");
        loadedCoreMods.add(string);
        "".length();
        return iTweaker;
    }

    private boolean isAlreadyInjected(String string) {
        if (MixinPlatformAgentFML.lIIIIllIl(loadedCoreMods.contains(string) ? 1 : 0)) {
            return true;
        }
        try {
            List list = (List)GlobalProperties.get("Tweaks");
            if (MixinPlatformAgentFML.lIIIlIlIl(list)) {
                return false;
            }
            Iterator iterator = list.iterator();
            while (MixinPlatformAgentFML.lIIIIllIl(iterator.hasNext() ? 1 : 0)) {
                ITweaker iTweaker = (ITweaker)iterator.next();
                Class<?> clazz = iTweaker.getClass();
                if (MixinPlatformAgentFML.lIIIIllIl("FMLPluginWrapper".equals(clazz.getSimpleName()) ? 1 : 0)) {
                    Field field = clazz.getField("coreModInstance");
                    field.setAccessible(true);
                    Object object = field.get(iTweaker);
                    if (MixinPlatformAgentFML.lIIIIllIl(string.equals(object.getClass().getName()) ? 1 : 0)) {
                        return true;
                    }
                }
                "".length();
                if (((85 + 70 - -18 + 38 ^ 58 + 77 - 127 + 129) & (0xF2 ^ 0x97 ^ (0x9B ^ 0xA4) ^ -" ".length())) <= "  ".length()) continue;
                return ((38 + 137 - 83 + 74 ^ 41 + 79 - 48 + 87) & (29 + 136 - 110 + 106 ^ 20 + 27 - -80 + 25 ^ -" ".length())) != 0;
            }
            "".length();
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (((0x94 ^ 0x91 ^ (0x11 ^ 0x30)) & (0xC2 ^ 0x8B ^ (0x73 ^ 0x1E) ^ -" ".length())) < 0) {
            return ((0x12 ^ 0x79 ^ (4 ^ 0x73)) & (50 + 21 - -14 + 91 ^ 123 + 120 - 169 + 98 ^ -" ".length())) != 0;
        }
        return false;
    }

    @Override
    public String getPhaseProvider() {
        return String.valueOf(new StringBuilder().append(MixinPlatformAgentFML.class.getName()).append("$PhaseProvider"));
    }

    @Override
    public void prepare() {
        this.initInjectionState |= MixinPlatformAgentFML.isTweakerQueued("FMLInjectionAndSortingTweaker");
    }

    @Override
    public void initPrimaryContainer() {
        if (MixinPlatformAgentFML.lIIIlIIIl(this.clCoreModManager)) {
            this.injectRemapper();
        }
    }

    private void injectRemapper() {
        try {
            MixinPlatformAgentAbstract.logger.debug("Creating FML remapper adapter: {}", new Object[]{"org.spongepowered.asm.bridge.RemapperAdapterFML"});
            Class<?> clazz = Class.forName("org.spongepowered.asm.bridge.RemapperAdapterFML", true, (ClassLoader)Launch.classLoader);
            Method method = clazz.getDeclaredMethod("create", new Class[0]);
            IRemapper iRemapper = (IRemapper)method.invoke(null, new Object[0]);
            MixinEnvironment.getDefaultEnvironment().getRemappers().add(iRemapper);
            "".length();
            "".length();
        }
        catch (Exception exception) {
            MixinPlatformAgentAbstract.logger.debug("Failed instancing FML remapper adapter, things will probably go horribly for notch-obf'd mods!");
        }
        if (-" ".length() >= " ".length()) {
            return;
        }
    }

    @Override
    public void inject() {
        if (MixinPlatformAgentFML.lIIIlIIIl(this.coreModWrapper) && MixinPlatformAgentFML.lIIIIllIl(this.checkForCoInitialisation() ? 1 : 0)) {
            MixinPlatformAgentAbstract.logger.debug("FML agent is co-initiralising coremod instance {} for {}", new Object[]{this.coreModWrapper, this.uri});
            this.coreModWrapper.injectIntoClassLoader(Launch.classLoader);
        }
    }

    @Override
    public String getLaunchTarget() {
        return null;
    }

    protected final boolean checkForCoInitialisation() {
        boolean bl;
        int n = MixinPlatformAgentFML.isTweakerQueued("FMLInjectionAndSortingTweaker");
        int n2 = MixinPlatformAgentFML.isTweakerQueued("TerminalTweaker");
        if (MixinPlatformAgentFML.lIIIIllIl(this.initInjectionState ? 1 : 0) && !MixinPlatformAgentFML.lIIIlIlII(n2) || MixinPlatformAgentFML.lIIIIllIl(n)) {
            MixinPlatformAgentAbstract.logger.debug("FML agent is skipping co-init for {} because FML will inject it normally", new Object[]{this.coreModWrapper});
            return false;
        }
        if (MixinPlatformAgentFML.lIIIlIlII(MixinPlatformAgentFML.isTweakerQueued("FMLDeobfTweaker") ? 1 : 0)) {
            bl = true;
            "".length();
            if ("   ".length() <= 0) {
                return ((0x6D ^ 0x52) & ~(0x82 ^ 0xBD)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean isTweakerQueued(String string) {
        Iterator iterator = ((List)GlobalProperties.get("TweakClasses")).iterator();
        while (MixinPlatformAgentFML.lIIIIllIl(iterator.hasNext() ? 1 : 0)) {
            String string2 = (String)iterator.next();
            if (MixinPlatformAgentFML.lIIIIllIl(string2.endsWith(string) ? 1 : 0)) {
                return true;
            }
            "".length();
            if (((0x2A ^ 0x25 ^ (0x76 ^ 0x37)) & (40 + 70 - -20 + 92 ^ 60 + 120 - 95 + 59 ^ -" ".length())) == ((144 + 89 - 113 + 39 ^ 186 + 151 - 306 + 164) & (200 + 117 - 305 + 231 ^ 147 + 102 - 243 + 169 ^ -" ".length()))) continue;
            return ((0x29 ^ 0x65 ^ (0x5E ^ 0x31)) & (0xDB ^ 0x8D ^ (0x66 ^ 0x13) ^ -" ".length())) != 0;
        }
        return false;
    }

    private static Class<?> getCoreModManagerClass() {
        try {
            return Class.forName(GlobalProperties.getString("mixin.launch.fml.coremodmanagerclass", "net.minecraftforge.fml.relauncher.CoreModManager"));
        }
        catch (ClassNotFoundException classNotFoundException) {
            return Class.forName("cpw.mods.fml.relauncher.CoreModManager");
        }
    }

    private static List<String> getIgnoredMods(Class<?> clazz) {
        Method method = null;
        try {
            method = clazz.getDeclaredMethod(GlobalProperties.getString("mixin.launch.fml.ignoredmodsmethod", "getIgnoredMods"), new Class[0]);
            "".length();
        }
        catch (NoSuchMethodException noSuchMethodException) {
            try {
                method = clazz.getDeclaredMethod("getLoadedCoremods", new Class[0]);
                "".length();
            }
            catch (NoSuchMethodException noSuchMethodException2) {
                MixinPlatformAgentAbstract.logger.catching(Level.DEBUG, (Throwable)noSuchMethodException2);
                return Collections.emptyList();
            }
            if (((0x8B ^ 0xA0 ^ (0x31 ^ 0xC)) & (0x68 ^ 0x3C ^ (0xF2 ^ 0xB0) ^ -" ".length())) < 0) {
                return null;
            }
        }
        if ("  ".length() > (0xC ^ 8)) {
            return null;
        }
        return (List)method.invoke(null, new Object[0]);
    }

    static {
        FML_TWEAKER_INJECTION = "FMLInjectionAndSortingTweaker";
        GET_IGNORED_MODS_METHOD = "getIgnoredMods";
        CORE_MOD_MANAGER_CLASS = "net.minecraftforge.fml.relauncher.CoreModManager";
        GET_REPARSEABLE_COREMODS_METHOD = "getReparseableCoremods";
        FML_TWEAKER_TERMINAL = "TerminalTweaker";
        FML_TWEAKER_DEOBF = "FMLDeobfTweaker";
        GET_IGNORED_MODS_METHOD_LEGACY = "getLoadedCoremods";
        MFATT_FMLCOREPLUGIN = "FMLCorePlugin";
        FML_REMAPPER_ADAPTER_CLASS = "org.spongepowered.asm.bridge.RemapperAdapterFML";
        CORE_MOD_MANAGER_CLASS_LEGACY = "cpw.mods.fml.relauncher.CoreModManager";
        FML_PLUGIN_WRAPPER_CLASS = "FMLPluginWrapper";
        FML_CMDLINE_COREMODS = "fml.coreMods.load";
        MFATT_FORCELOADASMOD = "ForceLoadAsMod";
        LOAD_CORE_MOD_METHOD = "loadCoreMod";
        MFATT_COREMODCONTAINSMOD = "FMLCorePluginContainsFMLMod";
        FML_CORE_MOD_INSTANCE_FIELD = "coreModInstance";
        loadedCoreMods = new HashSet<String>();
        String[] stringArray = System.getProperty("fml.coreMods.load", "").split(",");
        int n = stringArray.length;
        int n2 = 0;
        while (MixinPlatformAgentFML.lIIIlIllI(n2, n)) {
            String string = stringArray[n2];
            if (MixinPlatformAgentFML.lIIIlIlII(string.isEmpty() ? 1 : 0)) {
                MixinPlatformAgentAbstract.logger.debug("FML platform agent will ignore coremod {} specified on the command line", new Object[]{string});
                loadedCoreMods.add(string);
                "".length();
            }
            ++n2;
            "".length();
            if ("  ".length() != 0) continue;
            break;
        }
    }

    private static boolean lIIIlIllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIIIl(Object object) {
        return object != null;
    }

    private static boolean lIIIlIlIl(Object object) {
        return object == null;
    }

    private static boolean lIIIIllIl(int n) {
        return n != 0;
    }

    private static boolean lIIIlIlII(int n) {
        return n == 0;
    }
}

