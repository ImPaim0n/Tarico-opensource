/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.launch.platform;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.platform.MainAttributes;
import org.spongepowered.asm.launch.platform.MixinContainer;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.service.MixinService;

public class MixinPlatformManager {
    private static final String DEFAULT_MAIN_CLASS;
    private static final String MIXIN_TWEAKER_CLASS;
    private static final Logger logger;
    private final Map<URI, MixinContainer> containers = new LinkedHashMap<URI, MixinContainer>();
    private MixinContainer primaryContainer;
    private boolean prepared = false;
    private boolean injected;

    public void init() {
        logger.debug("Initialising Mixin Platform Manager");
        URI uRI = null;
        try {
            uRI = this.getClass().getProtectionDomain().getCodeSource().getLocation().toURI();
            if (MixinPlatformManager.lIlIIIl(uRI)) {
                logger.debug("Mixin platform: primary container is {}", new Object[]{uRI});
                this.primaryContainer = this.addContainer(uRI);
            }
            "".length();
        }
        catch (URISyntaxException uRISyntaxException) {
            uRISyntaxException.printStackTrace();
        }
        if (-"  ".length() >= 0) {
            return;
        }
        this.scanClasspath();
    }

    public Collection<String> getPhaseProviderClasses() {
        Collection<String> collection = this.primaryContainer.getPhaseProviders();
        if (MixinPlatformManager.lIlIIIl(collection)) {
            return Collections.unmodifiableCollection(collection);
        }
        return Collections.emptyList();
    }

    public final MixinContainer addContainer(URI uRI) {
        MixinContainer mixinContainer = this.containers.get(uRI);
        if (MixinPlatformManager.lIlIIIl(mixinContainer)) {
            return mixinContainer;
        }
        logger.debug("Adding mixin platform agents for container {}", new Object[]{uRI});
        MixinContainer mixinContainer2 = new MixinContainer(this, uRI);
        this.containers.put(uRI, mixinContainer2);
        "".length();
        if (MixinPlatformManager.lIlIIlI(this.prepared ? 1 : 0)) {
            mixinContainer2.prepare();
        }
        return mixinContainer2;
    }

    public final void prepare(List<String> list) {
        this.prepared = true;
        Object object = this.containers.values().iterator();
        while (MixinPlatformManager.lIlIIlI(object.hasNext() ? 1 : 0)) {
            MixinContainer mixinContainer = object.next();
            mixinContainer.prepare();
            "".length();
            if (-"   ".length() < 0) continue;
            return;
        }
        if (MixinPlatformManager.lIlIIIl(list)) {
            this.parseArgs(list);
            "".length();
            if (((0x3D ^ 0x77) & ~(0x26 ^ 0x6C)) < 0) {
                return;
            }
        } else {
            object = System.getProperty("sun.java.command");
            if (MixinPlatformManager.lIlIIIl(object)) {
                this.parseArgs(Arrays.asList(((String)object).split(" ")));
            }
        }
    }

    private void parseArgs(List<String> list) {
        int n = 0;
        Iterator<String> iterator = list.iterator();
        while (MixinPlatformManager.lIlIIlI(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            if (MixinPlatformManager.lIlIIlI(n)) {
                this.addConfig(string);
            }
            n = "--mixin".equals(string) ? 1 : 0;
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
    }

    public final void inject() {
        if (MixinPlatformManager.lIlIIlI(this.injected ? 1 : 0)) {
            return;
        }
        this.injected = true;
        if (MixinPlatformManager.lIlIIIl(this.primaryContainer)) {
            this.primaryContainer.initPrimaryContainer();
        }
        this.scanClasspath();
        logger.debug("inject() running with {} agents", new Object[]{this.containers.size()});
        Iterator<MixinContainer> iterator = this.containers.values().iterator();
        while (MixinPlatformManager.lIlIIlI(iterator.hasNext() ? 1 : 0)) {
            MixinContainer mixinContainer = iterator.next();
            try {
                mixinContainer.inject();
                "".length();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            if ((86 + 111 - 144 + 85 ^ 19 + 39 - 38 + 122) < "  ".length()) {
                return;
            }
            "".length();
            if ("   ".length() >= " ".length()) continue;
            return;
        }
    }

    private void scanClasspath() {
        URL[] uRLArray;
        URL[] uRLArray2 = uRLArray = MixinService.getService().getClassProvider().getClassPath();
        int n = uRLArray2.length;
        int n2 = 0;
        while (MixinPlatformManager.lIlIIll(n2, n)) {
            block11: {
                URI uRI;
                block10: {
                    block9: {
                        URL uRL = uRLArray2[n2];
                        uRI = uRL.toURI();
                        if (!MixinPlatformManager.lIlIIlI(this.containers.containsKey(uRI) ? 1 : 0)) break block9;
                        "".length();
                        if ("   ".length() == -" ".length()) {
                            return;
                        }
                        break block11;
                    }
                    logger.debug("Scanning {} for mixin tweaker", new Object[]{uRI});
                    if (MixinPlatformManager.lIlIIlI("file".equals(uRI.getScheme()) ? 1 : 0) && !MixinPlatformManager.lIlIlII(new File(uRI).exists() ? 1 : 0)) break block10;
                    "".length();
                    if (((0x28 ^ 0xD) & ~(0x4B ^ 0x6E)) < 0) {
                        return;
                    }
                    break block11;
                }
                try {
                    MainAttributes mainAttributes = MainAttributes.of(uRI);
                    String string = mainAttributes.get("TweakClass");
                    if (MixinPlatformManager.lIlIIlI("org.spongepowered.asm.launch.MixinTweaker".equals(string) ? 1 : 0)) {
                        logger.debug("{} contains a mixin tweaker, adding agents", new Object[]{uRI});
                        this.addContainer(uRI);
                        "".length();
                    }
                    "".length();
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                if (" ".length() >= (0x63 ^ 0x67)) {
                    return;
                }
            }
            ++n2;
            "".length();
            if ("   ".length() > ((0xEA ^ 0xA0) & ~(0x66 ^ 0x2C))) continue;
            return;
        }
    }

    public String getLaunchTarget() {
        Iterator<MixinContainer> iterator = this.containers.values().iterator();
        while (MixinPlatformManager.lIlIIlI(iterator.hasNext() ? 1 : 0)) {
            MixinContainer mixinContainer = iterator.next();
            String string = mixinContainer.getLaunchTarget();
            if (MixinPlatformManager.lIlIIIl(string)) {
                return string;
            }
            "".length();
            if (-" ".length() < ((0xE8 ^ 0x82 ^ (0xD4 ^ 0x8C)) & (49 + 49 - 49 + 97 ^ 24 + 112 - 56 + 80 ^ -" ".length()))) continue;
            return null;
        }
        return "net.minecraft.client.main.Main";
    }

    final void setCompatibilityLevel(String string) {
        try {
            MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel = MixinEnvironment$CompatibilityLevel.valueOf(string.toUpperCase());
            logger.debug("Setting mixin compatibility level: {}", new Object[]{mixinEnvironment$CompatibilityLevel});
            MixinEnvironment.setCompatibilityLevel(mixinEnvironment$CompatibilityLevel);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            logger.warn("Invalid compatibility level specified: {}", new Object[]{string});
        }
        "".length();
        if ((0x8C ^ 0xA4 ^ (0xAC ^ 0x80)) == 0) {
            return;
        }
    }

    final void addConfig(String string) {
        if (MixinPlatformManager.lIlIIlI(string.endsWith(".json") ? 1 : 0)) {
            logger.debug("Registering mixin config: {}", new Object[]{string});
            Mixins.addConfiguration(string);
            "".length();
            if (((91 + 134 - 139 + 103 ^ 40 + 132 - 75 + 64) & (0xAB ^ 0xC2 ^ (0x18 ^ 0x6D) ^ -" ".length())) >= "  ".length()) {
                return;
            }
        } else if (MixinPlatformManager.lIlIIlI(string.contains(".json@") ? 1 : 0)) {
            int n = string.indexOf(".json@");
            String string2 = string.substring(n + 6);
            string = string.substring(0, n + 5);
            MixinEnvironment$Phase mixinEnvironment$Phase = MixinEnvironment$Phase.forName(string2);
            if (MixinPlatformManager.lIlIIIl(mixinEnvironment$Phase)) {
                logger.warn("Setting config phase via manifest is deprecated: {}. Specify target in config instead", new Object[]{string});
                logger.debug("Registering mixin config: {}", new Object[]{string});
                MixinEnvironment.getEnvironment(mixinEnvironment$Phase).addConfiguration(string);
                "".length();
            }
        }
    }

    final void addTokenProvider(String string) {
        if (MixinPlatformManager.lIlIIlI(string.contains("@") ? 1 : 0)) {
            String[] stringArray = string.split("@", 2);
            MixinEnvironment$Phase mixinEnvironment$Phase = MixinEnvironment$Phase.forName(stringArray[1]);
            if (MixinPlatformManager.lIlIIIl(mixinEnvironment$Phase)) {
                logger.debug("Registering token provider class: {}", new Object[]{stringArray[0]});
                MixinEnvironment.getEnvironment(mixinEnvironment$Phase).registerTokenProviderClass(stringArray[0]);
                "".length();
            }
            return;
        }
        MixinEnvironment.getDefaultEnvironment().registerTokenProviderClass(string);
        "".length();
    }

    static {
        MIXIN_TWEAKER_CLASS = "org.spongepowered.asm.launch.MixinTweaker";
        DEFAULT_MAIN_CLASS = "net.minecraft.client.main.Main";
        logger = LogManager.getLogger((String)"mixin");
    }

    private static boolean lIlIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIIl(Object object) {
        return object != null;
    }

    private static boolean lIlIIlI(int n) {
        return n != 0;
    }

    private static boolean lIlIlII(int n) {
        return n == 0;
    }
}

