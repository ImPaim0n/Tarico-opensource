/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

public abstract class AnnotationVisitor {
    protected final int api;
    protected AnnotationVisitor av;

    public AnnotationVisitor(int n) {
        this(n, null);
    }

    public AnnotationVisitor(int n, AnnotationVisitor annotationVisitor) {
        if (AnnotationVisitor.lIIlIllIlIl(n, 262144) && AnnotationVisitor.lIIlIllIlIl(n, 327680)) {
            throw new IllegalArgumentException();
        }
        this.api = n;
        this.av = annotationVisitor;
    }

    public void visit(String string, Object object) {
        if (AnnotationVisitor.lIIlIllIllI(this.av)) {
            this.av.visit(string, object);
        }
    }

    public void visitEnum(String string, String string2, String string3) {
        if (AnnotationVisitor.lIIlIllIllI(this.av)) {
            this.av.visitEnum(string, string2, string3);
        }
    }

    public AnnotationVisitor visitAnnotation(String string, String string2) {
        if (AnnotationVisitor.lIIlIllIllI(this.av)) {
            return this.av.visitAnnotation(string, string2);
        }
        return null;
    }

    public AnnotationVisitor visitArray(String string) {
        if (AnnotationVisitor.lIIlIllIllI(this.av)) {
            return this.av.visitArray(string);
        }
        return null;
    }

    public void visitEnd() {
        if (AnnotationVisitor.lIIlIllIllI(this.av)) {
            this.av.visitEnd();
        }
    }

    private static boolean lIIlIllIllI(Object object) {
        return object != null;
    }

    private static boolean lIIlIllIlIl(int n, int n2) {
        return n != n2;
    }
}

