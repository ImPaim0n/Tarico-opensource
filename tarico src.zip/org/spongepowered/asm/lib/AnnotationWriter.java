/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.ByteVector;
import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.Item;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;

final class AnnotationWriter
extends AnnotationVisitor {
    private final ClassWriter cw;
    private int size;
    private final boolean named;
    private final ByteVector bv;
    private final ByteVector parent;
    private final int offset;
    AnnotationWriter next;
    AnnotationWriter prev;

    AnnotationWriter(ClassWriter classWriter, boolean bl, ByteVector byteVector, ByteVector byteVector2, int n) {
        super(327680);
        this.cw = classWriter;
        this.named = bl;
        this.bv = byteVector;
        this.parent = byteVector2;
        this.offset = n;
    }

    public void visit(String string, Object object) {
        ++this.size;
        if (AnnotationWriter.llIIlII(this.named ? 1 : 0)) {
            this.bv.putShort(this.cw.newUTF8(string));
            "".length();
        }
        if (AnnotationWriter.llIIlII(object instanceof String)) {
            this.bv.put12(115, this.cw.newUTF8((String)object));
            "".length();
            "".length();
            if ("   ".length() <= 0) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof Byte)) {
            this.bv.put12(66, this.cw.newInteger((int)((Byte)object).byteValue()).index);
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof Boolean)) {
            int n;
            if (AnnotationWriter.llIIlII(((Boolean)object).booleanValue() ? 1 : 0)) {
                n = 1;
                "".length();
                if (-(125 + 79 - 149 + 107 ^ 55 + 34 - 2 + 79) >= 0) {
                    return;
                }
            } else {
                n = 0;
            }
            int n2 = n;
            this.bv.put12(90, this.cw.newInteger((int)n2).index);
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof Character)) {
            this.bv.put12(67, this.cw.newInteger((int)((Character)object).charValue()).index);
            "".length();
            "".length();
            if (-" ".length() >= 0) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof Short)) {
            this.bv.put12(83, this.cw.newInteger((int)((Short)object).shortValue()).index);
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof Type)) {
            this.bv.put12(99, this.cw.newUTF8(((Type)object).getDescriptor()));
            "".length();
            "".length();
            if (" ".length() >= "   ".length()) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof byte[])) {
            byte[] byArray = (byte[])object;
            this.bv.put12(91, byArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, byArray.length)) {
                this.bv.put12(66, this.cw.newInteger((int)byArray[n]).index);
                "".length();
                ++n;
                "".length();
                if (" ".length() < "   ".length()) continue;
                return;
            }
            "".length();
            if (-"   ".length() > 0) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof boolean[])) {
            boolean[] blArray = (boolean[])object;
            this.bv.put12(91, blArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, blArray.length)) {
                int n3;
                if (AnnotationWriter.llIIlII(blArray[n])) {
                    n3 = 1;
                    "".length();
                    if (-" ".length() > 0) {
                        return;
                    }
                } else {
                    n3 = 0;
                }
                this.bv.put12(90, this.cw.newInteger((int)n3).index);
                "".length();
                ++n;
                "".length();
                if (null == null) continue;
                return;
            }
            "".length();
            if (-" ".length() > ((0x70 ^ 0x39) & ~(0x24 ^ 0x6D))) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof short[])) {
            short[] sArray = (short[])object;
            this.bv.put12(91, sArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, sArray.length)) {
                this.bv.put12(83, this.cw.newInteger((int)sArray[n]).index);
                "".length();
                ++n;
                "".length();
                if ((0x13 ^ 0x23 ^ (0xAB ^ 0x9F)) >= -" ".length()) continue;
                return;
            }
            "".length();
            if ("  ".length() < 0) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof char[])) {
            char[] cArray = (char[])object;
            this.bv.put12(91, cArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, cArray.length)) {
                this.bv.put12(67, this.cw.newInteger((int)cArray[n]).index);
                "".length();
                ++n;
                "".length();
                if ((0x78 ^ 0x7C) >= "   ".length()) continue;
                return;
            }
            "".length();
            if (null != null) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof int[])) {
            int[] nArray = (int[])object;
            this.bv.put12(91, nArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, nArray.length)) {
                this.bv.put12(73, this.cw.newInteger((int)nArray[n]).index);
                "".length();
                ++n;
                "".length();
                if (((60 + 59 - -22 + 3 ^ 94 + 62 - 25 + 4) & (0xDD ^ 0xB7 ^ (0x1E ^ 0x63) ^ -" ".length())) < "   ".length()) continue;
                return;
            }
            "".length();
            if (null != null) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof long[])) {
            long[] lArray = (long[])object;
            this.bv.put12(91, lArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, lArray.length)) {
                this.bv.put12(74, this.cw.newLong((long)lArray[n]).index);
                "".length();
                ++n;
                "".length();
                if (((0xE3 ^ 0xC7 ^ (0xD0 ^ 0xBA)) & (0x8E ^ 0x94 ^ (0x1B ^ 0x4F) ^ -" ".length())) < "  ".length()) continue;
                return;
            }
            "".length();
            if (-" ".length() >= "  ".length()) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof float[])) {
            float[] fArray = (float[])object;
            this.bv.put12(91, fArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, fArray.length)) {
                this.bv.put12(70, this.cw.newFloat((float)fArray[n]).index);
                "".length();
                ++n;
                "".length();
                if (" ".length() == " ".length()) continue;
                return;
            }
            "".length();
            if (((0xBB ^ 0x9A) & ~(0x2F ^ 0xE)) > " ".length()) {
                return;
            }
        } else if (AnnotationWriter.llIIlII(object instanceof double[])) {
            double[] dArray = (double[])object;
            this.bv.put12(91, dArray.length);
            "".length();
            int n = 0;
            while (AnnotationWriter.llIIlIl(n, dArray.length)) {
                this.bv.put12(68, this.cw.newDouble((double)dArray[n]).index);
                "".length();
                ++n;
                "".length();
                if ("   ".length() < (0x84 ^ 0x80)) continue;
                return;
            }
            "".length();
            if (null != null) {
                return;
            }
        } else {
            Item item = this.cw.newConstItem(object);
            this.bv.put12(".s.IFJDCS".charAt(item.type), item.index);
            "".length();
        }
    }

    public void visitEnum(String string, String string2, String string3) {
        ++this.size;
        if (AnnotationWriter.llIIlII(this.named ? 1 : 0)) {
            this.bv.putShort(this.cw.newUTF8(string));
            "".length();
        }
        this.bv.put12(101, this.cw.newUTF8(string2)).putShort(this.cw.newUTF8(string3));
        "".length();
    }

    public AnnotationVisitor visitAnnotation(String string, String string2) {
        ++this.size;
        if (AnnotationWriter.llIIlII(this.named ? 1 : 0)) {
            this.bv.putShort(this.cw.newUTF8(string));
            "".length();
        }
        this.bv.put12(64, this.cw.newUTF8(string2)).putShort(0);
        "".length();
        return new AnnotationWriter(this.cw, true, this.bv, this.bv, this.bv.length - 2);
    }

    public AnnotationVisitor visitArray(String string) {
        ++this.size;
        if (AnnotationWriter.llIIlII(this.named ? 1 : 0)) {
            this.bv.putShort(this.cw.newUTF8(string));
            "".length();
        }
        this.bv.put12(91, 0);
        "".length();
        return new AnnotationWriter(this.cw, false, this.bv, this.bv, this.bv.length - 2);
    }

    public void visitEnd() {
        if (AnnotationWriter.llIlIlI(this.parent)) {
            byte[] byArray = this.parent.data;
            byArray[this.offset] = (byte)(this.size >>> 8);
            byArray[this.offset + 1] = (byte)this.size;
        }
    }

    int getSize() {
        int n = 0;
        AnnotationWriter annotationWriter = this;
        while (AnnotationWriter.llIlIlI(annotationWriter)) {
            n += annotationWriter.bv.length;
            annotationWriter = annotationWriter.next;
            "".length();
            if (((0x9A ^ 0xB4) & ~(0xD ^ 0x23)) != -" ".length()) continue;
            return (0xF8 ^ 0xA3) & ~(0x30 ^ 0x6B);
        }
        return n;
    }

    void put(ByteVector byteVector) {
        int n = 0;
        int n2 = 2;
        AnnotationWriter annotationWriter = this;
        AnnotationWriter annotationWriter2 = null;
        while (AnnotationWriter.llIlIlI(annotationWriter)) {
            ++n;
            n2 += annotationWriter.bv.length;
            annotationWriter.visitEnd();
            annotationWriter.prev = annotationWriter2;
            annotationWriter2 = annotationWriter;
            annotationWriter = annotationWriter.next;
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return;
        }
        byteVector.putInt(n2);
        "".length();
        byteVector.putShort(n);
        "".length();
        annotationWriter = annotationWriter2;
        while (AnnotationWriter.llIlIlI(annotationWriter)) {
            byteVector.putByteArray(annotationWriter.bv.data, 0, annotationWriter.bv.length);
            "".length();
            annotationWriter = annotationWriter.prev;
            "".length();
            if (((0xA2 ^ 0xC2) & ~(0xEF ^ 0x8F)) < " ".length()) continue;
            return;
        }
    }

    static void put(AnnotationWriter[] annotationWriterArray, int n, ByteVector byteVector) {
        int n2 = 1 + 2 * (annotationWriterArray.length - n);
        int n3 = n;
        while (AnnotationWriter.llIIlIl(n3, annotationWriterArray.length)) {
            int n4;
            if (AnnotationWriter.llIlllI(annotationWriterArray[n3])) {
                n4 = 0;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n4 = annotationWriterArray[n3].getSize();
            }
            n2 += n4;
            ++n3;
            "".length();
            if (-"  ".length() < 0) continue;
            return;
        }
        byteVector.putInt(n2).putByte(annotationWriterArray.length - n);
        "".length();
        n3 = n;
        while (AnnotationWriter.llIIlIl(n3, annotationWriterArray.length)) {
            AnnotationWriter annotationWriter = annotationWriterArray[n3];
            AnnotationWriter annotationWriter2 = null;
            int n5 = 0;
            while (AnnotationWriter.llIlIlI(annotationWriter)) {
                ++n5;
                annotationWriter.visitEnd();
                annotationWriter.prev = annotationWriter2;
                annotationWriter2 = annotationWriter;
                annotationWriter = annotationWriter.next;
                "".length();
                if (null == null) continue;
                return;
            }
            byteVector.putShort(n5);
            "".length();
            annotationWriter = annotationWriter2;
            while (AnnotationWriter.llIlIlI(annotationWriter)) {
                byteVector.putByteArray(annotationWriter.bv.data, 0, annotationWriter.bv.length);
                "".length();
                annotationWriter = annotationWriter.prev;
                "".length();
                if (" ".length() == " ".length()) continue;
                return;
            }
            ++n3;
            "".length();
            if (-(0x2F ^ 0x2A) < 0) continue;
            return;
        }
    }

    static void putTarget(int n, TypePath typePath, ByteVector byteVector) {
        switch (n >>> 24) {
            case 0: 
            case 1: 
            case 22: {
                byteVector.putShort(n >>> 16);
                "".length();
                "".length();
                if (((0xAE ^ 0xA0 ^ (0xDB ^ 0x8A)) & (0x45 ^ 0x1A ^ (0x1C ^ 0x24) & ~(0xFC ^ 0xC4) ^ -" ".length())) == ((133 + 133 - 133 + 35 ^ 31 + 112 - 140 + 175) & (0x54 ^ 0x41 ^ (0x58 ^ 0x57) ^ -" ".length()))) break;
                return;
            }
            case 19: 
            case 20: 
            case 21: {
                byteVector.putByte(n >>> 24);
                "".length();
                "".length();
                if (-(0x5C ^ 0x64 ^ (0x2A ^ 0x16)) <= 0) break;
                return;
            }
            case 71: 
            case 72: 
            case 73: 
            case 74: 
            case 75: {
                byteVector.putInt(n);
                "".length();
                "".length();
                if (" ".length() > 0) break;
                return;
            }
            default: {
                byteVector.put12(n >>> 24, (n & 0xFFFF00) >> 8);
                "".length();
            }
        }
        if (AnnotationWriter.llIlllI(typePath)) {
            byteVector.putByte(0);
            "".length();
            "".length();
            if (-"   ".length() > 0) {
                return;
            }
        } else {
            int n2 = typePath.b[typePath.offset] * 2 + 1;
            byteVector.putByteArray(typePath.b, typePath.offset, n2);
            "".length();
        }
    }

    private static boolean llIIlIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIlI(Object object) {
        return object != null;
    }

    private static boolean llIlllI(Object object) {
        return object == null;
    }

    private static boolean llIIlII(int n) {
        return n != 0;
    }
}

