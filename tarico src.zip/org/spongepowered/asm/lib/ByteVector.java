/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

public class ByteVector {
    byte[] data;
    int length;

    public ByteVector() {
        this.data = new byte[64];
    }

    public ByteVector(int n) {
        this.data = new byte[n];
    }

    public ByteVector putByte(int n) {
        int n2 = this.length;
        if (ByteVector.lllIlIIIIl(n2 + 1, this.data.length)) {
            this.enlarge(1);
        }
        this.data[n2++] = (byte)n;
        this.length = n2;
        return this;
    }

    ByteVector put11(int n, int n2) {
        int n3 = this.length;
        if (ByteVector.lllIlIIIIl(n3 + 2, this.data.length)) {
            this.enlarge(2);
        }
        byte[] byArray = this.data;
        byArray[n3++] = (byte)n;
        byArray[n3++] = (byte)n2;
        this.length = n3;
        return this;
    }

    public ByteVector putShort(int n) {
        int n2 = this.length;
        if (ByteVector.lllIlIIIIl(n2 + 2, this.data.length)) {
            this.enlarge(2);
        }
        byte[] byArray = this.data;
        byArray[n2++] = (byte)(n >>> 8);
        byArray[n2++] = (byte)n;
        this.length = n2;
        return this;
    }

    ByteVector put12(int n, int n2) {
        int n3 = this.length;
        if (ByteVector.lllIlIIIIl(n3 + 3, this.data.length)) {
            this.enlarge(3);
        }
        byte[] byArray = this.data;
        byArray[n3++] = (byte)n;
        byArray[n3++] = (byte)(n2 >>> 8);
        byArray[n3++] = (byte)n2;
        this.length = n3;
        return this;
    }

    public ByteVector putInt(int n) {
        int n2 = this.length;
        if (ByteVector.lllIlIIIIl(n2 + 4, this.data.length)) {
            this.enlarge(4);
        }
        byte[] byArray = this.data;
        byArray[n2++] = (byte)(n >>> 24);
        byArray[n2++] = (byte)(n >>> 16);
        byArray[n2++] = (byte)(n >>> 8);
        byArray[n2++] = (byte)n;
        this.length = n2;
        return this;
    }

    public ByteVector putLong(long l) {
        int n = this.length;
        if (ByteVector.lllIlIIIIl(n + 8, this.data.length)) {
            this.enlarge(8);
        }
        byte[] byArray = this.data;
        int n2 = (int)(l >>> 32);
        byArray[n++] = (byte)(n2 >>> 24);
        byArray[n++] = (byte)(n2 >>> 16);
        byArray[n++] = (byte)(n2 >>> 8);
        byArray[n++] = (byte)n2;
        n2 = (int)l;
        byArray[n++] = (byte)(n2 >>> 24);
        byArray[n++] = (byte)(n2 >>> 16);
        byArray[n++] = (byte)(n2 >>> 8);
        byArray[n++] = (byte)n2;
        this.length = n;
        return this;
    }

    public ByteVector putUTF8(String string) {
        int n = string.length();
        if (ByteVector.lllIlIIIIl(n, 65535)) {
            throw new IllegalArgumentException();
        }
        int n2 = this.length;
        if (ByteVector.lllIlIIIIl(n2 + 2 + n, this.data.length)) {
            this.enlarge(2 + n);
        }
        byte[] byArray = this.data;
        byArray[n2++] = (byte)(n >>> 8);
        byArray[n2++] = (byte)n;
        int n3 = 0;
        while (ByteVector.lllIlIIIlI(n3, n)) {
            char c = string.charAt(n3);
            if (ByteVector.lllIlIIIll(c, 1) && ByteVector.lllIlIIlII(c, 127)) {
                byArray[n2++] = (byte)c;
                "".length();
                if (-"   ".length() > 0) {
                    return null;
                }
            } else {
                this.length = n2;
                return this.encodeUTF8(string, n3, 65535);
            }
            ++n3;
            "".length();
            if (" ".length() >= -" ".length()) continue;
            return null;
        }
        this.length = n2;
        return this;
    }

    ByteVector encodeUTF8(String string, int n, int n2) {
        char c;
        int n3 = string.length();
        int n4 = n;
        int n5 = n;
        while (ByteVector.lllIlIIIlI(n5, n3)) {
            c = string.charAt(n5);
            if (ByteVector.lllIlIIIll(c, 1) && ByteVector.lllIlIIlII(c, 127)) {
                ++n4;
                "".length();
                if (((0x5E ^ 9) & ~(0x67 ^ 0x30)) != 0) {
                    return null;
                }
            } else if (ByteVector.lllIlIIIIl(c, 2047)) {
                n4 += 3;
                "".length();
                if ((0x2A ^ 0x2E) == 0) {
                    return null;
                }
            } else {
                n4 += 2;
            }
            ++n5;
            "".length();
            if (-"   ".length() < 0) continue;
            return null;
        }
        if (ByteVector.lllIlIIIIl(n4, n2)) {
            throw new IllegalArgumentException();
        }
        n5 = this.length - n - 2;
        if (ByteVector.lllIlIIlIl(n5)) {
            this.data[n5] = (byte)(n4 >>> 8);
            this.data[n5 + 1] = (byte)n4;
        }
        if (ByteVector.lllIlIIIIl(this.length + n4 - n, this.data.length)) {
            this.enlarge(n4 - n);
        }
        int n6 = this.length;
        int n7 = n;
        while (ByteVector.lllIlIIIlI(n7, n3)) {
            c = string.charAt(n7);
            if (ByteVector.lllIlIIIll(c, 1) && ByteVector.lllIlIIlII(c, 127)) {
                this.data[n6++] = (byte)c;
                "".length();
                if (((0x56 ^ 0x70) & ~(0x37 ^ 0x11)) > 0) {
                    return null;
                }
            } else if (ByteVector.lllIlIIIIl(c, 2047)) {
                this.data[n6++] = (byte)(0xE0 | c >> 12 & 0xF);
                this.data[n6++] = (byte)(0x80 | c >> 6 & 0x3F);
                this.data[n6++] = (byte)(0x80 | c & 0x3F);
                "".length();
                if (" ".length() >= "   ".length()) {
                    return null;
                }
            } else {
                this.data[n6++] = (byte)(0xC0 | c >> 6 & 0x1F);
                this.data[n6++] = (byte)(0x80 | c & 0x3F);
            }
            ++n7;
            "".length();
            if (" ".length() <= "  ".length()) continue;
            return null;
        }
        this.length = n6;
        return this;
    }

    public ByteVector putByteArray(byte[] byArray, int n, int n2) {
        if (ByteVector.lllIlIIIIl(this.length + n2, this.data.length)) {
            this.enlarge(n2);
        }
        if (ByteVector.lllIlIIllI(byArray)) {
            System.arraycopy(byArray, n, this.data, this.length, n2);
        }
        this.length += n2;
        return this;
    }

    private void enlarge(int n) {
        int n2;
        int n3 = 2 * this.data.length;
        int n4 = this.length + n;
        if (ByteVector.lllIlIIIIl(n3, n4)) {
            n2 = n3;
            "".length();
            if (-"   ".length() > 0) {
                return;
            }
        } else {
            n2 = n4;
        }
        byte[] byArray = new byte[n2];
        System.arraycopy(this.data, 0, byArray, 0, this.length);
        this.data = byArray;
    }

    private static boolean lllIlIIIll(int n, int n2) {
        return n >= n2;
    }

    private static boolean lllIlIIIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIlIIlII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lllIlIIIIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIlIIllI(Object object) {
        return object != null;
    }

    private static boolean lllIlIIlIl(int n) {
        return n >= 0;
    }
}

