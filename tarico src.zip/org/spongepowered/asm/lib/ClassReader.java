/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import java.io.IOException;
import java.io.InputStream;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ByteVector;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.Context;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Item;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.MethodWriter;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;

public class ClassReader {
    static final boolean SIGNATURES;
    static final boolean ANNOTATIONS;
    static final boolean FRAMES;
    static final boolean WRITER;
    static final boolean RESIZE;
    public static final int SKIP_CODE;
    public static final int SKIP_DEBUG;
    public static final int SKIP_FRAMES;
    public static final int EXPAND_FRAMES;
    static final int EXPAND_ASM_INSNS;
    public final byte[] b;
    private final int[] items;
    private final String[] strings;
    private final int maxStringLength;
    public final int header;

    public ClassReader(byte[] byArray) {
        this(byArray, 0, byArray.length);
    }

    public ClassReader(byte[] byArray, int n, int n2) {
        this.b = byArray;
        if (ClassReader.llIllIlIIII(this.readShort(n + 6), 52)) {
            throw new IllegalArgumentException();
        }
        this.items = new int[this.readUnsignedShort(n + 8)];
        int n3 = this.items.length;
        this.strings = new String[n3];
        int n4 = 0;
        int n5 = n + 10;
        int n6 = 1;
        while (ClassReader.llIllIlIIIl(n6, n3)) {
            int n7;
            this.items[n6] = n5 + 1;
            switch (byArray[n5]) {
                case 3: 
                case 4: 
                case 9: 
                case 10: 
                case 11: 
                case 12: 
                case 18: {
                    n7 = 5;
                    "".length();
                    if ((0xAE ^ 0xAA) >= -" ".length()) break;
                    throw null;
                }
                case 5: 
                case 6: {
                    n7 = 9;
                    ++n6;
                    "".length();
                    if (((104 + 100 - 153 + 135 ^ 108 + 89 - 39 + 19) & (0x14 ^ 9 ^ (0xF ^ 0x19) ^ -" ".length())) == 0) break;
                    throw null;
                }
                case 1: {
                    n7 = 3 + this.readUnsignedShort(n5 + 1);
                    if (!ClassReader.llIllIlIIII(n7, n4)) break;
                    n4 = n7;
                    "".length();
                    if ("   ".length() >= "   ".length()) break;
                    throw null;
                }
                case 15: {
                    n7 = 4;
                    "".length();
                    if ((0x17 ^ 0x48 ^ (0xD3 ^ 0x88)) <= (169 + 77 - 187 + 136 ^ 178 + 13 - 44 + 52)) break;
                    throw null;
                }
                default: {
                    n7 = 3;
                }
            }
            n5 += n7;
            ++n6;
            "".length();
            if (-" ".length() < ((0x70 ^ 0x3A) & ~(0xCC ^ 0x86))) continue;
            throw null;
        }
        this.maxStringLength = n4;
        this.header = n5;
    }

    public int getAccess() {
        return this.readUnsignedShort(this.header);
    }

    public String getClassName() {
        return this.readClass(this.header + 2, new char[this.maxStringLength]);
    }

    public String getSuperName() {
        return this.readClass(this.header + 4, new char[this.maxStringLength]);
    }

    public String[] getInterfaces() {
        int n = this.header + 6;
        int n2 = this.readUnsignedShort(n);
        String[] stringArray = new String[n2];
        if (ClassReader.llIllIlIIlI(n2)) {
            char[] cArray = new char[this.maxStringLength];
            int n3 = 0;
            while (ClassReader.llIllIlIIIl(n3, n2)) {
                stringArray[n3] = this.readClass(n += 2, cArray);
                ++n3;
                "".length();
                if (-" ".length() < 0) continue;
                return null;
            }
        }
        return stringArray;
    }

    void copyPool(ClassWriter classWriter) {
        char[] cArray = new char[this.maxStringLength];
        int n = this.items.length;
        Item[] itemArray = new Item[n];
        int n2 = 1;
        while (ClassReader.llIllIlIIIl(n2, n)) {
            int n3;
            int n4 = this.items[n2];
            byte by = this.b[n4 - 1];
            Item item = new Item(n2);
            switch (by) {
                case 9: 
                case 10: 
                case 11: {
                    int n5 = this.items[this.readUnsignedShort(n4 + 2)];
                    item.set(by, this.readClass(n4, cArray), this.readUTF8(n5, cArray), this.readUTF8(n5 + 2, cArray));
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 3: {
                    item.set(this.readInt(n4));
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 4: {
                    item.set(Float.intBitsToFloat(this.readInt(n4)));
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 12: {
                    item.set(by, this.readUTF8(n4, cArray), this.readUTF8(n4 + 2, cArray), null);
                    "".length();
                    if (-"   ".length() < 0) break;
                    return;
                }
                case 5: {
                    item.set(this.readLong(n4));
                    ++n2;
                    "".length();
                    if (-"  ".length() <= 0) break;
                    return;
                }
                case 6: {
                    item.set(Double.longBitsToDouble(this.readLong(n4)));
                    ++n2;
                    "".length();
                    if ("   ".length() >= ((0xAF ^ 0xB6) & ~(0x3D ^ 0x24))) break;
                    return;
                }
                case 1: {
                    String string = this.strings[n2];
                    if (ClassReader.llIllIlIIll(string)) {
                        n4 = this.items[n2];
                        string = this.strings[n2] = this.readUTF(n4 + 2, this.readUnsignedShort(n4), cArray);
                    }
                    item.set(by, string, null, null);
                    "".length();
                    if ("   ".length() < (0x40 ^ 0x44)) break;
                    return;
                }
                case 15: {
                    n3 = this.items[this.readUnsignedShort(n4 + 1)];
                    int n5 = this.items[this.readUnsignedShort(n3 + 2)];
                    item.set(20 + this.readByte(n4), this.readClass(n3, cArray), this.readUTF8(n5, cArray), this.readUTF8(n5 + 2, cArray));
                    "".length();
                    if (-"   ".length() <= 0) break;
                    return;
                }
                case 18: {
                    if (ClassReader.llIllIlIIll(classWriter.bootstrapMethods)) {
                        this.copyBootstrapMethods(classWriter, itemArray, cArray);
                    }
                    int n5 = this.items[this.readUnsignedShort(n4 + 2)];
                    item.set(this.readUTF8(n5, cArray), this.readUTF8(n5 + 2, cArray), this.readUnsignedShort(n4));
                    "".length();
                    if (-(0x30 ^ 0x35) < 0) break;
                    return;
                }
                default: {
                    item.set(by, this.readUTF8(n4, cArray), null, null);
                }
            }
            n3 = item.hashCode % itemArray.length;
            item.next = itemArray[n3];
            itemArray[n3] = item;
            ++n2;
            "".length();
            if (-" ".length() < (0xBE ^ 0xBA)) continue;
            return;
        }
        n2 = this.items[1] - 1;
        classWriter.pool.putByteArray(this.b, n2, this.header - n2);
        "".length();
        classWriter.items = itemArray;
        classWriter.threshold = (int)(0.75 * (double)n);
        classWriter.index = n;
    }

    private void copyBootstrapMethods(ClassWriter classWriter, Item[] itemArray, char[] cArray) {
        int n = this.getAttributes();
        int n2 = 0;
        int n3 = this.readUnsignedShort(n);
        while (ClassReader.llIllIlIIlI(n3)) {
            String string = this.readUTF8(n + 2, cArray);
            if (ClassReader.llIllIlIlII("BootstrapMethods".equals(string) ? 1 : 0)) {
                n2 = 1;
                "".length();
                if ("  ".length() > -" ".length()) break;
                return;
            }
            n += 6 + this.readInt(n + 4);
            --n3;
            "".length();
            if ("   ".length() != (0xF6 ^ 0x88 ^ (0x1B ^ 0x61))) continue;
            return;
        }
        if (ClassReader.llIllIlIlIl(n2)) {
            return;
        }
        n3 = this.readUnsignedShort(n + 8);
        int n4 = 0;
        int n5 = n + 10;
        while (ClassReader.llIllIlIIIl(n4, n3)) {
            int n6 = n5 - n - 10;
            int n7 = this.readConst(this.readUnsignedShort(n5), cArray).hashCode();
            int n8 = this.readUnsignedShort(n5 + 2);
            while (ClassReader.llIllIlIIlI(n8)) {
                n7 ^= this.readConst(this.readUnsignedShort(n5 + 4), cArray).hashCode();
                n5 += 2;
                --n8;
                "".length();
                if ("  ".length() == "  ".length()) continue;
                return;
            }
            n5 += 4;
            Item item = new Item(n4);
            item.set(n6, n7 & Integer.MAX_VALUE);
            int n9 = item.hashCode % itemArray.length;
            item.next = itemArray[n9];
            itemArray[n9] = item;
            ++n4;
            "".length();
            if ((52 + 99 - 0 + 17 ^ 66 + 116 - 135 + 126) > 0) continue;
            return;
        }
        n4 = this.readInt(n + 4);
        ByteVector byteVector = new ByteVector(n4 + 62);
        byteVector.putByteArray(this.b, n + 10, n4 - 2);
        "".length();
        classWriter.bootstrapMethodsCount = n3;
        classWriter.bootstrapMethods = byteVector;
    }

    public ClassReader(InputStream inputStream) {
        this(ClassReader.readClass(inputStream, false));
    }

    public ClassReader(String string) {
        this(ClassReader.readClass(ClassLoader.getSystemResourceAsStream(String.valueOf(new StringBuilder().append(string.replace('.', '/')).append(".class"))), true));
    }

    private static byte[] readClass(InputStream inputStream, boolean bl) {
        if (ClassReader.llIllIlIIll(inputStream)) {
            throw new IOException("Class not found");
        }
        try {
            byte[] byArray = new byte[inputStream.available()];
            int n = 0;
            do {
                int n2;
                if (ClassReader.llIllIlIllI(n2 = inputStream.read(byArray, n, byArray.length - n), -1)) {
                    byte[] byArray2;
                    if (ClassReader.llIllIlIIIl(n, byArray.length)) {
                        byArray2 = new byte[n];
                        System.arraycopy(byArray, 0, byArray2, 0, n);
                        byArray = byArray2;
                    }
                    byArray2 = byArray;
                    return byArray2;
                }
                if (ClassReader.llIllIlIllI(n += n2, byArray.length)) {
                    byte[] byArray3;
                    int n3 = inputStream.read();
                    if (ClassReader.llIllIlIlll(n3)) {
                        byArray3 = byArray;
                        return byArray3;
                    }
                    byArray3 = new byte[byArray.length + 1000];
                    System.arraycopy(byArray, 0, byArray3, 0, n);
                    byArray3[n++] = (byte)n3;
                    byArray = byArray3;
                }
                "".length();
            } while (" ".length() < "  ".length());
            return null;
        }
        finally {
            if (ClassReader.llIllIlIlII(bl ? 1 : 0)) {
                inputStream.close();
            }
        }
    }

    public void accept(ClassVisitor classVisitor, int n) {
        this.accept(classVisitor, new Attribute[0], n);
    }

    public void accept(ClassVisitor classVisitor, Attribute[] attributeArray, int n) {
        int n2 = this.header;
        char[] cArray = new char[this.maxStringLength];
        Context context = new Context();
        context.attrs = attributeArray;
        context.flags = n;
        context.buffer = cArray;
        int n3 = this.readUnsignedShort(n2);
        String string = this.readClass(n2 + 2, cArray);
        String string2 = this.readClass(n2 + 4, cArray);
        String[] stringArray = new String[this.readUnsignedShort(n2 + 6)];
        n2 += 8;
        int n4 = 0;
        while (ClassReader.llIllIlIIIl(n4, stringArray.length)) {
            stringArray[n4] = this.readClass(n2, cArray);
            n2 += 2;
            ++n4;
            "".length();
            if (((237 + 214 - 337 + 128 ^ 133 + 104 - 61 + 12) & (0xE6 ^ 0xB7 ^ (0x5D ^ 0x42) ^ -" ".length())) >= 0) continue;
            return;
        }
        String string3 = null;
        String string4 = null;
        String string5 = null;
        String string6 = null;
        String string7 = null;
        String string8 = null;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        Attribute attribute = null;
        n2 = this.getAttributes();
        int n10 = this.readUnsignedShort(n2);
        while (ClassReader.llIllIlIIlI(n10)) {
            String string9 = this.readUTF8(n2 + 2, cArray);
            if (ClassReader.llIllIlIlII("SourceFile".equals(string9) ? 1 : 0)) {
                string4 = this.readUTF8(n2 + 8, cArray);
                "".length();
                if (-"  ".length() > 0) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("InnerClasses".equals(string9) ? 1 : 0)) {
                n9 = n2 + 8;
                "".length();
                if (" ".length() != " ".length()) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("EnclosingMethod".equals(string9) ? 1 : 0)) {
                string6 = this.readClass(n2 + 8, cArray);
                int n11 = this.readUnsignedShort(n2 + 10);
                if (ClassReader.llIllIlIlII(n11)) {
                    string7 = this.readUTF8(this.items[n11], cArray);
                    string8 = this.readUTF8(this.items[n11] + 2, cArray);
                }
                "".length();
                if (((0x64 ^ 0x20) & ~(0x2C ^ 0x68)) != 0) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("Signature".equals(string9) ? 1 : 0)) {
                string3 = this.readUTF8(n2 + 8, cArray);
                "".length();
                if ("  ".length() <= -" ".length()) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleAnnotations".equals(string9) ? 1 : 0)) {
                n5 = n2 + 8;
                "".length();
                if ("   ".length() != "   ".length()) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleTypeAnnotations".equals(string9) ? 1 : 0)) {
                n7 = n2 + 8;
                "".length();
                if ("   ".length() >= (0x82 ^ 0xBC ^ (0x7B ^ 0x41))) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("Deprecated".equals(string9) ? 1 : 0)) {
                n3 |= 0x20000;
                "".length();
                if (((0x55 ^ 0x4A) & ~(0x36 ^ 0x29)) > 0) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("Synthetic".equals(string9) ? 1 : 0)) {
                n3 |= 0x41000;
                "".length();
                if (null != null) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("SourceDebugExtension".equals(string9) ? 1 : 0)) {
                int n12 = this.readInt(n2 + 4);
                string5 = this.readUTF(n2 + 8, n12, new char[n12]);
                "".length();
                if ("   ".length() <= "  ".length()) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleAnnotations".equals(string9) ? 1 : 0)) {
                n6 = n2 + 8;
                "".length();
                if ("  ".length() > (0xAC ^ 0xA8)) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleTypeAnnotations".equals(string9) ? 1 : 0)) {
                n8 = n2 + 8;
                "".length();
                if ("  ".length() == 0) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("BootstrapMethods".equals(string9) ? 1 : 0)) {
                int[] nArray = new int[this.readUnsignedShort(n2 + 8)];
                int n13 = 0;
                int n14 = n2 + 10;
                while (ClassReader.llIllIlIIIl(n13, nArray.length)) {
                    nArray[n13] = n14;
                    n14 += 2 + this.readUnsignedShort(n14 + 2) << 1;
                    ++n13;
                    "".length();
                    if (((0x7F ^ 0x3B) & ~(0x4C ^ 8)) == 0) continue;
                    return;
                }
                context.bootstrapMethods = nArray;
                "".length();
                if ((24 + 1 - -7 + 113 ^ 92 + 130 - 211 + 138) <= " ".length()) {
                    return;
                }
            } else {
                Attribute attribute2 = this.readAttribute(attributeArray, string9, n2 + 8, this.readInt(n2 + 4), cArray, -1, null);
                if (ClassReader.llIllIllIIl(attribute2)) {
                    attribute2.next = attribute;
                    attribute = attribute2;
                }
            }
            n2 += 6 + this.readInt(n2 + 4);
            --n10;
            "".length();
            if (((0x58 ^ 0x79) & ~(0x13 ^ 0x32)) == 0) continue;
            return;
        }
        classVisitor.visit(this.readInt(this.items[1] - 7), n3, string, string3, string2, stringArray);
        if (ClassReader.llIllIlIlIl(n & 2) && (!ClassReader.llIllIlIIll(string4) || ClassReader.llIllIllIIl(string5))) {
            classVisitor.visitSource(string4, string5);
        }
        if (ClassReader.llIllIllIIl(string6)) {
            classVisitor.visitOuterClass(string6, string7, string8);
        }
        if (ClassReader.llIllIlIlII(n5)) {
            n10 = this.readUnsignedShort(n5);
            int n15 = n5 + 2;
            while (ClassReader.llIllIlIIlI(n10)) {
                n15 = this.readAnnotationValues(n15 + 2, cArray, true, classVisitor.visitAnnotation(this.readUTF8(n15, cArray), true));
                --n10;
                "".length();
                if ("   ".length() > "  ".length()) continue;
                return;
            }
        }
        if (ClassReader.llIllIlIlII(n6)) {
            n10 = this.readUnsignedShort(n6);
            int n16 = n6 + 2;
            while (ClassReader.llIllIlIIlI(n10)) {
                n16 = this.readAnnotationValues(n16 + 2, cArray, true, classVisitor.visitAnnotation(this.readUTF8(n16, cArray), false));
                --n10;
                "".length();
                if ((118 + 40 - 157 + 148 ^ 1 + 88 - 70 + 126) > ((0xC0 ^ 0xA6 ^ (0xF0 ^ 0xAF)) & (74 + 58 - -40 + 8 ^ 17 + 39 - -73 + 12 ^ -" ".length()))) continue;
                return;
            }
        }
        if (ClassReader.llIllIlIlII(n7)) {
            n10 = this.readUnsignedShort(n7);
            int n17 = n7 + 2;
            while (ClassReader.llIllIlIIlI(n10)) {
                n17 = this.readAnnotationTarget(context, n17);
                n17 = this.readAnnotationValues(n17 + 2, cArray, true, classVisitor.visitTypeAnnotation(context.typeRef, context.typePath, this.readUTF8(n17, cArray), true));
                --n10;
                "".length();
                if (-" ".length() != ((0x30 ^ 0x69) & ~(0xE7 ^ 0xBE))) continue;
                return;
            }
        }
        if (ClassReader.llIllIlIlII(n8)) {
            n10 = this.readUnsignedShort(n8);
            int n18 = n8 + 2;
            while (ClassReader.llIllIlIIlI(n10)) {
                n18 = this.readAnnotationTarget(context, n18);
                n18 = this.readAnnotationValues(n18 + 2, cArray, true, classVisitor.visitTypeAnnotation(context.typeRef, context.typePath, this.readUTF8(n18, cArray), false));
                --n10;
                "".length();
                if (-" ".length() <= (0x60 ^ 0x64)) continue;
                return;
            }
        }
        while (ClassReader.llIllIllIIl(attribute)) {
            Attribute attribute3 = attribute.next;
            attribute.next = null;
            classVisitor.visitAttribute(attribute);
            attribute = attribute3;
            "".length();
            if (-" ".length() <= 0) continue;
            return;
        }
        if (ClassReader.llIllIlIlII(n9)) {
            n10 = n9 + 2;
            int n19 = this.readUnsignedShort(n9);
            while (ClassReader.llIllIlIIlI(n19)) {
                classVisitor.visitInnerClass(this.readClass(n10, cArray), this.readClass(n10 + 2, cArray), this.readUTF8(n10 + 4, cArray), this.readUnsignedShort(n10 + 6));
                n10 += 8;
                --n19;
                "".length();
                if ("  ".length() < "   ".length()) continue;
                return;
            }
        }
        n2 = this.header + 10 + 2 * stringArray.length;
        n10 = this.readUnsignedShort(n2 - 2);
        while (ClassReader.llIllIlIIlI(n10)) {
            n2 = this.readField(classVisitor, context, n2);
            --n10;
            "".length();
            if ("  ".length() <= "  ".length()) continue;
            return;
        }
        n10 = this.readUnsignedShort((n2 += 2) - 2);
        while (ClassReader.llIllIlIIlI(n10)) {
            n2 = this.readMethod(classVisitor, context, n2);
            --n10;
            "".length();
            if (-" ".length() < ((81 + 116 - 89 + 26 ^ 111 + 17 - 115 + 155) & (1 + 48 - -81 + 18 ^ 129 + 105 - 191 + 143 ^ -" ".length()))) continue;
            return;
        }
        classVisitor.visitEnd();
    }

    private int readField(ClassVisitor classVisitor, Context context, int n) {
        int n2;
        char[] cArray = context.buffer;
        int n3 = this.readUnsignedShort(n);
        String string = this.readUTF8(n + 2, cArray);
        String string2 = this.readUTF8(n + 4, cArray);
        n += 6;
        String string3 = null;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        Object object = null;
        Attribute attribute = null;
        int n8 = this.readUnsignedShort(n);
        while (ClassReader.llIllIlIIlI(n8)) {
            String string4 = this.readUTF8(n + 2, cArray);
            if (ClassReader.llIllIlIlII("ConstantValue".equals(string4) ? 1 : 0)) {
                Object object2;
                n2 = this.readUnsignedShort(n + 8);
                if (ClassReader.llIllIlIlIl(n2)) {
                    object2 = null;
                    "".length();
                    if ((7 + 5 - -18 + 115 ^ 124 + 148 - 222 + 99) <= 0) {
                        return (0xA5 ^ 0xBD ^ (0x10 ^ 7)) & (" ".length() ^ (3 ^ 0xD) ^ -" ".length());
                    }
                } else {
                    object2 = this.readConst(n2, cArray);
                }
                object = object2;
                "".length();
                if ("  ".length() > "  ".length()) {
                    return (0xEF ^ 0x96 ^ (0x7C ^ 0x41)) & (0x70 ^ 0x58 ^ (0xC6 ^ 0xAA) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("Signature".equals(string4) ? 1 : 0)) {
                string3 = this.readUTF8(n + 8, cArray);
                "".length();
                if ((0x64 ^ 0x60) <= "   ".length()) {
                    return (0x77 ^ 0x2A) & ~(0x77 ^ 0x2A);
                }
            } else if (ClassReader.llIllIlIlII("Deprecated".equals(string4) ? 1 : 0)) {
                n3 |= 0x20000;
                "".length();
                if (((0x7E ^ 0x60 ^ (0x54 ^ 0x17)) & (68 + 209 - 63 + 33 ^ 154 + 92 - 92 + 16 ^ -" ".length())) != 0) {
                    return (159 + 72 - 183 + 126 ^ 120 + 61 - 162 + 137) & (138 + 164 - 154 + 25 ^ 109 + 102 - 86 + 34 ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("Synthetic".equals(string4) ? 1 : 0)) {
                n3 |= 0x41000;
                "".length();
                if (" ".length() > " ".length()) {
                    return (0xAE ^ 0x80) & ~(0x42 ^ 0x6C);
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleAnnotations".equals(string4) ? 1 : 0)) {
                n4 = n + 8;
                "".length();
                if (-" ".length() != -" ".length()) {
                    return (83 + 182 - 61 + 7 ^ 78 + 133 - 175 + 118) & (0x7B ^ 0x5D ^ (0x55 ^ 0x3A) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleTypeAnnotations".equals(string4) ? 1 : 0)) {
                n6 = n + 8;
                "".length();
                if (" ".length() < " ".length()) {
                    return (0x46 ^ 0x38 ^ (0x7E ^ 0x53)) & (0xF0 ^ 0x98 ^ (0x4D ^ 0x76) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleAnnotations".equals(string4) ? 1 : 0)) {
                n5 = n + 8;
                "".length();
                if (((0x9E ^ 0x80) & ~(0x8E ^ 0x90)) <= -" ".length()) {
                    return (0x37 ^ 2) & ~(0x47 ^ 0x72);
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleTypeAnnotations".equals(string4) ? 1 : 0)) {
                n7 = n + 8;
                "".length();
                if ((0x7E ^ 0x7A) != (0xB2 ^ 0xB6)) {
                    return (0x80 ^ 0x9D) & ~(0xF ^ 0x12);
                }
            } else {
                Attribute attribute2 = this.readAttribute(context.attrs, string4, n + 8, this.readInt(n + 4), cArray, -1, null);
                if (ClassReader.llIllIllIIl(attribute2)) {
                    attribute2.next = attribute;
                    attribute = attribute2;
                }
            }
            n += 6 + this.readInt(n + 4);
            --n8;
            "".length();
            if ("   ".length() != 0) continue;
            return (0xEC ^ 0xC0) & ~(0x21 ^ 0xD);
        }
        n += 2;
        FieldVisitor fieldVisitor = classVisitor.visitField(n3, string, string2, string3, object);
        if (ClassReader.llIllIlIIll(fieldVisitor)) {
            return n;
        }
        if (ClassReader.llIllIlIlII(n4)) {
            int n9 = this.readUnsignedShort(n4);
            n2 = n4 + 2;
            while (ClassReader.llIllIlIIlI(n9)) {
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, fieldVisitor.visitAnnotation(this.readUTF8(n2, cArray), true));
                --n9;
                "".length();
                if (-" ".length() == -" ".length()) continue;
                return (0x2A ^ 3) & ~(0x7C ^ 0x55);
            }
        }
        if (ClassReader.llIllIlIlII(n5)) {
            int n10 = this.readUnsignedShort(n5);
            n2 = n5 + 2;
            while (ClassReader.llIllIlIIlI(n10)) {
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, fieldVisitor.visitAnnotation(this.readUTF8(n2, cArray), false));
                --n10;
                "".length();
                if (null == null) continue;
                return "   ".length() & ("   ".length() ^ -" ".length());
            }
        }
        if (ClassReader.llIllIlIlII(n6)) {
            int n11 = this.readUnsignedShort(n6);
            n2 = n6 + 2;
            while (ClassReader.llIllIlIIlI(n11)) {
                n2 = this.readAnnotationTarget(context, n2);
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, fieldVisitor.visitTypeAnnotation(context.typeRef, context.typePath, this.readUTF8(n2, cArray), true));
                --n11;
                "".length();
                if (null == null) continue;
                return (202 + 26 - 50 + 73 ^ 62 + 118 - 117 + 116) & (58 + 71 - 95 + 93 ^ (0x7F ^ 0x48) ^ -" ".length());
            }
        }
        if (ClassReader.llIllIlIlII(n7)) {
            int n12 = this.readUnsignedShort(n7);
            n2 = n7 + 2;
            while (ClassReader.llIllIlIIlI(n12)) {
                n2 = this.readAnnotationTarget(context, n2);
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, fieldVisitor.visitTypeAnnotation(context.typeRef, context.typePath, this.readUTF8(n2, cArray), false));
                --n12;
                "".length();
                if (-" ".length() < (83 + 125 - 38 + 0 ^ 108 + 81 - 24 + 9)) continue;
                return (90 + 101 - 165 + 103 ^ 47 + 109 - 133 + 144) & (0xF3 ^ 0x8E ^ (0x65 ^ 0x3E) ^ -" ".length());
            }
        }
        while (ClassReader.llIllIllIIl(attribute)) {
            Attribute attribute3 = attribute.next;
            attribute.next = null;
            fieldVisitor.visitAttribute(attribute);
            attribute = attribute3;
            "".length();
            if (" ".length() < (137 + 37 - 127 + 103 ^ 32 + 95 - 1 + 20)) continue;
            return (0xA ^ 0x1D ^ (0xB4 ^ 0xB8)) & (0x7D ^ 0x5A ^ (0x41 ^ 0x7D) ^ -" ".length());
        }
        fieldVisitor.visitEnd();
        return n;
    }

    private int readMethod(ClassVisitor classVisitor, Context context, int n) {
        int n2;
        Object object;
        char[] cArray = context.buffer;
        context.access = this.readUnsignedShort(n);
        context.name = this.readUTF8(n + 2, cArray);
        context.desc = this.readUTF8(n + 4, cArray);
        n += 6;
        int n3 = 0;
        int n4 = 0;
        String[] stringArray = null;
        String string = null;
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        int n10 = 0;
        int n11 = 0;
        int n12 = 0;
        int n13 = n;
        Attribute attribute = null;
        int n14 = this.readUnsignedShort(n);
        while (ClassReader.llIllIlIIlI(n14)) {
            object = this.readUTF8(n + 2, cArray);
            if (ClassReader.llIllIlIlII("Code".equals(object) ? 1 : 0)) {
                if (ClassReader.llIllIlIlIl(context.flags & 1)) {
                    n3 = n + 8;
                    "".length();
                    if (((2 ^ 0x3F) & ~(0x3E ^ 3)) != 0) {
                        return (0xA ^ 0x34) & ~(9 ^ 0x37);
                    }
                }
            } else if (ClassReader.llIllIlIlII("Exceptions".equals(object) ? 1 : 0)) {
                stringArray = new String[this.readUnsignedShort(n + 8)];
                n4 = n + 10;
                n2 = 0;
                while (ClassReader.llIllIlIIIl(n2, stringArray.length)) {
                    stringArray[n2] = this.readClass(n4, cArray);
                    n4 += 2;
                    ++n2;
                    "".length();
                    if (" ".length() >= 0) continue;
                    return (0x1F ^ 0x12) & ~(0x83 ^ 0x8E);
                }
                "".length();
                if (null != null) {
                    return (0xE0 ^ 0xC1) & ~(0x65 ^ 0x44);
                }
            } else if (ClassReader.llIllIlIlII("Signature".equals(object) ? 1 : 0)) {
                string = this.readUTF8(n + 8, cArray);
                "".length();
                if (-" ".length() >= " ".length()) {
                    return (0xFB ^ 0xBA ^ (0xFC ^ 0x98)) & (11 + 132 - 41 + 31 ^ 100 + 98 - 41 + 3 ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("Deprecated".equals(object) ? 1 : 0)) {
                context.access |= 0x20000;
                "".length();
                if (null != null) {
                    return (0x90 ^ 0x94 ^ (0xC8 ^ 0x96)) & (79 + 170 - 227 + 190 ^ 55 + 130 - 58 + 15 ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleAnnotations".equals(object) ? 1 : 0)) {
                n6 = n + 8;
                "".length();
                if (((0x55 ^ 0x43) & ~(0x26 ^ 0x30)) != ((0x8A ^ 0xA1) & ~(0xB7 ^ 0x9C))) {
                    return (0xF3 ^ 0xAA) & ~(0x2F ^ 0x76) & ~((0x9D ^ 0xBF) & ~(0x1F ^ 0x3D));
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleTypeAnnotations".equals(object) ? 1 : 0)) {
                n8 = n + 8;
                "".length();
                if (null != null) {
                    return (47 + 56 - -42 + 9 ^ 31 + 134 - 113 + 123) & (0x9D ^ 0x8C ^ (0x60 ^ 0x44) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("AnnotationDefault".equals(object) ? 1 : 0)) {
                n10 = n + 8;
                "".length();
                if (-(0xBE ^ 0xB3 ^ (0xA5 ^ 0xAD)) >= 0) {
                    return "   ".length() & ("   ".length() ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("Synthetic".equals(object) ? 1 : 0)) {
                context.access |= 0x41000;
                "".length();
                if (null != null) {
                    return (0x13 ^ 0x72) & ~(0xCC ^ 0xAD);
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleAnnotations".equals(object) ? 1 : 0)) {
                n7 = n + 8;
                "".length();
                if ("  ".length() < -" ".length()) {
                    return (7 ^ 1 ^ (0xD9 ^ 0x98)) & (0x50 ^ 0x3D ^ (0xAE ^ 0x84) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleTypeAnnotations".equals(object) ? 1 : 0)) {
                n9 = n + 8;
                "".length();
                if (((25 + 181 - 54 + 32 ^ 113 + 129 - 192 + 138) & (0x1A ^ 0x6E ^ (0x34 ^ 0x44) ^ -" ".length())) == " ".length()) {
                    return (7 ^ 0x38 ^ (0x6E ^ 0x1C)) & (96 + 98 - -39 + 10 ^ 48 + 38 - -100 + 4 ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleParameterAnnotations".equals(object) ? 1 : 0)) {
                n11 = n + 8;
                "".length();
                if (((0xA5 ^ 0x8E) & ~(0x1A ^ 0x31)) == (0x98 ^ 0x9C)) {
                    return (0xF4 ^ 0xC3) & ~(8 ^ 0x3F);
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleParameterAnnotations".equals(object) ? 1 : 0)) {
                n12 = n + 8;
                "".length();
                if (((0x62 ^ 0x2A ^ (0xA2 ^ 0xB5)) & (0x8E ^ 0xBF ^ (0xEB ^ 0x85) ^ -" ".length())) == "  ".length()) {
                    return (0xE9 ^ 0xBA ^ (0x20 ^ 0x60)) & (0x4F ^ 3 ^ (0x11 ^ 0x4E) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIlII("MethodParameters".equals(object) ? 1 : 0)) {
                n5 = n + 8;
                "".length();
                if ((0x82 ^ 0x86) < -" ".length()) {
                    return (0x65 ^ 0x33) & ~(0xE1 ^ 0xB7);
                }
            } else {
                Attribute attribute2 = this.readAttribute(context.attrs, (String)object, n + 8, this.readInt(n + 4), cArray, -1, null);
                if (ClassReader.llIllIllIIl(attribute2)) {
                    attribute2.next = attribute;
                    attribute = attribute2;
                }
            }
            n += 6 + this.readInt(n + 4);
            --n14;
            "".length();
            if (null == null) continue;
            return (0 ^ 0x15 ^ (0x65 ^ 0x53)) & (0xFF ^ 0x97 ^ (0x8F ^ 0xC4) ^ -" ".length());
        }
        n += 2;
        MethodVisitor methodVisitor = classVisitor.visitMethod(context.access, context.name, context.desc, string, stringArray);
        if (ClassReader.llIllIlIIll(methodVisitor)) {
            return n;
        }
        if (ClassReader.llIllIlIlII(methodVisitor instanceof MethodWriter)) {
            object = (MethodWriter)methodVisitor;
            if (ClassReader.llIlllIIIlI(((MethodWriter)object).cw.cr, this) && ClassReader.llIlllIIIlI(string, ((MethodWriter)object).signature)) {
                n2 = 0;
                if (ClassReader.llIllIlIIll(stringArray)) {
                    int n15;
                    if (ClassReader.llIllIlIlIl(((MethodWriter)object).exceptionCount)) {
                        n15 = 1;
                        "".length();
                        if (null != null) {
                            return (0x94 ^ 0x9E) & ~(0x7A ^ 0x70);
                        }
                    } else {
                        n15 = 0;
                    }
                    n2 = n15;
                    "".length();
                    if ((0xB2 ^ 0xB6) == ((0xD6 ^ 0xC2) & ~(0xAE ^ 0xBA))) {
                        return (0x8A ^ 0xBB) & ~(0x97 ^ 0xA6);
                    }
                } else if (ClassReader.llIllIlIllI(stringArray.length, ((MethodWriter)object).exceptionCount)) {
                    n2 = 1;
                    int n16 = stringArray.length - 1;
                    while (ClassReader.llIlllIIIll(n16)) {
                        if (ClassReader.llIlllIIlII(((MethodWriter)object).exceptions[n16], this.readUnsignedShort(n4 -= 2))) {
                            n2 = 0;
                            "".length();
                            if ((0x83 ^ 0x87) != 0) break;
                            return (0xF1 ^ 0xBD) & ~(0x70 ^ 0x3C);
                        }
                        --n16;
                        "".length();
                        if (((0x91 ^ 0x9C) & ~(3 ^ 0xE)) == 0) continue;
                        return (0x35 ^ 0x22) & ~(0x84 ^ 0x93);
                    }
                }
                if (ClassReader.llIllIlIlII(n2)) {
                    ((MethodWriter)object).classReaderOffset = n13;
                    ((MethodWriter)object).classReaderLength = n - n13;
                    return n;
                }
            }
        }
        if (ClassReader.llIllIlIlII(n5)) {
            int n17 = this.b[n5] & 0xFF;
            n2 = n5 + 1;
            while (ClassReader.llIllIlIIlI(n17)) {
                methodVisitor.visitParameter(this.readUTF8(n2, cArray), this.readUnsignedShort(n2 + 2));
                --n17;
                n2 += 4;
                "".length();
                if ((0x48 ^ 0x3D ^ (0x69 ^ 0x18)) == (0x76 ^ 0x56 ^ (0x12 ^ 0x36))) continue;
                return (0x59 ^ 9 ^ (0x7E ^ 0x69)) & (0xDE ^ 0x80 ^ (0x3E ^ 0x27) ^ -" ".length());
            }
        }
        if (ClassReader.llIllIlIlII(n10)) {
            AnnotationVisitor annotationVisitor = methodVisitor.visitAnnotationDefault();
            this.readAnnotationValue(n10, cArray, null, annotationVisitor);
            "".length();
            if (ClassReader.llIllIllIIl(annotationVisitor)) {
                annotationVisitor.visitEnd();
            }
        }
        if (ClassReader.llIllIlIlII(n6)) {
            int n18 = this.readUnsignedShort(n6);
            n2 = n6 + 2;
            while (ClassReader.llIllIlIIlI(n18)) {
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, methodVisitor.visitAnnotation(this.readUTF8(n2, cArray), true));
                --n18;
                "".length();
                if (null == null) continue;
                return (112 + 18 - 66 + 134 ^ 14 + 95 - 29 + 74) & (0xE ^ 0x40 ^ (0x39 ^ 0x2B) ^ -" ".length());
            }
        }
        if (ClassReader.llIllIlIlII(n7)) {
            int n19 = this.readUnsignedShort(n7);
            n2 = n7 + 2;
            while (ClassReader.llIllIlIIlI(n19)) {
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, methodVisitor.visitAnnotation(this.readUTF8(n2, cArray), false));
                --n19;
                "".length();
                if (" ".length() != 0) continue;
                return (0x84 ^ 0xB6) & ~(0x59 ^ 0x6B);
            }
        }
        if (ClassReader.llIllIlIlII(n8)) {
            int n20 = this.readUnsignedShort(n8);
            n2 = n8 + 2;
            while (ClassReader.llIllIlIIlI(n20)) {
                n2 = this.readAnnotationTarget(context, n2);
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, methodVisitor.visitTypeAnnotation(context.typeRef, context.typePath, this.readUTF8(n2, cArray), true));
                --n20;
                "".length();
                if (-"   ".length() <= 0) continue;
                return (0xAD ^ 0x94 ^ (0x5D ^ 0x24)) & (0x23 ^ 0x2F ^ (0x3C ^ 0x70) ^ -" ".length());
            }
        }
        if (ClassReader.llIllIlIlII(n9)) {
            int n21 = this.readUnsignedShort(n9);
            n2 = n9 + 2;
            while (ClassReader.llIllIlIIlI(n21)) {
                n2 = this.readAnnotationTarget(context, n2);
                n2 = this.readAnnotationValues(n2 + 2, cArray, true, methodVisitor.visitTypeAnnotation(context.typeRef, context.typePath, this.readUTF8(n2, cArray), false));
                --n21;
                "".length();
                if (-" ".length() < 0) continue;
                return (0x67 ^ 0x42) & ~(0x80 ^ 0xA5);
            }
        }
        if (ClassReader.llIllIlIlII(n11)) {
            this.readParameterAnnotations(methodVisitor, context, n11, true);
        }
        if (ClassReader.llIllIlIlII(n12)) {
            this.readParameterAnnotations(methodVisitor, context, n12, false);
        }
        while (ClassReader.llIllIllIIl(attribute)) {
            Attribute attribute3 = attribute.next;
            attribute.next = null;
            methodVisitor.visitAttribute(attribute);
            attribute = attribute3;
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return (0x82 ^ 0xC3) & ~(0xF3 ^ 0xB2);
        }
        if (ClassReader.llIllIlIlII(n3)) {
            methodVisitor.visitCode();
            this.readCode(methodVisitor, context, n3);
        }
        methodVisitor.visitEnd();
        return n;
    }

    private void readCode(MethodVisitor methodVisitor, Context context, int n) {
        int n2;
        int n3;
        boolean bl;
        int n4;
        byte[] byArray = this.b;
        char[] cArray = context.buffer;
        int n5 = this.readUnsignedShort(n);
        int n6 = this.readUnsignedShort(n + 2);
        int n7 = this.readInt(n + 4);
        int n8 = n += 8;
        int n9 = n + n7;
        context.labels = new Label[n7 + 2];
        Label[] labelArray = context.labels;
        this.readLabel(n7 + 1, labelArray);
        "".length();
        while (ClassReader.llIllIlIIIl(n, n9)) {
            n4 = n - n8;
            int n10 = byArray[n] & 0xFF;
            switch (ClassWriter.TYPE[n10]) {
                case 0: 
                case 4: {
                    ++n;
                    "".length();
                    if (-(0x4E ^ 0x4A) < 0) break;
                    return;
                }
                case 9: {
                    this.readLabel(n4 + this.readShort(n + 1), labelArray);
                    "".length();
                    n += 3;
                    "".length();
                    if (-" ".length() < 0) break;
                    return;
                }
                case 18: {
                    this.readLabel(n4 + this.readUnsignedShort(n + 1), labelArray);
                    "".length();
                    n += 3;
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 10: {
                    this.readLabel(n4 + this.readInt(n + 1), labelArray);
                    "".length();
                    n += 5;
                    "".length();
                    if ((0xB5 ^ 0xB1) > ((0x8E ^ 0x90) & ~(0xDA ^ 0xC4))) break;
                    return;
                }
                case 17: {
                    n10 = byArray[n + 1] & 0xFF;
                    if (ClassReader.llIllIlIllI(n10, 132)) {
                        n += 6;
                        "".length();
                        if ("   ".length() > 0) break;
                        return;
                    }
                    n += 4;
                    "".length();
                    if ((0x3D ^ 0x39) > 0) break;
                    return;
                }
                case 14: {
                    n = n + 4 - (n4 & 3);
                    this.readLabel(n4 + this.readInt(n), labelArray);
                    "".length();
                    int n11 = this.readInt(n + 8) - this.readInt(n + 4) + 1;
                    while (ClassReader.llIllIlIIlI(n11)) {
                        this.readLabel(n4 + this.readInt(n + 12), labelArray);
                        "".length();
                        n += 4;
                        --n11;
                        "".length();
                        if (" ".length() == " ".length()) continue;
                        return;
                    }
                    n += 12;
                    "".length();
                    if ("   ".length() >= 0) break;
                    return;
                }
                case 15: {
                    n = n + 4 - (n4 & 3);
                    this.readLabel(n4 + this.readInt(n), labelArray);
                    "".length();
                    int n11 = this.readInt(n + 4);
                    while (ClassReader.llIllIlIIlI(n11)) {
                        this.readLabel(n4 + this.readInt(n + 12), labelArray);
                        "".length();
                        n += 8;
                        --n11;
                        "".length();
                        if (-" ".length() <= 0) continue;
                        return;
                    }
                    n += 8;
                    "".length();
                    if (((0xC ^ 0x11) & ~(0x21 ^ 0x3C)) == 0) break;
                    return;
                }
                case 1: 
                case 3: 
                case 11: {
                    n += 2;
                    "".length();
                    if ("   ".length() > -" ".length()) break;
                    return;
                }
                case 2: 
                case 5: 
                case 6: 
                case 12: 
                case 13: {
                    n += 3;
                    "".length();
                    if (((0xA4 ^ 0xB0) & ~(0x30 ^ 0x24)) <= 0) break;
                    return;
                }
                case 7: 
                case 8: {
                    n += 5;
                    "".length();
                    if (((0x2B ^ 0x69) & ~(0x2E ^ 0x6C)) <= 0) break;
                    return;
                }
                default: {
                    n += 4;
                }
            }
            "".length();
            if ("   ".length() >= "  ".length()) continue;
            return;
        }
        n4 = this.readUnsignedShort(n);
        while (ClassReader.llIllIlIIlI(n4)) {
            Label label = this.readLabel(this.readUnsignedShort(n + 2), labelArray);
            Label label2 = this.readLabel(this.readUnsignedShort(n + 4), labelArray);
            Label label3 = this.readLabel(this.readUnsignedShort(n + 6), labelArray);
            String string = this.readUTF8(this.items[this.readUnsignedShort(n + 8)], cArray);
            methodVisitor.visitTryCatchBlock(label, label2, label3, string);
            n += 8;
            --n4;
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
        n += 2;
        int[] nArray = null;
        int[] nArray2 = null;
        int n12 = 0;
        int n13 = 0;
        int n14 = -1;
        int n15 = -1;
        int n16 = 0;
        int n17 = 0;
        boolean bl2 = true;
        if (ClassReader.llIllIlIlII(context.flags & 8)) {
            bl = true;
            "".length();
            if ((0x7C ^ 0x44 ^ (0 ^ 0x3C)) <= -" ".length()) {
                return;
            }
        } else {
            bl = false;
        }
        boolean bl3 = bl;
        int n18 = 0;
        int n19 = 0;
        int n20 = 0;
        Context context2 = null;
        Attribute attribute = null;
        int n21 = this.readUnsignedShort(n);
        while (ClassReader.llIllIlIIlI(n21)) {
            int n22;
            int n23;
            String string = this.readUTF8(n + 2, cArray);
            if (ClassReader.llIllIlIlII("LocalVariableTable".equals(string) ? 1 : 0)) {
                if (ClassReader.llIllIlIlIl(context.flags & 2)) {
                    n16 = n + 8;
                    n23 = this.readUnsignedShort(n + 8);
                    n3 = n;
                    while (ClassReader.llIllIlIIlI(n23)) {
                        n22 = this.readUnsignedShort(n3 + 10);
                        if (ClassReader.llIllIlIIll(labelArray[n22])) {
                            this.readLabel((int)n22, (Label[])labelArray).status |= 1;
                        }
                        if (ClassReader.llIllIlIIll(labelArray[n22 += this.readUnsignedShort(n3 + 12)])) {
                            this.readLabel((int)n22, (Label[])labelArray).status |= 1;
                        }
                        n3 += 10;
                        --n23;
                        "".length();
                        if (null == null) continue;
                        return;
                    }
                    "".length();
                    if ("  ".length() <= -" ".length()) {
                        return;
                    }
                }
            } else if (ClassReader.llIllIlIlII("LocalVariableTypeTable".equals(string) ? 1 : 0)) {
                n17 = n + 8;
                "".length();
                if (null != null) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("LineNumberTable".equals(string) ? 1 : 0)) {
                if (ClassReader.llIllIlIlIl(context.flags & 2)) {
                    n23 = this.readUnsignedShort(n + 8);
                    n3 = n;
                    while (ClassReader.llIllIlIIlI(n23)) {
                        n22 = this.readUnsignedShort(n3 + 10);
                        if (ClassReader.llIllIlIIll(labelArray[n22])) {
                            this.readLabel((int)n22, (Label[])labelArray).status |= 1;
                        }
                        Label label = labelArray[n22];
                        while (ClassReader.llIllIlIIlI(label.line)) {
                            if (ClassReader.llIllIlIIll(label.next)) {
                                label.next = new Label();
                            }
                            label = label.next;
                            "".length();
                            if (null == null) continue;
                            return;
                        }
                        label.line = this.readUnsignedShort(n3 + 12);
                        n3 += 4;
                        --n23;
                        "".length();
                        if (((0x5C ^ 0x3D) & ~(0xDB ^ 0xBA)) == 0) continue;
                        return;
                    }
                    "".length();
                    if (-" ".length() < -" ".length()) {
                        return;
                    }
                }
            } else if (ClassReader.llIllIlIlII("RuntimeVisibleTypeAnnotations".equals(string) ? 1 : 0)) {
                int n24;
                nArray = this.readTypeAnnotations(methodVisitor, context, n + 8, true);
                if (!ClassReader.llIllIlIlII(nArray.length) || ClassReader.llIllIlIIIl(this.readByte(nArray[0]), 67)) {
                    n24 = -1;
                    "".length();
                    if ("   ".length() < " ".length()) {
                        return;
                    }
                } else {
                    n24 = this.readUnsignedShort(nArray[0] + 1);
                }
                n14 = n24;
                "".length();
                if ("   ".length() < 0) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("RuntimeInvisibleTypeAnnotations".equals(string) ? 1 : 0)) {
                int n25;
                nArray2 = this.readTypeAnnotations(methodVisitor, context, n + 8, false);
                if (!ClassReader.llIllIlIlII(nArray2.length) || ClassReader.llIllIlIIIl(this.readByte(nArray2[0]), 67)) {
                    n25 = -1;
                    "".length();
                    if ("  ".length() == (0x34 ^ 0x30)) {
                        return;
                    }
                } else {
                    n25 = this.readUnsignedShort(nArray2[0] + 1);
                }
                n15 = n25;
                "".length();
                if ((0x46 ^ 0x42) <= 0) {
                    return;
                }
            } else if (ClassReader.llIllIlIlII("StackMapTable".equals(string) ? 1 : 0)) {
                if (ClassReader.llIllIlIlIl(context.flags & 4)) {
                    n18 = n + 10;
                    n19 = this.readInt(n + 4);
                    n20 = this.readUnsignedShort(n + 8);
                    "".length();
                    if ("  ".length() != "  ".length()) {
                        return;
                    }
                }
            } else if (ClassReader.llIllIlIlII("StackMap".equals(string) ? 1 : 0)) {
                if (ClassReader.llIllIlIlIl(context.flags & 4)) {
                    bl2 = false;
                    n18 = n + 10;
                    n19 = this.readInt(n + 4);
                    n20 = this.readUnsignedShort(n + 8);
                    "".length();
                    if ((0x92 ^ 0x96) < "  ".length()) {
                        return;
                    }
                }
            } else {
                n23 = 0;
                while (ClassReader.llIllIlIIIl(n23, context.attrs.length)) {
                    Attribute attribute2;
                    if (ClassReader.llIllIlIlII(context.attrs[n23].type.equals(string) ? 1 : 0) && ClassReader.llIllIllIIl(attribute2 = context.attrs[n23].read(this, n + 8, this.readInt(n + 4), cArray, n8 - 8, labelArray))) {
                        attribute2.next = attribute;
                        attribute = attribute2;
                    }
                    ++n23;
                    "".length();
                    if (null == null) continue;
                    return;
                }
            }
            n += 6 + this.readInt(n + 4);
            --n21;
            "".length();
            if (null == null) continue;
            return;
        }
        n += 2;
        if (ClassReader.llIllIlIlII(n18)) {
            context2 = context;
            context2.offset = -1;
            context2.mode = 0;
            context2.localCount = 0;
            context2.localDiff = 0;
            context2.stackCount = 0;
            context2.local = new Object[n6];
            context2.stack = new Object[n5];
            if (ClassReader.llIllIlIlII(bl3 ? 1 : 0)) {
                this.getImplicitFrame(context);
            }
            n21 = n18;
            while (ClassReader.llIllIlIIIl(n21, n18 + n19 - 2)) {
                int n26;
                if (ClassReader.llIllIlIllI(byArray[n21], 8) && ClassReader.llIlllIIIll(n26 = this.readUnsignedShort(n21 + 1)) && ClassReader.llIllIlIIIl(n26, n7) && ClassReader.llIllIlIllI(byArray[n8 + n26] & 0xFF, 187)) {
                    this.readLabel(n26, labelArray);
                    "".length();
                }
                ++n21;
                "".length();
                if (null == null) continue;
                return;
            }
        }
        if (ClassReader.llIllIlIlII(context.flags & 0x100)) {
            methodVisitor.visitFrame(-1, n6, null, 0, null);
        }
        if (ClassReader.llIllIlIlIl(context.flags & 0x100)) {
            n2 = -33;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            n2 = 0;
        }
        n21 = n2;
        n = n8;
        while (ClassReader.llIllIlIIIl(n, n9)) {
            int n27 = n - n8;
            Label label = labelArray[n27];
            if (ClassReader.llIllIllIIl(label)) {
                Label label4 = label.next;
                label.next = null;
                methodVisitor.visitLabel(label);
                if (ClassReader.llIllIlIlIl(context.flags & 2) && ClassReader.llIllIlIIlI(label.line)) {
                    methodVisitor.visitLineNumber(label.line, label);
                    while (ClassReader.llIllIllIIl(label4)) {
                        methodVisitor.visitLineNumber(label4.line, label);
                        label4 = label4.next;
                        "".length();
                        if ("  ".length() != 0) continue;
                        return;
                    }
                }
            }
            while (ClassReader.llIllIllIIl(context2) && (!ClassReader.llIlllIIlII(context2.offset, n27) || ClassReader.llIllIlIllI(context2.offset, -1))) {
                if (ClassReader.llIlllIIlII(context2.offset, -1)) {
                    if (!ClassReader.llIllIlIlII(bl2 ? 1 : 0) || ClassReader.llIllIlIlII(bl3 ? 1 : 0)) {
                        methodVisitor.visitFrame(-1, context2.localCount, context2.local, context2.stackCount, context2.stack);
                        "".length();
                        if (" ".length() != " ".length()) {
                            return;
                        }
                    } else {
                        methodVisitor.visitFrame(context2.mode, context2.localDiff, context2.local, context2.stackCount, context2.stack);
                    }
                }
                if (ClassReader.llIllIlIIlI(n20)) {
                    n18 = this.readFrame(n18, bl2, bl3, context2);
                    --n20;
                    "".length();
                    if ((160 + 126 - 104 + 10 ^ 161 + 121 - 92 + 6) != ((8 + 130 - 120 + 122 ^ 32 + 17 - 32 + 113) & (51 + 117 - 44 + 4 ^ 46 + 31 - -54 + 11 ^ -" ".length()))) continue;
                    return;
                }
                context2 = null;
                "".length();
                if (((0x60 ^ 0x4A) & ~(0x9F ^ 0xB5)) < " ".length()) continue;
                return;
            }
            int n28 = byArray[n] & 0xFF;
            switch (ClassWriter.TYPE[n28]) {
                case 0: {
                    methodVisitor.visitInsn(n28);
                    ++n;
                    "".length();
                    if ((0x7D ^ 0x79) > "  ".length()) break;
                    return;
                }
                case 4: {
                    if (ClassReader.llIllIlIIII(n28, 54)) {
                        methodVisitor.visitVarInsn(54 + ((n28 -= 59) >> 2), n28 & 3);
                        "".length();
                        if ("   ".length() <= "  ".length()) {
                            return;
                        }
                    } else {
                        methodVisitor.visitVarInsn(21 + ((n28 -= 26) >> 2), n28 & 3);
                    }
                    ++n;
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 9: {
                    methodVisitor.visitJumpInsn(n28, labelArray[n27 + this.readShort(n + 1)]);
                    n += 3;
                    "".length();
                    if (((0x30 ^ 0x74 ^ (6 ^ 0xB)) & (0x8C ^ 0x9C ^ (0x68 ^ 0x31) ^ -" ".length())) >= ((76 + 159 - 226 + 188 ^ 131 + 38 - 53 + 48) & (0x6B ^ 0x6F ^ (9 ^ 0x6C) ^ -" ".length()))) break;
                    return;
                }
                case 10: {
                    methodVisitor.visitJumpInsn(n28 + n21, labelArray[n27 + this.readInt(n + 1)]);
                    n += 5;
                    "".length();
                    if ((88 + 59 - 75 + 120 ^ 51 + 66 - -61 + 18) == (0x13 ^ 0x20 ^ (3 ^ 0x34))) break;
                    return;
                }
                case 18: {
                    int n29;
                    if (ClassReader.llIllIlIIIl(n28, 218)) {
                        n29 = n28 - 49;
                        "".length();
                        if (((7 ^ 0x47) & ~(0x2A ^ 0x6A)) != 0) {
                            return;
                        }
                    } else {
                        n29 = n28 - 20;
                    }
                    n28 = n29;
                    Label label5 = labelArray[n27 + this.readUnsignedShort(n + 1)];
                    if (!ClassReader.llIlllIIlII(n28, 167) || ClassReader.llIllIlIllI(n28, 168)) {
                        methodVisitor.visitJumpInsn(n28 + 33, label5);
                        "".length();
                        if ("  ".length() <= -" ".length()) {
                            return;
                        }
                    } else {
                        int n30;
                        if (ClassReader.llIlllIlIIl(n28, 166)) {
                            n30 = (n28 + 1 ^ 1) - 1;
                            "".length();
                            if ("  ".length() != "  ".length()) {
                                return;
                            }
                        } else {
                            n30 = n28 ^ 1;
                        }
                        n28 = n30;
                        Label label6 = new Label();
                        methodVisitor.visitJumpInsn(n28, label6);
                        methodVisitor.visitJumpInsn(200, label5);
                        methodVisitor.visitLabel(label6);
                        if (ClassReader.llIllIlIlII(n18) && (!ClassReader.llIllIllIIl(context2) || ClassReader.llIlllIIlII(context2.offset, n27 + 3))) {
                            methodVisitor.visitFrame(256, 0, null, 0, null);
                        }
                    }
                    n += 3;
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 17: {
                    n28 = byArray[n + 1] & 0xFF;
                    if (ClassReader.llIllIlIllI(n28, 132)) {
                        methodVisitor.visitIincInsn(this.readUnsignedShort(n + 2), this.readShort(n + 4));
                        n += 6;
                        "".length();
                        if (null == null) break;
                        return;
                    }
                    methodVisitor.visitVarInsn(n28, this.readUnsignedShort(n + 2));
                    n += 4;
                    "".length();
                    if (" ".length() > 0) break;
                    return;
                }
                case 14: {
                    n = n + 4 - (n27 & 3);
                    int n31 = n27 + this.readInt(n);
                    int n32 = this.readInt(n + 4);
                    int n33 = this.readInt(n + 8);
                    Label[] labelArray2 = new Label[n33 - n32 + 1];
                    n += 12;
                    int n34 = 0;
                    while (ClassReader.llIllIlIIIl(n34, labelArray2.length)) {
                        labelArray2[n34] = labelArray[n27 + this.readInt(n)];
                        n += 4;
                        ++n34;
                        "".length();
                        if ((15 + 115 - 34 + 103 ^ 120 + 62 - 181 + 194) > 0) continue;
                        return;
                    }
                    methodVisitor.visitTableSwitchInsn(n32, n33, labelArray[n31], labelArray2);
                    "".length();
                    if (" ".length() < "  ".length()) break;
                    return;
                }
                case 15: {
                    n = n + 4 - (n27 & 3);
                    int n35 = n27 + this.readInt(n);
                    int n36 = this.readInt(n + 4);
                    int[] nArray3 = new int[n36];
                    Label[] labelArray3 = new Label[n36];
                    n += 8;
                    int n37 = 0;
                    while (ClassReader.llIllIlIIIl(n37, n36)) {
                        nArray3[n37] = this.readInt(n);
                        labelArray3[n37] = labelArray[n27 + this.readInt(n + 4)];
                        n += 8;
                        ++n37;
                        "".length();
                        if (((0x20 ^ 0x57 ^ 3 + 31 - 14 + 107) & (0x44 ^ 0x1B ^ (0xFF ^ 0xA8) ^ -" ".length())) == 0) continue;
                        return;
                    }
                    methodVisitor.visitLookupSwitchInsn(labelArray[n35], nArray3, labelArray3);
                    "".length();
                    if (((0xD4 ^ 0xB2 ^ (0x20 ^ 0x72)) & (2 + 3 - -85 + 96 ^ 96 + 24 - 36 + 58 ^ -" ".length())) != "  ".length()) break;
                    return;
                }
                case 3: {
                    methodVisitor.visitVarInsn(n28, byArray[n + 1] & 0xFF);
                    n += 2;
                    "".length();
                    if (-(0x5E ^ 0x5A) < 0) break;
                    return;
                }
                case 1: {
                    methodVisitor.visitIntInsn(n28, byArray[n + 1]);
                    n += 2;
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 2: {
                    methodVisitor.visitIntInsn(n28, this.readShort(n + 1));
                    n += 3;
                    "".length();
                    if (null == null) break;
                    return;
                }
                case 11: {
                    methodVisitor.visitLdcInsn(this.readConst(byArray[n + 1] & 0xFF, cArray));
                    n += 2;
                    "".length();
                    if (((0x1A ^ 1) & ~(0x40 ^ 0x5B)) < " ".length()) break;
                    return;
                }
                case 12: {
                    methodVisitor.visitLdcInsn(this.readConst(this.readUnsignedShort(n + 1), cArray));
                    n += 3;
                    "".length();
                    if ("   ".length() != 0) break;
                    return;
                }
                case 6: 
                case 7: {
                    boolean bl4;
                    int n38 = this.items[this.readUnsignedShort(n + 1)];
                    if (ClassReader.llIllIlIllI(byArray[n38 - 1], 11)) {
                        bl4 = true;
                        "".length();
                        if ((0x90 ^ 0x94) == 0) {
                            return;
                        }
                    } else {
                        bl4 = false;
                    }
                    boolean bl5 = bl4;
                    String string = this.readClass(n38, cArray);
                    n38 = this.items[this.readUnsignedShort(n38 + 2)];
                    String string2 = this.readUTF8(n38, cArray);
                    String string3 = this.readUTF8(n38 + 2, cArray);
                    if (ClassReader.llIllIlIIIl(n28, 182)) {
                        methodVisitor.visitFieldInsn(n28, string, string2, string3);
                        "".length();
                        if (null != null) {
                            return;
                        }
                    } else {
                        methodVisitor.visitMethodInsn(n28, string, string2, string3, bl5);
                    }
                    if (ClassReader.llIllIlIllI(n28, 185)) {
                        n += 5;
                        "".length();
                        if (((0x51 ^ 0xC) & ~(0xE7 ^ 0xBA)) == 0) break;
                        return;
                    }
                    n += 3;
                    "".length();
                    if ("   ".length() != -" ".length()) break;
                    return;
                }
                case 8: {
                    int n39 = this.items[this.readUnsignedShort(n + 1)];
                    int n40 = context.bootstrapMethods[this.readUnsignedShort(n39)];
                    Handle handle = (Handle)this.readConst(this.readUnsignedShort(n40), cArray);
                    int n41 = this.readUnsignedShort(n40 + 2);
                    Object[] objectArray = new Object[n41];
                    n40 += 4;
                    int n42 = 0;
                    while (ClassReader.llIllIlIIIl(n42, n41)) {
                        objectArray[n42] = this.readConst(this.readUnsignedShort(n40), cArray);
                        n40 += 2;
                        ++n42;
                        "".length();
                        if ("  ".length() != 0) continue;
                        return;
                    }
                    n39 = this.items[this.readUnsignedShort(n39 + 2)];
                    String string = this.readUTF8(n39, cArray);
                    String string4 = this.readUTF8(n39 + 2, cArray);
                    methodVisitor.visitInvokeDynamicInsn(string, string4, handle, objectArray);
                    n += 5;
                    "".length();
                    if ((0x71 ^ 0x3D ^ (0xFD ^ 0xB5)) >= "  ".length()) break;
                    return;
                }
                case 5: {
                    methodVisitor.visitTypeInsn(n28, this.readClass(n + 1, cArray));
                    n += 3;
                    "".length();
                    if (" ".length() == " ".length()) break;
                    return;
                }
                case 13: {
                    methodVisitor.visitIincInsn(byArray[n + 1] & 0xFF, byArray[n + 2]);
                    n += 3;
                    "".length();
                    if ("   ".length() > 0) break;
                    return;
                }
                default: {
                    methodVisitor.visitMultiANewArrayInsn(this.readClass(n + 1, cArray), byArray[n + 3] & 0xFF);
                    n += 4;
                }
            }
            while (ClassReader.llIllIllIIl(nArray) && ClassReader.llIllIlIIIl(n12, nArray.length) && ClassReader.llIlllIlIIl(n14, n27)) {
                int n43;
                if (ClassReader.llIllIlIllI(n14, n27)) {
                    int n44 = this.readAnnotationTarget(context, nArray[n12]);
                    this.readAnnotationValues(n44 + 2, cArray, true, methodVisitor.visitInsnAnnotation(context.typeRef, context.typePath, this.readUTF8(n44, cArray), true));
                    "".length();
                }
                if (!ClassReader.llIllIlIIIl(++n12, nArray.length) || ClassReader.llIllIlIIIl(this.readByte(nArray[n12]), 67)) {
                    n43 = -1;
                    "".length();
                    if (((0xCE ^ 0xC3) & ~(0x75 ^ 0x78)) != 0) {
                        return;
                    }
                } else {
                    n43 = this.readUnsignedShort(nArray[n12] + 1);
                }
                n14 = n43;
                "".length();
                if (null == null) continue;
                return;
            }
            while (ClassReader.llIllIllIIl(nArray2) && ClassReader.llIllIlIIIl(n13, nArray2.length) && ClassReader.llIlllIlIIl(n15, n27)) {
                int n45;
                if (ClassReader.llIllIlIllI(n15, n27)) {
                    int n46 = this.readAnnotationTarget(context, nArray2[n13]);
                    this.readAnnotationValues(n46 + 2, cArray, true, methodVisitor.visitInsnAnnotation(context.typeRef, context.typePath, this.readUTF8(n46, cArray), false));
                    "".length();
                }
                if (!ClassReader.llIllIlIIIl(++n13, nArray2.length) || ClassReader.llIllIlIIIl(this.readByte(nArray2[n13]), 67)) {
                    n45 = -1;
                    "".length();
                    if (null != null) {
                        return;
                    }
                } else {
                    n45 = this.readUnsignedShort(nArray2[n13] + 1);
                }
                n15 = n45;
                "".length();
                if ("   ".length() <= "   ".length()) continue;
                return;
            }
            "".length();
            if ("   ".length() >= 0) continue;
            return;
        }
        if (ClassReader.llIllIllIIl(labelArray[n7])) {
            methodVisitor.visitLabel(labelArray[n7]);
        }
        if (ClassReader.llIllIlIlIl(context.flags & 2) && ClassReader.llIllIlIlII(n16)) {
            int[] nArray4 = null;
            if (ClassReader.llIllIlIlII(n17)) {
                n = n17 + 2;
                nArray4 = new int[this.readUnsignedShort(n17) * 3];
                int n47 = nArray4.length;
                while (ClassReader.llIllIlIIlI(n47)) {
                    nArray4[--n47] = n + 6;
                    nArray4[--n47] = this.readUnsignedShort(n + 8);
                    nArray4[--n47] = this.readUnsignedShort(n);
                    n += 10;
                    "".length();
                    if ((0xDD ^ 0x82 ^ (0x2A ^ 0x70)) != 0) continue;
                    return;
                }
            }
            n = n16 + 2;
            int n48 = this.readUnsignedShort(n16);
            while (ClassReader.llIllIlIIlI(n48)) {
                n3 = this.readUnsignedShort(n);
                int n49 = this.readUnsignedShort(n + 2);
                int n50 = this.readUnsignedShort(n + 8);
                String string = null;
                if (ClassReader.llIllIllIIl(nArray4)) {
                    int n51 = 0;
                    while (ClassReader.llIllIlIIIl(n51, nArray4.length)) {
                        if (ClassReader.llIllIlIllI(nArray4[n51], n3) && ClassReader.llIllIlIllI(nArray4[n51 + 1], n50)) {
                            string = this.readUTF8(nArray4[n51 + 2], cArray);
                            "".length();
                            if (((0x7F ^ 0x6B) & ~(0x55 ^ 0x41)) <= " ".length()) break;
                            return;
                        }
                        n51 += 3;
                        "".length();
                        if ("   ".length() != 0) continue;
                        return;
                    }
                }
                methodVisitor.visitLocalVariable(this.readUTF8(n + 4, cArray), this.readUTF8(n + 6, cArray), string, labelArray[n3], labelArray[n3 + n49], n50);
                n += 10;
                --n48;
                "".length();
                if (null == null) continue;
                return;
            }
        }
        if (ClassReader.llIllIllIIl(nArray)) {
            int n52 = 0;
            while (ClassReader.llIllIlIIIl(n52, nArray.length)) {
                if (ClassReader.llIllIlIllI(this.readByte(nArray[n52]) >> 1, 32)) {
                    int n53 = this.readAnnotationTarget(context, nArray[n52]);
                    n53 = this.readAnnotationValues(n53 + 2, cArray, true, methodVisitor.visitLocalVariableAnnotation(context.typeRef, context.typePath, context.start, context.end, context.index, this.readUTF8(n53, cArray), true));
                }
                ++n52;
                "".length();
                if (((0x36 ^ 0x20) & ~(0x48 ^ 0x5E)) >= 0) continue;
                return;
            }
        }
        if (ClassReader.llIllIllIIl(nArray2)) {
            int n54 = 0;
            while (ClassReader.llIllIlIIIl(n54, nArray2.length)) {
                if (ClassReader.llIllIlIllI(this.readByte(nArray2[n54]) >> 1, 32)) {
                    int n55 = this.readAnnotationTarget(context, nArray2[n54]);
                    n55 = this.readAnnotationValues(n55 + 2, cArray, true, methodVisitor.visitLocalVariableAnnotation(context.typeRef, context.typePath, context.start, context.end, context.index, this.readUTF8(n55, cArray), false));
                }
                ++n54;
                "".length();
                if (((0x9D ^ 0x86) & ~(0x23 ^ 0x38)) == 0) continue;
                return;
            }
        }
        while (ClassReader.llIllIllIIl(attribute)) {
            Attribute attribute3 = attribute.next;
            attribute.next = null;
            methodVisitor.visitAttribute(attribute);
            attribute = attribute3;
            "".length();
            if (null == null) continue;
            return;
        }
        methodVisitor.visitMaxs(n5, n6);
    }

    private int[] readTypeAnnotations(MethodVisitor methodVisitor, Context context, int n, boolean bl) {
        char[] cArray = context.buffer;
        int[] nArray = new int[this.readUnsignedShort(n)];
        n += 2;
        int n2 = 0;
        while (ClassReader.llIllIlIIIl(n2, nArray.length)) {
            int n3;
            nArray[n2] = n;
            int n4 = this.readInt(n);
            switch (n4 >>> 24) {
                case 0: 
                case 1: 
                case 22: {
                    n += 2;
                    "".length();
                    if ("   ".length() != 0) break;
                    return null;
                }
                case 19: 
                case 20: 
                case 21: {
                    ++n;
                    "".length();
                    if ("   ".length() != "  ".length()) break;
                    return null;
                }
                case 64: 
                case 65: {
                    n3 = this.readUnsignedShort(n + 1);
                    while (ClassReader.llIllIlIIlI(n3)) {
                        int n5 = this.readUnsignedShort(n + 3);
                        int n6 = this.readUnsignedShort(n + 5);
                        this.readLabel(n5, context.labels);
                        "".length();
                        this.readLabel(n5 + n6, context.labels);
                        "".length();
                        n += 6;
                        --n3;
                        "".length();
                        if (((0x2E ^ 0x6A) & ~(0xD2 ^ 0x96)) >= 0) continue;
                        return null;
                    }
                    n += 3;
                    "".length();
                    if (null == null) break;
                    return null;
                }
                case 71: 
                case 72: 
                case 73: 
                case 74: 
                case 75: {
                    n += 4;
                    "".length();
                    if ("  ".length() >= " ".length()) break;
                    return null;
                }
                default: {
                    n += 3;
                }
            }
            n3 = this.readByte(n);
            if (ClassReader.llIllIlIllI(n4 >>> 24, 66)) {
                TypePath typePath;
                if (ClassReader.llIllIlIlIl(n3)) {
                    typePath = null;
                    "".length();
                    if (" ".length() == 0) {
                        return null;
                    }
                } else {
                    typePath = new TypePath(this.b, n);
                }
                TypePath typePath2 = typePath;
                n += 1 + 2 * n3;
                n = this.readAnnotationValues(n + 2, cArray, true, methodVisitor.visitTryCatchAnnotation(n4, typePath2, this.readUTF8(n, cArray), bl));
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                n = this.readAnnotationValues(n + 3 + 2 * n3, cArray, true, null);
            }
            ++n2;
            "".length();
            if (((0xA4 ^ 0xC3 ^ (0x3E ^ 0x62)) & (0x89 ^ 0x8F ^ (0xA9 ^ 0x94) ^ -" ".length())) >= 0) continue;
            return null;
        }
        return nArray;
    }

    private int readAnnotationTarget(Context context, int n) {
        TypePath typePath;
        int n2;
        int n3 = this.readInt(n);
        switch (n3 >>> 24) {
            case 0: 
            case 1: 
            case 22: {
                n3 &= 0xFFFF0000;
                n += 2;
                "".length();
                if ((0xE6 ^ 0xB4 ^ (0xC4 ^ 0x92)) > 0) break;
                return (87 + 171 - 172 + 94 ^ 34 + 125 - 71 + 61) & (0xD8 ^ 0xA5 ^ (0xF ^ 0x53) ^ -" ".length());
            }
            case 19: 
            case 20: 
            case 21: {
                n3 &= 0xFF000000;
                ++n;
                "".length();
                if ("   ".length() < (0x2B ^ 0x2D ^ "  ".length())) break;
                return (0x74 ^ 0x68 ^ (0xE0 ^ 0xAB)) & (0x61 ^ 0x5E ^ (0x51 ^ 0x39) ^ -" ".length());
            }
            case 64: 
            case 65: {
                n3 &= 0xFF000000;
                n2 = this.readUnsignedShort(n + 1);
                context.start = new Label[n2];
                context.end = new Label[n2];
                context.index = new int[n2];
                n += 3;
                int n4 = 0;
                while (ClassReader.llIllIlIIIl(n4, n2)) {
                    int n5 = this.readUnsignedShort(n);
                    int n6 = this.readUnsignedShort(n + 2);
                    context.start[n4] = this.readLabel(n5, context.labels);
                    context.end[n4] = this.readLabel(n5 + n6, context.labels);
                    context.index[n4] = this.readUnsignedShort(n + 4);
                    n += 6;
                    ++n4;
                    "".length();
                    if (((22 + 80 - 79 + 142 ^ 5 + 98 - 56 + 81) & (0xED ^ 0x8C ^ (0x57 ^ 0x13) ^ -" ".length())) < " ".length()) continue;
                    return (92 + 201 - 280 + 210 ^ 79 + 116 - 133 + 70) & (0xC5 ^ 0x9E ^ (0x85 ^ 0x99) & ~(0x8C ^ 0x90) ^ -" ".length());
                }
                "".length();
                if ("   ".length() > "  ".length()) break;
                return (0x51 ^ 0xA) & ~(0x69 ^ 0x32);
            }
            case 71: 
            case 72: 
            case 73: 
            case 74: 
            case 75: {
                n3 &= 0xFF0000FF;
                n += 4;
                "".length();
                if ((0xB1 ^ 0xB5) >= -" ".length()) break;
                return (0x53 ^ 0x71) & ~(0x8B ^ 0xA9);
            }
            default: {
                int n7;
                if (ClassReader.llIllIlIIIl(n3 >>> 24, 67)) {
                    n7 = -256;
                    "".length();
                    if ("   ".length() <= -" ".length()) {
                        return (0xB ^ 0x7F ^ (0x58 ^ 0x3C)) & (0x1B ^ 0x5C ^ (0x93 ^ 0xC4) ^ -" ".length());
                    }
                } else {
                    n7 = -16777216;
                }
                n3 &= n7;
                n += 3;
            }
        }
        n2 = this.readByte(n);
        context.typeRef = n3;
        if (ClassReader.llIllIlIlIl(n2)) {
            typePath = null;
            "".length();
            if (" ".length() > "   ".length()) {
                return (0x54 ^ 0x74) & ~(0x63 ^ 0x43);
            }
        } else {
            typePath = new TypePath(this.b, n);
        }
        context.typePath = typePath;
        return n + 1 + 2 * n2;
    }

    private void readParameterAnnotations(MethodVisitor methodVisitor, Context context, int n, boolean bl) {
        AnnotationVisitor annotationVisitor;
        int n2 = this.b[n++] & 0xFF;
        int n3 = Type.getArgumentTypes(context.desc).length - n2;
        int n4 = 0;
        while (ClassReader.llIllIlIIIl(n4, n3)) {
            annotationVisitor = methodVisitor.visitParameterAnnotation(n4, "Ljava/lang/Synthetic;", false);
            if (ClassReader.llIllIllIIl(annotationVisitor)) {
                annotationVisitor.visitEnd();
            }
            ++n4;
            "".length();
            if (-(0x18 ^ 0x1D) < 0) continue;
            return;
        }
        char[] cArray = context.buffer;
        while (ClassReader.llIllIlIIIl(n4, n2 + n3)) {
            int n5 = this.readUnsignedShort(n);
            n += 2;
            while (ClassReader.llIllIlIIlI(n5)) {
                annotationVisitor = methodVisitor.visitParameterAnnotation(n4, this.readUTF8(n, cArray), bl);
                n = this.readAnnotationValues(n + 2, cArray, true, annotationVisitor);
                --n5;
                "".length();
                if (null == null) continue;
                return;
            }
            ++n4;
            "".length();
            if ("   ".length() != ((0x7A ^ 0x4E) & ~(0xAC ^ 0x98))) continue;
            return;
        }
    }

    private int readAnnotationValues(int n, char[] cArray, boolean bl, AnnotationVisitor annotationVisitor) {
        int n2 = this.readUnsignedShort(n);
        n += 2;
        if (ClassReader.llIllIlIlII(bl ? 1 : 0)) {
            while (ClassReader.llIllIlIIlI(n2)) {
                n = this.readAnnotationValue(n + 2, cArray, this.readUTF8(n, cArray), annotationVisitor);
                --n2;
                "".length();
                if ("  ".length() < "   ".length()) continue;
                return (0x75 ^ 0x22 ^ (0xC ^ 0x4C)) & (0x37 ^ 0xB ^ (0x6F ^ 0x44) ^ -" ".length());
            }
        } else {
            while (ClassReader.llIllIlIIlI(n2)) {
                n = this.readAnnotationValue(n, cArray, null, annotationVisitor);
                --n2;
                "".length();
                if ("  ".length() > " ".length()) continue;
                return (0x78 ^ 0x6E ^ (0x73 ^ 0x32)) & (0x9B ^ 0x9C ^ (0x56 ^ 6) ^ -" ".length());
            }
        }
        if (ClassReader.llIllIllIIl(annotationVisitor)) {
            annotationVisitor.visitEnd();
        }
        return n;
    }

    private int readAnnotationValue(int n, char[] cArray, String string, AnnotationVisitor annotationVisitor) {
        if (ClassReader.llIllIlIIll(annotationVisitor)) {
            switch (this.b[n] & 0xFF) {
                case 101: {
                    return n + 5;
                }
                case 64: {
                    return this.readAnnotationValues(n + 3, cArray, true, null);
                }
                case 91: {
                    return this.readAnnotationValues(n + 1, cArray, false, null);
                }
            }
            return n + 3;
        }
        block5 : switch (this.b[n++] & 0xFF) {
            case 68: 
            case 70: 
            case 73: 
            case 74: {
                annotationVisitor.visit(string, this.readConst(this.readUnsignedShort(n), cArray));
                n += 2;
                "".length();
                if ("   ".length() >= -" ".length()) break;
                return (0x6A ^ 0x28) & ~(0xC1 ^ 0x83);
            }
            case 66: {
                annotationVisitor.visit(string, (byte)this.readInt(this.items[this.readUnsignedShort(n)]));
                n += 2;
                "".length();
                if (((" ".length() ^ (0xA8 ^ 0x95)) & (0x6B ^ 0x45 ^ (0xB5 ^ 0xA7) ^ -" ".length())) == 0) break;
                return ("   ".length() ^ (4 ^ 0x45)) & (0x4A ^ 0x7A ^ (0x6F ^ 0x1D) ^ -" ".length());
            }
            case 90: {
                Boolean bl;
                if (ClassReader.llIllIlIlIl(this.readInt(this.items[this.readUnsignedShort(n)]))) {
                    bl = Boolean.FALSE;
                    "".length();
                    if (" ".length() <= -" ".length()) {
                        return (0x18 ^ 0x40) & ~(0x5F ^ 7);
                    }
                } else {
                    bl = Boolean.TRUE;
                }
                annotationVisitor.visit(string, bl);
                n += 2;
                "".length();
                if ("  ".length() < (0x4F ^ 0x5B ^ (3 ^ 0x13))) break;
                return (0x5C ^ 0x70 ^ (0x6D ^ 0x76)) & (158 + 54 - 68 + 42 ^ 0 + 93 - 0 + 48 ^ -" ".length());
            }
            case 83: {
                annotationVisitor.visit(string, (short)this.readInt(this.items[this.readUnsignedShort(n)]));
                n += 2;
                "".length();
                if (((0xE ^ 0x77 ^ (0x27 ^ 0x64)) & (0x47 ^ 0x16 ^ (0x62 ^ 9) ^ -" ".length())) == 0) break;
                return (68 + 147 - 59 + 24 ^ 138 + 75 - 112 + 61) & (0xCC ^ 0xA0 ^ (0xA ^ 0x70) ^ -" ".length());
            }
            case 67: {
                annotationVisitor.visit(string, Character.valueOf((char)this.readInt(this.items[this.readUnsignedShort(n)])));
                n += 2;
                "".length();
                if (-"  ".length() <= 0) break;
                return (0x5E ^ 0x46) & ~(0xB9 ^ 0xA1);
            }
            case 115: {
                annotationVisitor.visit(string, this.readUTF8(n, cArray));
                n += 2;
                "".length();
                if ("   ".length() > -" ".length()) break;
                return " ".length() & (" ".length() ^ -" ".length());
            }
            case 101: {
                annotationVisitor.visitEnum(string, this.readUTF8(n, cArray), this.readUTF8(n + 2, cArray));
                n += 4;
                "".length();
                if (null == null) break;
                return (0x3D ^ 0x6E ^ (0x77 ^ 0x60)) & (189 + 70 - 175 + 108 ^ 125 + 90 - 193 + 110 ^ -" ".length());
            }
            case 99: {
                annotationVisitor.visit(string, Type.getType(this.readUTF8(n, cArray)));
                n += 2;
                "".length();
                if ("  ".length() >= 0) break;
                return (0x6E ^ 0x4C) & ~(0xE6 ^ 0xC4);
            }
            case 64: {
                n = this.readAnnotationValues(n + 2, cArray, true, annotationVisitor.visitAnnotation(string, this.readUTF8(n, cArray)));
                "".length();
                if (-" ".length() <= " ".length()) break;
                return (8 ^ 0x46) & ~(0xC ^ 0x42);
            }
            case 91: {
                int n2 = this.readUnsignedShort(n);
                n += 2;
                if (ClassReader.llIllIlIlIl(n2)) {
                    return this.readAnnotationValues(n - 2, cArray, false, annotationVisitor.visitArray(string));
                }
                switch (this.b[n++] & 0xFF) {
                    case 66: {
                        byte[] byArray = new byte[n2];
                        int n3 = 0;
                        while (ClassReader.llIllIlIIIl(n3, n2)) {
                            byArray[n3] = (byte)this.readInt(this.items[this.readUnsignedShort(n)]);
                            n += 3;
                            ++n3;
                            "".length();
                            if ("  ".length() > 0) continue;
                            return (0x65 ^ 0x55 ^ "   ".length()) & (12 + 145 - 83 + 86 ^ 51 + 26 - -43 + 27 ^ -" ".length());
                        }
                        annotationVisitor.visit(string, byArray);
                        --n;
                        "".length();
                        if ((0x6F ^ 0x59 ^ (0x13 ^ 0x21)) >= "  ".length()) break block5;
                        return (0x91 ^ 0xAD ^ (0x12 ^ 0x32)) & (125 + 4 - 51 + 84 ^ 76 + 80 - -12 + 22 ^ -" ".length());
                    }
                    case 90: {
                        boolean[] blArray = new boolean[n2];
                        int n4 = 0;
                        while (ClassReader.llIllIlIIIl(n4, n2)) {
                            boolean bl;
                            if (ClassReader.llIllIlIlII(this.readInt(this.items[this.readUnsignedShort(n)]))) {
                                bl = true;
                                "".length();
                                if (null != null) {
                                    return (0x45 ^ 0x56) & ~(0xB6 ^ 0xA5);
                                }
                            } else {
                                bl = false;
                            }
                            blArray[n4] = bl;
                            n += 3;
                            ++n4;
                            "".length();
                            if (((0x2D ^ 0x7C ^ (0x2B ^ 0x65)) & (8 + 127 - 22 + 67 ^ 94 + 76 - 169 + 170 ^ -" ".length())) == 0) continue;
                            return (0x66 ^ 0x20 ^ (0x51 ^ 0x43)) & (102 + 81 - -21 + 12 ^ 73 + 89 - 34 + 12 ^ -" ".length());
                        }
                        annotationVisitor.visit(string, blArray);
                        --n;
                        "".length();
                        if ("   ".length() < (0x14 ^ 0x10)) break block5;
                        return (0x2C ^ 8) & ~(0x93 ^ 0xB7);
                    }
                    case 83: {
                        short[] sArray = new short[n2];
                        int n5 = 0;
                        while (ClassReader.llIllIlIIIl(n5, n2)) {
                            sArray[n5] = (short)this.readInt(this.items[this.readUnsignedShort(n)]);
                            n += 3;
                            ++n5;
                            "".length();
                            if (-"   ".length() <= 0) continue;
                            return (0x8F ^ 0xA5) & ~(0x52 ^ 0x78);
                        }
                        annotationVisitor.visit(string, sArray);
                        --n;
                        "".length();
                        if ((0x53 ^ 0x56) != 0) break block5;
                        return (0xA9 ^ 0x84) & ~(0x87 ^ 0xAA);
                    }
                    case 67: {
                        char[] cArray2 = new char[n2];
                        int n6 = 0;
                        while (ClassReader.llIllIlIIIl(n6, n2)) {
                            cArray2[n6] = (char)this.readInt(this.items[this.readUnsignedShort(n)]);
                            n += 3;
                            ++n6;
                            "".length();
                            if (-(0x5D ^ 0x11 ^ (0x7F ^ 0x36)) < 0) continue;
                            return (73 + 163 - 85 + 14 ^ 18 + 114 - 84 + 140) & ("  ".length() ^ (0x56 ^ 0x4D) ^ -" ".length());
                        }
                        annotationVisitor.visit(string, cArray2);
                        --n;
                        "".length();
                        if (-" ".length() < (0xE4 ^ 0xA9 ^ (0x56 ^ 0x1F))) break block5;
                        return (0xFB ^ 0xB5 ^ (0xC7 ^ 0x9B)) & (0x11 ^ 0x58 ^ (0xF1 ^ 0xAA) ^ -" ".length());
                    }
                    case 73: {
                        int[] nArray = new int[n2];
                        int n7 = 0;
                        while (ClassReader.llIllIlIIIl(n7, n2)) {
                            nArray[n7] = this.readInt(this.items[this.readUnsignedShort(n)]);
                            n += 3;
                            ++n7;
                            "".length();
                            if (-"   ".length() < 0) continue;
                            return (0x22 ^ 0x1A) & ~(0x2D ^ 0x15);
                        }
                        annotationVisitor.visit(string, nArray);
                        --n;
                        "".length();
                        if (" ".length() == " ".length()) break block5;
                        return (0x8F ^ 0xAA) & ~(0xB6 ^ 0x93);
                    }
                    case 74: {
                        long[] lArray = new long[n2];
                        int n8 = 0;
                        while (ClassReader.llIllIlIIIl(n8, n2)) {
                            lArray[n8] = this.readLong(this.items[this.readUnsignedShort(n)]);
                            n += 3;
                            ++n8;
                            "".length();
                            if (null == null) continue;
                            return (0x40 ^ 0x18) & ~(0x47 ^ 0x1F);
                        }
                        annotationVisitor.visit(string, lArray);
                        --n;
                        "".length();
                        if ((0x5D ^ 0x59) >= 0) break block5;
                        return (0x86 ^ 0x90) & ~(0x6D ^ 0x7B);
                    }
                    case 70: {
                        float[] fArray = new float[n2];
                        int n9 = 0;
                        while (ClassReader.llIllIlIIIl(n9, n2)) {
                            fArray[n9] = Float.intBitsToFloat(this.readInt(this.items[this.readUnsignedShort(n)]));
                            n += 3;
                            ++n9;
                            "".length();
                            if (((0x56 ^ 0x3B ^ (0x13 ^ 0x36)) & (118 + 58 - -31 + 22 ^ 12 + 106 - 0 + 55 ^ -" ".length())) == 0) continue;
                            return (0xD9 ^ 0xBD ^ (0x70 ^ 1)) & (0x88 ^ 0x9B ^ (0x98 ^ 0x9E) ^ -" ".length());
                        }
                        annotationVisitor.visit(string, fArray);
                        --n;
                        "".length();
                        if (" ".length() >= 0) break block5;
                        return (0x6D ^ 0x2F) & ~(0xA ^ 0x48);
                    }
                    case 68: {
                        double[] dArray = new double[n2];
                        int n10 = 0;
                        while (ClassReader.llIllIlIIIl(n10, n2)) {
                            dArray[n10] = Double.longBitsToDouble(this.readLong(this.items[this.readUnsignedShort(n)]));
                            n += 3;
                            ++n10;
                            "".length();
                            if ((0x18 ^ 0x48 ^ (0 ^ 0x54)) > -" ".length()) continue;
                            return (0xD ^ 0x3C ^ (0x2C ^ 0x49)) & (0x8D ^ 0x88 ^ (0xF ^ 0x5E) ^ -" ".length());
                        }
                        annotationVisitor.visit(string, dArray);
                        --n;
                        "".length();
                        if (" ".length() >= " ".length()) break block5;
                        return (87 + 46 - 28 + 40 ^ 125 + 31 - 95 + 81) & (102 + 182 - 85 + 19 ^ 139 + 163 - 196 + 91 ^ -" ".length());
                    }
                }
                n = this.readAnnotationValues(n - 3, cArray, false, annotationVisitor.visitArray(string));
            }
        }
        return n;
    }

    private void getImplicitFrame(Context context) {
        int n;
        block18: {
            String string = context.desc;
            Object[] objectArray = context.local;
            n = 0;
            if (ClassReader.llIllIlIlIl(context.access & 8)) {
                if (ClassReader.llIllIlIlII("<init>".equals(context.name) ? 1 : 0)) {
                    objectArray[n++] = Opcodes.UNINITIALIZED_THIS;
                    "".length();
                    if ((107 + 112 - 179 + 132 ^ 154 + 3 - 58 + 69) < 0) {
                        return;
                    }
                } else {
                    objectArray[n++] = this.readClass(this.header + 2, context.buffer);
                }
            }
            int n2 = 1;
            do {
                int n3 = n2;
                switch (string.charAt(n2++)) {
                    case 'B': 
                    case 'C': 
                    case 'I': 
                    case 'S': 
                    case 'Z': {
                        objectArray[n++] = Opcodes.INTEGER;
                        "".length();
                        if (((0x21 ^ 0x78) & ~(0x4C ^ 0x15)) == 0) break;
                        return;
                    }
                    case 'F': {
                        objectArray[n++] = Opcodes.FLOAT;
                        "".length();
                        if (-(0x92 ^ 0x96) < 0) break;
                        return;
                    }
                    case 'J': {
                        objectArray[n++] = Opcodes.LONG;
                        "".length();
                        if ((0x1A ^ 0x1C ^ "  ".length()) != 0) break;
                        return;
                    }
                    case 'D': {
                        objectArray[n++] = Opcodes.DOUBLE;
                        "".length();
                        if ("  ".length() == "  ".length()) break;
                        return;
                    }
                    case '[': {
                        while (ClassReader.llIllIlIllI(string.charAt(n2), 91)) {
                            ++n2;
                            "".length();
                            if (null == null) continue;
                            return;
                        }
                        if (ClassReader.llIllIlIllI(string.charAt(n2), 76)) {
                            ++n2;
                            while (ClassReader.llIlllIIlII(string.charAt(n2), 59)) {
                                ++n2;
                                "".length();
                                if (-" ".length() < "   ".length()) continue;
                                return;
                            }
                        }
                        objectArray[n++] = string.substring(n3, ++n2);
                        "".length();
                        if (-"   ".length() <= 0) break;
                        return;
                    }
                    case 'L': {
                        while (ClassReader.llIlllIIlII(string.charAt(n2), 59)) {
                            ++n2;
                            "".length();
                            if ((0x6B ^ 0x6F) > -" ".length()) continue;
                            return;
                        }
                        objectArray[n++] = string.substring(n3 + 1, n2++);
                        "".length();
                        if (" ".length() != 0) break;
                        return;
                    }
                    default: {
                        "".length();
                        if (null != null) {
                            return;
                        }
                        break block18;
                    }
                }
                "".length();
            } while (-(0xF2 ^ 0x82 ^ (0xEF ^ 0x9A)) < 0);
            return;
        }
        context.localCount = n;
    }

    private int readFrame(int n, boolean bl, boolean bl2, Context context) {
        int n2;
        int n3;
        char[] cArray = context.buffer;
        Label[] labelArray = context.labels;
        if (ClassReader.llIllIlIlII(bl ? 1 : 0)) {
            n3 = this.b[n++] & 0xFF;
            "".length();
            if ((0x74 ^ 0x4A ^ (0xAA ^ 0x90)) <= 0) {
                return (181 + 183 - 255 + 124 ^ 77 + 39 - 37 + 82) & (130 + 190 - 278 + 168 ^ 25 + 98 - 0 + 31 ^ -" ".length());
            }
        } else {
            n3 = 255;
            context.offset = -1;
        }
        context.localDiff = 0;
        if (ClassReader.llIllIlIIIl(n3, 64)) {
            n2 = n3;
            context.mode = 3;
            context.stackCount = 0;
            "".length();
            if (null != null) {
                return (0x8E ^ 0x9A) & ~(0xA3 ^ 0xB7);
            }
        } else if (ClassReader.llIllIlIIIl(n3, 128)) {
            n2 = n3 - 64;
            n = this.readFrameType(context.stack, 0, n, cArray, labelArray);
            context.mode = 4;
            context.stackCount = 1;
            "".length();
            if (((7 + 179 - 32 + 49 ^ 129 + 47 - 115 + 77) & (0xF8 ^ 0xA8 ^ (0x4F ^ 0x5E) ^ -" ".length())) != 0) {
                return (2 ^ 0x2F ^ (0x44 ^ 0x70)) & (0xC2 ^ 0x8E ^ (0xDF ^ 0x8A) ^ -" ".length());
            }
        } else {
            n2 = this.readUnsignedShort(n);
            n += 2;
            if (ClassReader.llIllIlIllI(n3, 247)) {
                n = this.readFrameType(context.stack, 0, n, cArray, labelArray);
                context.mode = 4;
                context.stackCount = 1;
                "".length();
                if (((0xA8 ^ 0x8C) & ~(0x3E ^ 0x1A)) < 0) {
                    return (0x7F ^ 0x28) & ~(0xEF ^ 0xB8);
                }
            } else if (ClassReader.llIlllIlIlI(n3, 248) && ClassReader.llIllIlIIIl(n3, 251)) {
                context.mode = 2;
                context.localDiff = 251 - n3;
                context.localCount -= context.localDiff;
                context.stackCount = 0;
                "".length();
                if ("  ".length() == -" ".length()) {
                    return (0x9E ^ 0x88 ^ (0x6E ^ 0x32)) & (0x2A ^ 0x13 ^ (0x53 ^ 0x20) ^ -" ".length());
                }
            } else if (ClassReader.llIllIlIllI(n3, 251)) {
                context.mode = 3;
                context.stackCount = 0;
                "".length();
                if (" ".length() >= "   ".length()) {
                    return (0x56 ^ 0x6D) & ~(0x68 ^ 0x53);
                }
            } else if (ClassReader.llIllIlIIIl(n3, 255)) {
                int n4;
                if (ClassReader.llIllIlIlII(bl2 ? 1 : 0)) {
                    n4 = context.localCount;
                    "".length();
                    if (((0x44 ^ 0x49) & ~(0x94 ^ 0x99)) > (0x60 ^ 0x64)) {
                        return (0x43 ^ 0x6B) & ~(0x32 ^ 0x1A);
                    }
                } else {
                    n4 = 0;
                }
                int n5 = n4;
                int n6 = n3 - 251;
                while (ClassReader.llIllIlIIlI(n6)) {
                    n = this.readFrameType(context.local, n5++, n, cArray, labelArray);
                    --n6;
                    "".length();
                    if ((0x13 ^ 0x17) > 0) continue;
                    return (0x38 ^ 0xF) & ~(0x5C ^ 0x6B);
                }
                context.mode = 1;
                context.localDiff = n3 - 251;
                context.localCount += context.localDiff;
                context.stackCount = 0;
                "".length();
                if ((0x69 ^ 0x1C ^ (0xB3 ^ 0xC3)) == 0) {
                    return (0x2E ^ 9 ^ (0x17 ^ 0x2C)) & (0x4C ^ 0x65 ^ (0x3F ^ 0xA) ^ -" ".length());
                }
            } else {
                context.mode = 0;
                int n7 = this.readUnsignedShort(n);
                n += 2;
                context.localDiff = n7;
                context.localCount = n7;
                int n8 = 0;
                while (ClassReader.llIllIlIIlI(n7)) {
                    n = this.readFrameType(context.local, n8++, n, cArray, labelArray);
                    --n7;
                    "".length();
                    if (" ".length() <= " ".length()) continue;
                    return (0x54 ^ 0x69) & ~(0x49 ^ 0x74);
                }
                n7 = this.readUnsignedShort(n);
                n += 2;
                context.stackCount = n7;
                n8 = 0;
                while (ClassReader.llIllIlIIlI(n7)) {
                    n = this.readFrameType(context.stack, n8++, n, cArray, labelArray);
                    --n7;
                    "".length();
                    if (-" ".length() <= 0) continue;
                    return (0x73 ^ 0x6D ^ (0x1B ^ 0x29)) & (0xFE ^ 0x8F ^ (0x44 ^ 0x19) ^ -" ".length());
                }
            }
        }
        context.offset += n2 + 1;
        this.readLabel(context.offset, labelArray);
        "".length();
        return n;
    }

    private int readFrameType(Object[] objectArray, int n, int n2, char[] cArray, Label[] labelArray) {
        int n3 = this.b[n2++] & 0xFF;
        switch (n3) {
            case 0: {
                objectArray[n] = Opcodes.TOP;
                "".length();
                if (-" ".length() <= -" ".length()) break;
                return (0x1B ^ 0xF ^ (0x24 ^ 0x1A)) & (168 + 89 - 193 + 124 ^ 26 + 140 - 21 + 5 ^ -" ".length());
            }
            case 1: {
                objectArray[n] = Opcodes.INTEGER;
                "".length();
                if (-" ".length() != ((0x8A ^ 0x9B) & ~(7 ^ 0x16))) break;
                return (0x5B ^ 0x4A) & ~(0x92 ^ 0x83);
            }
            case 2: {
                objectArray[n] = Opcodes.FLOAT;
                "".length();
                if ((33 + 57 - -23 + 62 ^ 12 + 49 - -3 + 107) == (73 + 23 - -13 + 30 ^ 78 + 119 - 71 + 17)) break;
                return (0x53 ^ 0x58 ^ (0xBF ^ 0xBB)) & (0x8D ^ 0x84 ^ (0x5B ^ 0x5D) ^ -" ".length());
            }
            case 3: {
                objectArray[n] = Opcodes.DOUBLE;
                "".length();
                if (((0xD9 ^ 0xBB ^ (0 ^ 0x4A)) & (118 + 100 - 214 + 146 ^ 150 + 177 - 157 + 20 ^ -" ".length())) == 0) break;
                return (0x1F ^ 0x72 ^ (0xA ^ 0x38)) & (0x51 ^ 0x67 ^ (0x18 ^ 0x71) ^ -" ".length());
            }
            case 4: {
                objectArray[n] = Opcodes.LONG;
                "".length();
                if ((0x81 ^ 0x84) > 0) break;
                return (0xC4 ^ 0x93) & ~(0x4B ^ 0x1C);
            }
            case 5: {
                objectArray[n] = Opcodes.NULL;
                "".length();
                if (((0x24 ^ 0x76) & ~(0x32 ^ 0x60)) >= ((0x8D ^ 0xBF) & ~(0xF3 ^ 0xC1))) break;
                return (0x57 ^ 0x61) & ~(0x60 ^ 0x56);
            }
            case 6: {
                objectArray[n] = Opcodes.UNINITIALIZED_THIS;
                "".length();
                if (null == null) break;
                return (0x22 ^ 0xB) & ~(0x21 ^ 8);
            }
            case 7: {
                objectArray[n] = this.readClass(n2, cArray);
                n2 += 2;
                "".length();
                if ("  ".length() != (13 + 16 - -68 + 32 ^ 63 + 81 - 103 + 92)) break;
                return (0x78 ^ 0x4D ^ (0x7C ^ 0x1C)) & (0xC9 ^ 0x91 ^ (0x61 ^ 0x6C) ^ -" ".length());
            }
            default: {
                objectArray[n] = this.readLabel(this.readUnsignedShort(n2), labelArray);
                n2 += 2;
            }
        }
        return n2;
    }

    protected Label readLabel(int n, Label[] labelArray) {
        if (ClassReader.llIllIlIIll(labelArray[n])) {
            labelArray[n] = new Label();
        }
        return labelArray[n];
    }

    private int getAttributes() {
        int n;
        int n2 = this.header + 8 + this.readUnsignedShort(this.header + 6) * 2;
        int n3 = this.readUnsignedShort(n2);
        while (ClassReader.llIllIlIIlI(n3)) {
            n = this.readUnsignedShort(n2 + 8);
            while (ClassReader.llIllIlIIlI(n)) {
                n2 += 6 + this.readInt(n2 + 12);
                --n;
                "".length();
                if (null == null) continue;
                return (0x78 ^ 0x42 ^ (0x1C ^ 0x2B)) & (0x51 ^ 0x5F ^ "   ".length() ^ -" ".length());
            }
            n2 += 8;
            --n3;
            "".length();
            if ("  ".length() < "   ".length()) continue;
            return (0x1D ^ 1) & ~(0x6C ^ 0x70);
        }
        n3 = this.readUnsignedShort(n2 += 2);
        while (ClassReader.llIllIlIIlI(n3)) {
            n = this.readUnsignedShort(n2 + 8);
            while (ClassReader.llIllIlIIlI(n)) {
                n2 += 6 + this.readInt(n2 + 12);
                --n;
                "".length();
                if ("   ".length() >= 0) continue;
                return (0xA2 ^ 0x93) & ~(0x60 ^ 0x51) & ~((0xAE ^ 0xAB) & ~(0xAF ^ 0xAA));
            }
            n2 += 8;
            --n3;
            "".length();
            if (" ".length() >= 0) continue;
            return (0x17 ^ 0x3B) & ~(0x99 ^ 0xB5);
        }
        return n2 + 2;
    }

    private Attribute readAttribute(Attribute[] attributeArray, String string, int n, int n2, char[] cArray, int n3, Label[] labelArray) {
        int n4 = 0;
        while (ClassReader.llIllIlIIIl(n4, attributeArray.length)) {
            if (ClassReader.llIllIlIlII(attributeArray[n4].type.equals(string) ? 1 : 0)) {
                return attributeArray[n4].read(this, n, n2, cArray, n3, labelArray);
            }
            ++n4;
            "".length();
            if ((0x15 ^ 0x11) > 0) continue;
            return null;
        }
        return new Attribute(string).read(this, n, n2, null, -1, null);
    }

    public int getItemCount() {
        return this.items.length;
    }

    public int getItem(int n) {
        return this.items[n];
    }

    public int getMaxStringLength() {
        return this.maxStringLength;
    }

    public int readByte(int n) {
        return this.b[n] & 0xFF;
    }

    public int readUnsignedShort(int n) {
        byte[] byArray = this.b;
        return (byArray[n] & 0xFF) << 8 | byArray[n + 1] & 0xFF;
    }

    public short readShort(int n) {
        byte[] byArray = this.b;
        return (short)((byArray[n] & 0xFF) << 8 | byArray[n + 1] & 0xFF);
    }

    public int readInt(int n) {
        byte[] byArray = this.b;
        return (byArray[n] & 0xFF) << 24 | (byArray[n + 1] & 0xFF) << 16 | (byArray[n + 2] & 0xFF) << 8 | byArray[n + 3] & 0xFF;
    }

    public long readLong(int n) {
        long l = this.readInt(n);
        long l2 = (long)this.readInt(n + 4) & 0xFFFFFFFFL;
        return l << 32 | l2;
    }

    public String readUTF8(int n, char[] cArray) {
        int n2 = this.readUnsignedShort(n);
        if (!ClassReader.llIllIlIlII(n) || ClassReader.llIllIlIlIl(n2)) {
            return null;
        }
        String string = this.strings[n2];
        if (ClassReader.llIllIllIIl(string)) {
            return string;
        }
        n = this.items[n2];
        this.strings[n2] = this.readUTF(n + 2, this.readUnsignedShort(n), cArray);
        return this.strings[n2];
    }

    private String readUTF(int n, int n2, char[] cArray) {
        int n3 = n + n2;
        byte[] byArray = this.b;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        while (ClassReader.llIllIlIIIl(n, n3)) {
            int n7 = byArray[n++];
            switch (n5) {
                case 0: {
                    if (ClassReader.llIllIlIIIl(n7 &= 0xFF, 128)) {
                        cArray[n4++] = (char)n7;
                        "".length();
                        if (-"   ".length() < 0) break;
                        return null;
                    }
                    if (ClassReader.llIllIlIIIl(n7, 224) && ClassReader.llIllIlIIII(n7, 191)) {
                        n6 = (char)(n7 & 0x1F);
                        n5 = 1;
                        "".length();
                        if ("   ".length() <= "   ".length()) break;
                        return null;
                    }
                    n6 = (char)(n7 & 0xF);
                    n5 = 2;
                    "".length();
                    if ("  ".length() >= 0) break;
                    return null;
                }
                case 1: {
                    cArray[n4++] = (char)(n6 << 6 | n7 & 0x3F);
                    n5 = 0;
                    "".length();
                    if ((0x8F ^ 0x8B) == (0xB0 ^ 0xB4)) break;
                    return null;
                }
                case 2: {
                    n6 = (char)(n6 << 6 | n7 & 0x3F);
                    n5 = 1;
                }
            }
            "".length();
            if (-(0x55 ^ 0x50) < 0) continue;
            return null;
        }
        return new String(cArray, 0, n4);
    }

    public String readClass(int n, char[] cArray) {
        return this.readUTF8(this.items[this.readUnsignedShort(n)], cArray);
    }

    public Object readConst(int n, char[] cArray) {
        boolean bl;
        int n2 = this.items[n];
        switch (this.b[n2 - 1]) {
            case 3: {
                return this.readInt(n2);
            }
            case 4: {
                return Float.valueOf(Float.intBitsToFloat(this.readInt(n2)));
            }
            case 5: {
                return this.readLong(n2);
            }
            case 6: {
                return Double.longBitsToDouble(this.readLong(n2));
            }
            case 7: {
                return Type.getObjectType(this.readUTF8(n2, cArray));
            }
            case 8: {
                return this.readUTF8(n2, cArray);
            }
            case 16: {
                return Type.getMethodType(this.readUTF8(n2, cArray));
            }
        }
        int n3 = this.readByte(n2);
        int[] nArray = this.items;
        int n4 = nArray[this.readUnsignedShort(n2 + 1)];
        if (ClassReader.llIllIlIllI(this.b[n4 - 1], 11)) {
            bl = true;
            "".length();
            if ("  ".length() == "   ".length()) {
                return null;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        String string = this.readClass(n4, cArray);
        n4 = nArray[this.readUnsignedShort(n4 + 2)];
        String string2 = this.readUTF8(n4, cArray);
        String string3 = this.readUTF8(n4 + 2, cArray);
        return new Handle(n3, string, string2, string3, bl2);
    }

    static {
        ANNOTATIONS = true;
        RESIZE = true;
        FRAMES = true;
        SKIP_FRAMES = 4;
        EXPAND_FRAMES = 8;
        SIGNATURES = true;
        SKIP_DEBUG = 2;
        EXPAND_ASM_INSNS = 256;
        WRITER = true;
        SKIP_CODE = 1;
    }

    private static boolean llIllIlIllI(int n, int n2) {
        return n == n2;
    }

    private static boolean llIlllIlIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIllIlIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlllIlIIl(int n, int n2) {
        return n <= n2;
    }

    private static boolean llIllIlIIII(int n, int n2) {
        return n > n2;
    }

    private static boolean llIllIllIIl(Object object) {
        return object != null;
    }

    private static boolean llIlllIIIlI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIllIlIIll(Object object) {
        return object == null;
    }

    private static boolean llIllIlIlII(int n) {
        return n != 0;
    }

    private static boolean llIllIlIlIl(int n) {
        return n == 0;
    }

    private static boolean llIlllIIIll(int n) {
        return n >= 0;
    }

    private static boolean llIllIlIlll(int n) {
        return n < 0;
    }

    private static boolean llIllIlIIlI(int n) {
        return n > 0;
    }

    private static boolean llIlllIIlII(int n, int n2) {
        return n != n2;
    }
}

