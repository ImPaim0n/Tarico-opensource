/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.TypePath;

public abstract class ClassVisitor {
    protected final int api;
    protected ClassVisitor cv;

    public ClassVisitor(int n) {
        this(n, null);
    }

    public ClassVisitor(int n, ClassVisitor classVisitor) {
        if (ClassVisitor.llIlllllI(n, 262144) && ClassVisitor.llIlllllI(n, 327680)) {
            throw new IllegalArgumentException();
        }
        this.api = n;
        this.cv = classVisitor;
    }

    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        if (ClassVisitor.llIllllll(this.cv)) {
            this.cv.visit(n, n2, string, string2, string3, stringArray);
        }
    }

    public void visitSource(String string, String string2) {
        if (ClassVisitor.llIllllll(this.cv)) {
            this.cv.visitSource(string, string2);
        }
    }

    public void visitOuterClass(String string, String string2, String string3) {
        if (ClassVisitor.llIllllll(this.cv)) {
            this.cv.visitOuterClass(string, string2, string3);
        }
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        if (ClassVisitor.llIllllll(this.cv)) {
            return this.cv.visitAnnotation(string, bl);
        }
        return null;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        if (ClassVisitor.lllIIIIII(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (ClassVisitor.llIllllll(this.cv)) {
            return this.cv.visitTypeAnnotation(n, typePath, string, bl);
        }
        return null;
    }

    public void visitAttribute(Attribute attribute) {
        if (ClassVisitor.llIllllll(this.cv)) {
            this.cv.visitAttribute(attribute);
        }
    }

    public void visitInnerClass(String string, String string2, String string3, int n) {
        if (ClassVisitor.llIllllll(this.cv)) {
            this.cv.visitInnerClass(string, string2, string3, n);
        }
    }

    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        if (ClassVisitor.llIllllll(this.cv)) {
            return this.cv.visitField(n, string, string2, string3, object);
        }
        return null;
    }

    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        if (ClassVisitor.llIllllll(this.cv)) {
            return this.cv.visitMethod(n, string, string2, string3, stringArray);
        }
        return null;
    }

    public void visitEnd() {
        if (ClassVisitor.llIllllll(this.cv)) {
            this.cv.visitEnd();
        }
    }

    private static boolean lllIIIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIllllll(Object object) {
        return object != null;
    }

    private static boolean llIlllllI(int n, int n2) {
        return n != n2;
    }
}

