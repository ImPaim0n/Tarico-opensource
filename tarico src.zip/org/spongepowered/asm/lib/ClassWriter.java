/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.AnnotationWriter;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ByteVector;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.FieldWriter;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Item;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.MethodWriter;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;

public class ClassWriter
extends ClassVisitor {
    public static final int COMPUTE_MAXS;
    public static final int COMPUTE_FRAMES;
    static final int ACC_SYNTHETIC_ATTRIBUTE;
    static final int TO_ACC_SYNTHETIC;
    static final int NOARG_INSN;
    static final int SBYTE_INSN;
    static final int SHORT_INSN;
    static final int VAR_INSN;
    static final int IMPLVAR_INSN;
    static final int TYPE_INSN;
    static final int FIELDORMETH_INSN;
    static final int ITFMETH_INSN;
    static final int INDYMETH_INSN;
    static final int LABEL_INSN;
    static final int LABELW_INSN;
    static final int LDC_INSN;
    static final int LDCW_INSN;
    static final int IINC_INSN;
    static final int TABL_INSN;
    static final int LOOK_INSN;
    static final int MANA_INSN;
    static final int WIDE_INSN;
    static final int ASM_LABEL_INSN;
    static final int F_INSERT;
    static final byte[] TYPE;
    static final int CLASS;
    static final int FIELD;
    static final int METH;
    static final int IMETH;
    static final int STR;
    static final int INT;
    static final int FLOAT;
    static final int LONG;
    static final int DOUBLE;
    static final int NAME_TYPE;
    static final int UTF8;
    static final int MTYPE;
    static final int HANDLE;
    static final int INDY;
    static final int HANDLE_BASE;
    static final int TYPE_NORMAL;
    static final int TYPE_UNINIT;
    static final int TYPE_MERGED;
    static final int BSM;
    ClassReader cr;
    int version;
    int index = 1;
    final ByteVector pool = new ByteVector();
    Item[] items = new Item[256];
    int threshold = (int)(0.75 * (double)this.items.length);
    final Item key = new Item();
    final Item key2 = new Item();
    final Item key3 = new Item();
    final Item key4 = new Item();
    Item[] typeTable;
    private short typeCount;
    private int access;
    private int name;
    String thisName;
    private int signature;
    private int superName;
    private int interfaceCount;
    private int[] interfaces;
    private int sourceFile;
    private ByteVector sourceDebug;
    private int enclosingMethodOwner;
    private int enclosingMethod;
    private AnnotationWriter anns;
    private AnnotationWriter ianns;
    private AnnotationWriter tanns;
    private AnnotationWriter itanns;
    private Attribute attrs;
    private int innerClassesCount;
    private ByteVector innerClasses;
    int bootstrapMethodsCount;
    ByteVector bootstrapMethods;
    FieldWriter firstField;
    FieldWriter lastField;
    MethodWriter firstMethod;
    MethodWriter lastMethod;
    private int compute;
    boolean hasAsmInsns;

    public ClassWriter(int n) {
        super(327680);
        int n2;
        if (ClassWriter.llIIlllll(n & 2)) {
            n2 = 0;
            "".length();
            if (" ".length() <= 0) {
                throw null;
            }
        } else if (ClassWriter.llIIlllll(n & 1)) {
            n2 = 2;
            "".length();
            if (((0x71 ^ 0x4C ^ (0x51 ^ 0x72)) & (62 + 47 - 17 + 79 ^ 13 + 12 - 0 + 156 ^ -" ".length())) != 0) {
                throw null;
            }
        } else {
            n2 = 3;
        }
        this.compute = n2;
    }

    public ClassWriter(ClassReader classReader, int n) {
        this(n);
        classReader.copyPool(this);
        this.cr = classReader;
    }

    public final void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        int n3;
        this.version = n;
        this.access = n2;
        this.name = this.newClass(string);
        this.thisName = string;
        if (ClassWriter.llIlIIIII(string2)) {
            this.signature = this.newUTF8(string2);
        }
        if (ClassWriter.llIlIIIIl(string3)) {
            n3 = 0;
            "".length();
            if ((132 + 48 - 172 + 140 ^ 22 + 76 - 2 + 48) < 0) {
                return;
            }
        } else {
            n3 = this.superName = this.newClass(string3);
        }
        if (ClassWriter.llIlIIIII(stringArray) && ClassWriter.llIlIIIlI(stringArray.length)) {
            this.interfaceCount = stringArray.length;
            this.interfaces = new int[this.interfaceCount];
            int n4 = 0;
            while (ClassWriter.llIlIIIll(n4, this.interfaceCount)) {
                this.interfaces[n4] = this.newClass(stringArray[n4]);
                ++n4;
                "".length();
                if (((201 + 63 - 161 + 109 ^ 62 + 37 - 37 + 135) & (0x5C ^ 0x62 ^ (0x7E ^ 0x51) ^ -" ".length())) == 0) continue;
                return;
            }
        }
    }

    public final void visitSource(String string, String string2) {
        if (ClassWriter.llIlIIIII(string)) {
            this.sourceFile = this.newUTF8(string);
        }
        if (ClassWriter.llIlIIIII(string2)) {
            this.sourceDebug = new ByteVector().encodeUTF8(string2, 0, Integer.MAX_VALUE);
        }
    }

    public final void visitOuterClass(String string, String string2, String string3) {
        this.enclosingMethodOwner = this.newClass(string);
        if (ClassWriter.llIlIIIII(string2) && ClassWriter.llIlIIIII(string3)) {
            this.enclosingMethod = this.newNameType(string2, string3);
        }
    }

    public final AnnotationVisitor visitAnnotation(String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        byteVector.putShort(this.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this, true, byteVector, byteVector, 2);
        if (ClassWriter.llIIlllll(bl ? 1 : 0)) {
            annotationWriter.next = this.anns;
            this.anns = annotationWriter;
            "".length();
            if (-"   ".length() >= 0) {
                return null;
            }
        } else {
            annotationWriter.next = this.ianns;
            this.ianns = annotationWriter;
        }
        return annotationWriter;
    }

    public final AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        AnnotationWriter.putTarget(n, typePath, byteVector);
        byteVector.putShort(this.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this, true, byteVector, byteVector, byteVector.length - 2);
        if (ClassWriter.llIIlllll(bl ? 1 : 0)) {
            annotationWriter.next = this.tanns;
            this.tanns = annotationWriter;
            "".length();
            if ((0x4B ^ 0x56 ^ (0xBE ^ 0xA7)) == 0) {
                return null;
            }
        } else {
            annotationWriter.next = this.itanns;
            this.itanns = annotationWriter;
        }
        return annotationWriter;
    }

    public final void visitAttribute(Attribute attribute) {
        attribute.next = this.attrs;
        this.attrs = attribute;
    }

    public final void visitInnerClass(String string, String string2, String string3, int n) {
        if (ClassWriter.llIlIIIIl(this.innerClasses)) {
            this.innerClasses = new ByteVector();
        }
        Item item = this.newClassItem(string);
        if (ClassWriter.llIlIIlII(item.intVal)) {
            int n2;
            int n3;
            ++this.innerClassesCount;
            this.innerClasses.putShort(item.index);
            "".length();
            if (ClassWriter.llIlIIIIl(string2)) {
                n3 = 0;
                "".length();
                if (" ".length() >= "   ".length()) {
                    return;
                }
            } else {
                n3 = this.newClass(string2);
            }
            this.innerClasses.putShort(n3);
            "".length();
            if (ClassWriter.llIlIIIIl(string3)) {
                n2 = 0;
                "".length();
                if ((71 + 99 - 5 + 10 ^ 163 + 156 - 314 + 166) <= 0) {
                    return;
                }
            } else {
                n2 = this.newUTF8(string3);
            }
            this.innerClasses.putShort(n2);
            "".length();
            this.innerClasses.putShort(n);
            "".length();
            item.intVal = this.innerClassesCount;
        }
    }

    public final FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        return new FieldWriter(this, n, string, string2, string3, object);
    }

    public final MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        return new MethodWriter(this, n, string, string2, string3, stringArray, this.compute);
    }

    public final void visitEnd() {
    }

    public byte[] toByteArray() {
        if (ClassWriter.llIlIIlIl(this.index, 65535)) {
            throw new RuntimeException("Class file too large!");
        }
        int n = 24 + 2 * this.interfaceCount;
        int n2 = 0;
        FieldWriter fieldWriter = this.firstField;
        while (ClassWriter.llIlIIIII(fieldWriter)) {
            ++n2;
            n += fieldWriter.getSize();
            fieldWriter = (FieldWriter)fieldWriter.fv;
            "".length();
            if ((0x3E ^ 0x3A) > "   ".length()) continue;
            return null;
        }
        int n3 = 0;
        MethodWriter methodWriter = this.firstMethod;
        while (ClassWriter.llIlIIIII(methodWriter)) {
            ++n3;
            n += methodWriter.getSize();
            methodWriter = (MethodWriter)methodWriter.mv;
            "".length();
            if (null == null) continue;
            return null;
        }
        int n4 = 0;
        if (ClassWriter.llIlIIIII(this.bootstrapMethods)) {
            ++n4;
            n += 8 + this.bootstrapMethods.length;
            this.newUTF8("BootstrapMethods");
            "".length();
        }
        if (ClassWriter.llIIlllll(this.signature)) {
            ++n4;
            n += 8;
            this.newUTF8("Signature");
            "".length();
        }
        if (ClassWriter.llIIlllll(this.sourceFile)) {
            ++n4;
            n += 8;
            this.newUTF8("SourceFile");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.sourceDebug)) {
            ++n4;
            n += this.sourceDebug.length + 6;
            this.newUTF8("SourceDebugExtension");
            "".length();
        }
        if (ClassWriter.llIIlllll(this.enclosingMethodOwner)) {
            ++n4;
            n += 10;
            this.newUTF8("EnclosingMethod");
            "".length();
        }
        if (ClassWriter.llIIlllll(this.access & 0x20000)) {
            ++n4;
            n += 6;
            this.newUTF8("Deprecated");
            "".length();
        }
        if (ClassWriter.llIIlllll(this.access & 0x1000) && (!ClassWriter.llIlIIllI(this.version & 0xFFFF, 49) || ClassWriter.llIIlllll(this.access & 0x40000))) {
            ++n4;
            n += 6;
            this.newUTF8("Synthetic");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.innerClasses)) {
            ++n4;
            n += 8 + this.innerClasses.length;
            this.newUTF8("InnerClasses");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.anns)) {
            ++n4;
            n += 8 + this.anns.getSize();
            this.newUTF8("RuntimeVisibleAnnotations");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.ianns)) {
            ++n4;
            n += 8 + this.ianns.getSize();
            this.newUTF8("RuntimeInvisibleAnnotations");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.tanns)) {
            ++n4;
            n += 8 + this.tanns.getSize();
            this.newUTF8("RuntimeVisibleTypeAnnotations");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.itanns)) {
            ++n4;
            n += 8 + this.itanns.getSize();
            this.newUTF8("RuntimeInvisibleTypeAnnotations");
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.attrs)) {
            n4 += this.attrs.getCount();
            n += this.attrs.getSize(this, null, 0, -1, -1);
        }
        ByteVector byteVector = new ByteVector(n += this.pool.length);
        byteVector.putInt(-889275714).putInt(this.version);
        "".length();
        byteVector.putShort(this.index).putByteArray(this.pool.data, 0, this.pool.length);
        "".length();
        int n5 = 0x60000 | (this.access & 0x40000) / 64;
        byteVector.putShort(this.access & ~n5).putShort(this.name).putShort(this.superName);
        "".length();
        byteVector.putShort(this.interfaceCount);
        "".length();
        int n6 = 0;
        while (ClassWriter.llIlIIIll(n6, this.interfaceCount)) {
            byteVector.putShort(this.interfaces[n6]);
            "".length();
            ++n6;
            "".length();
            if (((0x26 ^ 0xE ^ (0x2F ^ 0x1F)) & (9 ^ 0x59 ^ (0x3C ^ 0x74) ^ -" ".length())) < "   ".length()) continue;
            return null;
        }
        byteVector.putShort(n2);
        "".length();
        fieldWriter = this.firstField;
        while (ClassWriter.llIlIIIII(fieldWriter)) {
            fieldWriter.put(byteVector);
            fieldWriter = (FieldWriter)fieldWriter.fv;
            "".length();
            if (null == null) continue;
            return null;
        }
        byteVector.putShort(n3);
        "".length();
        methodWriter = this.firstMethod;
        while (ClassWriter.llIlIIIII(methodWriter)) {
            methodWriter.put(byteVector);
            methodWriter = (MethodWriter)methodWriter.mv;
            "".length();
            if (-"   ".length() <= 0) continue;
            return null;
        }
        byteVector.putShort(n4);
        "".length();
        if (ClassWriter.llIlIIIII(this.bootstrapMethods)) {
            byteVector.putShort(this.newUTF8("BootstrapMethods"));
            "".length();
            byteVector.putInt(this.bootstrapMethods.length + 2).putShort(this.bootstrapMethodsCount);
            "".length();
            byteVector.putByteArray(this.bootstrapMethods.data, 0, this.bootstrapMethods.length);
            "".length();
        }
        if (ClassWriter.llIIlllll(this.signature)) {
            byteVector.putShort(this.newUTF8("Signature")).putInt(2).putShort(this.signature);
            "".length();
        }
        if (ClassWriter.llIIlllll(this.sourceFile)) {
            byteVector.putShort(this.newUTF8("SourceFile")).putInt(2).putShort(this.sourceFile);
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.sourceDebug)) {
            n6 = this.sourceDebug.length;
            byteVector.putShort(this.newUTF8("SourceDebugExtension")).putInt(n6);
            "".length();
            byteVector.putByteArray(this.sourceDebug.data, 0, n6);
            "".length();
        }
        if (ClassWriter.llIIlllll(this.enclosingMethodOwner)) {
            byteVector.putShort(this.newUTF8("EnclosingMethod")).putInt(4);
            "".length();
            byteVector.putShort(this.enclosingMethodOwner).putShort(this.enclosingMethod);
            "".length();
        }
        if (ClassWriter.llIIlllll(this.access & 0x20000)) {
            byteVector.putShort(this.newUTF8("Deprecated")).putInt(0);
            "".length();
        }
        if (ClassWriter.llIIlllll(this.access & 0x1000) && (!ClassWriter.llIlIIllI(this.version & 0xFFFF, 49) || ClassWriter.llIIlllll(this.access & 0x40000))) {
            byteVector.putShort(this.newUTF8("Synthetic")).putInt(0);
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.innerClasses)) {
            byteVector.putShort(this.newUTF8("InnerClasses"));
            "".length();
            byteVector.putInt(this.innerClasses.length + 2).putShort(this.innerClassesCount);
            "".length();
            byteVector.putByteArray(this.innerClasses.data, 0, this.innerClasses.length);
            "".length();
        }
        if (ClassWriter.llIlIIIII(this.anns)) {
            byteVector.putShort(this.newUTF8("RuntimeVisibleAnnotations"));
            "".length();
            this.anns.put(byteVector);
        }
        if (ClassWriter.llIlIIIII(this.ianns)) {
            byteVector.putShort(this.newUTF8("RuntimeInvisibleAnnotations"));
            "".length();
            this.ianns.put(byteVector);
        }
        if (ClassWriter.llIlIIIII(this.tanns)) {
            byteVector.putShort(this.newUTF8("RuntimeVisibleTypeAnnotations"));
            "".length();
            this.tanns.put(byteVector);
        }
        if (ClassWriter.llIlIIIII(this.itanns)) {
            byteVector.putShort(this.newUTF8("RuntimeInvisibleTypeAnnotations"));
            "".length();
            this.itanns.put(byteVector);
        }
        if (ClassWriter.llIlIIIII(this.attrs)) {
            this.attrs.put(this, null, 0, -1, -1, byteVector);
        }
        if (ClassWriter.llIIlllll(this.hasAsmInsns ? 1 : 0)) {
            this.anns = null;
            this.ianns = null;
            this.attrs = null;
            this.innerClassesCount = 0;
            this.innerClasses = null;
            this.firstField = null;
            this.lastField = null;
            this.firstMethod = null;
            this.lastMethod = null;
            this.compute = 1;
            this.hasAsmInsns = false;
            new ClassReader(byteVector.data).accept(this, 264);
            return this.toByteArray();
        }
        return byteVector.data;
    }

    Item newConstItem(Object object) {
        if (ClassWriter.llIIlllll(object instanceof Integer)) {
            int n = (Integer)object;
            return this.newInteger(n);
        }
        if (ClassWriter.llIIlllll(object instanceof Byte)) {
            int n = ((Byte)object).intValue();
            return this.newInteger(n);
        }
        if (ClassWriter.llIIlllll(object instanceof Character)) {
            char c = ((Character)object).charValue();
            return this.newInteger(c);
        }
        if (ClassWriter.llIIlllll(object instanceof Short)) {
            int n = ((Short)object).intValue();
            return this.newInteger(n);
        }
        if (ClassWriter.llIIlllll(object instanceof Boolean)) {
            int n;
            if (ClassWriter.llIIlllll(((Boolean)object).booleanValue() ? 1 : 0)) {
                n = 1;
                "".length();
                if ("   ".length() == "  ".length()) {
                    return null;
                }
            } else {
                n = 0;
            }
            int n2 = n;
            return this.newInteger(n2);
        }
        if (ClassWriter.llIIlllll(object instanceof Float)) {
            float f = ((Float)object).floatValue();
            return this.newFloat(f);
        }
        if (ClassWriter.llIIlllll(object instanceof Long)) {
            long l = (Long)object;
            return this.newLong(l);
        }
        if (ClassWriter.llIIlllll(object instanceof Double)) {
            double d = (Double)object;
            return this.newDouble(d);
        }
        if (ClassWriter.llIIlllll(object instanceof String)) {
            return this.newString((String)object);
        }
        if (ClassWriter.llIIlllll(object instanceof Type)) {
            Type type = (Type)object;
            int n = type.getSort();
            if (ClassWriter.llIlIlIll(n, 10)) {
                return this.newClassItem(type.getInternalName());
            }
            if (ClassWriter.llIlIlIll(n, 11)) {
                return this.newMethodTypeItem(type.getDescriptor());
            }
            return this.newClassItem(type.getDescriptor());
        }
        if (ClassWriter.llIIlllll(object instanceof Handle)) {
            Handle handle = (Handle)object;
            return this.newHandleItem(handle.tag, handle.owner, handle.name, handle.desc, handle.itf);
        }
        throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("value ").append(object)));
    }

    public int newConst(Object object) {
        return this.newConstItem((Object)object).index;
    }

    public int newUTF8(String string) {
        this.key.set(1, string, null, null);
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.putByte(1).putUTF8(string);
            "".length();
            item = new Item(this.index++, this.key);
            this.put(item);
        }
        return item.index;
    }

    Item newClassItem(String string) {
        this.key2.set(7, string, null, null);
        Item item = this.get(this.key2);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.put12(7, this.newUTF8(string));
            "".length();
            item = new Item(this.index++, this.key2);
            this.put(item);
        }
        return item;
    }

    public int newClass(String string) {
        return this.newClassItem((String)string).index;
    }

    Item newMethodTypeItem(String string) {
        this.key2.set(16, string, null, null);
        Item item = this.get(this.key2);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.put12(16, this.newUTF8(string));
            "".length();
            item = new Item(this.index++, this.key2);
            this.put(item);
        }
        return item;
    }

    public int newMethodType(String string) {
        return this.newMethodTypeItem((String)string).index;
    }

    Item newHandleItem(int n, String string, String string2, String string3, boolean bl) {
        this.key4.set(20 + n, string, string2, string3);
        Item item = this.get(this.key4);
        if (ClassWriter.llIlIIIIl(item)) {
            if (ClassWriter.llIlIlllI(n, 4)) {
                this.put112(15, n, this.newField(string, string2, string3));
                "".length();
                if (" ".length() < " ".length()) {
                    return null;
                }
            } else {
                this.put112(15, n, this.newMethod(string, string2, string3, bl));
            }
            item = new Item(this.index++, this.key4);
            this.put(item);
        }
        return item;
    }

    @Deprecated
    public int newHandle(int n, String string, String string2, String string3) {
        boolean bl;
        if (ClassWriter.llIlIlIll(n, 9)) {
            bl = true;
            "".length();
            if (-"   ".length() >= 0) {
                return (0x65 ^ 0x54 ^ (0x6C ^ 0x50)) & (0x3F ^ 0x6C ^ (0x74 ^ 0x2A) ^ -" ".length());
            }
        } else {
            bl = false;
        }
        return this.newHandle(n, string, string2, string3, bl);
    }

    public int newHandle(int n, String string, String string2, String string3, boolean bl) {
        return this.newHandleItem((int)n, (String)string, (String)string2, (String)string3, (boolean)bl).index;
    }

    Item newInvokeDynamicItem(String string, String string2, Handle handle, Object ... objectArray) {
        int n;
        ByteVector byteVector = this.bootstrapMethods;
        if (ClassWriter.llIlIIIIl(byteVector)) {
            byteVector = this.bootstrapMethods = new ByteVector();
        }
        int n2 = byteVector.length;
        int n3 = handle.hashCode();
        byteVector.putShort(this.newHandle(handle.tag, handle.owner, handle.name, handle.desc, handle.isInterface()));
        "".length();
        int n4 = objectArray.length;
        byteVector.putShort(n4);
        "".length();
        int n5 = 0;
        while (ClassWriter.llIlIIIll(n5, n4)) {
            Object object = objectArray[n5];
            n3 ^= object.hashCode();
            byteVector.putShort(this.newConst(object));
            "".length();
            ++n5;
            "".length();
            if (" ".length() <= " ".length()) continue;
            return null;
        }
        byte[] byArray = byteVector.data;
        int n6 = 2 + n4 << 1;
        Item item = this.items[(n3 &= Integer.MAX_VALUE) % this.items.length];
        block1: while (ClassWriter.llIlIIIII(item)) {
            if (!ClassWriter.llIlIlIll(item.type, 33) || ClassWriter.llIlIllll(item.hashCode, n3)) {
                item = item.next;
                "".length();
                if (((0xBF ^ 0xB8) & ~(0x45 ^ 0x42)) <= "   ".length()) continue;
                return null;
            }
            n = item.intVal;
            int n7 = 0;
            while (ClassWriter.llIlIIIll(n7, n6)) {
                if (ClassWriter.llIlIllll(byArray[n2 + n7], byArray[n + n7])) {
                    item = item.next;
                    "".length();
                    if ("  ".length() > 0) continue block1;
                    return null;
                }
                ++n7;
                "".length();
                if ("  ".length() <= (0x2A ^ 0x2E)) continue;
                return null;
            }
            "".length();
            if ((0x1A ^ 0x1F) > 0) break;
            return null;
        }
        if (ClassWriter.llIlIIIII(item)) {
            n = item.index;
            byteVector.length = n2;
            "".length();
            if (-"  ".length() > 0) {
                return null;
            }
        } else {
            n = this.bootstrapMethodsCount++;
            item = new Item(n);
            item.set(n2, n3);
            this.put(item);
        }
        this.key3.set(string, string2, n);
        item = this.get(this.key3);
        if (ClassWriter.llIlIIIIl(item)) {
            this.put122(18, n, this.newNameType(string, string2));
            item = new Item(this.index++, this.key3);
            this.put(item);
        }
        return item;
    }

    public int newInvokeDynamic(String string, String string2, Handle handle, Object ... objectArray) {
        return this.newInvokeDynamicItem((String)string, (String)string2, (Handle)handle, (Object[])objectArray).index;
    }

    Item newFieldItem(String string, String string2, String string3) {
        this.key3.set(9, string, string2, string3);
        Item item = this.get(this.key3);
        if (ClassWriter.llIlIIIIl(item)) {
            this.put122(9, this.newClass(string), this.newNameType(string2, string3));
            item = new Item(this.index++, this.key3);
            this.put(item);
        }
        return item;
    }

    public int newField(String string, String string2, String string3) {
        return this.newFieldItem((String)string, (String)string2, (String)string3).index;
    }

    Item newMethodItem(String string, String string2, String string3, boolean bl) {
        int n;
        if (ClassWriter.llIIlllll(bl ? 1 : 0)) {
            n = 11;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            n = 10;
        }
        int n2 = n;
        this.key3.set(n2, string, string2, string3);
        Item item = this.get(this.key3);
        if (ClassWriter.llIlIIIIl(item)) {
            this.put122(n2, this.newClass(string), this.newNameType(string2, string3));
            item = new Item(this.index++, this.key3);
            this.put(item);
        }
        return item;
    }

    public int newMethod(String string, String string2, String string3, boolean bl) {
        return this.newMethodItem((String)string, (String)string2, (String)string3, (boolean)bl).index;
    }

    Item newInteger(int n) {
        this.key.set(n);
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.putByte(3).putInt(n);
            "".length();
            item = new Item(this.index++, this.key);
            this.put(item);
        }
        return item;
    }

    Item newFloat(float f) {
        this.key.set(f);
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.putByte(4).putInt(this.key.intVal);
            "".length();
            item = new Item(this.index++, this.key);
            this.put(item);
        }
        return item;
    }

    Item newLong(long l) {
        this.key.set(l);
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.putByte(5).putLong(l);
            "".length();
            item = new Item(this.index, this.key);
            this.index += 2;
            this.put(item);
        }
        return item;
    }

    Item newDouble(double d) {
        this.key.set(d);
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.putByte(6).putLong(this.key.longVal);
            "".length();
            item = new Item(this.index, this.key);
            this.index += 2;
            this.put(item);
        }
        return item;
    }

    private Item newString(String string) {
        this.key2.set(8, string, null, null);
        Item item = this.get(this.key2);
        if (ClassWriter.llIlIIIIl(item)) {
            this.pool.put12(8, this.newUTF8(string));
            "".length();
            item = new Item(this.index++, this.key2);
            this.put(item);
        }
        return item;
    }

    public int newNameType(String string, String string2) {
        return this.newNameTypeItem((String)string, (String)string2).index;
    }

    Item newNameTypeItem(String string, String string2) {
        this.key2.set(12, string, string2, null);
        Item item = this.get(this.key2);
        if (ClassWriter.llIlIIIIl(item)) {
            this.put122(12, this.newUTF8(string), this.newUTF8(string2));
            item = new Item(this.index++, this.key2);
            this.put(item);
        }
        return item;
    }

    int addType(String string) {
        this.key.set(30, string, null, null);
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            item = this.addType(this.key);
        }
        return item.index;
    }

    int addUninitializedType(String string, int n) {
        this.key.type = 31;
        this.key.intVal = n;
        this.key.strVal1 = string;
        this.key.hashCode = Integer.MAX_VALUE & 31 + string.hashCode() + n;
        Item item = this.get(this.key);
        if (ClassWriter.llIlIIIIl(item)) {
            item = this.addType(this.key);
        }
        return item.index;
    }

    private Item addType(Item item) {
        this.typeCount = (short)(this.typeCount + 1);
        Item item2 = new Item(this.typeCount, this.key);
        this.put(item2);
        if (ClassWriter.llIlIIIIl(this.typeTable)) {
            this.typeTable = new Item[16];
        }
        if (ClassWriter.llIlIlIll(this.typeCount, this.typeTable.length)) {
            Item[] itemArray = new Item[2 * this.typeTable.length];
            System.arraycopy(this.typeTable, 0, itemArray, 0, this.typeTable.length);
            this.typeTable = itemArray;
        }
        this.typeTable[this.typeCount] = item2;
        return item2;
    }

    int getMergedType(int n, int n2) {
        this.key2.type = 32;
        this.key2.longVal = (long)n | (long)n2 << 32;
        this.key2.hashCode = Integer.MAX_VALUE & 32 + n + n2;
        Item item = this.get(this.key2);
        if (ClassWriter.llIlIIIIl(item)) {
            String string = this.typeTable[n].strVal1;
            String string2 = this.typeTable[n2].strVal1;
            this.key2.intVal = this.addType(this.getCommonSuperClass(string, string2));
            item = new Item(0, this.key2);
            this.put(item);
        }
        return item.intVal;
    }

    protected String getCommonSuperClass(String string, String string2) {
        Class<?> clazz;
        Class<?> clazz2;
        ClassLoader classLoader = this.getClass().getClassLoader();
        try {
            clazz2 = Class.forName(string.replace('/', '.'), false, classLoader);
            clazz = Class.forName(string2.replace('/', '.'), false, classLoader);
            "".length();
        }
        catch (Exception exception) {
            throw new RuntimeException(exception.toString());
        }
        if (((212 + 39 - 32 + 11 ^ 16 + 106 - 112 + 180) & (0xA4 ^ 0xC3 ^ (0x4E ^ 0x71) ^ -" ".length())) != 0) {
            return null;
        }
        if (ClassWriter.llIIlllll(clazz2.isAssignableFrom(clazz) ? 1 : 0)) {
            return string;
        }
        if (ClassWriter.llIIlllll(clazz.isAssignableFrom(clazz2) ? 1 : 0)) {
            return string2;
        }
        if (!ClassWriter.llIlIIlII(clazz2.isInterface() ? 1 : 0) || ClassWriter.llIIlllll(clazz.isInterface() ? 1 : 0)) {
            return "java/lang/Object";
        }
        while (!ClassWriter.llIIlllll((clazz2 = clazz2.getSuperclass()).isAssignableFrom(clazz) ? 1 : 0)) {
        }
        return clazz2.getName().replace('.', '/');
    }

    private Item get(Item item) {
        Item item2 = this.items[item.hashCode % this.items.length];
        while (ClassWriter.llIlIIIII(item2) && (!ClassWriter.llIlIlIll(item2.type, item.type) || ClassWriter.llIlIIlII(item.isEqualTo(item2) ? 1 : 0))) {
            item2 = item2.next;
            "".length();
            if (" ".length() < (0x47 ^ 0x43)) continue;
            return null;
        }
        return item2;
    }

    private void put(Item item) {
        int n;
        if (ClassWriter.llIlIIlIl(this.index + this.typeCount, this.threshold)) {
            n = this.items.length;
            int n2 = n * 2 + 1;
            Item[] itemArray = new Item[n2];
            int n3 = n - 1;
            while (ClassWriter.llIllIlII(n3)) {
                Item item2 = this.items[n3];
                while (ClassWriter.llIlIIIII(item2)) {
                    int n4 = item2.hashCode % itemArray.length;
                    Item item3 = item2.next;
                    item2.next = itemArray[n4];
                    itemArray[n4] = item2;
                    item2 = item3;
                    "".length();
                    if (-"   ".length() <= 0) continue;
                    return;
                }
                --n3;
                "".length();
                if (("   ".length() ^ (0x54 ^ 0x52)) != 0) continue;
                return;
            }
            this.items = itemArray;
            this.threshold = (int)((double)n2 * 0.75);
        }
        n = item.hashCode % this.items.length;
        item.next = this.items[n];
        this.items[n] = item;
    }

    private void put122(int n, int n2, int n3) {
        this.pool.put12(n, n2).putShort(n3);
        "".length();
    }

    private void put112(int n, int n2, int n3) {
        this.pool.put11(n, n2).putShort(n3);
        "".length();
    }

    static {
        block1: {
            ACC_SYNTHETIC_ATTRIBUTE = 262144;
            COMPUTE_MAXS = 1;
            METH = 10;
            UTF8 = 1;
            DOUBLE = 6;
            INDY = 18;
            COMPUTE_FRAMES = 2;
            STR = 8;
            TABL_INSN = 14;
            IINC_INSN = 13;
            TYPE_MERGED = 32;
            FIELDORMETH_INSN = 6;
            SHORT_INSN = 2;
            VAR_INSN = 3;
            INDYMETH_INSN = 8;
            MTYPE = 16;
            TYPE_INSN = 5;
            MANA_INSN = 16;
            WIDE_INSN = 17;
            TYPE_UNINIT = 31;
            IMPLVAR_INSN = 4;
            ITFMETH_INSN = 7;
            SBYTE_INSN = 1;
            ASM_LABEL_INSN = 18;
            FIELD = 9;
            LONG = 5;
            HANDLE_BASE = 20;
            IMETH = 11;
            TYPE_NORMAL = 30;
            LDC_INSN = 11;
            INT = 3;
            BSM = 33;
            LABEL_INSN = 9;
            NAME_TYPE = 12;
            HANDLE = 15;
            LABELW_INSN = 10;
            FLOAT = 4;
            LOOK_INSN = 15;
            CLASS = 7;
            NOARG_INSN = 0;
            F_INSERT = 256;
            TO_ACC_SYNTHETIC = 64;
            LDCW_INSN = 12;
            byte[] byArray = new byte[220];
            String string = "AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKSSSSSSSSSSSSSSSSSS";
            int n = 0;
            while (ClassWriter.llIlIIIll(n, byArray.length)) {
                byArray[n] = (byte)(string.charAt(n) - 65);
                ++n;
                "".length();
                if (((195 + 140 - 225 + 105 ^ 70 + 65 - 73 + 67) & (0xDD ^ 0xBB ^ (0x68 ^ 0x58) ^ -" ".length())) == 0) continue;
                break block1;
            }
            TYPE = byArray;
        }
    }

    private static boolean llIlIlIll(int n, int n2) {
        return n == n2;
    }

    private static boolean llIlIIllI(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIlIIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIlllI(int n, int n2) {
        return n <= n2;
    }

    private static boolean llIlIIlIl(int n, int n2) {
        return n > n2;
    }

    private static boolean llIlIIIII(Object object) {
        return object != null;
    }

    private static boolean llIlIIIIl(Object object) {
        return object == null;
    }

    private static boolean llIIlllll(int n) {
        return n != 0;
    }

    private static boolean llIlIIlII(int n) {
        return n == 0;
    }

    private static boolean llIllIlII(int n) {
        return n >= 0;
    }

    private static boolean llIlIIIlI(int n) {
        return n > 0;
    }

    private static boolean llIlIllll(int n, int n2) {
        return n != n2;
    }
}

