/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.Frame;
import org.spongepowered.asm.lib.Item;

class CurrentFrame
extends Frame {
    CurrentFrame() {
    }

    void execute(int n, int n2, ClassWriter classWriter, Item item) {
        super.execute(n, n2, classWriter, item);
        Frame frame = new Frame();
        this.merge(classWriter, frame, 0);
        "".length();
        this.set(frame);
        this.owner.inputStackTop = 0;
    }
}

