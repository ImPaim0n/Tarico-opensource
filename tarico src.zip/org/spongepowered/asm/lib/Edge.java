/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.Label;

class Edge {
    static final int NORMAL;
    static final int EXCEPTION;
    int info;
    Label successor;
    Edge next;

    Edge() {
    }

    static {
        EXCEPTION = Integer.MAX_VALUE;
        NORMAL = 0;
    }
}

