/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.TypePath;

public abstract class FieldVisitor {
    protected final int api;
    protected FieldVisitor fv;

    public FieldVisitor(int n) {
        this(n, null);
    }

    public FieldVisitor(int n, FieldVisitor fieldVisitor) {
        if (FieldVisitor.llIIIlllIlI(n, 262144) && FieldVisitor.llIIIlllIlI(n, 327680)) {
            throw new IllegalArgumentException();
        }
        this.api = n;
        this.fv = fieldVisitor;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        if (FieldVisitor.llIIIlllIll(this.fv)) {
            return this.fv.visitAnnotation(string, bl);
        }
        return null;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        if (FieldVisitor.llIIIllllII(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (FieldVisitor.llIIIlllIll(this.fv)) {
            return this.fv.visitTypeAnnotation(n, typePath, string, bl);
        }
        return null;
    }

    public void visitAttribute(Attribute attribute) {
        if (FieldVisitor.llIIIlllIll(this.fv)) {
            this.fv.visitAttribute(attribute);
        }
    }

    public void visitEnd() {
        if (FieldVisitor.llIIIlllIll(this.fv)) {
            this.fv.visitEnd();
        }
    }

    private static boolean llIIIllllII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIIIlllIll(Object object) {
        return object != null;
    }

    private static boolean llIIIlllIlI(int n, int n2) {
        return n != n2;
    }
}

