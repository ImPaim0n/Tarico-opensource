/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.Item;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;

class Frame {
    static final int DIM;
    static final int ARRAY_OF;
    static final int ELEMENT_OF;
    static final int KIND;
    static final int TOP_IF_LONG_OR_DOUBLE;
    static final int VALUE;
    static final int BASE_KIND;
    static final int BASE_VALUE;
    static final int BASE;
    static final int OBJECT;
    static final int UNINITIALIZED;
    private static final int LOCAL;
    private static final int STACK;
    static final int TOP;
    static final int BOOLEAN;
    static final int BYTE;
    static final int CHAR;
    static final int SHORT;
    static final int INTEGER;
    static final int FLOAT;
    static final int DOUBLE;
    static final int LONG;
    static final int NULL;
    static final int UNINITIALIZED_THIS;
    static final int[] SIZE;
    Label owner;
    int[] inputLocals;
    int[] inputStack;
    private int[] outputLocals;
    private int[] outputStack;
    int outputStackTop;
    private int initializationCount;
    private int[] initializations;

    Frame() {
    }

    final void set(ClassWriter classWriter, int n, Object[] objectArray, int n2, Object[] objectArray2) {
        int n3 = Frame.convert(classWriter, n, objectArray, this.inputLocals);
        while (Frame.lIllllIIlI(n3, objectArray.length)) {
            this.inputLocals[n3++] = 0x1000000;
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return;
        }
        int n4 = 0;
        int n5 = 0;
        while (Frame.lIllllIIlI(n5, n2)) {
            if (!Frame.lIllllIIll(objectArray2[n5], Opcodes.LONG) || Frame.lIllllIlII(objectArray2[n5], Opcodes.DOUBLE)) {
                ++n4;
            }
            ++n5;
            "".length();
            if (((0x53 ^ 0x1E) & ~(0x2C ^ 0x61)) != (0xBA ^ 0xBE)) continue;
            return;
        }
        this.inputStack = new int[n2 + n4];
        Frame.convert(classWriter, n2, objectArray2, this.inputStack);
        "".length();
        this.outputStackTop = 0;
        this.initializationCount = 0;
    }

    private static int convert(ClassWriter classWriter, int n, Object[] objectArray, int[] nArray) {
        int n2 = 0;
        int n3 = 0;
        while (Frame.lIllllIIlI(n3, n)) {
            if (Frame.lIllllIlIl(objectArray[n3] instanceof Integer)) {
                nArray[n2++] = 0x1000000 | (Integer)objectArray[n3];
                if (!Frame.lIllllIIll(objectArray[n3], Opcodes.LONG) || Frame.lIllllIlII(objectArray[n3], Opcodes.DOUBLE)) {
                    nArray[n2++] = 0x1000000;
                    "".length();
                    if (((94 + 114 - -18 + 3 ^ 114 + 57 - 10 + 37) & (0x9A ^ 0x9E ^ (0x6B ^ 0x4C) ^ -" ".length())) != 0) {
                        return (0xF ^ 0x38 ^ (0xB ^ 7)) & (89 + 41 - 15 + 35 ^ 135 + 49 - 137 + 126 ^ -" ".length());
                    }
                }
            } else if (Frame.lIllllIlIl(objectArray[n3] instanceof String)) {
                nArray[n2++] = Frame.type(classWriter, Type.getObjectType((String)objectArray[n3]).getDescriptor());
                "".length();
                if (null != null) {
                    return (0x6A ^ 0x7C) & ~(0x83 ^ 0x95);
                }
            } else {
                nArray[n2++] = 0x1800000 | classWriter.addUninitializedType("", ((Label)objectArray[n3]).position);
            }
            ++n3;
            "".length();
            if ("  ".length() > " ".length()) continue;
            return (8 ^ 0xF) & ~(0x56 ^ 0x51);
        }
        return n2;
    }

    final void set(Frame frame) {
        this.inputLocals = frame.inputLocals;
        this.inputStack = frame.inputStack;
        this.outputLocals = frame.outputLocals;
        this.outputStack = frame.outputStack;
        this.outputStackTop = frame.outputStackTop;
        this.initializationCount = frame.initializationCount;
        this.initializations = frame.initializations;
    }

    private int get(int n) {
        if (!Frame.lIllllIllI(this.outputLocals) || Frame.lIllllIlll(n, this.outputLocals.length)) {
            return 0x2000000 | n;
        }
        int n2 = this.outputLocals[n];
        if (Frame.lIlllllIII(n2)) {
            n2 = this.outputLocals[n] = 0x2000000 | n;
        }
        return n2;
    }

    private void set(int n, int n2) {
        int n3;
        if (Frame.lIlllllIIl(this.outputLocals)) {
            this.outputLocals = new int[10];
        }
        if (Frame.lIllllIlll(n, n3 = this.outputLocals.length)) {
            int[] nArray = new int[Math.max(n + 1, 2 * n3)];
            System.arraycopy(this.outputLocals, 0, nArray, 0, n3);
            this.outputLocals = nArray;
        }
        this.outputLocals[n] = n2;
    }

    private void push(int n) {
        int n2;
        if (Frame.lIlllllIIl(this.outputStack)) {
            this.outputStack = new int[10];
        }
        if (Frame.lIllllIlll(this.outputStackTop, n2 = this.outputStack.length)) {
            int[] nArray = new int[Math.max(this.outputStackTop + 1, 2 * n2)];
            System.arraycopy(this.outputStack, 0, nArray, 0, n2);
            this.outputStack = nArray;
        }
        this.outputStack[this.outputStackTop++] = n;
        int n3 = this.owner.inputStackTop + this.outputStackTop;
        if (Frame.lIlllllIlI(n3, this.owner.outputStackMax)) {
            this.owner.outputStackMax = n3;
        }
    }

    private void push(ClassWriter classWriter, String string) {
        int n = Frame.type(classWriter, string);
        if (Frame.lIllllIlIl(n)) {
            this.push(n);
            if (!Frame.lIlllllIll(n, 0x1000004) || Frame.lIllllllII(n, 0x1000003)) {
                this.push(0x1000000);
            }
        }
    }

    private static int type(ClassWriter classWriter, String string) {
        int n;
        int n2;
        if (Frame.lIllllllII(string.charAt(0), 40)) {
            n2 = string.indexOf(41) + 1;
            "".length();
            if (" ".length() == "   ".length()) {
                return (0x57 ^ 0x71 ^ (0x59 ^ 0x31)) & (143 + 189 - 310 + 220 ^ 45 + 81 - 55 + 117 ^ -" ".length());
            }
        } else {
            n2 = 0;
        }
        int n3 = n2;
        switch (string.charAt(n3)) {
            case 'V': {
                return 0;
            }
            case 'B': 
            case 'C': 
            case 'I': 
            case 'S': 
            case 'Z': {
                return 0x1000001;
            }
            case 'F': {
                return 0x1000002;
            }
            case 'J': {
                return 0x1000004;
            }
            case 'D': {
                return 0x1000003;
            }
            case 'L': {
                String string2 = string.substring(n3 + 1, string.length() - 1);
                return 0x1700000 | classWriter.addType(string2);
            }
        }
        int n4 = n3 + 1;
        while (Frame.lIllllllII(string.charAt(n4), 91)) {
            ++n4;
            "".length();
            if (" ".length() >= 0) continue;
            return (0x89 ^ 0xBA) & ~(3 ^ 0x30);
        }
        switch (string.charAt(n4)) {
            case 'Z': {
                n = 0x1000009;
                "".length();
                if ((29 + 124 - 115 + 96 ^ 58 + 6 - -39 + 27) == (87 + 39 - 22 + 60 ^ 92 + 92 - 84 + 60)) break;
                return (0xD9 ^ 0xB5 ^ (0xA7 ^ 0x84)) & (128 + 120 - 242 + 130 ^ 109 + 95 - 20 + 15 ^ -" ".length());
            }
            case 'C': {
                n = 0x100000B;
                "".length();
                if (" ".length() <= " ".length()) break;
                return (0xC6 ^ 0xAC ^ (0x4D ^ 0x37)) & (0x36 ^ 0x4E ^ (0x1D ^ 0x75) ^ -" ".length());
            }
            case 'B': {
                n = 0x100000A;
                "".length();
                if (" ".length() > 0) break;
                return (0xFB ^ 0xC5) & ~(0x52 ^ 0x6C);
            }
            case 'S': {
                n = 0x100000C;
                "".length();
                if (-" ".length() <= 0) break;
                return (0xDE ^ 0x98) & ~(0x18 ^ 0x5E);
            }
            case 'I': {
                n = 0x1000001;
                "".length();
                if (null == null) break;
                return (0xD3 ^ 0xB1) & ~(0xDD ^ 0xBF);
            }
            case 'F': {
                n = 0x1000002;
                "".length();
                if (null == null) break;
                return (0x88 ^ 0xC0) & ~(0x78 ^ 0x30);
            }
            case 'J': {
                n = 0x1000004;
                "".length();
                if (" ".length() == " ".length()) break;
                return (116 + 179 - 252 + 146 ^ 12 + 99 - 12 + 46) & (0x1F ^ 0x4C ^ 87 + 57 - 122 + 105 ^ -" ".length());
            }
            case 'D': {
                n = 0x1000003;
                "".length();
                if ("   ".length() <= "   ".length()) break;
                return (0x59 ^ 0x50 ^ (0xA5 ^ 0x85)) & (0x3C ^ 1 ^ (0x15 ^ 1) ^ -" ".length());
            }
            default: {
                String string3 = string.substring(n4 + 1, string.length() - 1);
                n = 0x1700000 | classWriter.addType(string3);
            }
        }
        return n4 - n3 << 28 | n;
    }

    private int pop() {
        if (Frame.lIllllllIl(this.outputStackTop)) {
            return this.outputStack[--this.outputStackTop];
        }
        return 0x3000000 | -(--this.owner.inputStackTop);
    }

    private void pop(int n) {
        if (Frame.lIllllIlll(this.outputStackTop, n)) {
            this.outputStackTop -= n;
            "".length();
            if (-" ".length() >= 0) {
                return;
            }
        } else {
            this.owner.inputStackTop -= n - this.outputStackTop;
            this.outputStackTop = 0;
        }
    }

    private void pop(String string) {
        char c = string.charAt(0);
        if (Frame.lIllllllII(c, 40)) {
            this.pop((Type.getArgumentsAndReturnSizes(string) >> 2) - 1);
            "".length();
            if ((0x81 ^ 0x85) < -" ".length()) {
                return;
            }
        } else if (!Frame.lIlllllIll(c, 74) || Frame.lIllllllII(c, 68)) {
            this.pop(2);
            "".length();
            if ("   ".length() <= 0) {
                return;
            }
        } else {
            this.pop(1);
        }
    }

    private void init(int n) {
        int n2;
        if (Frame.lIlllllIIl(this.initializations)) {
            this.initializations = new int[2];
        }
        if (Frame.lIllllIlll(this.initializationCount, n2 = this.initializations.length)) {
            int[] nArray = new int[Math.max(this.initializationCount + 1, 2 * n2)];
            System.arraycopy(this.initializations, 0, nArray, 0, n2);
            this.initializations = nArray;
        }
        this.initializations[this.initializationCount++] = n;
    }

    private int init(ClassWriter classWriter, int n) {
        int n2;
        if (Frame.lIllllllII(n, 0x1000006)) {
            n2 = 0x1700000 | classWriter.addType(classWriter.thisName);
            "".length();
            if (-(0x46 ^ 0x42) >= 0) {
                return (0x37 ^ 0x2F) & ~(0x61 ^ 0x79);
            }
        } else if (Frame.lIllllllII(n & 0xFFF00000, 0x1800000)) {
            String string = classWriter.typeTable[n & 0xFFFFF].strVal1;
            n2 = 0x1700000 | classWriter.addType(string);
            "".length();
            if ("  ".length() < 0) {
                return (0xD ^ 0x11) & ~(0x49 ^ 0x55);
            }
        } else {
            return n;
        }
        int n3 = 0;
        while (Frame.lIllllIIlI(n3, this.initializationCount)) {
            int n4 = this.initializations[n3];
            int n5 = n4 & 0xF0000000;
            int n6 = n4 & 0xF000000;
            if (Frame.lIllllllII(n6, 0x2000000)) {
                n4 = n5 + this.inputLocals[n4 & 0x7FFFFF];
                "".length();
                if ((0x37 ^ 0x6A ^ (0x4A ^ 0x13)) > (0x79 ^ 0x68 ^ (0x9E ^ 0x8B))) {
                    return (0xF5 ^ 0x9C ^ (0xF3 ^ 0xB5)) & (148 + 10 - 89 + 113 ^ 80 + 85 - 87 + 75 ^ -" ".length());
                }
            } else if (Frame.lIllllllII(n6, 0x3000000)) {
                n4 = n5 + this.inputStack[this.inputStack.length - (n4 & 0x7FFFFF)];
            }
            if (Frame.lIllllllII(n, n4)) {
                return n2;
            }
            ++n3;
            "".length();
            if ((0x59 ^ 0x25 ^ (0x68 ^ 0x10)) >= " ".length()) continue;
            return (120 + 79 - 186 + 136 ^ 57 + 124 - 35 + 9) & (65 + 103 - 128 + 144 ^ 76 + 14 - -18 + 74 ^ -" ".length());
        }
        return n;
    }

    final void initInputFrame(ClassWriter classWriter, int n, Type[] typeArray, int n2) {
        this.inputLocals = new int[n2];
        this.inputStack = new int[0];
        int n3 = 0;
        if (Frame.lIlllllIII(n & 8)) {
            if (Frame.lIlllllIII(n & 0x80000)) {
                this.inputLocals[n3++] = 0x1700000 | classWriter.addType(classWriter.thisName);
                "".length();
                if ("  ".length() < "  ".length()) {
                    return;
                }
            } else {
                this.inputLocals[n3++] = 0x1000006;
            }
        }
        int n4 = 0;
        while (Frame.lIllllIIlI(n4, typeArray.length)) {
            int n5 = Frame.type(classWriter, typeArray[n4].getDescriptor());
            this.inputLocals[n3++] = n5;
            if (!Frame.lIlllllIll(n5, 0x1000004) || Frame.lIllllllII(n5, 0x1000003)) {
                this.inputLocals[n3++] = 0x1000000;
            }
            ++n4;
            "".length();
            if (null == null) continue;
            return;
        }
        while (Frame.lIllllIIlI(n3, n2)) {
            this.inputLocals[n3++] = 0x1000000;
            "".length();
            if (((176 + 66 - 80 + 40 ^ 92 + 184 - 248 + 165) & (0x54 ^ 0x58 ^ (0x4C ^ 0x4B) ^ -" ".length())) == 0) continue;
            return;
        }
    }

    void execute(int n, int n2, ClassWriter classWriter, Item item) {
        block0 : switch (n) {
            case 0: 
            case 116: 
            case 117: 
            case 118: 
            case 119: 
            case 145: 
            case 146: 
            case 147: 
            case 167: 
            case 177: {
                "".length();
                if ("  ".length() == "  ".length()) break;
                return;
            }
            case 1: {
                this.push(0x1000005);
                "".length();
                if (-" ".length() >= -" ".length()) break;
                return;
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 16: 
            case 17: 
            case 21: {
                this.push(0x1000001);
                "".length();
                if ("   ".length() >= 0) break;
                return;
            }
            case 9: 
            case 10: 
            case 22: {
                this.push(0x1000004);
                this.push(0x1000000);
                "".length();
                if (null == null) break;
                return;
            }
            case 11: 
            case 12: 
            case 13: 
            case 23: {
                this.push(0x1000002);
                "".length();
                if (null == null) break;
                return;
            }
            case 14: 
            case 15: 
            case 24: {
                this.push(0x1000003);
                this.push(0x1000000);
                "".length();
                if ((0xA0 ^ 0xA5) != 0) break;
                return;
            }
            case 18: {
                switch (item.type) {
                    case 3: {
                        this.push(0x1000001);
                        "".length();
                        if (" ".length() > 0) break block0;
                        return;
                    }
                    case 5: {
                        this.push(0x1000004);
                        this.push(0x1000000);
                        "".length();
                        if ("  ".length() > " ".length()) break block0;
                        return;
                    }
                    case 4: {
                        this.push(0x1000002);
                        "".length();
                        if (-" ".length() <= ((0x3C ^ 0x6A ^ (0xF1 ^ 0xA2)) & (133 + 16 - -24 + 8 ^ 154 + 26 - 99 + 95 ^ -" ".length()))) break block0;
                        return;
                    }
                    case 6: {
                        this.push(0x1000003);
                        this.push(0x1000000);
                        "".length();
                        if ("   ".length() <= (3 ^ 7)) break block0;
                        return;
                    }
                    case 7: {
                        this.push(0x1700000 | classWriter.addType("java/lang/Class"));
                        "".length();
                        if (null == null) break block0;
                        return;
                    }
                    case 8: {
                        this.push(0x1700000 | classWriter.addType("java/lang/String"));
                        "".length();
                        if ("  ".length() < (0x22 ^ 0x26)) break block0;
                        return;
                    }
                    case 16: {
                        this.push(0x1700000 | classWriter.addType("java/lang/invoke/MethodType"));
                        "".length();
                        if (-" ".length() == -" ".length()) break block0;
                        return;
                    }
                    default: {
                        this.push(0x1700000 | classWriter.addType("java/lang/invoke/MethodHandle"));
                        "".length();
                        if (((240 + 232 - 340 + 115 ^ 67 + 120 - 84 + 74) & (28 + 142 - 15 + 37 ^ 106 + 130 - 208 + 106 ^ -" ".length())) < "  ".length()) break block0;
                        return;
                    }
                }
            }
            case 25: {
                this.push(this.get(n2));
                "".length();
                if ("  ".length() <= "   ".length()) break;
                return;
            }
            case 46: 
            case 51: 
            case 52: 
            case 53: {
                this.pop(2);
                this.push(0x1000001);
                "".length();
                if (" ".length() != 0) break;
                return;
            }
            case 47: 
            case 143: {
                this.pop(2);
                this.push(0x1000004);
                this.push(0x1000000);
                "".length();
                if ((0x13 ^ 0x17) <= (0x13 ^ 0x17)) break;
                return;
            }
            case 48: {
                this.pop(2);
                this.push(0x1000002);
                "".length();
                if (((0x67 ^ 0xF ^ (0x7A ^ 0x47)) & (0x64 ^ 0x44 ^ (0xC8 ^ 0xBD) ^ -" ".length())) == 0) break;
                return;
            }
            case 49: 
            case 138: {
                this.pop(2);
                this.push(0x1000003);
                this.push(0x1000000);
                "".length();
                if (-"   ".length() < 0) break;
                return;
            }
            case 50: {
                this.pop(1);
                int n3 = this.pop();
                this.push(-268435456 + n3);
                "".length();
                if ("  ".length() > -" ".length()) break;
                return;
            }
            case 54: 
            case 56: 
            case 58: {
                int n4 = this.pop();
                this.set(n2, n4);
                if (!Frame.lIllllllIl(n2)) break;
                int n5 = this.get(n2 - 1);
                if (!Frame.lIlllllIll(n5, 0x1000004) || Frame.lIllllllII(n5, 0x1000003)) {
                    this.set(n2 - 1, 0x1000000);
                    "".length();
                    if (" ".length() >= -" ".length()) break;
                    return;
                }
                if (!Frame.lIlllllIll(n5 & 0xF000000, 0x1000000)) break;
                this.set(n2 - 1, n5 | 0x800000);
                "".length();
                if ("  ".length() >= 0) break;
                return;
            }
            case 55: 
            case 57: {
                this.pop(1);
                int n6 = this.pop();
                this.set(n2, n6);
                this.set(n2 + 1, 0x1000000);
                if (!Frame.lIllllllIl(n2)) break;
                int n7 = this.get(n2 - 1);
                if (!Frame.lIlllllIll(n7, 0x1000004) || Frame.lIllllllII(n7, 0x1000003)) {
                    this.set(n2 - 1, 0x1000000);
                    "".length();
                    if (-" ".length() < (0x71 ^ 0x7D ^ (5 ^ 0xD))) break;
                    return;
                }
                if (!Frame.lIlllllIll(n7 & 0xF000000, 0x1000000)) break;
                this.set(n2 - 1, n7 | 0x800000);
                "".length();
                if (((0x87 ^ 0x89 ^ (0x26 ^ 0x31)) & (0xF4 ^ 0xB3 ^ (0x5E ^ 0) ^ -" ".length())) == 0) break;
                return;
            }
            case 79: 
            case 81: 
            case 83: 
            case 84: 
            case 85: 
            case 86: {
                this.pop(3);
                "".length();
                if ("  ".length() >= -" ".length()) break;
                return;
            }
            case 80: 
            case 82: {
                this.pop(4);
                "".length();
                if (-" ".length() < ((0xF8 ^ 0xB5) & ~(0x8E ^ 0xC3))) break;
                return;
            }
            case 87: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 170: 
            case 171: 
            case 172: 
            case 174: 
            case 176: 
            case 191: 
            case 194: 
            case 195: 
            case 198: 
            case 199: {
                this.pop(1);
                "".length();
                if (null == null) break;
                return;
            }
            case 88: 
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: 
            case 165: 
            case 166: 
            case 173: 
            case 175: {
                this.pop(2);
                "".length();
                if ("   ".length() >= 0) break;
                return;
            }
            case 89: {
                int n8 = this.pop();
                this.push(n8);
                this.push(n8);
                "".length();
                if (-" ".length() == -" ".length()) break;
                return;
            }
            case 90: {
                int n9 = this.pop();
                int n10 = this.pop();
                this.push(n9);
                this.push(n10);
                this.push(n9);
                "".length();
                if (-"  ".length() < 0) break;
                return;
            }
            case 91: {
                int n11 = this.pop();
                int n12 = this.pop();
                int n13 = this.pop();
                this.push(n11);
                this.push(n13);
                this.push(n12);
                this.push(n11);
                "".length();
                if (" ".length() > 0) break;
                return;
            }
            case 92: {
                int n14 = this.pop();
                int n15 = this.pop();
                this.push(n15);
                this.push(n14);
                this.push(n15);
                this.push(n14);
                "".length();
                if ("  ".length() != 0) break;
                return;
            }
            case 93: {
                int n16 = this.pop();
                int n17 = this.pop();
                int n18 = this.pop();
                this.push(n17);
                this.push(n16);
                this.push(n18);
                this.push(n17);
                this.push(n16);
                "".length();
                if (" ".length() >= ((0x71 ^ 0x79) & ~(0xB6 ^ 0xBE))) break;
                return;
            }
            case 94: {
                int n19 = this.pop();
                int n20 = this.pop();
                int n21 = this.pop();
                int n22 = this.pop();
                this.push(n20);
                this.push(n19);
                this.push(n22);
                this.push(n21);
                this.push(n20);
                this.push(n19);
                "".length();
                if ("  ".length() != 0) break;
                return;
            }
            case 95: {
                int n23 = this.pop();
                int n24 = this.pop();
                this.push(n23);
                this.push(n24);
                "".length();
                if ("   ".length() <= (0x1F ^ 0x2D ^ (0xB0 ^ 0x86))) break;
                return;
            }
            case 96: 
            case 100: 
            case 104: 
            case 108: 
            case 112: 
            case 120: 
            case 122: 
            case 124: 
            case 126: 
            case 128: 
            case 130: 
            case 136: 
            case 142: 
            case 149: 
            case 150: {
                this.pop(2);
                this.push(0x1000001);
                "".length();
                if ("   ".length() == "   ".length()) break;
                return;
            }
            case 97: 
            case 101: 
            case 105: 
            case 109: 
            case 113: 
            case 127: 
            case 129: 
            case 131: {
                this.pop(4);
                this.push(0x1000004);
                this.push(0x1000000);
                "".length();
                if ("  ".length() < "   ".length()) break;
                return;
            }
            case 98: 
            case 102: 
            case 106: 
            case 110: 
            case 114: 
            case 137: 
            case 144: {
                this.pop(2);
                this.push(0x1000002);
                "".length();
                if (null == null) break;
                return;
            }
            case 99: 
            case 103: 
            case 107: 
            case 111: 
            case 115: {
                this.pop(4);
                this.push(0x1000003);
                this.push(0x1000000);
                "".length();
                if (" ".length() < "   ".length()) break;
                return;
            }
            case 121: 
            case 123: 
            case 125: {
                this.pop(3);
                this.push(0x1000004);
                this.push(0x1000000);
                "".length();
                if ((0x64 ^ 0x29 ^ (0xCB ^ 0x83)) > 0) break;
                return;
            }
            case 132: {
                this.set(n2, 0x1000001);
                "".length();
                if ("  ".length() >= 0) break;
                return;
            }
            case 133: 
            case 140: {
                this.pop(1);
                this.push(0x1000004);
                this.push(0x1000000);
                "".length();
                if ("   ".length() > "  ".length()) break;
                return;
            }
            case 134: {
                this.pop(1);
                this.push(0x1000002);
                "".length();
                if (null == null) break;
                return;
            }
            case 135: 
            case 141: {
                this.pop(1);
                this.push(0x1000003);
                this.push(0x1000000);
                "".length();
                if (((0x79 ^ 0x47) & ~(0x5C ^ 0x62)) == 0) break;
                return;
            }
            case 139: 
            case 190: 
            case 193: {
                this.pop(1);
                this.push(0x1000001);
                "".length();
                if ("  ".length() >= ((0x17 ^ 4) & ~(0x41 ^ 0x52))) break;
                return;
            }
            case 148: 
            case 151: 
            case 152: {
                this.pop(4);
                this.push(0x1000001);
                "".length();
                if ((0xB1 ^ 0xB4) > 0) break;
                return;
            }
            case 168: 
            case 169: {
                throw new RuntimeException("JSR/RET are not supported with computeFrames option");
            }
            case 178: {
                this.push(classWriter, item.strVal3);
                "".length();
                if (" ".length() >= -" ".length()) break;
                return;
            }
            case 179: {
                this.pop(item.strVal3);
                "".length();
                if (" ".length() >= 0) break;
                return;
            }
            case 180: {
                this.pop(1);
                this.push(classWriter, item.strVal3);
                "".length();
                if (-" ".length() <= 0) break;
                return;
            }
            case 181: {
                this.pop(item.strVal3);
                this.pop();
                "".length();
                "".length();
                if ((6 ^ 2) > " ".length()) break;
                return;
            }
            case 182: 
            case 183: 
            case 184: 
            case 185: {
                this.pop(item.strVal3);
                if (Frame.lIlllllIll(n, 184)) {
                    int n25 = this.pop();
                    if (Frame.lIllllllII(n, 183) && Frame.lIllllllII(item.strVal2.charAt(0), 60)) {
                        this.init(n25);
                    }
                }
                this.push(classWriter, item.strVal3);
                "".length();
                if (-(0x49 ^ 0x40 ^ (0x8E ^ 0x83)) <= 0) break;
                return;
            }
            case 186: {
                this.pop(item.strVal2);
                this.push(classWriter, item.strVal2);
                "".length();
                if (-" ".length() < 0) break;
                return;
            }
            case 187: {
                this.push(0x1800000 | classWriter.addUninitializedType(item.strVal1, n2));
                "".length();
                if (-" ".length() == -" ".length()) break;
                return;
            }
            case 188: {
                this.pop();
                "".length();
                switch (n2) {
                    case 4: {
                        this.push(0x11000009);
                        "".length();
                        if (-(0xD4 ^ 0xBC ^ (0x41 ^ 0x2D)) < 0) break block0;
                        return;
                    }
                    case 5: {
                        this.push(0x1100000B);
                        "".length();
                        if ((3 ^ 7) != 0) break block0;
                        return;
                    }
                    case 8: {
                        this.push(0x1100000A);
                        "".length();
                        if ((0x72 ^ 0x76) > 0) break block0;
                        return;
                    }
                    case 9: {
                        this.push(0x1100000C);
                        "".length();
                        if ((0xA0 ^ 0xA9 ^ (0xA2 ^ 0xAE)) != 0) break block0;
                        return;
                    }
                    case 10: {
                        this.push(0x11000001);
                        "".length();
                        if (null == null) break block0;
                        return;
                    }
                    case 6: {
                        this.push(0x11000002);
                        "".length();
                        if (-" ".length() < ((0x74 ^ 0x3B) & ~(0xF1 ^ 0xBE))) break block0;
                        return;
                    }
                    case 7: {
                        this.push(0x11000003);
                        "".length();
                        if ("   ".length() != "  ".length()) break block0;
                        return;
                    }
                    default: {
                        this.push(0x11000004);
                        "".length();
                        if ("  ".length() != " ".length()) break block0;
                        return;
                    }
                }
            }
            case 189: {
                String string = item.strVal1;
                this.pop();
                "".length();
                if (Frame.lIllllllII(string.charAt(0), 91)) {
                    this.push(classWriter, String.valueOf(new StringBuilder().append('[').append(string)));
                    "".length();
                    if (-" ".length() < "   ".length()) break;
                    return;
                }
                this.push(0x11700000 | classWriter.addType(string));
                "".length();
                if (null == null) break;
                return;
            }
            case 192: {
                String string = item.strVal1;
                this.pop();
                "".length();
                if (Frame.lIllllllII(string.charAt(0), 91)) {
                    this.push(classWriter, string);
                    "".length();
                    if (null == null) break;
                    return;
                }
                this.push(0x1700000 | classWriter.addType(string));
                "".length();
                if (" ".length() != "   ".length()) break;
                return;
            }
            default: {
                this.pop(n2);
                this.push(classWriter, item.strVal1);
            }
        }
    }

    final boolean merge(ClassWriter classWriter, Frame frame, int n) {
        int n2;
        int n3;
        int n4;
        int n5;
        boolean bl = false;
        int n6 = this.inputLocals.length;
        int n7 = this.inputStack.length;
        if (Frame.lIlllllIIl(frame.inputLocals)) {
            frame.inputLocals = new int[n6];
            bl = true;
        }
        int n8 = 0;
        while (Frame.lIllllIIlI(n8, n6)) {
            if (Frame.lIllllIllI(this.outputLocals) && Frame.lIllllIIlI(n8, this.outputLocals.length)) {
                n5 = this.outputLocals[n8];
                if (Frame.lIlllllIII(n5)) {
                    n4 = this.inputLocals[n8];
                    "".length();
                    if ("   ".length() != "   ".length()) {
                        return ((0xE2 ^ 0xA4) & ~(0x3D ^ 0x7B)) != 0;
                    }
                } else {
                    n3 = n5 & 0xF0000000;
                    n2 = n5 & 0xF000000;
                    if (Frame.lIllllllII(n2, 0x1000000)) {
                        n4 = n5;
                        "".length();
                        if ("   ".length() < -" ".length()) {
                            return ((0x89 ^ 0xA6 ^ (0x3E ^ 0x2C)) & (1 ^ 0x2B ^ (4 ^ 0x13) ^ -" ".length())) != 0;
                        }
                    } else {
                        if (Frame.lIllllllII(n2, 0x2000000)) {
                            n4 = n3 + this.inputLocals[n5 & 0x7FFFFF];
                            "".length();
                            if (null != null) {
                                return ((0x1F ^ 5) & ~(0x25 ^ 0x3F)) != 0;
                            }
                        } else {
                            n4 = n3 + this.inputStack[n7 - (n5 & 0x7FFFFF)];
                        }
                        if (Frame.lIllllIlIl(n5 & 0x800000) && (!Frame.lIlllllIll(n4, 0x1000004) || Frame.lIllllllII(n4, 0x1000003))) {
                            n4 = 0x1000000;
                            "".length();
                            if (null != null) {
                                return ("   ".length() & ~"   ".length()) != 0;
                            }
                        }
                    }
                }
            } else {
                n4 = this.inputLocals[n8];
            }
            if (Frame.lIllllIllI(this.initializations)) {
                n4 = this.init(classWriter, n4);
            }
            bl |= Frame.merge(classWriter, n4, frame.inputLocals, n8);
            ++n8;
            "".length();
            if ((0x59 ^ 0x40 ^ (0x63 ^ 0x7F)) > 0) continue;
            return ((101 + 25 - 84 + 101 ^ 115 + 110 - 75 + 16) & (0xFC ^ 0xA9 ^ (0xE ^ 0x72) ^ -" ".length())) != 0;
        }
        if (Frame.lIllllllIl(n)) {
            n8 = 0;
            while (Frame.lIllllIIlI(n8, n6)) {
                n4 = this.inputLocals[n8];
                bl |= Frame.merge(classWriter, n4, frame.inputLocals, n8);
                ++n8;
                "".length();
                if ((154 + 25 - 140 + 137 ^ 153 + 172 - 152 + 7) == (174 + 64 - 118 + 73 ^ 186 + 191 - 268 + 88)) continue;
                return ((0x61 ^ 0x38 ^ (0x25 ^ 0x52)) & (0x5F ^ 0x71 ^ (0x74 ^ 0x72) & ~(0x94 ^ 0x92) ^ -" ".length())) != 0;
            }
            if (Frame.lIlllllIIl(frame.inputStack)) {
                frame.inputStack = new int[1];
                bl = true;
            }
            return bl |= Frame.merge(classWriter, n, frame.inputStack, 0);
        }
        int n9 = this.inputStack.length + this.owner.inputStackTop;
        if (Frame.lIlllllIIl(frame.inputStack)) {
            frame.inputStack = new int[n9 + this.outputStackTop];
            bl = true;
        }
        n8 = 0;
        while (Frame.lIllllIIlI(n8, n9)) {
            n4 = this.inputStack[n8];
            if (Frame.lIllllIllI(this.initializations)) {
                n4 = this.init(classWriter, n4);
            }
            bl |= Frame.merge(classWriter, n4, frame.inputStack, n8);
            ++n8;
            "".length();
            if (-" ".length() < ((0xAA ^ 0xAC) & ~(0x22 ^ 0x24))) continue;
            return ((0x6E ^ 0x7A) & ~(0x3A ^ 0x2E)) != 0;
        }
        n8 = 0;
        while (Frame.lIllllIIlI(n8, this.outputStackTop)) {
            n5 = this.outputStack[n8];
            n3 = n5 & 0xF0000000;
            n2 = n5 & 0xF000000;
            if (Frame.lIllllllII(n2, 0x1000000)) {
                n4 = n5;
                "".length();
                if (null != null) {
                    return ((0x16 ^ 0x62 ^ (0x45 ^ 0x6A)) & (0x42 ^ 0x31 ^ (0x24 ^ 0xC) ^ -" ".length())) != 0;
                }
            } else {
                if (Frame.lIllllllII(n2, 0x2000000)) {
                    n4 = n3 + this.inputLocals[n5 & 0x7FFFFF];
                    "".length();
                    if ("  ".length() <= 0) {
                        return ((0x78 ^ 0x27 ^ (0x2C ^ 0x31)) & ("  ".length() ^ (0x6A ^ 0x2A) ^ -" ".length())) != 0;
                    }
                } else {
                    n4 = n3 + this.inputStack[n7 - (n5 & 0x7FFFFF)];
                }
                if (Frame.lIllllIlIl(n5 & 0x800000) && (!Frame.lIlllllIll(n4, 0x1000004) || Frame.lIllllllII(n4, 0x1000003))) {
                    n4 = 0x1000000;
                }
            }
            if (Frame.lIllllIllI(this.initializations)) {
                n4 = this.init(classWriter, n4);
            }
            bl |= Frame.merge(classWriter, n4, frame.inputStack, n9 + n8);
            ++n8;
            "".length();
            if (((0x57 ^ 2 ^ (0xAE ^ 0x9A)) & (0xD6 ^ 0xAA ^ (0x86 ^ 0x9B) ^ -" ".length())) == 0) continue;
            return ((0x15 ^ 0x32 ^ (0xD5 ^ 0x90)) & (0 ^ 0x77 ^ (0x3D ^ 0x28) ^ -" ".length())) != 0;
        }
        return bl;
    }

    private static boolean merge(ClassWriter classWriter, int n, int[] nArray, int n2) {
        int n3;
        int n4 = nArray[n2];
        if (Frame.lIllllllII(n4, n)) {
            return false;
        }
        if (Frame.lIllllllII(n & 0xFFFFFFF, 0x1000005)) {
            if (Frame.lIllllllII(n4, 0x1000005)) {
                return false;
            }
            n = 0x1000005;
        }
        if (Frame.lIlllllIII(n4)) {
            nArray[n2] = n;
            return true;
        }
        if (!Frame.lIlllllIll(n4 & 0xFF00000, 0x1700000) || Frame.lIllllIlIl(n4 & 0xF0000000)) {
            if (Frame.lIllllllII(n, 0x1000005)) {
                return false;
            }
            if (Frame.lIllllllII(n & 0xFFF00000, n4 & 0xFFF00000)) {
                if (Frame.lIllllllII(n4 & 0xFF00000, 0x1700000)) {
                    n3 = n & 0xF0000000 | 0x1700000 | classWriter.getMergedType(n & 0xFFFFF, n4 & 0xFFFFF);
                    "".length();
                    if (-(0x44 ^ 0x40) >= 0) {
                        return ((0xC1 ^ 0x84) & ~(0x4F ^ 0xA)) != 0;
                    }
                } else {
                    int n5 = -268435456 + (n4 & 0xF0000000);
                    n3 = n5 | 0x1700000 | classWriter.addType("java/lang/Object");
                    "".length();
                    if ("   ".length() == -" ".length()) {
                        return ((0x40 ^ 9) & ~(0xE ^ 0x47)) != 0;
                    }
                }
            } else if (!Frame.lIlllllIll(n & 0xFF00000, 0x1700000) || Frame.lIllllIlIl(n & 0xF0000000)) {
                int n6;
                int n7;
                if (!Frame.lIllllIlIl(n & 0xF0000000) || Frame.lIllllllII(n & 0xFF00000, 0x1700000)) {
                    n7 = 0;
                    "".length();
                    if (((0x44 ^ 0x62 ^ (0x12 ^ 0x63)) & (0xAA ^ 0x93 ^ (0xF2 ^ 0x9C) ^ -" ".length())) != 0) {
                        return ((0xAF ^ 0xA4 ^ (0x4D ^ 0x6D)) & (0xC1 ^ 0x91 ^ (0x7E ^ 5) ^ -" ".length())) != 0;
                    }
                } else {
                    n7 = -268435456;
                }
                int n8 = n7 + (n & 0xF0000000);
                if (!Frame.lIllllIlIl(n4 & 0xF0000000) || Frame.lIllllllII(n4 & 0xFF00000, 0x1700000)) {
                    n6 = 0;
                    "".length();
                    if (-(0x2E ^ 0x2A) >= 0) {
                        return ((0xE1 ^ 0xB0) & ~(0x30 ^ 0x61)) != 0;
                    }
                } else {
                    n6 = -268435456;
                }
                int n9 = n6 + (n4 & 0xF0000000);
                n3 = Math.min(n8, n9) | 0x1700000 | classWriter.addType("java/lang/Object");
                "".length();
                if (-"   ".length() >= 0) {
                    return (" ".length() & ~" ".length()) != 0;
                }
            } else {
                n3 = 0x1000000;
                "".length();
                if (((0xE ^ 0x46) & ~(5 ^ 0x4D)) != 0) {
                    return ((0x6C ^ 0x5A) & ~(0xF5 ^ 0xC3)) != 0;
                }
            }
        } else if (Frame.lIllllllII(n4, 0x1000005)) {
            int n10;
            if (!Frame.lIlllllIll(n & 0xFF00000, 0x1700000) || Frame.lIllllIlIl(n & 0xF0000000)) {
                n10 = n;
                "".length();
                if ((49 + 55 - 32 + 71 ^ 48 + 34 - -53 + 4) < -" ".length()) {
                    return ((177 + 128 - 236 + 164 ^ 85 + 143 - 133 + 81) & (0x9F ^ 0xBF ^ (0x77 ^ 0xE) ^ -" ".length())) != 0;
                }
            } else {
                n10 = 0x1000000;
            }
            n3 = n10;
            "".length();
            if (null != null) {
                return ((0x93 ^ 0xBC ^ (0xF1 ^ 0x87)) & (0x9A ^ 0xB2 ^ (0xE1 ^ 0x90) ^ -" ".length())) != 0;
            }
        } else {
            n3 = 0x1000000;
        }
        if (Frame.lIlllllIll(n4, n3)) {
            nArray[n2] = n3;
            return true;
        }
        return false;
    }

    static {
        block1: {
            STACK = 0x3000000;
            VALUE = 0x7FFFFF;
            DIM = -268435456;
            KIND = 0xF000000;
            BOOLEAN = 0x1000009;
            ARRAY_OF = 0x10000000;
            LONG = 0x1000004;
            DOUBLE = 0x1000003;
            TOP = 0x1000000;
            UNINITIALIZED_THIS = 0x1000006;
            BASE_KIND = 0xFF00000;
            BASE_VALUE = 1048575;
            SHORT = 0x100000C;
            BYTE = 0x100000A;
            BASE = 0x1000000;
            INTEGER = 0x1000001;
            ELEMENT_OF = -268435456;
            CHAR = 0x100000B;
            LOCAL = 0x2000000;
            OBJECT = 0x1700000;
            FLOAT = 0x1000002;
            TOP_IF_LONG_OR_DOUBLE = 0x800000;
            UNINITIALIZED = 0x1800000;
            NULL = 0x1000005;
            int[] nArray = new int[202];
            String string = "EFFFFFFFFGGFFFGGFFFEEFGFGFEEEEEEEEEEEEEEEEEEEEDEDEDDDDDCDCDEEEEEEEEEEEEEEEEEEEEBABABBBBDCFFFGGGEDCDCDCDCDCDCDCDCDCDCEEEEDDDDDDDCDCDCEFEFDDEEFFDEDEEEBDDBBDDDDDDCCCCCCCCEFEDDDCDCDEEEEEEEEEEFEEEEEEDDEEDDEE";
            int n = 0;
            while (Frame.lIllllIIlI(n, nArray.length)) {
                nArray[n] = string.charAt(n) - 69;
                ++n;
                "".length();
                if (-"   ".length() <= 0) continue;
                break block1;
            }
            SIZE = nArray;
        }
    }

    private static boolean lIllllllII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIllllIlll(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIllllIIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlllllIlI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllllIIll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIllllIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIllllIllI(Object object) {
        return object != null;
    }

    private static boolean lIlllllIIl(Object object) {
        return object == null;
    }

    private static boolean lIllllIlIl(int n) {
        return n != 0;
    }

    private static boolean lIlllllIII(int n) {
        return n == 0;
    }

    private static boolean lIllllllIl(int n) {
        return n > 0;
    }

    private static boolean lIlllllIll(int n, int n2) {
        return n != n2;
    }
}

