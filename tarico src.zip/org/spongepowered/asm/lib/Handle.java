/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

public final class Handle {
    final int tag;
    final String owner;
    final String name;
    final String desc;
    final boolean itf;

    @Deprecated
    public Handle(int n, String string, String string2, String string3) {
        boolean bl;
        if (Handle.lllIIIIlIIl(n, 9)) {
            bl = true;
            "".length();
            if ((0xAF ^ 0xAB) < "  ".length()) {
                throw null;
            }
        } else {
            bl = false;
        }
        this(n, string, string2, string3, bl);
    }

    public Handle(int n, String string, String string2, String string3, boolean bl) {
        this.tag = n;
        this.owner = string;
        this.name = string2;
        this.desc = string3;
        this.itf = bl;
    }

    public int getTag() {
        return this.tag;
    }

    public String getOwner() {
        return this.owner;
    }

    public String getName() {
        return this.name;
    }

    public String getDesc() {
        return this.desc;
    }

    public boolean isInterface() {
        return this.itf;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (Handle.lllIIIIlIlI(object, this)) {
            return true;
        }
        if (Handle.lllIIIIlIll(object instanceof Handle)) {
            return false;
        }
        Handle handle = (Handle)object;
        if (Handle.lllIIIIlIIl(this.tag, handle.tag) && Handle.lllIIIIlIIl(this.itf ? 1 : 0, handle.itf ? 1 : 0) && Handle.lllIIIIllII(this.owner.equals(handle.owner) ? 1 : 0) && Handle.lllIIIIllII(this.name.equals(handle.name) ? 1 : 0) && Handle.lllIIIIllII(this.desc.equals(handle.desc) ? 1 : 0)) {
            bl = true;
            "".length();
            if ((0x37 ^ 0x33) < (0xAB ^ 0xAF)) {
                return ((0xA0 ^ 0xB1) & ~(0x7F ^ 0x6E)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        int n;
        if (Handle.lllIIIIllII(this.itf ? 1 : 0)) {
            n = 64;
            "".length();
            if (((0x6D ^ 0x49) & ~(0x72 ^ 0x56)) > 0) {
                return (0xB7 ^ 0x8D) & ~(0xB9 ^ 0x83);
            }
        } else {
            n = 0;
        }
        return this.tag + n + this.owner.hashCode() * this.name.hashCode() * this.desc.hashCode();
    }

    public String toString() {
        String string;
        StringBuilder stringBuilder = new StringBuilder().append(this.owner).append('.').append(this.name).append(this.desc).append(" (").append(this.tag);
        if (Handle.lllIIIIllII(this.itf ? 1 : 0)) {
            string = " itf";
            "".length();
            if ("  ".length() <= -" ".length()) {
                return null;
            }
        } else {
            string = "";
        }
        return String.valueOf(stringBuilder.append(string).append(')'));
    }

    private static boolean lllIIIIlIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIIIIlIlI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIIIIllII(int n) {
        return n != 0;
    }

    private static boolean lllIIIIlIll(int n) {
        return n == 0;
    }
}

