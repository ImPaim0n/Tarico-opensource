/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.Label;

class Handler {
    Label start;
    Label end;
    Label handler;
    String desc;
    int type;
    Handler next;

    Handler() {
    }

    static Handler remove(Handler handler, Label label, Label label2) {
        int n;
        int n2;
        if (Handler.lIIlIIllIIl(handler)) {
            return null;
        }
        handler.next = Handler.remove(handler.next, label, label2);
        int n3 = handler.start.position;
        int n4 = handler.end.position;
        int n5 = label.position;
        if (Handler.lIIlIIllIIl(label2)) {
            n2 = Integer.MAX_VALUE;
            "".length();
            if (" ".length() >= (0x34 ^ 0x15 ^ (0xAC ^ 0x89))) {
                return null;
            }
        } else {
            n2 = n = label2.position;
        }
        if (Handler.lIIlIIllIlI(n5, n4) && Handler.lIIlIIllIll(n, n3)) {
            if (Handler.lIIlIIlllII(n5, n3)) {
                if (Handler.lIIlIIlllIl(n, n4)) {
                    handler = handler.next;
                    "".length();
                    if ("  ".length() < "  ".length()) {
                        return null;
                    }
                } else {
                    handler.start = label2;
                    "".length();
                    if (-" ".length() != -" ".length()) {
                        return null;
                    }
                }
            } else if (Handler.lIIlIIlllIl(n, n4)) {
                handler.end = label;
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                Handler handler2 = new Handler();
                handler2.start = label2;
                handler2.end = handler.end;
                handler2.handler = handler.handler;
                handler2.desc = handler.desc;
                handler2.type = handler.type;
                handler2.next = handler.next;
                handler.end = label;
                handler.next = handler2;
            }
        }
        return handler;
    }

    private static boolean lIIlIIlllIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIlIIllIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIlIIlllII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIlIIllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIlIIllIIl(Object object) {
        return object == null;
    }
}

