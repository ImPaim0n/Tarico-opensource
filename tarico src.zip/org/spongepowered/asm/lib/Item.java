/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

final class Item {
    int index;
    int type;
    int intVal;
    long longVal;
    String strVal1;
    String strVal2;
    String strVal3;
    int hashCode;
    Item next;

    Item() {
    }

    Item(int n) {
        this.index = n;
    }

    Item(int n, Item item) {
        this.index = n;
        this.type = item.type;
        this.intVal = item.intVal;
        this.longVal = item.longVal;
        this.strVal1 = item.strVal1;
        this.strVal2 = item.strVal2;
        this.strVal3 = item.strVal3;
        this.hashCode = item.hashCode;
    }

    void set(int n) {
        this.type = 3;
        this.intVal = n;
        this.hashCode = Integer.MAX_VALUE & this.type + n;
    }

    void set(long l) {
        this.type = 5;
        this.longVal = l;
        this.hashCode = Integer.MAX_VALUE & this.type + (int)l;
    }

    void set(float f) {
        this.type = 4;
        this.intVal = Float.floatToRawIntBits(f);
        this.hashCode = Integer.MAX_VALUE & this.type + (int)f;
    }

    void set(double d) {
        this.type = 6;
        this.longVal = Double.doubleToRawLongBits(d);
        this.hashCode = Integer.MAX_VALUE & this.type + (int)d;
    }

    void set(int n, String string, String string2, String string3) {
        this.type = n;
        this.strVal1 = string;
        this.strVal2 = string2;
        this.strVal3 = string3;
        switch (n) {
            case 7: {
                this.intVal = 0;
            }
            case 1: 
            case 8: 
            case 16: 
            case 30: {
                this.hashCode = Integer.MAX_VALUE & n + string.hashCode();
                return;
            }
            case 12: {
                this.hashCode = Integer.MAX_VALUE & n + string.hashCode() * string2.hashCode();
                return;
            }
        }
        this.hashCode = Integer.MAX_VALUE & n + string.hashCode() * string2.hashCode() * string3.hashCode();
    }

    void set(String string, String string2, int n) {
        this.type = 18;
        this.longVal = n;
        this.strVal1 = string;
        this.strVal2 = string2;
        this.hashCode = Integer.MAX_VALUE & 18 + n * this.strVal1.hashCode() * this.strVal2.hashCode();
    }

    void set(int n, int n2) {
        this.type = 33;
        this.intVal = n;
        this.hashCode = n2;
    }

    boolean isEqualTo(Item item) {
        boolean bl;
        switch (this.type) {
            case 1: 
            case 7: 
            case 8: 
            case 16: 
            case 30: {
                return item.strVal1.equals(this.strVal1);
            }
            case 5: 
            case 6: 
            case 32: {
                boolean bl2;
                if (Item.llIlIlIII(Item.llIlIIlll(item.longVal, this.longVal))) {
                    bl2 = true;
                    "".length();
                    if (-"  ".length() >= 0) {
                        return ((0x1C ^ 0x26 ^ (0xB6 ^ 0x96)) & (99 + 126 - 222 + 133 ^ 25 + 78 - 24 + 67 ^ -" ".length())) != 0;
                    }
                } else {
                    bl2 = false;
                }
                return bl2;
            }
            case 3: 
            case 4: {
                boolean bl3;
                if (Item.llIlIlIIl(item.intVal, this.intVal)) {
                    bl3 = true;
                    "".length();
                    if ("  ".length() < 0) {
                        return ((0x3C ^ 0x7B) & ~(0xE4 ^ 0xA3)) != 0;
                    }
                } else {
                    bl3 = false;
                }
                return bl3;
            }
            case 31: {
                boolean bl4;
                if (Item.llIlIlIIl(item.intVal, this.intVal) && Item.llIlIlIlI(item.strVal1.equals(this.strVal1) ? 1 : 0)) {
                    bl4 = true;
                    "".length();
                    if ((5 ^ 1) <= 0) {
                        return ((0xA2 ^ 0x82) & ~(0x5D ^ 0x7D)) != 0;
                    }
                } else {
                    bl4 = false;
                }
                return bl4;
            }
            case 12: {
                boolean bl5;
                if (Item.llIlIlIlI(item.strVal1.equals(this.strVal1) ? 1 : 0) && Item.llIlIlIlI(item.strVal2.equals(this.strVal2) ? 1 : 0)) {
                    bl5 = true;
                    "".length();
                    if ((80 + 95 - 63 + 21 ^ 10 + 61 - 26 + 84) < ((0x12 ^ 0x56 ^ (0x98 ^ 0x87)) & (62 + 88 - 117 + 124 ^ 35 + 146 - 89 + 106 ^ -" ".length()))) {
                        return ((137 + 83 - 141 + 66 ^ 138 + 128 - 203 + 88) & (137 + 6 - 99 + 113 ^ 150 + 7 - 82 + 80 ^ -" ".length())) != 0;
                    }
                } else {
                    bl5 = false;
                }
                return bl5;
            }
            case 18: {
                boolean bl6;
                if (Item.llIlIlIII(Item.llIlIIlll(item.longVal, this.longVal)) && Item.llIlIlIlI(item.strVal1.equals(this.strVal1) ? 1 : 0) && Item.llIlIlIlI(item.strVal2.equals(this.strVal2) ? 1 : 0)) {
                    bl6 = true;
                    "".length();
                    if (-" ".length() > 0) {
                        return ((0x22 ^ 0x42) & ~(0x64 ^ 4)) != 0;
                    }
                } else {
                    bl6 = false;
                }
                return bl6;
            }
        }
        if (Item.llIlIlIlI(item.strVal1.equals(this.strVal1) ? 1 : 0) && Item.llIlIlIlI(item.strVal2.equals(this.strVal2) ? 1 : 0) && Item.llIlIlIlI(item.strVal3.equals(this.strVal3) ? 1 : 0)) {
            bl = true;
            "".length();
            if ("   ".length() >= (3 ^ 0x6B ^ (0x2D ^ 0x41))) {
                return ((170 + 14 - 102 + 92 ^ 141 + 16 - -5 + 21) & (0x5B ^ 0x2D ^ (0x1B ^ 0x74) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean llIlIlIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean llIlIlIlI(int n) {
        return n != 0;
    }

    private static boolean llIlIlIII(int n) {
        return n == 0;
    }

    private static int llIlIIlll(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }
}

