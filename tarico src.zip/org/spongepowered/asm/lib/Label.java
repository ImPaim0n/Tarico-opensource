/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.ByteVector;
import org.spongepowered.asm.lib.Edge;
import org.spongepowered.asm.lib.Frame;
import org.spongepowered.asm.lib.MethodWriter;

public class Label {
    static final int DEBUG = 1;
    static final int RESOLVED;
    static final int RESIZED;
    static final int PUSHED;
    static final int TARGET;
    static final int STORE;
    static final int REACHABLE;
    static final int JSR;
    static final int RET;
    static final int SUBROUTINE;
    static final int VISITED;
    static final int VISITED2;
    public Object info;
    int status;
    int line;
    int position;
    private int referenceCount;
    private int[] srcAndRefPositions;
    int inputStackTop;
    int outputStackMax;
    Frame frame;
    Label successor;
    Edge successors;
    Label next;

    public int getOffset() {
        if (Label.lIlllllIlIl(this.status & 2)) {
            throw new IllegalStateException("Label offset position has not been resolved yet");
        }
        return this.position;
    }

    void put(MethodWriter methodWriter, ByteVector byteVector, int n, boolean bl) {
        if (Label.lIlllllIlIl(this.status & 2)) {
            if (Label.lIlllllIllI(bl ? 1 : 0)) {
                this.addReference(-1 - n, byteVector.length);
                byteVector.putInt(-1);
                "".length();
                "".length();
                if ((0x80 ^ 0xA1 ^ (0x79 ^ 0x5C)) <= "   ".length()) {
                    return;
                }
            } else {
                this.addReference(n, byteVector.length);
                byteVector.putShort(-1);
                "".length();
                "".length();
                if ("   ".length() <= 0) {
                    return;
                }
            }
        } else if (Label.lIlllllIllI(bl ? 1 : 0)) {
            byteVector.putInt(this.position - n);
            "".length();
            "".length();
            if ("   ".length() <= -" ".length()) {
                return;
            }
        } else {
            byteVector.putShort(this.position - n);
            "".length();
        }
    }

    private void addReference(int n, int n2) {
        if (Label.lIllllllIII(this.srcAndRefPositions)) {
            this.srcAndRefPositions = new int[6];
        }
        if (Label.lIllllllIlI(this.referenceCount, this.srcAndRefPositions.length)) {
            int[] nArray = new int[this.srcAndRefPositions.length + 6];
            System.arraycopy(this.srcAndRefPositions, 0, nArray, 0, this.srcAndRefPositions.length);
            this.srcAndRefPositions = nArray;
        }
        this.srcAndRefPositions[this.referenceCount++] = n;
        this.srcAndRefPositions[this.referenceCount++] = n2;
    }

    boolean resolve(MethodWriter methodWriter, int n, byte[] byArray) {
        boolean bl = false;
        this.status |= 2;
        this.position = n;
        int n2 = 0;
        while (Label.lIllllllIll(n2, this.referenceCount)) {
            int n3;
            int n4 = this.srcAndRefPositions[n2++];
            int n5 = this.srcAndRefPositions[n2++];
            if (Label.lIlllllllII(n4)) {
                n3 = n - n4;
                if (!Label.lIllllllIlI(n3, Short.MIN_VALUE) || Label.lIlllllllIl(n3, Short.MAX_VALUE)) {
                    int n6 = byArray[n5 - 1] & 0xFF;
                    if (Label.lIllllllllI(n6, 168)) {
                        byArray[n5 - 1] = (byte)(n6 + 49);
                        "".length();
                        if (-" ".length() >= 0) {
                            return ((111 + 7 - 42 + 111 ^ 139 + 146 - 189 + 67) & (0x3F ^ 0x6A ^ (0xF4 ^ 0xB9) ^ -" ".length())) != 0;
                        }
                    } else {
                        byArray[n5 - 1] = (byte)(n6 + 20);
                    }
                    bl = true;
                }
                byArray[n5++] = (byte)(n3 >>> 8);
                byArray[n5] = (byte)n3;
                "".length();
                if ((53 + 45 - 19 + 86 ^ 107 + 49 - 23 + 27) <= 0) {
                    return ((47 + 67 - 106 + 141 ^ 37 + 0 - 29 + 188) & (82 + 86 - 71 + 127 ^ 176 + 159 - 285 + 127 ^ -" ".length())) != 0;
                }
            } else {
                n3 = n + n4 + 1;
                byArray[n5++] = (byte)(n3 >>> 24);
                byArray[n5++] = (byte)(n3 >>> 16);
                byArray[n5++] = (byte)(n3 >>> 8);
                byArray[n5] = (byte)n3;
            }
            "".length();
            if (-"   ".length() <= 0) continue;
            return ((0xD7 ^ 0x80 ^ (0x71 ^ 0x22)) & (0x57 ^ 0xF ^ (0x46 ^ 0x1A) ^ -" ".length())) != 0;
        }
        return bl;
    }

    Label getFirst() {
        Label label;
        if (Label.lIllllllIII(this.frame)) {
            label = this;
            "".length();
            if ("  ".length() != "  ".length()) {
                return null;
            }
        } else {
            label = this.frame.owner;
        }
        return label;
    }

    boolean inSubroutine(long l) {
        if (Label.lIlllllIllI(this.status & 0x400)) {
            boolean bl;
            if (Label.lIlllllIllI(this.srcAndRefPositions[(int)(l >>> 32)] & (int)l)) {
                bl = true;
                "".length();
                if (-" ".length() > "   ".length()) {
                    return ((0xE4 ^ 0xAF) & ~(0x5D ^ 0x16)) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    boolean inSameSubroutine(Label label) {
        if (!Label.lIlllllIllI(this.status & 0x400) || Label.lIlllllIlIl(label.status & 0x400)) {
            return false;
        }
        int n = 0;
        while (Label.lIllllllIll(n, this.srcAndRefPositions.length)) {
            if (Label.lIlllllIllI(this.srcAndRefPositions[n] & label.srcAndRefPositions[n])) {
                return true;
            }
            ++n;
            "".length();
            if ("  ".length() >= 0) continue;
            return ((53 + 69 - 60 + 73 ^ 16 + 22 - -61 + 49) & (69 + 121 - 121 + 69 ^ 47 + 127 - 50 + 29 ^ -" ".length())) != 0;
        }
        return false;
    }

    void addToSubroutine(long l, int n) {
        if (Label.lIlllllIlIl(this.status & 0x400)) {
            this.status |= 0x400;
            this.srcAndRefPositions = new int[n / 32 + 1];
        }
        int n2 = (int)(l >>> 32);
        this.srcAndRefPositions[n2] = this.srcAndRefPositions[n2] | (int)l;
    }

    void visitSubroutine(Label label, long l, int n) {
        Label label2 = this;
        while (Label.lIlllllllll(label2)) {
            Edge edge;
            Label label3 = label2;
            label2 = label3.next;
            label3.next = null;
            if (Label.lIlllllllll(label)) {
                if (Label.lIlllllIllI(label3.status & 0x800)) {
                    "".length();
                    if (null == null) continue;
                    return;
                }
                label3.status |= 0x800;
                if (Label.lIlllllIllI(label3.status & 0x100) && Label.lIlllllIlIl(label3.inSameSubroutine(label) ? 1 : 0)) {
                    edge = new Edge();
                    edge.info = label3.inputStackTop;
                    edge.successor = label.successors.successor;
                    edge.next = label3.successors;
                    label3.successors = edge;
                    "".length();
                    if ((0xB3 ^ 0xB7) <= " ".length()) {
                        return;
                    }
                }
            } else {
                if (Label.lIlllllIllI(label3.inSubroutine(l) ? 1 : 0)) {
                    "".length();
                    if ("  ".length() < (0x11 ^ 0xA ^ (0x14 ^ 0xB))) continue;
                    return;
                }
                label3.addToSubroutine(l, n);
            }
            edge = label3.successors;
            while (Label.lIlllllllll(edge)) {
                if ((!Label.lIlllllIllI(label3.status & 0x80) || Label.llIIIIIIIII(edge, label3.successors.next)) && Label.lIllllllIII(edge.successor.next)) {
                    edge.successor.next = label2;
                    label2 = edge.successor;
                }
                edge = edge.next;
                "".length();
                if (" ".length() >= ((0x38 ^ 0x7A ^ (0xA4 ^ 0xAA)) & (165 + 97 - 236 + 200 ^ 173 + 53 - 125 + 73 ^ -" ".length()))) continue;
                return;
            }
            "".length();
            if ("  ".length() != 0) continue;
            return;
        }
    }

    public String toString() {
        return String.valueOf(new StringBuilder().append("L").append(System.identityHashCode(this)));
    }

    static {
        JSR = 128;
        PUSHED = 8;
        TARGET = 16;
        REACHABLE = 64;
        RET = 256;
        VISITED = 1024;
        SUBROUTINE = 512;
        STORE = 32;
        VISITED2 = 2048;
        RESOLVED = 2;
        RESIZED = 4;
    }

    private static boolean lIllllllIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIllllllIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllllllllI(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIlllllllIl(int n, int n2) {
        return n > n2;
    }

    private static boolean llIIIIIIIII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIlllllllll(Object object) {
        return object != null;
    }

    private static boolean lIllllllIII(Object object) {
        return object == null;
    }

    private static boolean lIlllllIllI(int n) {
        return n != 0;
    }

    private static boolean lIlllllIlIl(int n) {
        return n == 0;
    }

    private static boolean lIlllllllII(int n) {
        return n >= 0;
    }
}

