/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.TypePath;

public abstract class MethodVisitor {
    protected final int api;
    protected MethodVisitor mv;

    public MethodVisitor(int n) {
        this(n, null);
    }

    public MethodVisitor(int n, MethodVisitor methodVisitor) {
        if (MethodVisitor.lIIlIlIIIII(n, 262144) && MethodVisitor.lIIlIlIIIII(n, 327680)) {
            throw new IllegalArgumentException();
        }
        this.api = n;
        this.mv = methodVisitor;
    }

    public void visitParameter(String string, int n) {
        if (MethodVisitor.lIIlIlIIIIl(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitParameter(string, n);
        }
    }

    public AnnotationVisitor visitAnnotationDefault() {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitAnnotationDefault();
        }
        return null;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitAnnotation(string, bl);
        }
        return null;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        if (MethodVisitor.lIIlIlIIIIl(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitTypeAnnotation(n, typePath, string, bl);
        }
        return null;
    }

    public AnnotationVisitor visitParameterAnnotation(int n, String string, boolean bl) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitParameterAnnotation(n, string, bl);
        }
        return null;
    }

    public void visitAttribute(Attribute attribute) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitAttribute(attribute);
        }
    }

    public void visitCode() {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitCode();
        }
    }

    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitFrame(n, n2, objectArray, n3, objectArray2);
        }
    }

    public void visitInsn(int n) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitInsn(n);
        }
    }

    public void visitIntInsn(int n, int n2) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitIntInsn(n, n2);
        }
    }

    public void visitVarInsn(int n, int n2) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitVarInsn(n, n2);
        }
    }

    public void visitTypeInsn(int n, String string) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitTypeInsn(n, string);
        }
    }

    public void visitFieldInsn(int n, String string, String string2, String string3) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitFieldInsn(n, string, string2, string3);
        }
    }

    @Deprecated
    public void visitMethodInsn(int n, String string, String string2, String string3) {
        if (MethodVisitor.lIIlIlIIlIl(this.api, 327680)) {
            boolean bl;
            if (MethodVisitor.lIIlIlIIllI(n, 185)) {
                bl = true;
                "".length();
                if (((110 + 5 - 69 + 128 ^ 96 + 76 - 70 + 78) & (58 + 140 - 158 + 150 ^ 153 + 116 - 267 + 162 ^ -" ".length())) != ((0x5C ^ 0x7D ^ (0xF8 ^ 0x90)) & (158 + 109 - 133 + 58 ^ 20 + 56 - 73 + 134 ^ -" ".length()))) {
                    return;
                }
            } else {
                bl = false;
            }
            boolean bl2 = bl;
            this.visitMethodInsn(n, string, string2, string3, bl2);
            return;
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitMethodInsn(n, string, string2, string3);
        }
    }

    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (MethodVisitor.lIIlIlIIIIl(this.api, 327680)) {
            int n2;
            if (MethodVisitor.lIIlIlIIllI(n, 185)) {
                n2 = 1;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n2 = 0;
            }
            if (MethodVisitor.lIIlIlIIIII(bl ? 1 : 0, n2)) {
                throw new IllegalArgumentException("INVOKESPECIAL/STATIC on interfaces require ASM 5");
            }
            this.visitMethodInsn(n, string, string2, string3);
            return;
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitMethodInsn(n, string, string2, string3, bl);
        }
    }

    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitInvokeDynamicInsn(string, string2, handle, objectArray);
        }
    }

    public void visitJumpInsn(int n, Label label) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitJumpInsn(n, label);
        }
    }

    public void visitLabel(Label label) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitLabel(label);
        }
    }

    public void visitLdcInsn(Object object) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitLdcInsn(object);
        }
    }

    public void visitIincInsn(int n, int n2) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitIincInsn(n, n2);
        }
    }

    public void visitTableSwitchInsn(int n, int n2, Label label, Label ... labelArray) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitTableSwitchInsn(n, n2, label, labelArray);
        }
    }

    public void visitLookupSwitchInsn(Label label, int[] nArray, Label[] labelArray) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitLookupSwitchInsn(label, nArray, labelArray);
        }
    }

    public void visitMultiANewArrayInsn(String string, int n) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitMultiANewArrayInsn(string, n);
        }
    }

    public AnnotationVisitor visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        if (MethodVisitor.lIIlIlIIIIl(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitInsnAnnotation(n, typePath, string, bl);
        }
        return null;
    }

    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitTryCatchBlock(label, label2, label3, string);
        }
    }

    public AnnotationVisitor visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        if (MethodVisitor.lIIlIlIIIIl(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitTryCatchAnnotation(n, typePath, string, bl);
        }
        return null;
    }

    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitLocalVariable(string, string2, string3, label, label2, n);
        }
    }

    public AnnotationVisitor visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        if (MethodVisitor.lIIlIlIIIIl(this.api, 327680)) {
            throw new RuntimeException();
        }
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            return this.mv.visitLocalVariableAnnotation(n, typePath, labelArray, labelArray2, nArray, string, bl);
        }
        return null;
    }

    public void visitLineNumber(int n, Label label) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitLineNumber(n, label);
        }
    }

    public void visitMaxs(int n, int n2) {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitMaxs(n, n2);
        }
    }

    public void visitEnd() {
        if (MethodVisitor.lIIlIlIIIlI(this.mv)) {
            this.mv.visitEnd();
        }
    }

    private static boolean lIIlIlIIllI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIlIlIIlIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIlIlIIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIlIlIIIlI(Object object) {
        return object != null;
    }

    private static boolean lIIlIlIIIII(int n, int n2) {
        return n != n2;
    }
}

