/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.AnnotationWriter;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ByteVector;
import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.CurrentFrame;
import org.spongepowered.asm.lib.Edge;
import org.spongepowered.asm.lib.Frame;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Handler;
import org.spongepowered.asm.lib.Item;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;

class MethodWriter
extends MethodVisitor {
    static final int ACC_CONSTRUCTOR;
    static final int SAME_FRAME;
    static final int SAME_LOCALS_1_STACK_ITEM_FRAME;
    static final int RESERVED;
    static final int SAME_LOCALS_1_STACK_ITEM_FRAME_EXTENDED;
    static final int CHOP_FRAME;
    static final int SAME_FRAME_EXTENDED;
    static final int APPEND_FRAME;
    static final int FULL_FRAME;
    static final int FRAMES;
    static final int INSERTED_FRAMES;
    static final int MAXS;
    static final int NOTHING;
    final ClassWriter cw;
    private int access;
    private final int name;
    private final int desc;
    private final String descriptor;
    String signature;
    int classReaderOffset;
    int classReaderLength;
    int exceptionCount;
    int[] exceptions;
    private ByteVector annd;
    private AnnotationWriter anns;
    private AnnotationWriter ianns;
    private AnnotationWriter tanns;
    private AnnotationWriter itanns;
    private AnnotationWriter[] panns;
    private AnnotationWriter[] ipanns;
    private int synthetics;
    private Attribute attrs;
    private ByteVector code = new ByteVector();
    private int maxStack;
    private int maxLocals;
    private int currentLocals;
    private int frameCount;
    private ByteVector stackMap;
    private int previousFrameOffset;
    private int[] previousFrame;
    private int[] frame;
    private int handlerCount;
    private Handler firstHandler;
    private Handler lastHandler;
    private int methodParametersCount;
    private ByteVector methodParameters;
    private int localVarCount;
    private ByteVector localVar;
    private int localVarTypeCount;
    private ByteVector localVarType;
    private int lineNumberCount;
    private ByteVector lineNumber;
    private int lastCodeOffset;
    private AnnotationWriter ctanns;
    private AnnotationWriter ictanns;
    private Attribute cattrs;
    private int subroutines;
    private final int compute;
    private Label labels;
    private Label previousBlock;
    private Label currentBlock;
    private int stackSize;
    private int maxStackSize;

    MethodWriter(ClassWriter classWriter, int n, String string, String string2, String string3, String[] stringArray, int n2) {
        super(327680);
        int n3;
        if (MethodWriter.lIIIllIlIlIl(classWriter.firstMethod)) {
            classWriter.firstMethod = this;
            "".length();
            if ("  ".length() > (0x90 ^ 0x94)) {
                throw null;
            }
        } else {
            classWriter.lastMethod.mv = this;
        }
        classWriter.lastMethod = this;
        this.cw = classWriter;
        this.access = n;
        if (MethodWriter.lIIIllIlIllI("<init>".equals(string) ? 1 : 0)) {
            this.access |= 0x80000;
        }
        this.name = classWriter.newUTF8(string);
        this.desc = classWriter.newUTF8(string2);
        this.descriptor = string2;
        this.signature = string3;
        if (MethodWriter.lIIIllIlIlll(stringArray) && MethodWriter.lIIIllIllIII(stringArray.length)) {
            this.exceptionCount = stringArray.length;
            this.exceptions = new int[this.exceptionCount];
            n3 = 0;
            while (MethodWriter.lIIIllIllIIl(n3, this.exceptionCount)) {
                this.exceptions[n3] = classWriter.newClass(stringArray[n3]);
                ++n3;
                "".length();
                if ((0x2E ^ 0xB ^ (0x68 ^ 0x49)) == (132 + 69 - 82 + 46 ^ 70 + 144 - 171 + 118)) continue;
                throw null;
            }
        }
        this.compute = n2;
        if (MethodWriter.lIIIllIllIlI(n2, 3)) {
            n3 = Type.getArgumentsAndReturnSizes(this.descriptor) >> 2;
            if (MethodWriter.lIIIllIlIllI(n & 8)) {
                --n3;
            }
            this.maxLocals = n3;
            this.currentLocals = n3;
            this.labels = new Label();
            this.labels.status |= 8;
            this.visitLabel(this.labels);
        }
    }

    public void visitParameter(String string, int n) {
        int n2;
        if (MethodWriter.lIIIllIlIlIl(this.methodParameters)) {
            this.methodParameters = new ByteVector();
        }
        ++this.methodParametersCount;
        if (MethodWriter.lIIIllIlIlIl(string)) {
            n2 = 0;
            "".length();
            if ("  ".length() >= (0xD5 ^ 0x81 ^ (0x74 ^ 0x24))) {
                return;
            }
        } else {
            n2 = this.cw.newUTF8(string);
        }
        this.methodParameters.putShort(n2).putShort(n);
        "".length();
    }

    public AnnotationVisitor visitAnnotationDefault() {
        this.annd = new ByteVector();
        return new AnnotationWriter(this.cw, false, this.annd, null, 0);
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        byteVector.putShort(this.cw.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this.cw, true, byteVector, byteVector, 2);
        if (MethodWriter.lIIIllIlIllI(bl ? 1 : 0)) {
            annotationWriter.next = this.anns;
            this.anns = annotationWriter;
            "".length();
            if (" ".length() < ((0x9F ^ 0x89) & ~(0xB1 ^ 0xA7))) {
                return null;
            }
        } else {
            annotationWriter.next = this.ianns;
            this.ianns = annotationWriter;
        }
        return annotationWriter;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        AnnotationWriter.putTarget(n, typePath, byteVector);
        byteVector.putShort(this.cw.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this.cw, true, byteVector, byteVector, byteVector.length - 2);
        if (MethodWriter.lIIIllIlIllI(bl ? 1 : 0)) {
            annotationWriter.next = this.tanns;
            this.tanns = annotationWriter;
            "".length();
            if (((0x48 ^ 0x15) & ~(0x3E ^ 0x63)) != 0) {
                return null;
            }
        } else {
            annotationWriter.next = this.itanns;
            this.itanns = annotationWriter;
        }
        return annotationWriter;
    }

    public AnnotationVisitor visitParameterAnnotation(int n, String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        if (MethodWriter.lIIIllIlIllI("Ljava/lang/Synthetic;".equals(string) ? 1 : 0)) {
            this.synthetics = Math.max(this.synthetics, n + 1);
            return new AnnotationWriter(this.cw, false, byteVector, null, 0);
        }
        byteVector.putShort(this.cw.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this.cw, true, byteVector, byteVector, 2);
        if (MethodWriter.lIIIllIlIllI(bl ? 1 : 0)) {
            if (MethodWriter.lIIIllIlIlIl(this.panns)) {
                this.panns = new AnnotationWriter[Type.getArgumentTypes(this.descriptor).length];
            }
            annotationWriter.next = this.panns[n];
            this.panns[n] = annotationWriter;
            "".length();
            if ("   ".length() < 0) {
                return null;
            }
        } else {
            if (MethodWriter.lIIIllIlIlIl(this.ipanns)) {
                this.ipanns = new AnnotationWriter[Type.getArgumentTypes(this.descriptor).length];
            }
            annotationWriter.next = this.ipanns[n];
            this.ipanns[n] = annotationWriter;
        }
        return annotationWriter;
    }

    public void visitAttribute(Attribute attribute) {
        if (MethodWriter.lIIIllIlIllI(attribute.isCodeAttribute() ? 1 : 0)) {
            attribute.next = this.cattrs;
            this.cattrs = attribute;
            "".length();
            if (((0x18 ^ 0x32) & ~(0xA2 ^ 0x88)) != 0) {
                return;
            }
        } else {
            attribute.next = this.attrs;
            this.attrs = attribute;
        }
    }

    public void visitCode() {
    }

    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        if (MethodWriter.lIIIllIllIll(this.compute)) {
            return;
        }
        if (MethodWriter.lIIIllIlllII(this.compute, 1)) {
            if (MethodWriter.lIIIllIlIlIl(this.currentBlock.frame)) {
                this.currentBlock.frame = new CurrentFrame();
                this.currentBlock.frame.owner = this.currentBlock;
                this.currentBlock.frame.initInputFrame(this.cw, this.access, Type.getArgumentTypes(this.descriptor), n2);
                this.visitImplicitFirstFrame();
                "".length();
                if ("  ".length() <= -" ".length()) {
                    return;
                }
            } else {
                if (MethodWriter.lIIIllIlllII(n, -1)) {
                    this.currentBlock.frame.set(this.cw, n2, objectArray, n3, objectArray2);
                }
                this.visitFrame(this.currentBlock.frame);
                "".length();
                if (" ".length() <= 0) {
                    return;
                }
            }
        } else if (MethodWriter.lIIIllIlllII(n, -1)) {
            if (MethodWriter.lIIIllIlIlIl(this.previousFrame)) {
                this.visitImplicitFirstFrame();
            }
            this.currentLocals = n2;
            int n4 = this.startFrame(this.code.length, n2, n3);
            int n5 = 0;
            while (MethodWriter.lIIIllIllIIl(n5, n2)) {
                if (MethodWriter.lIIIllIlIllI(objectArray[n5] instanceof String)) {
                    this.frame[n4++] = 0x1700000 | this.cw.addType((String)objectArray[n5]);
                    "".length();
                    if ("  ".length() < 0) {
                        return;
                    }
                } else if (MethodWriter.lIIIllIlIllI(objectArray[n5] instanceof Integer)) {
                    this.frame[n4++] = (Integer)objectArray[n5];
                    "".length();
                    if (-"  ".length() > 0) {
                        return;
                    }
                } else {
                    this.frame[n4++] = 0x1800000 | this.cw.addUninitializedType("", ((Label)objectArray[n5]).position);
                }
                ++n5;
                "".length();
                if (((45 + 20 - -21 + 137 ^ 16 + 55 - 64 + 183) & (0x2F ^ 0x5A ^ (9 ^ 0x1D) ^ -" ".length())) == 0) continue;
                return;
            }
            n5 = 0;
            while (MethodWriter.lIIIllIllIIl(n5, n3)) {
                if (MethodWriter.lIIIllIlIllI(objectArray2[n5] instanceof String)) {
                    this.frame[n4++] = 0x1700000 | this.cw.addType((String)objectArray2[n5]);
                    "".length();
                    if (" ".length() == "   ".length()) {
                        return;
                    }
                } else if (MethodWriter.lIIIllIlIllI(objectArray2[n5] instanceof Integer)) {
                    this.frame[n4++] = (Integer)objectArray2[n5];
                    "".length();
                    if ((0x42 ^ 0x73 ^ (0xA9 ^ 0x9C)) < 0) {
                        return;
                    }
                } else {
                    this.frame[n4++] = 0x1800000 | this.cw.addUninitializedType("", ((Label)objectArray2[n5]).position);
                }
                ++n5;
                "".length();
                if ("  ".length() < (0x33 ^ 0x28 ^ (0x4D ^ 0x52))) continue;
                return;
            }
            this.endFrame();
            "".length();
            if (null != null) {
                return;
            }
        } else {
            int n6;
            if (MethodWriter.lIIIllIlIlIl(this.stackMap)) {
                this.stackMap = new ByteVector();
                n6 = this.code.length;
                "".length();
                if (-(0x15 ^ 0x10) >= 0) {
                    return;
                }
            } else {
                n6 = this.code.length - this.previousFrameOffset - 1;
                if (MethodWriter.lIIIllIlllIl(n6)) {
                    if (MethodWriter.lIIIllIlllII(n, 3)) {
                        return;
                    }
                    throw new IllegalStateException();
                }
            }
            switch (n) {
                case 0: {
                    this.currentLocals = n2;
                    this.stackMap.putByte(255).putShort(n6).putShort(n2);
                    "".length();
                    int n7 = 0;
                    while (MethodWriter.lIIIllIllIIl(n7, n2)) {
                        this.writeFrameType(objectArray[n7]);
                        ++n7;
                        "".length();
                        if (-(0xC6 ^ 0xC3) < 0) continue;
                        return;
                    }
                    this.stackMap.putShort(n3);
                    "".length();
                    n7 = 0;
                    while (MethodWriter.lIIIllIllIIl(n7, n3)) {
                        this.writeFrameType(objectArray2[n7]);
                        ++n7;
                        "".length();
                        if ("   ".length() >= 0) continue;
                        return;
                    }
                    "".length();
                    if (" ".length() >= 0) break;
                    return;
                }
                case 1: {
                    this.currentLocals += n2;
                    this.stackMap.putByte(251 + n2).putShort(n6);
                    "".length();
                    int n8 = 0;
                    while (MethodWriter.lIIIllIllIIl(n8, n2)) {
                        this.writeFrameType(objectArray[n8]);
                        ++n8;
                        "".length();
                        if (null == null) continue;
                        return;
                    }
                    "".length();
                    if (-" ".length() < ((0xB1 ^ 0xBA) & ~(0x63 ^ 0x68))) break;
                    return;
                }
                case 2: {
                    this.currentLocals -= n2;
                    this.stackMap.putByte(251 - n2).putShort(n6);
                    "".length();
                    "".length();
                    if (-" ".length() != (0x7E ^ 0x7A)) break;
                    return;
                }
                case 3: {
                    if (MethodWriter.lIIIllIllIIl(n6, 64)) {
                        this.stackMap.putByte(n6);
                        "".length();
                        "".length();
                        if (null == null) break;
                        return;
                    }
                    this.stackMap.putByte(251).putShort(n6);
                    "".length();
                    "".length();
                    if ((8 ^ 0x6F ^ (0xA2 ^ 0xC0)) > 0) break;
                    return;
                }
                case 4: {
                    if (MethodWriter.lIIIllIllIIl(n6, 64)) {
                        this.stackMap.putByte(64 + n6);
                        "".length();
                        "".length();
                        if (-"  ".length() >= 0) {
                            return;
                        }
                    } else {
                        this.stackMap.putByte(247).putShort(n6);
                        "".length();
                    }
                    this.writeFrameType(objectArray2[0]);
                }
            }
            this.previousFrameOffset = this.code.length;
            ++this.frameCount;
        }
        this.maxStack = Math.max(this.maxStack, n3);
        this.maxLocals = Math.max(this.maxLocals, this.currentLocals);
    }

    public void visitInsn(int n) {
        this.lastCodeOffset = this.code.length;
        this.code.putByte(n);
        "".length();
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, 0, null, null);
                "".length();
                if ((92 + 138 - 187 + 132 ^ 50 + 44 - 66 + 143) > (130 + 26 - 99 + 122 ^ 62 + 109 - 117 + 129)) {
                    return;
                }
            } else {
                int n2 = this.stackSize + Frame.SIZE[n];
                if (MethodWriter.lIIIllIllllI(n2, this.maxStackSize)) {
                    this.maxStackSize = n2;
                }
                this.stackSize = n2;
            }
            if (MethodWriter.lIIIllIlllll(n, 172) && !MethodWriter.lIIIllIllllI(n, 177) || MethodWriter.lIIIllIlllII(n, 191)) {
                this.noSuccessor();
            }
        }
    }

    public void visitIntInsn(int n, int n2) {
        this.lastCodeOffset = this.code.length;
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, n2, null, null);
                "".length();
                if ("   ".length() <= 0) {
                    return;
                }
            } else if (MethodWriter.lIIIllIllIlI(n, 188)) {
                int n3 = this.stackSize + 1;
                if (MethodWriter.lIIIllIllllI(n3, this.maxStackSize)) {
                    this.maxStackSize = n3;
                }
                this.stackSize = n3;
            }
        }
        if (MethodWriter.lIIIllIlllII(n, 17)) {
            this.code.put12(n, n2);
            "".length();
            "".length();
            if ((0x28 ^ 0x2C) <= -" ".length()) {
                return;
            }
        } else {
            this.code.put11(n, n2);
            "".length();
        }
    }

    public void visitVarInsn(int n, int n2) {
        int n3;
        this.lastCodeOffset = this.code.length;
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, n2, null, null);
                "".length();
                if (-"   ".length() >= 0) {
                    return;
                }
            } else if (MethodWriter.lIIIllIlllII(n, 169)) {
                this.currentBlock.status |= 0x100;
                this.currentBlock.inputStackTop = this.stackSize;
                this.noSuccessor();
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n3 = this.stackSize + Frame.SIZE[n];
                if (MethodWriter.lIIIllIllllI(n3, this.maxStackSize)) {
                    this.maxStackSize = n3;
                }
                this.stackSize = n3;
            }
        }
        if (MethodWriter.lIIIllIllIlI(this.compute, 3)) {
            if (!MethodWriter.lIIIllIllIlI(n, 22) || !MethodWriter.lIIIllIllIlI(n, 24) || !MethodWriter.lIIIllIllIlI(n, 55) || MethodWriter.lIIIllIlllII(n, 57)) {
                n3 = n2 + 2;
                "".length();
                if ((7 ^ 3) < (0x93 ^ 0x97)) {
                    return;
                }
            } else {
                n3 = n2 + 1;
            }
            if (MethodWriter.lIIIllIllllI(n3, this.maxLocals)) {
                this.maxLocals = n3;
            }
        }
        if (MethodWriter.lIIIllIllIIl(n2, 4) && MethodWriter.lIIIllIllIlI(n, 169)) {
            if (MethodWriter.lIIIllIllIIl(n, 54)) {
                n3 = 26 + (n - 21 << 2) + n2;
                "".length();
                if ("  ".length() > "   ".length()) {
                    return;
                }
            } else {
                n3 = 59 + (n - 54 << 2) + n2;
            }
            this.code.putByte(n3);
            "".length();
            "".length();
            if (-(0x3C ^ 0x6A ^ (0x62 ^ 0x30)) > 0) {
                return;
            }
        } else if (MethodWriter.lIIIllIlllll(n2, 256)) {
            this.code.putByte(196).put12(n, n2);
            "".length();
            "".length();
            if ((47 + 8 - 46 + 165 ^ 38 + 136 - 98 + 94) <= -" ".length()) {
                return;
            }
        } else {
            this.code.put11(n, n2);
            "".length();
        }
        if (MethodWriter.lIIIllIlllll(n, 54) && MethodWriter.lIIIllIllIll(this.compute) && MethodWriter.lIIIllIllIII(this.handlerCount)) {
            this.visitLabel(new Label());
        }
    }

    public void visitTypeInsn(int n, String string) {
        this.lastCodeOffset = this.code.length;
        Item item = this.cw.newClassItem(string);
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, this.code.length, this.cw, item);
                "".length();
                if ((" ".length() & ~" ".length()) > 0) {
                    return;
                }
            } else if (MethodWriter.lIIIllIlllII(n, 187)) {
                int n2 = this.stackSize + 1;
                if (MethodWriter.lIIIllIllllI(n2, this.maxStackSize)) {
                    this.maxStackSize = n2;
                }
                this.stackSize = n2;
            }
        }
        this.code.put12(n, item.index);
        "".length();
    }

    public void visitFieldInsn(int n, String string, String string2, String string3) {
        this.lastCodeOffset = this.code.length;
        Item item = this.cw.newFieldItem(string, string2, string3);
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, 0, this.cw, item);
                "".length();
                if ("   ".length() != "   ".length()) {
                    return;
                }
            } else {
                int n2;
                char c = string3.charAt(0);
                switch (n) {
                    case 178: {
                        int n3;
                        if (!MethodWriter.lIIIllIllIlI(c, 68) || MethodWriter.lIIIllIlllII(c, 74)) {
                            n3 = 2;
                            "".length();
                            if ("   ".length() != "   ".length()) {
                                return;
                            }
                        } else {
                            n3 = 1;
                        }
                        n2 = this.stackSize + n3;
                        "".length();
                        if (((0xD3 ^ 0x98) & ~(0xFF ^ 0xB4)) == 0) break;
                        return;
                    }
                    case 179: {
                        int n4;
                        if (!MethodWriter.lIIIllIllIlI(c, 68) || MethodWriter.lIIIllIlllII(c, 74)) {
                            n4 = -2;
                            "".length();
                            if ("  ".length() == 0) {
                                return;
                            }
                        } else {
                            n4 = -1;
                        }
                        n2 = this.stackSize + n4;
                        "".length();
                        if ("   ".length() >= "   ".length()) break;
                        return;
                    }
                    case 180: {
                        int n5;
                        if (!MethodWriter.lIIIllIllIlI(c, 68) || MethodWriter.lIIIllIlllII(c, 74)) {
                            n5 = 1;
                            "".length();
                            if (" ".length() == 0) {
                                return;
                            }
                        } else {
                            n5 = 0;
                        }
                        n2 = this.stackSize + n5;
                        "".length();
                        if (((0x89 ^ 0xA8) & ~(0x15 ^ 0x34)) == 0) break;
                        return;
                    }
                    default: {
                        int n6;
                        if (!MethodWriter.lIIIllIllIlI(c, 68) || MethodWriter.lIIIllIlllII(c, 74)) {
                            n6 = -3;
                            "".length();
                            if (null != null) {
                                return;
                            }
                        } else {
                            n6 = -2;
                        }
                        n2 = this.stackSize + n6;
                    }
                }
                if (MethodWriter.lIIIllIllllI(n2, this.maxStackSize)) {
                    this.maxStackSize = n2;
                }
                this.stackSize = n2;
            }
        }
        this.code.put12(n, item.index);
        "".length();
    }

    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        this.lastCodeOffset = this.code.length;
        Item item = this.cw.newMethodItem(string, string2, string3, bl);
        int n2 = item.intVal;
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, 0, this.cw, item);
                "".length();
                if (" ".length() < 0) {
                    return;
                }
            } else {
                int n3;
                if (MethodWriter.lIIIllIllIll(n2)) {
                    item.intVal = n2 = Type.getArgumentsAndReturnSizes(string3);
                }
                if (MethodWriter.lIIIllIlllII(n, 184)) {
                    n3 = this.stackSize - (n2 >> 2) + (n2 & 3) + 1;
                    "".length();
                    if (-" ".length() < -" ".length()) {
                        return;
                    }
                } else {
                    n3 = this.stackSize - (n2 >> 2) + (n2 & 3);
                }
                if (MethodWriter.lIIIllIllllI(n3, this.maxStackSize)) {
                    this.maxStackSize = n3;
                }
                this.stackSize = n3;
            }
        }
        if (MethodWriter.lIIIllIlllII(n, 185)) {
            if (MethodWriter.lIIIllIllIll(n2)) {
                item.intVal = n2 = Type.getArgumentsAndReturnSizes(string3);
            }
            this.code.put12(185, item.index).put11(n2 >> 2, 0);
            "".length();
            "".length();
            if ((0x84 ^ 0x80) <= "   ".length()) {
                return;
            }
        } else {
            this.code.put12(n, item.index);
            "".length();
        }
    }

    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        this.lastCodeOffset = this.code.length;
        Item item = this.cw.newInvokeDynamicItem(string, string2, handle, objectArray);
        int n = item.intVal;
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(186, 0, this.cw, item);
                "".length();
                if ("  ".length() < ((0x76 ^ 0x4A ^ (0xCB ^ 0xA8)) & (141 + 178 - 304 + 191 ^ 16 + 126 - 10 + 13 ^ -" ".length()))) {
                    return;
                }
            } else {
                int n2;
                if (MethodWriter.lIIIllIllIll(n)) {
                    item.intVal = n = Type.getArgumentsAndReturnSizes(string2);
                }
                if (MethodWriter.lIIIllIllllI(n2 = this.stackSize - (n >> 2) + (n & 3) + 1, this.maxStackSize)) {
                    this.maxStackSize = n2;
                }
                this.stackSize = n2;
            }
        }
        this.code.put12(186, item.index);
        "".length();
        this.code.putShort(0);
        "".length();
    }

    public void visitJumpInsn(int n, Label label) {
        int n2;
        int n3;
        int n4;
        if (MethodWriter.lIIIllIlllll(n, 200)) {
            n4 = 1;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            n4 = 0;
        }
        if (MethodWriter.lIIIllIlIllI(n3 = n4)) {
            n2 = n - 33;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            n2 = n;
        }
        n = n2;
        this.lastCodeOffset = this.code.length;
        Label label2 = null;
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (MethodWriter.lIIIllIllIll(this.compute)) {
                this.currentBlock.frame.execute(n, 0, null, null);
                label.getFirst().status |= 0x10;
                this.addSuccessor(0, label);
                if (MethodWriter.lIIIllIllIlI(n, 167)) {
                    label2 = new Label();
                    "".length();
                    if (((0x2D ^ 0x1A) & ~(0xB6 ^ 0x81)) < 0) {
                        return;
                    }
                }
            } else if (MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(n, 0, null, null);
                "".length();
                if (null != null) {
                    return;
                }
            } else if (MethodWriter.lIIIllIlllII(n, 168)) {
                if (MethodWriter.lIIIllIllIll(label.status & 0x200)) {
                    label.status |= 0x200;
                    ++this.subroutines;
                }
                this.currentBlock.status |= 0x80;
                this.addSuccessor(this.stackSize + 1, label);
                label2 = new Label();
                "".length();
                if ("  ".length() >= (146 + 90 - 103 + 51 ^ 96 + 33 - -30 + 29)) {
                    return;
                }
            } else {
                this.stackSize += Frame.SIZE[n];
                this.addSuccessor(this.stackSize, label);
            }
        }
        if (MethodWriter.lIIIllIlIllI(label.status & 2) && MethodWriter.lIIIllIllIIl(label.position - this.code.length, Short.MIN_VALUE)) {
            if (MethodWriter.lIIIllIlllII(n, 167)) {
                this.code.putByte(200);
                "".length();
                "".length();
                if (-" ".length() < -" ".length()) {
                    return;
                }
            } else if (MethodWriter.lIIIllIlllII(n, 168)) {
                this.code.putByte(201);
                "".length();
                "".length();
                if (-"  ".length() > 0) {
                    return;
                }
            } else {
                int n5;
                if (MethodWriter.lIIIllIlIlll(label2)) {
                    label2.status |= 0x10;
                }
                if (MethodWriter.lIIIlllIIIII(n, 166)) {
                    n5 = (n + 1 ^ 1) - 1;
                    "".length();
                    if ("   ".length() <= 0) {
                        return;
                    }
                } else {
                    n5 = n ^ 1;
                }
                this.code.putByte(n5);
                "".length();
                this.code.putShort(8);
                "".length();
                this.code.putByte(200);
                "".length();
            }
            label.put(this, this.code, this.code.length - 1, true);
            "".length();
            if (" ".length() <= 0) {
                return;
            }
        } else if (MethodWriter.lIIIllIlIllI(n3)) {
            this.code.putByte(n + 33);
            "".length();
            label.put(this, this.code, this.code.length - 1, true);
            "".length();
            if ("  ".length() < 0) {
                return;
            }
        } else {
            this.code.putByte(n);
            "".length();
            label.put(this, this.code, this.code.length - 1, false);
        }
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (MethodWriter.lIIIllIlIlll(label2)) {
                this.visitLabel(label2);
            }
            if (MethodWriter.lIIIllIlllII(n, 167)) {
                this.noSuccessor();
            }
        }
    }

    public void visitLabel(Label label) {
        this.cw.hasAsmInsns |= label.resolve(this, this.code.length, this.code.data);
        if (MethodWriter.lIIIllIlIllI(label.status & 1)) {
            return;
        }
        if (MethodWriter.lIIIllIllIll(this.compute)) {
            if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
                if (MethodWriter.lIIIllIlllII(label.position, this.currentBlock.position)) {
                    this.currentBlock.status |= label.status & 0x10;
                    label.frame = this.currentBlock.frame;
                    return;
                }
                this.addSuccessor(0, label);
            }
            this.currentBlock = label;
            if (MethodWriter.lIIIllIlIlIl(label.frame)) {
                label.frame = new Frame();
                label.frame.owner = label;
            }
            if (MethodWriter.lIIIllIlIlll(this.previousBlock)) {
                if (MethodWriter.lIIIllIlllII(label.position, this.previousBlock.position)) {
                    this.previousBlock.status |= label.status & 0x10;
                    label.frame = this.previousBlock.frame;
                    this.currentBlock = this.previousBlock;
                    return;
                }
                this.previousBlock.successor = label;
            }
            this.previousBlock = label;
            "".length();
            if (("   ".length() & ("   ".length() ^ -" ".length())) < 0) {
                return;
            }
        } else if (MethodWriter.lIIIllIlllII(this.compute, 1)) {
            if (MethodWriter.lIIIllIlIlIl(this.currentBlock)) {
                this.currentBlock = label;
                "".length();
                if ("  ".length() != "  ".length()) {
                    return;
                }
            } else {
                this.currentBlock.frame.owner = label;
                "".length();
                if ("   ".length() <= 0) {
                    return;
                }
            }
        } else if (MethodWriter.lIIIllIlllII(this.compute, 2)) {
            if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
                this.currentBlock.outputStackMax = this.maxStackSize;
                this.addSuccessor(this.stackSize, label);
            }
            this.currentBlock = label;
            this.stackSize = 0;
            this.maxStackSize = 0;
            if (MethodWriter.lIIIllIlIlll(this.previousBlock)) {
                this.previousBlock.successor = label;
            }
            this.previousBlock = label;
        }
    }

    public void visitLdcInsn(Object object) {
        int n;
        this.lastCodeOffset = this.code.length;
        Item item = this.cw.newConstItem(object);
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(18, 0, this.cw, item);
                "".length();
                if ("  ".length() < " ".length()) {
                    return;
                }
            } else {
                if (!MethodWriter.lIIIllIllIlI(item.type, 5) || MethodWriter.lIIIllIlllII(item.type, 6)) {
                    n = this.stackSize + 2;
                    "".length();
                    if ((0x51 ^ 0x54) == 0) {
                        return;
                    }
                } else {
                    n = this.stackSize + 1;
                }
                if (MethodWriter.lIIIllIllllI(n, this.maxStackSize)) {
                    this.maxStackSize = n;
                }
                this.stackSize = n;
            }
        }
        n = item.index;
        if (!MethodWriter.lIIIllIllIlI(item.type, 5) || MethodWriter.lIIIllIlllII(item.type, 6)) {
            this.code.put12(20, n);
            "".length();
            "".length();
            if (((0x9E ^ 0xC6) & ~(0x32 ^ 0x6A)) != 0) {
                return;
            }
        } else if (MethodWriter.lIIIllIlllll(n, 256)) {
            this.code.put12(19, n);
            "".length();
            "".length();
            if ((111 + 48 - 123 + 105 ^ 104 + 116 - 118 + 35) < 0) {
                return;
            }
        } else {
            this.code.put11(18, n);
            "".length();
        }
    }

    public void visitIincInsn(int n, int n2) {
        int n3;
        this.lastCodeOffset = this.code.length;
        if (MethodWriter.lIIIllIlIlll(this.currentBlock) && (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1))) {
            this.currentBlock.frame.execute(132, n, null, null);
        }
        if (MethodWriter.lIIIllIllIlI(this.compute, 3) && MethodWriter.lIIIllIllllI(n3 = n + 1, this.maxLocals)) {
            this.maxLocals = n3;
        }
        if (!MethodWriter.lIIIlllIIIII(n, 255) || !MethodWriter.lIIIlllIIIII(n2, 127) || MethodWriter.lIIIllIllIIl(n2, -128)) {
            this.code.putByte(196).put12(132, n).putShort(n2);
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else {
            this.code.putByte(132).put11(n, n2);
            "".length();
        }
    }

    public void visitTableSwitchInsn(int n, int n2, Label label, Label ... labelArray) {
        this.lastCodeOffset = this.code.length;
        int n3 = this.code.length;
        this.code.putByte(170);
        "".length();
        this.code.putByteArray(null, 0, (4 - this.code.length % 4) % 4);
        "".length();
        label.put(this, this.code, n3, true);
        this.code.putInt(n).putInt(n2);
        "".length();
        int n4 = 0;
        while (MethodWriter.lIIIllIllIIl(n4, labelArray.length)) {
            labelArray[n4].put(this, this.code, n3, true);
            ++n4;
            "".length();
            if (null == null) continue;
            return;
        }
        this.visitSwitchInsn(label, labelArray);
    }

    public void visitLookupSwitchInsn(Label label, int[] nArray, Label[] labelArray) {
        this.lastCodeOffset = this.code.length;
        int n = this.code.length;
        this.code.putByte(171);
        "".length();
        this.code.putByteArray(null, 0, (4 - this.code.length % 4) % 4);
        "".length();
        label.put(this, this.code, n, true);
        this.code.putInt(labelArray.length);
        "".length();
        int n2 = 0;
        while (MethodWriter.lIIIllIllIIl(n2, labelArray.length)) {
            this.code.putInt(nArray[n2]);
            "".length();
            labelArray[n2].put(this, this.code, n, true);
            ++n2;
            "".length();
            if (((167 + 34 - 129 + 174 ^ 10 + 55 - -80 + 45) & (2 ^ 7 ^ (0x4A ^ 7) ^ -" ".length())) == ((0x3A ^ 8 ^ (0x23 ^ 0xD)) & (55 + 176 - 123 + 82 ^ 84 + 140 - 93 + 31 ^ -" ".length()))) continue;
            return;
        }
        this.visitSwitchInsn(label, labelArray);
    }

    private void visitSwitchInsn(Label label, Label[] labelArray) {
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (MethodWriter.lIIIllIllIll(this.compute)) {
                this.currentBlock.frame.execute(171, 0, null, null);
                this.addSuccessor(0, label);
                label.getFirst().status |= 0x10;
                int n = 0;
                while (MethodWriter.lIIIllIllIIl(n, labelArray.length)) {
                    this.addSuccessor(0, labelArray[n]);
                    labelArray[n].getFirst().status |= 0x10;
                    ++n;
                    "".length();
                    if (" ".length() > ((3 ^ 0x2C) & ~(0x24 ^ 0xB))) continue;
                    return;
                }
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                --this.stackSize;
                this.addSuccessor(this.stackSize, label);
                int n = 0;
                while (MethodWriter.lIIIllIllIIl(n, labelArray.length)) {
                    this.addSuccessor(this.stackSize, labelArray[n]);
                    ++n;
                    "".length();
                    if (null == null) continue;
                    return;
                }
            }
            this.noSuccessor();
        }
    }

    public void visitMultiANewArrayInsn(String string, int n) {
        this.lastCodeOffset = this.code.length;
        Item item = this.cw.newClassItem(string);
        if (MethodWriter.lIIIllIlIlll(this.currentBlock)) {
            if (!MethodWriter.lIIIllIlIllI(this.compute) || MethodWriter.lIIIllIlllII(this.compute, 1)) {
                this.currentBlock.frame.execute(197, n, this.cw, item);
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                this.stackSize += 1 - n;
            }
        }
        this.code.put12(197, item.index).putByte(n);
        "".length();
    }

    public AnnotationVisitor visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        n = n & 0xFF0000FF | this.lastCodeOffset << 8;
        AnnotationWriter.putTarget(n, typePath, byteVector);
        byteVector.putShort(this.cw.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this.cw, true, byteVector, byteVector, byteVector.length - 2);
        if (MethodWriter.lIIIllIlIllI(bl ? 1 : 0)) {
            annotationWriter.next = this.ctanns;
            this.ctanns = annotationWriter;
            "".length();
            if (-"  ".length() > 0) {
                return null;
            }
        } else {
            annotationWriter.next = this.ictanns;
            this.ictanns = annotationWriter;
        }
        return annotationWriter;
    }

    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        int n;
        ++this.handlerCount;
        Handler handler = new Handler();
        handler.start = label;
        handler.end = label2;
        handler.handler = label3;
        handler.desc = string;
        if (MethodWriter.lIIIllIlIlll(string)) {
            n = this.cw.newClass(string);
            "".length();
            if ("  ".length() < " ".length()) {
                return;
            }
        } else {
            n = handler.type = 0;
        }
        if (MethodWriter.lIIIllIlIlIl(this.lastHandler)) {
            this.firstHandler = handler;
            "".length();
            if (-"  ".length() >= 0) {
                return;
            }
        } else {
            this.lastHandler.next = handler;
        }
        this.lastHandler = handler;
    }

    public AnnotationVisitor visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        AnnotationWriter.putTarget(n, typePath, byteVector);
        byteVector.putShort(this.cw.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this.cw, true, byteVector, byteVector, byteVector.length - 2);
        if (MethodWriter.lIIIllIlIllI(bl ? 1 : 0)) {
            annotationWriter.next = this.ctanns;
            this.ctanns = annotationWriter;
            "".length();
            if (-" ".length() >= " ".length()) {
                return null;
            }
        } else {
            annotationWriter.next = this.ictanns;
            this.ictanns = annotationWriter;
        }
        return annotationWriter;
    }

    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        if (MethodWriter.lIIIllIlIlll(string3)) {
            if (MethodWriter.lIIIllIlIlIl(this.localVarType)) {
                this.localVarType = new ByteVector();
            }
            ++this.localVarTypeCount;
            this.localVarType.putShort(label.position).putShort(label2.position - label.position).putShort(this.cw.newUTF8(string)).putShort(this.cw.newUTF8(string3)).putShort(n);
            "".length();
        }
        if (MethodWriter.lIIIllIlIlIl(this.localVar)) {
            this.localVar = new ByteVector();
        }
        ++this.localVarCount;
        this.localVar.putShort(label.position).putShort(label2.position - label.position).putShort(this.cw.newUTF8(string)).putShort(this.cw.newUTF8(string2)).putShort(n);
        "".length();
        if (MethodWriter.lIIIllIllIlI(this.compute, 3)) {
            int n2;
            int n3;
            char c = string2.charAt(0);
            if (!MethodWriter.lIIIllIllIlI(c, 74) || MethodWriter.lIIIllIlllII(c, 68)) {
                n3 = 2;
                "".length();
                if ("   ".length() < "   ".length()) {
                    return;
                }
            } else {
                n3 = 1;
            }
            if (MethodWriter.lIIIllIllllI(n2 = n + n3, this.maxLocals)) {
                this.maxLocals = n2;
            }
        }
    }

    public AnnotationVisitor visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        ByteVector byteVector = new ByteVector();
        byteVector.putByte(n >>> 24).putShort(labelArray.length);
        "".length();
        int n2 = 0;
        while (MethodWriter.lIIIllIllIIl(n2, labelArray.length)) {
            byteVector.putShort(labelArray[n2].position).putShort(labelArray2[n2].position - labelArray[n2].position).putShort(nArray[n2]);
            "".length();
            ++n2;
            "".length();
            if (null == null) continue;
            return null;
        }
        if (MethodWriter.lIIIllIlIlIl(typePath)) {
            byteVector.putByte(0);
            "".length();
            "".length();
            if (((0x99 ^ 0x8D) & ~(0x94 ^ 0x80)) > 0) {
                return null;
            }
        } else {
            n2 = typePath.b[typePath.offset] * 2 + 1;
            byteVector.putByteArray(typePath.b, typePath.offset, n2);
            "".length();
        }
        byteVector.putShort(this.cw.newUTF8(string)).putShort(0);
        "".length();
        AnnotationWriter annotationWriter = new AnnotationWriter(this.cw, true, byteVector, byteVector, byteVector.length - 2);
        if (MethodWriter.lIIIllIlIllI(bl ? 1 : 0)) {
            annotationWriter.next = this.ctanns;
            this.ctanns = annotationWriter;
            "".length();
            if (((0xB8 ^ 0x9F) & ~(0x49 ^ 0x6E)) >= "  ".length()) {
                return null;
            }
        } else {
            annotationWriter.next = this.ictanns;
            this.ictanns = annotationWriter;
        }
        return annotationWriter;
    }

    public void visitLineNumber(int n, Label label) {
        if (MethodWriter.lIIIllIlIlIl(this.lineNumber)) {
            this.lineNumber = new ByteVector();
        }
        ++this.lineNumberCount;
        this.lineNumber.putShort(label.position);
        "".length();
        this.lineNumber.putShort(n);
        "".length();
    }

    public void visitMaxs(int n, int n2) {
        if (MethodWriter.lIIIllIllIll(this.compute)) {
            int n3;
            Edge edge;
            int n4;
            Object object;
            Label label;
            Object object2;
            Handler handler = this.firstHandler;
            while (MethodWriter.lIIIllIlIlll(handler)) {
                String string;
                object2 = handler.start.getFirst();
                Label label2 = handler.handler.getFirst();
                label = handler.end.getFirst();
                if (MethodWriter.lIIIllIlIlIl(handler.desc)) {
                    string = "java/lang/Throwable";
                    "".length();
                    if (((0xA2 ^ 0x90) & ~(0x43 ^ 0x71)) < ((0x6B ^ 0x32) & ~(0x70 ^ 0x29))) {
                        return;
                    }
                } else {
                    string = handler.desc;
                }
                object = string;
                n4 = 0x1700000 | this.cw.addType((String)object);
                label2.status |= 0x10;
                while (MethodWriter.lIIIlllIIIIl(object2, label)) {
                    edge = new Edge();
                    edge.info = n4;
                    edge.successor = label2;
                    edge.next = ((Label)object2).successors;
                    ((Label)object2).successors = edge;
                    object2 = ((Label)object2).successor;
                    "".length();
                    if ((0xB8 ^ 0xBC) >= (0x49 ^ 0x4D)) continue;
                    return;
                }
                handler = handler.next;
                "".length();
                if (((141 + 231 - 283 + 151 ^ 133 + 156 - 192 + 84) & (0x45 ^ 0x4D ^ (0xFA ^ 0xB7) ^ -" ".length())) == 0) continue;
                return;
            }
            object2 = this.labels.frame;
            ((Frame)object2).initInputFrame(this.cw, this.access, Type.getArgumentTypes(this.descriptor), this.maxLocals);
            this.visitFrame((Frame)object2);
            int n5 = 0;
            label = this.labels;
            while (MethodWriter.lIIIllIlIlll(label)) {
                object = label;
                label = label.next;
                ((Label)object).next = null;
                object2 = ((Label)object).frame;
                if (MethodWriter.lIIIllIlIllI(((Label)object).status & 0x10)) {
                    ((Label)object).status |= 0x20;
                }
                ((Label)object).status |= 0x40;
                n4 = ((Frame)object2).inputStack.length + ((Label)object).outputStackMax;
                if (MethodWriter.lIIIllIllllI(n4, n5)) {
                    n5 = n4;
                }
                edge = ((Label)object).successors;
                while (MethodWriter.lIIIllIlIlll(edge)) {
                    Label label3 = edge.successor.getFirst();
                    n3 = ((Frame)object2).merge(this.cw, label3.frame, edge.info) ? 1 : 0;
                    if (MethodWriter.lIIIllIlIllI(n3) && MethodWriter.lIIIllIlIlIl(label3.next)) {
                        label3.next = label;
                        label = label3;
                    }
                    edge = edge.next;
                    "".length();
                    if (((0x4F ^ 0x5A) & ~(0x1F ^ 0xA)) == 0) continue;
                    return;
                }
                "".length();
                if (null == null) continue;
                return;
            }
            object = this.labels;
            while (MethodWriter.lIIIllIlIlll(object)) {
                object2 = ((Label)object).frame;
                if (MethodWriter.lIIIllIlIllI(((Label)object).status & 0x20)) {
                    this.visitFrame((Frame)object2);
                }
                if (MethodWriter.lIIIllIllIll(((Label)object).status & 0x40)) {
                    int n6;
                    int n7;
                    Label label4 = ((Label)object).successor;
                    int n8 = ((Label)object).position;
                    if (MethodWriter.lIIIllIlIlIl(label4)) {
                        n7 = this.code.length;
                        "".length();
                        if (-"   ".length() > 0) {
                            return;
                        }
                    } else {
                        n7 = label4.position;
                    }
                    if (MethodWriter.lIIIllIlllll(n6 = n7 - 1, n8)) {
                        n5 = Math.max(n5, 1);
                        n3 = n8;
                        while (MethodWriter.lIIIllIllIIl(n3, n6)) {
                            this.code.data[n3] = 0;
                            ++n3;
                            "".length();
                            if ((0x39 ^ 0x3D) >= 0) continue;
                            return;
                        }
                        this.code.data[n6] = -65;
                        n3 = this.startFrame(n8, 0, 1);
                        this.frame[n3] = 0x1700000 | this.cw.addType("java/lang/Throwable");
                        this.endFrame();
                        this.firstHandler = Handler.remove(this.firstHandler, (Label)object, label4);
                    }
                }
                object = ((Label)object).successor;
                "".length();
                if ("  ".length() < "   ".length()) continue;
                return;
            }
            handler = this.firstHandler;
            this.handlerCount = 0;
            while (MethodWriter.lIIIllIlIlll(handler)) {
                ++this.handlerCount;
                handler = handler.next;
                "".length();
                if (null == null) continue;
                return;
            }
            this.maxStack = n5;
            "".length();
            if (((0x27 ^ 0x7D) & ~(0x78 ^ 0x22)) < 0) {
                return;
            }
        } else if (MethodWriter.lIIIllIlllII(this.compute, 2)) {
            Object object;
            Label label;
            Label label5;
            Handler handler = this.firstHandler;
            while (MethodWriter.lIIIllIlIlll(handler)) {
                Label label6 = handler.start;
                label5 = handler.handler;
                label = handler.end;
                while (MethodWriter.lIIIlllIIIIl(label6, label)) {
                    object = new Edge();
                    ((Edge)object).info = Integer.MAX_VALUE;
                    ((Edge)object).successor = label5;
                    if (MethodWriter.lIIIllIllIll(label6.status & 0x80)) {
                        ((Edge)object).next = label6.successors;
                        label6.successors = object;
                        "".length();
                        if ("   ".length() >= (0xCE ^ 0xA1 ^ (0xAF ^ 0xC4))) {
                            return;
                        }
                    } else {
                        ((Edge)object).next = label6.successors.next.next;
                        label6.successors.next.next = object;
                    }
                    label6 = label6.successor;
                    "".length();
                    if (null == null) continue;
                    return;
                }
                handler = handler.next;
                "".length();
                if ("   ".length() != 0) continue;
                return;
            }
            if (MethodWriter.lIIIllIllIII(this.subroutines)) {
                int n9 = 0;
                this.labels.visitSubroutine(null, 1L, this.subroutines);
                label5 = this.labels;
                while (MethodWriter.lIIIllIlIlll(label5)) {
                    if (MethodWriter.lIIIllIlIllI(label5.status & 0x80)) {
                        label = label5.successors.next.successor;
                        if (MethodWriter.lIIIllIllIll(label.status & 0x400)) {
                            label.visitSubroutine(null, (long)(++n9) / 32L << 32 | 1L << n9 % 32, this.subroutines);
                        }
                    }
                    label5 = label5.successor;
                    "".length();
                    if (((4 ^ 0x45 ^ (0x21 ^ 0x4C)) & (88 + 53 - 95 + 99 ^ 4 + 44 - -135 + 6 ^ -" ".length())) == 0) continue;
                    return;
                }
                label5 = this.labels;
                while (MethodWriter.lIIIllIlIlll(label5)) {
                    if (MethodWriter.lIIIllIlIllI(label5.status & 0x80)) {
                        label = this.labels;
                        while (MethodWriter.lIIIllIlIlll(label)) {
                            label.status &= 0xFFFFF7FF;
                            label = label.successor;
                            "".length();
                            if (" ".length() == " ".length()) continue;
                            return;
                        }
                        object = label5.successors.next.successor;
                        ((Label)object).visitSubroutine(label5, 0L, this.subroutines);
                    }
                    label5 = label5.successor;
                    "".length();
                    if ((0x37 ^ 0x49 ^ (0x37 ^ 0x4D)) >= "  ".length()) continue;
                    return;
                }
            }
            int n10 = 0;
            label5 = this.labels;
            while (MethodWriter.lIIIllIlIlll(label5)) {
                label = label5;
                label5 = label5.next;
                int n11 = label.inputStackTop;
                int n12 = n11 + label.outputStackMax;
                if (MethodWriter.lIIIllIllllI(n12, n10)) {
                    n10 = n12;
                }
                Edge edge = label.successors;
                if (MethodWriter.lIIIllIlIllI(label.status & 0x80)) {
                    edge = edge.next;
                }
                while (MethodWriter.lIIIllIlIlll(edge)) {
                    label = edge.successor;
                    if (MethodWriter.lIIIllIllIll(label.status & 8)) {
                        int n13;
                        if (MethodWriter.lIIIllIlllII(edge.info, Integer.MAX_VALUE)) {
                            n13 = 1;
                            "".length();
                            if (" ".length() <= 0) {
                                return;
                            }
                        } else {
                            n13 = n11 + edge.info;
                        }
                        label.inputStackTop = n13;
                        label.status |= 8;
                        label.next = label5;
                        label5 = label;
                    }
                    edge = edge.next;
                    "".length();
                    if ("  ".length() >= " ".length()) continue;
                    return;
                }
                "".length();
                if ("   ".length() == "   ".length()) continue;
                return;
            }
            this.maxStack = Math.max(n, n10);
            "".length();
            if (-(0x6F ^ 0x63 ^ (0x1B ^ 0x13)) >= 0) {
                return;
            }
        } else {
            this.maxStack = n;
            this.maxLocals = n2;
        }
    }

    public void visitEnd() {
    }

    private void addSuccessor(int n, Label label) {
        Edge edge = new Edge();
        edge.info = n;
        edge.successor = label;
        edge.next = this.currentBlock.successors;
        this.currentBlock.successors = edge;
    }

    private void noSuccessor() {
        if (MethodWriter.lIIIllIllIll(this.compute)) {
            Label label = new Label();
            label.frame = new Frame();
            label.frame.owner = label;
            label.resolve(this, this.code.length, this.code.data);
            "".length();
            this.previousBlock.successor = label;
            this.previousBlock = label;
            "".length();
            if (((0x32 ^ 0x3F) & ~(0xB2 ^ 0xBF)) >= (0x79 ^ 0x7D)) {
                return;
            }
        } else {
            this.currentBlock.outputStackMax = this.maxStackSize;
        }
        if (MethodWriter.lIIIllIllIlI(this.compute, 1)) {
            this.currentBlock = null;
        }
    }

    private void visitFrame(Frame frame) {
        int n;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int[] nArray = frame.inputLocals;
        int[] nArray2 = frame.inputStack;
        int n5 = 0;
        while (MethodWriter.lIIIllIllIIl(n5, nArray.length)) {
            n = nArray[n5];
            if (MethodWriter.lIIIllIlllII(n, 0x1000000)) {
                ++n2;
                "".length();
                if ((0x99 ^ 0x9C) == 0) {
                    return;
                }
            } else {
                n3 += n2 + 1;
                n2 = 0;
            }
            if (!MethodWriter.lIIIllIllIlI(n, 0x1000004) || MethodWriter.lIIIllIlllII(n, 0x1000003)) {
                ++n5;
            }
            ++n5;
            "".length();
            if (-"  ".length() < 0) continue;
            return;
        }
        n5 = 0;
        while (MethodWriter.lIIIllIllIIl(n5, nArray2.length)) {
            n = nArray2[n5];
            ++n4;
            if (!MethodWriter.lIIIllIllIlI(n, 0x1000004) || MethodWriter.lIIIllIlllII(n, 0x1000003)) {
                ++n5;
            }
            ++n5;
            "".length();
            if ("  ".length() < (0xB0 ^ 0x89 ^ (0x71 ^ 0x4C))) continue;
            return;
        }
        int n6 = this.startFrame(frame.owner.position, n3, n4);
        n5 = 0;
        while (MethodWriter.lIIIllIllIII(n3)) {
            n = nArray[n5];
            this.frame[n6++] = n;
            if (!MethodWriter.lIIIllIllIlI(n, 0x1000004) || MethodWriter.lIIIllIlllII(n, 0x1000003)) {
                ++n5;
            }
            ++n5;
            --n3;
            "".length();
            if (null == null) continue;
            return;
        }
        n5 = 0;
        while (MethodWriter.lIIIllIllIIl(n5, nArray2.length)) {
            n = nArray2[n5];
            this.frame[n6++] = n;
            if (!MethodWriter.lIIIllIllIlI(n, 0x1000004) || MethodWriter.lIIIllIlllII(n, 0x1000003)) {
                ++n5;
            }
            ++n5;
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return;
        }
        this.endFrame();
    }

    private void visitImplicitFirstFrame() {
        int n;
        block18: {
            n = this.startFrame(0, this.descriptor.length() + 1, 0);
            if (MethodWriter.lIIIllIllIll(this.access & 8)) {
                if (MethodWriter.lIIIllIllIll(this.access & 0x80000)) {
                    this.frame[n++] = 0x1700000 | this.cw.addType(this.cw.thisName);
                    "".length();
                    if (-" ".length() > ((0xC2 ^ 0x9F) & ~(0x11 ^ 0x4C))) {
                        return;
                    }
                } else {
                    this.frame[n++] = 6;
                }
            }
            int n2 = 1;
            do {
                int n3 = n2;
                switch (this.descriptor.charAt(n2++)) {
                    case 'B': 
                    case 'C': 
                    case 'I': 
                    case 'S': 
                    case 'Z': {
                        this.frame[n++] = 1;
                        "".length();
                        if (-(0x7A ^ 0x73 ^ (9 ^ 5)) < 0) break;
                        return;
                    }
                    case 'F': {
                        this.frame[n++] = 2;
                        "".length();
                        if ((0x2B ^ 0x2E) > 0) break;
                        return;
                    }
                    case 'J': {
                        this.frame[n++] = 4;
                        "".length();
                        if (" ".length() < "   ".length()) break;
                        return;
                    }
                    case 'D': {
                        this.frame[n++] = 3;
                        "".length();
                        if (((48 + 158 - 91 + 56 ^ 32 + 44 - -34 + 81) & (0x76 ^ 0x51 ^ (0xA7 ^ 0x94) ^ -" ".length())) == ("   ".length() & ("   ".length() ^ -" ".length()))) break;
                        return;
                    }
                    case '[': {
                        while (MethodWriter.lIIIllIlllII(this.descriptor.charAt(n2), 91)) {
                            ++n2;
                            "".length();
                            if ("  ".length() >= 0) continue;
                            return;
                        }
                        if (MethodWriter.lIIIllIlllII(this.descriptor.charAt(n2), 76)) {
                            ++n2;
                            while (MethodWriter.lIIIllIllIlI(this.descriptor.charAt(n2), 59)) {
                                ++n2;
                                "".length();
                                if (-(0x37 ^ 0x41 ^ (0x3E ^ 0x4C)) < 0) continue;
                                return;
                            }
                        }
                        this.frame[n++] = 0x1700000 | this.cw.addType(this.descriptor.substring(n3, ++n2));
                        "".length();
                        if ("  ".length() != 0) break;
                        return;
                    }
                    case 'L': {
                        while (MethodWriter.lIIIllIllIlI(this.descriptor.charAt(n2), 59)) {
                            ++n2;
                            "".length();
                            if (((0x6B ^ 0x50) & ~(0x74 ^ 0x4F)) >= 0) continue;
                            return;
                        }
                        this.frame[n++] = 0x1700000 | this.cw.addType(this.descriptor.substring(n3 + 1, n2++));
                        "".length();
                        if (-"  ".length() < 0) break;
                        return;
                    }
                    default: {
                        "".length();
                        if ("  ".length() >= "   ".length()) {
                            return;
                        }
                        break block18;
                    }
                }
                "".length();
            } while ("   ".length() >= "  ".length());
            return;
        }
        this.frame[1] = n - 3;
        this.endFrame();
    }

    private int startFrame(int n, int n2, int n3) {
        int n4 = 3 + n2 + n3;
        if (!MethodWriter.lIIIllIlIlll(this.frame) || MethodWriter.lIIIllIllIIl(this.frame.length, n4)) {
            this.frame = new int[n4];
        }
        this.frame[0] = n;
        this.frame[1] = n2;
        this.frame[2] = n3;
        return 3;
    }

    private void endFrame() {
        if (MethodWriter.lIIIllIlIlll(this.previousFrame)) {
            if (MethodWriter.lIIIllIlIlIl(this.stackMap)) {
                this.stackMap = new ByteVector();
            }
            this.writeFrame();
            ++this.frameCount;
        }
        this.previousFrame = this.frame;
        this.frame = null;
    }

    private void writeFrame() {
        int n;
        int n2 = this.frame[1];
        int n3 = this.frame[2];
        if (MethodWriter.lIIIllIllIIl(this.cw.version & 0xFFFF, 50)) {
            this.stackMap.putShort(this.frame[0]).putShort(n2);
            "".length();
            this.writeFrameTypes(3, 3 + n2);
            this.stackMap.putShort(n3);
            "".length();
            this.writeFrameTypes(3 + n2, 3 + n2 + n3);
            return;
        }
        int n4 = this.previousFrame[1];
        int n5 = 255;
        int n6 = 0;
        if (MethodWriter.lIIIllIllIll(this.frameCount)) {
            n = this.frame[0];
            "".length();
            if (((26 + 85 - -31 + 3 ^ 130 + 95 - 87 + 60) & (0x92 ^ 0xA6 ^ (0x27 ^ 0x44) ^ -" ".length())) != 0) {
                return;
            }
        } else {
            n = this.frame[0] - this.previousFrame[0] - 1;
        }
        if (MethodWriter.lIIIllIllIll(n3)) {
            n6 = n2 - n4;
            switch (n6) {
                case -3: 
                case -2: 
                case -1: {
                    n5 = 248;
                    n4 = n2;
                    "".length();
                    if ("   ".length() != 0) break;
                    return;
                }
                case 0: {
                    int n7;
                    if (MethodWriter.lIIIllIllIIl(n, 64)) {
                        n7 = 0;
                        "".length();
                        if (((115 + 104 - 137 + 54 ^ 118 + 119 - 232 + 126) & (129 + 8 - 105 + 107 ^ 60 + 26 - 44 + 86 ^ -" ".length())) != 0) {
                            return;
                        }
                    } else {
                        n7 = 251;
                    }
                    n5 = n7;
                    "".length();
                    if ((0x16 ^ 0x12) > 0) break;
                    return;
                }
                case 1: 
                case 2: 
                case 3: {
                    n5 = 252;
                }
            }
            "".length();
            if (" ".length() < 0) {
                return;
            }
        } else if (MethodWriter.lIIIllIlllII(n2, n4) && MethodWriter.lIIIllIlllII(n3, 1)) {
            int n8;
            if (MethodWriter.lIIIllIllIIl(n, 63)) {
                n8 = 64;
                "".length();
                if (" ".length() <= ("   ".length() & ("   ".length() ^ -" ".length()))) {
                    return;
                }
            } else {
                n8 = n5 = 247;
            }
        }
        if (MethodWriter.lIIIllIllIlI(n5, 255)) {
            int n9 = 3;
            int n10 = 0;
            while (MethodWriter.lIIIllIllIIl(n10, n4)) {
                if (MethodWriter.lIIIllIllIlI(this.frame[n9], this.previousFrame[n9])) {
                    n5 = 255;
                    "".length();
                    if (null == null) break;
                    return;
                }
                ++n9;
                ++n10;
                "".length();
                if ("   ".length() > 0) continue;
                return;
            }
        }
        switch (n5) {
            case 0: {
                this.stackMap.putByte(n);
                "".length();
                "".length();
                if (((0x1A ^ 0x35) & ~(0x7D ^ 0x52)) <= (0x43 ^ 0x47)) break;
                return;
            }
            case 64: {
                this.stackMap.putByte(64 + n);
                "".length();
                this.writeFrameTypes(3 + n2, 4 + n2);
                "".length();
                if (-" ".length() <= 0) break;
                return;
            }
            case 247: {
                this.stackMap.putByte(247).putShort(n);
                "".length();
                this.writeFrameTypes(3 + n2, 4 + n2);
                "".length();
                if ((0x92 ^ 0x96) > "   ".length()) break;
                return;
            }
            case 251: {
                this.stackMap.putByte(251).putShort(n);
                "".length();
                "".length();
                if ((92 + 70 - 41 + 34 ^ 14 + 51 - 3 + 97) > " ".length()) break;
                return;
            }
            case 248: {
                this.stackMap.putByte(251 + n6).putShort(n);
                "".length();
                "".length();
                if (((0xD9 ^ 0x8E) & ~(0x49 ^ 0x1E)) < " ".length()) break;
                return;
            }
            case 252: {
                this.stackMap.putByte(251 + n6).putShort(n);
                "".length();
                this.writeFrameTypes(3 + n4, 3 + n2);
                "".length();
                if (((0xE ^ 0x4A) & ~(0xFC ^ 0xB8)) == 0) break;
                return;
            }
            default: {
                this.stackMap.putByte(255).putShort(n).putShort(n2);
                "".length();
                this.writeFrameTypes(3, 3 + n2);
                this.stackMap.putShort(n3);
                "".length();
                this.writeFrameTypes(3 + n2, 3 + n2 + n3);
            }
        }
    }

    private void writeFrameTypes(int n, int n2) {
        int n3 = n;
        while (MethodWriter.lIIIllIllIIl(n3, n2)) {
            int n4 = this.frame[n3];
            int n5 = n4 & 0xF0000000;
            if (MethodWriter.lIIIllIllIll(n5)) {
                int n6 = n4 & 0xFFFFF;
                switch (n4 & 0xFF00000) {
                    case 0x1700000: {
                        this.stackMap.putByte(7).putShort(this.cw.newClass(this.cw.typeTable[n6].strVal1));
                        "".length();
                        "".length();
                        if ("   ".length() == "   ".length()) break;
                        return;
                    }
                    case 0x1800000: {
                        this.stackMap.putByte(8).putShort(this.cw.typeTable[n6].intVal);
                        "".length();
                        "".length();
                        if ((109 + 78 - 91 + 73 ^ 12 + 60 - -5 + 96) >= -" ".length()) break;
                        return;
                    }
                    default: {
                        this.stackMap.putByte(n6);
                        "".length();
                    }
                }
                "".length();
                if (-(0x5A ^ 0x5E) >= 0) {
                    return;
                }
            } else {
                StringBuilder stringBuilder = new StringBuilder();
                n5 >>= 28;
                while (MethodWriter.lIIIllIllIII(n5--)) {
                    stringBuilder.append('[');
                    "".length();
                    "".length();
                    if (" ".length() <= "  ".length()) continue;
                    return;
                }
                if (MethodWriter.lIIIllIlllII(n4 & 0xFF00000, 0x1700000)) {
                    stringBuilder.append('L');
                    "".length();
                    stringBuilder.append(this.cw.typeTable[n4 & 0xFFFFF].strVal1);
                    "".length();
                    stringBuilder.append(';');
                    "".length();
                    "".length();
                    if (((0x88 ^ 0xAF) & ~(0x7E ^ 0x59)) != 0) {
                        return;
                    }
                } else {
                    switch (n4 & 0xF) {
                        case 1: {
                            stringBuilder.append('I');
                            "".length();
                            "".length();
                            if ("  ".length() == "  ".length()) break;
                            return;
                        }
                        case 2: {
                            stringBuilder.append('F');
                            "".length();
                            "".length();
                            if (null == null) break;
                            return;
                        }
                        case 3: {
                            stringBuilder.append('D');
                            "".length();
                            "".length();
                            if ((0x8E ^ 0x8A) <= (0x13 ^ 0x17)) break;
                            return;
                        }
                        case 9: {
                            stringBuilder.append('Z');
                            "".length();
                            "".length();
                            if ((0x66 ^ 0x42 ^ (0x12 ^ 0x32)) > " ".length()) break;
                            return;
                        }
                        case 10: {
                            stringBuilder.append('B');
                            "".length();
                            "".length();
                            if ("   ".length() > 0) break;
                            return;
                        }
                        case 11: {
                            stringBuilder.append('C');
                            "".length();
                            "".length();
                            if (-(0x39 ^ 0x3D) <= 0) break;
                            return;
                        }
                        case 12: {
                            stringBuilder.append('S');
                            "".length();
                            "".length();
                            if (-" ".length() <= "  ".length()) break;
                            return;
                        }
                        default: {
                            stringBuilder.append('J');
                            "".length();
                        }
                    }
                }
                this.stackMap.putByte(7).putShort(this.cw.newClass(String.valueOf(stringBuilder)));
                "".length();
            }
            ++n3;
            "".length();
            if ("  ".length() >= ((0xEE ^ 0xB6) & ~(0x5D ^ 5))) continue;
            return;
        }
    }

    private void writeFrameType(Object object) {
        if (MethodWriter.lIIIllIlIllI(object instanceof String)) {
            this.stackMap.putByte(7).putShort(this.cw.newClass((String)object));
            "".length();
            "".length();
            if ("  ".length() > (0x83 ^ 0x87)) {
                return;
            }
        } else if (MethodWriter.lIIIllIlIllI(object instanceof Integer)) {
            this.stackMap.putByte((Integer)object);
            "".length();
            "".length();
            if (" ".length() != " ".length()) {
                return;
            }
        } else {
            this.stackMap.putByte(8).putShort(((Label)object).position);
            "".length();
        }
    }

    final int getSize() {
        int n;
        if (MethodWriter.lIIIllIlIllI(this.classReaderOffset)) {
            return 6 + this.classReaderLength;
        }
        int n2 = 8;
        if (MethodWriter.lIIIllIllIII(this.code.length)) {
            if (MethodWriter.lIIIllIllllI(this.code.length, 65535)) {
                throw new RuntimeException("Method code too large!");
            }
            this.cw.newUTF8("Code");
            "".length();
            n2 += 18 + this.code.length + 8 * this.handlerCount;
            if (MethodWriter.lIIIllIlIlll(this.localVar)) {
                this.cw.newUTF8("LocalVariableTable");
                "".length();
                n2 += 8 + this.localVar.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.localVarType)) {
                this.cw.newUTF8("LocalVariableTypeTable");
                "".length();
                n2 += 8 + this.localVarType.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.lineNumber)) {
                this.cw.newUTF8("LineNumberTable");
                "".length();
                n2 += 8 + this.lineNumber.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.stackMap)) {
                String string;
                int n3;
                if (MethodWriter.lIIIllIlllll(this.cw.version & 0xFFFF, 50)) {
                    n3 = 1;
                    "".length();
                    if ((0xB4 ^ 0xB0) <= 0) {
                        return (0xEA ^ 0xC3) & ~(0x6C ^ 0x45);
                    }
                } else {
                    n3 = 0;
                }
                if (MethodWriter.lIIIllIlIllI(n = n3)) {
                    string = "StackMapTable";
                    "".length();
                    if (-" ".length() >= "  ".length()) {
                        return (0x2D ^ 0x4E ^ (0xD4 ^ 0xA6)) & (" ".length() ^ (0x54 ^ 0x44) ^ -" ".length());
                    }
                } else {
                    string = "StackMap";
                }
                this.cw.newUTF8(string);
                "".length();
                n2 += 8 + this.stackMap.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.ctanns)) {
                this.cw.newUTF8("RuntimeVisibleTypeAnnotations");
                "".length();
                n2 += 8 + this.ctanns.getSize();
            }
            if (MethodWriter.lIIIllIlIlll(this.ictanns)) {
                this.cw.newUTF8("RuntimeInvisibleTypeAnnotations");
                "".length();
                n2 += 8 + this.ictanns.getSize();
            }
            if (MethodWriter.lIIIllIlIlll(this.cattrs)) {
                n2 += this.cattrs.getSize(this.cw, this.code.data, this.code.length, this.maxStack, this.maxLocals);
            }
        }
        if (MethodWriter.lIIIllIllIII(this.exceptionCount)) {
            this.cw.newUTF8("Exceptions");
            "".length();
            n2 += 8 + 2 * this.exceptionCount;
        }
        if (MethodWriter.lIIIllIlIllI(this.access & 0x1000) && (!MethodWriter.lIIIllIlllll(this.cw.version & 0xFFFF, 49) || MethodWriter.lIIIllIlIllI(this.access & 0x40000))) {
            this.cw.newUTF8("Synthetic");
            "".length();
            n2 += 6;
        }
        if (MethodWriter.lIIIllIlIllI(this.access & 0x20000)) {
            this.cw.newUTF8("Deprecated");
            "".length();
            n2 += 6;
        }
        if (MethodWriter.lIIIllIlIlll(this.signature)) {
            this.cw.newUTF8("Signature");
            "".length();
            this.cw.newUTF8(this.signature);
            "".length();
            n2 += 8;
        }
        if (MethodWriter.lIIIllIlIlll(this.methodParameters)) {
            this.cw.newUTF8("MethodParameters");
            "".length();
            n2 += 7 + this.methodParameters.length;
        }
        if (MethodWriter.lIIIllIlIlll(this.annd)) {
            this.cw.newUTF8("AnnotationDefault");
            "".length();
            n2 += 6 + this.annd.length;
        }
        if (MethodWriter.lIIIllIlIlll(this.anns)) {
            this.cw.newUTF8("RuntimeVisibleAnnotations");
            "".length();
            n2 += 8 + this.anns.getSize();
        }
        if (MethodWriter.lIIIllIlIlll(this.ianns)) {
            this.cw.newUTF8("RuntimeInvisibleAnnotations");
            "".length();
            n2 += 8 + this.ianns.getSize();
        }
        if (MethodWriter.lIIIllIlIlll(this.tanns)) {
            this.cw.newUTF8("RuntimeVisibleTypeAnnotations");
            "".length();
            n2 += 8 + this.tanns.getSize();
        }
        if (MethodWriter.lIIIllIlIlll(this.itanns)) {
            this.cw.newUTF8("RuntimeInvisibleTypeAnnotations");
            "".length();
            n2 += 8 + this.itanns.getSize();
        }
        if (MethodWriter.lIIIllIlIlll(this.panns)) {
            this.cw.newUTF8("RuntimeVisibleParameterAnnotations");
            "".length();
            n2 += 7 + 2 * (this.panns.length - this.synthetics);
            n = this.panns.length - 1;
            while (MethodWriter.lIIIllIlllll(n, this.synthetics)) {
                int n4;
                if (MethodWriter.lIIIllIlIlIl(this.panns[n])) {
                    n4 = 0;
                    "".length();
                    if (-" ".length() > "   ".length()) {
                        return (0x96 ^ 0x9A) & ~(0xBB ^ 0xB7);
                    }
                } else {
                    n4 = this.panns[n].getSize();
                }
                n2 += n4;
                --n;
                "".length();
                if (((0x35 ^ 0x11) & ~(0xBF ^ 0x9B)) == 0) continue;
                return (0xA4 ^ 0x88) & ~(0xD ^ 0x21);
            }
        }
        if (MethodWriter.lIIIllIlIlll(this.ipanns)) {
            this.cw.newUTF8("RuntimeInvisibleParameterAnnotations");
            "".length();
            n2 += 7 + 2 * (this.ipanns.length - this.synthetics);
            n = this.ipanns.length - 1;
            while (MethodWriter.lIIIllIlllll(n, this.synthetics)) {
                int n5;
                if (MethodWriter.lIIIllIlIlIl(this.ipanns[n])) {
                    n5 = 0;
                    "".length();
                    if ((0x9D ^ 0x99) <= ((0x97 ^ 0xBE) & ~(0x64 ^ 0x4D))) {
                        return (0x74 ^ 0x24) & ~(0xB ^ 0x5B);
                    }
                } else {
                    n5 = this.ipanns[n].getSize();
                }
                n2 += n5;
                --n;
                "".length();
                if ("  ".length() > -" ".length()) continue;
                return "   ".length() & ("   ".length() ^ -" ".length());
            }
        }
        if (MethodWriter.lIIIllIlIlll(this.attrs)) {
            n2 += this.attrs.getSize(this.cw, null, 0, -1, -1);
        }
        return n2;
    }

    final void put(ByteVector byteVector) {
        int n;
        int n2 = 64;
        int n3 = 0xE0000 | (this.access & 0x40000) / 64;
        byteVector.putShort(this.access & ~n3).putShort(this.name).putShort(this.desc);
        "".length();
        if (MethodWriter.lIIIllIlIllI(this.classReaderOffset)) {
            byteVector.putByteArray(this.cw.cr.b, this.classReaderOffset, this.classReaderLength);
            "".length();
            return;
        }
        int n4 = 0;
        if (MethodWriter.lIIIllIllIII(this.code.length)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIllIII(this.exceptionCount)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIllI(this.access & 0x1000) && (!MethodWriter.lIIIllIlllll(this.cw.version & 0xFFFF, 49) || MethodWriter.lIIIllIlIllI(this.access & 0x40000))) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIllI(this.access & 0x20000)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.signature)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.methodParameters)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.annd)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.anns)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.ianns)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.tanns)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.itanns)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.panns)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.ipanns)) {
            ++n4;
        }
        if (MethodWriter.lIIIllIlIlll(this.attrs)) {
            n4 += this.attrs.getCount();
        }
        byteVector.putShort(n4);
        "".length();
        if (MethodWriter.lIIIllIllIII(this.code.length)) {
            n = 12 + this.code.length + 8 * this.handlerCount;
            if (MethodWriter.lIIIllIlIlll(this.localVar)) {
                n += 8 + this.localVar.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.localVarType)) {
                n += 8 + this.localVarType.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.lineNumber)) {
                n += 8 + this.lineNumber.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.stackMap)) {
                n += 8 + this.stackMap.length;
            }
            if (MethodWriter.lIIIllIlIlll(this.ctanns)) {
                n += 8 + this.ctanns.getSize();
            }
            if (MethodWriter.lIIIllIlIlll(this.ictanns)) {
                n += 8 + this.ictanns.getSize();
            }
            if (MethodWriter.lIIIllIlIlll(this.cattrs)) {
                n += this.cattrs.getSize(this.cw, this.code.data, this.code.length, this.maxStack, this.maxLocals);
            }
            byteVector.putShort(this.cw.newUTF8("Code")).putInt(n);
            "".length();
            byteVector.putShort(this.maxStack).putShort(this.maxLocals);
            "".length();
            byteVector.putInt(this.code.length).putByteArray(this.code.data, 0, this.code.length);
            "".length();
            byteVector.putShort(this.handlerCount);
            "".length();
            if (MethodWriter.lIIIllIllIII(this.handlerCount)) {
                Handler handler = this.firstHandler;
                while (MethodWriter.lIIIllIlIlll(handler)) {
                    byteVector.putShort(handler.start.position).putShort(handler.end.position).putShort(handler.handler.position).putShort(handler.type);
                    "".length();
                    handler = handler.next;
                    "".length();
                    if (null == null) continue;
                    return;
                }
            }
            n4 = 0;
            if (MethodWriter.lIIIllIlIlll(this.localVar)) {
                ++n4;
            }
            if (MethodWriter.lIIIllIlIlll(this.localVarType)) {
                ++n4;
            }
            if (MethodWriter.lIIIllIlIlll(this.lineNumber)) {
                ++n4;
            }
            if (MethodWriter.lIIIllIlIlll(this.stackMap)) {
                ++n4;
            }
            if (MethodWriter.lIIIllIlIlll(this.ctanns)) {
                ++n4;
            }
            if (MethodWriter.lIIIllIlIlll(this.ictanns)) {
                ++n4;
            }
            if (MethodWriter.lIIIllIlIlll(this.cattrs)) {
                n4 += this.cattrs.getCount();
            }
            byteVector.putShort(n4);
            "".length();
            if (MethodWriter.lIIIllIlIlll(this.localVar)) {
                byteVector.putShort(this.cw.newUTF8("LocalVariableTable"));
                "".length();
                byteVector.putInt(this.localVar.length + 2).putShort(this.localVarCount);
                "".length();
                byteVector.putByteArray(this.localVar.data, 0, this.localVar.length);
                "".length();
            }
            if (MethodWriter.lIIIllIlIlll(this.localVarType)) {
                byteVector.putShort(this.cw.newUTF8("LocalVariableTypeTable"));
                "".length();
                byteVector.putInt(this.localVarType.length + 2).putShort(this.localVarTypeCount);
                "".length();
                byteVector.putByteArray(this.localVarType.data, 0, this.localVarType.length);
                "".length();
            }
            if (MethodWriter.lIIIllIlIlll(this.lineNumber)) {
                byteVector.putShort(this.cw.newUTF8("LineNumberTable"));
                "".length();
                byteVector.putInt(this.lineNumber.length + 2).putShort(this.lineNumberCount);
                "".length();
                byteVector.putByteArray(this.lineNumber.data, 0, this.lineNumber.length);
                "".length();
            }
            if (MethodWriter.lIIIllIlIlll(this.stackMap)) {
                String string;
                int n5;
                int n6;
                if (MethodWriter.lIIIllIlllll(this.cw.version & 0xFFFF, 50)) {
                    n6 = 1;
                    "".length();
                    if (-(8 ^ 0xC) > 0) {
                        return;
                    }
                } else {
                    n6 = 0;
                }
                if (MethodWriter.lIIIllIlIllI(n5 = n6)) {
                    string = "StackMapTable";
                    "".length();
                    if ("   ".length() == ((0x9F ^ 0x95 ^ (0x1F ^ 0x5B)) & (7 + 233 - 9 + 19 ^ 22 + 55 - 14 + 117 ^ -" ".length()))) {
                        return;
                    }
                } else {
                    string = "StackMap";
                }
                byteVector.putShort(this.cw.newUTF8(string));
                "".length();
                byteVector.putInt(this.stackMap.length + 2).putShort(this.frameCount);
                "".length();
                byteVector.putByteArray(this.stackMap.data, 0, this.stackMap.length);
                "".length();
            }
            if (MethodWriter.lIIIllIlIlll(this.ctanns)) {
                byteVector.putShort(this.cw.newUTF8("RuntimeVisibleTypeAnnotations"));
                "".length();
                this.ctanns.put(byteVector);
            }
            if (MethodWriter.lIIIllIlIlll(this.ictanns)) {
                byteVector.putShort(this.cw.newUTF8("RuntimeInvisibleTypeAnnotations"));
                "".length();
                this.ictanns.put(byteVector);
            }
            if (MethodWriter.lIIIllIlIlll(this.cattrs)) {
                this.cattrs.put(this.cw, this.code.data, this.code.length, this.maxLocals, this.maxStack, byteVector);
            }
        }
        if (MethodWriter.lIIIllIllIII(this.exceptionCount)) {
            byteVector.putShort(this.cw.newUTF8("Exceptions")).putInt(2 * this.exceptionCount + 2);
            "".length();
            byteVector.putShort(this.exceptionCount);
            "".length();
            n = 0;
            while (MethodWriter.lIIIllIllIIl(n, this.exceptionCount)) {
                byteVector.putShort(this.exceptions[n]);
                "".length();
                ++n;
                "".length();
                if ("   ".length() > " ".length()) continue;
                return;
            }
        }
        if (MethodWriter.lIIIllIlIllI(this.access & 0x1000) && (!MethodWriter.lIIIllIlllll(this.cw.version & 0xFFFF, 49) || MethodWriter.lIIIllIlIllI(this.access & 0x40000))) {
            byteVector.putShort(this.cw.newUTF8("Synthetic")).putInt(0);
            "".length();
        }
        if (MethodWriter.lIIIllIlIllI(this.access & 0x20000)) {
            byteVector.putShort(this.cw.newUTF8("Deprecated")).putInt(0);
            "".length();
        }
        if (MethodWriter.lIIIllIlIlll(this.signature)) {
            byteVector.putShort(this.cw.newUTF8("Signature")).putInt(2).putShort(this.cw.newUTF8(this.signature));
            "".length();
        }
        if (MethodWriter.lIIIllIlIlll(this.methodParameters)) {
            byteVector.putShort(this.cw.newUTF8("MethodParameters"));
            "".length();
            byteVector.putInt(this.methodParameters.length + 1).putByte(this.methodParametersCount);
            "".length();
            byteVector.putByteArray(this.methodParameters.data, 0, this.methodParameters.length);
            "".length();
        }
        if (MethodWriter.lIIIllIlIlll(this.annd)) {
            byteVector.putShort(this.cw.newUTF8("AnnotationDefault"));
            "".length();
            byteVector.putInt(this.annd.length);
            "".length();
            byteVector.putByteArray(this.annd.data, 0, this.annd.length);
            "".length();
        }
        if (MethodWriter.lIIIllIlIlll(this.anns)) {
            byteVector.putShort(this.cw.newUTF8("RuntimeVisibleAnnotations"));
            "".length();
            this.anns.put(byteVector);
        }
        if (MethodWriter.lIIIllIlIlll(this.ianns)) {
            byteVector.putShort(this.cw.newUTF8("RuntimeInvisibleAnnotations"));
            "".length();
            this.ianns.put(byteVector);
        }
        if (MethodWriter.lIIIllIlIlll(this.tanns)) {
            byteVector.putShort(this.cw.newUTF8("RuntimeVisibleTypeAnnotations"));
            "".length();
            this.tanns.put(byteVector);
        }
        if (MethodWriter.lIIIllIlIlll(this.itanns)) {
            byteVector.putShort(this.cw.newUTF8("RuntimeInvisibleTypeAnnotations"));
            "".length();
            this.itanns.put(byteVector);
        }
        if (MethodWriter.lIIIllIlIlll(this.panns)) {
            byteVector.putShort(this.cw.newUTF8("RuntimeVisibleParameterAnnotations"));
            "".length();
            AnnotationWriter.put(this.panns, this.synthetics, byteVector);
        }
        if (MethodWriter.lIIIllIlIlll(this.ipanns)) {
            byteVector.putShort(this.cw.newUTF8("RuntimeInvisibleParameterAnnotations"));
            "".length();
            AnnotationWriter.put(this.ipanns, this.synthetics, byteVector);
        }
        if (MethodWriter.lIIIllIlIlll(this.attrs)) {
            this.attrs.put(this.cw, null, 0, -1, -1, byteVector);
        }
    }

    static {
        SAME_FRAME = 0;
        APPEND_FRAME = 252;
        SAME_LOCALS_1_STACK_ITEM_FRAME_EXTENDED = 247;
        ACC_CONSTRUCTOR = 524288;
        FULL_FRAME = 255;
        SAME_LOCALS_1_STACK_ITEM_FRAME = 64;
        CHOP_FRAME = 248;
        FRAMES = 0;
        INSERTED_FRAMES = 1;
        MAXS = 2;
        RESERVED = 128;
        NOTHING = 3;
        SAME_FRAME_EXTENDED = 251;
    }

    private static boolean lIIIllIlllII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIllIlllll(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIllIllIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlllIIIII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIllIllllI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlllIIIIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIllIlIlll(Object object) {
        return object != null;
    }

    private static boolean lIIIllIlIlIl(Object object) {
        return object == null;
    }

    private static boolean lIIIllIlIllI(int n) {
        return n != 0;
    }

    private static boolean lIIIllIllIll(int n) {
        return n == 0;
    }

    private static boolean lIIIllIlllIl(int n) {
        return n < 0;
    }

    private static boolean lIIIllIllIII(int n) {
        return n > 0;
    }

    private static boolean lIIIllIllIlI(int n, int n2) {
        return n != n2;
    }
}

