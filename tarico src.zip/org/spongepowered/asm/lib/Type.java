/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class Type {
    public static final int VOID;
    public static final int BOOLEAN;
    public static final int CHAR;
    public static final int BYTE;
    public static final int SHORT;
    public static final int INT;
    public static final int FLOAT;
    public static final int LONG;
    public static final int DOUBLE;
    public static final int ARRAY;
    public static final int OBJECT;
    public static final int METHOD;
    public static final Type VOID_TYPE;
    public static final Type BOOLEAN_TYPE;
    public static final Type CHAR_TYPE;
    public static final Type BYTE_TYPE;
    public static final Type SHORT_TYPE;
    public static final Type INT_TYPE;
    public static final Type FLOAT_TYPE;
    public static final Type LONG_TYPE;
    public static final Type DOUBLE_TYPE;
    private final int sort;
    private final char[] buf;
    private final int off;
    private final int len;

    private Type(int n, char[] cArray, int n2, int n3) {
        this.sort = n;
        this.buf = cArray;
        this.off = n2;
        this.len = n3;
    }

    public static Type getType(String string) {
        return Type.getType(string.toCharArray(), 0);
    }

    public static Type getObjectType(String string) {
        int n;
        char[] cArray = string.toCharArray();
        if (Type.lIlIllIIlI(cArray[0], 91)) {
            n = 9;
            "".length();
            if (-" ".length() >= 0) {
                return null;
            }
        } else {
            n = 10;
        }
        return new Type(n, cArray, 0, cArray.length);
    }

    public static Type getMethodType(String string) {
        return Type.getType(string.toCharArray(), 0);
    }

    public static Type getMethodType(Type type, Type ... typeArray) {
        return Type.getType(Type.getMethodDescriptor(type, typeArray));
    }

    public static Type getType(Class<?> clazz) {
        if (Type.lIlIllIIll(clazz.isPrimitive() ? 1 : 0)) {
            if (Type.lIlIllIlII(clazz, Integer.TYPE)) {
                return INT_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Void.TYPE)) {
                return VOID_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Boolean.TYPE)) {
                return BOOLEAN_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Byte.TYPE)) {
                return BYTE_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Character.TYPE)) {
                return CHAR_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Short.TYPE)) {
                return SHORT_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Double.TYPE)) {
                return DOUBLE_TYPE;
            }
            if (Type.lIlIllIlII(clazz, Float.TYPE)) {
                return FLOAT_TYPE;
            }
            return LONG_TYPE;
        }
        return Type.getType(Type.getDescriptor(clazz));
    }

    public static Type getType(Constructor<?> constructor) {
        return Type.getType(Type.getConstructorDescriptor(constructor));
    }

    public static Type getType(Method method) {
        return Type.getType(Type.getMethodDescriptor(method));
    }

    public static Type[] getArgumentTypes(String string) {
        int n;
        int n2;
        char[] cArray;
        block12: {
            cArray = string.toCharArray();
            n2 = 1;
            n = 0;
            do {
                char c;
                if (Type.lIlIllIIlI(c = cArray[n2++], 41)) {
                    "".length();
                    if ((0x3E ^ 0x3A) != (0x1A ^ 0x1E)) {
                        return null;
                    }
                    break block12;
                }
                if (Type.lIlIllIIlI(c, 76)) {
                    while (Type.lIlIllIlIl(cArray[n2++], 59)) {
                        "".length();
                        if ((0x10 ^ 0x14) > 0) continue;
                        return null;
                    }
                    ++n;
                    "".length();
                    if ((0x88 ^ 0x8C) <= ((0x6B ^ 0x22) & ~(0x1E ^ 0x57))) {
                        return null;
                    }
                } else if (Type.lIlIllIlIl(c, 91)) {
                    ++n;
                }
                "".length();
            } while (((0x40 ^ 0x1C) & ~(0x17 ^ 0x4B)) == 0);
            return null;
        }
        Type[] typeArray = new Type[n];
        n2 = 1;
        n = 0;
        while (Type.lIlIllIlIl(cArray[n2], 41)) {
            int n3;
            typeArray[n] = Type.getType(cArray, n2);
            int n4 = typeArray[n].len;
            if (Type.lIlIllIIlI(typeArray[n].sort, 10)) {
                n3 = 2;
                "".length();
                if (-"   ".length() > 0) {
                    return null;
                }
            } else {
                n3 = 0;
            }
            n2 += n4 + n3;
            ++n;
            "".length();
            if (((0x55 ^ 0x34) & ~(0x4E ^ 0x2F)) == 0) continue;
            return null;
        }
        return typeArray;
    }

    public static Type[] getArgumentTypes(Method method) {
        Class<?>[] classArray = method.getParameterTypes();
        Type[] typeArray = new Type[classArray.length];
        int n = classArray.length - 1;
        while (Type.lIlIllIllI(n)) {
            typeArray[n] = Type.getType(classArray[n]);
            --n;
            "".length();
            if ((113 + 110 - 179 + 97 ^ 47 + 102 - 47 + 34) > 0) continue;
            return null;
        }
        return typeArray;
    }

    public static Type getReturnType(String string) {
        char[] cArray = string.toCharArray();
        int n = 1;
        do {
            char c;
            if (Type.lIlIllIIlI(c = cArray[n++], 41)) {
                return Type.getType(cArray, n);
            }
            if (Type.lIlIllIIlI(c, 76)) {
                while (Type.lIlIllIlIl(cArray[n++], 59)) {
                    "".length();
                    if (((72 + 19 - 16 + 170 ^ 57 + 126 - 68 + 48) & (0x63 ^ 0x3B ^ (0 ^ 0xE) ^ -" ".length())) < "  ".length()) continue;
                    return null;
                }
            }
            "".length();
        } while ("   ".length() >= "   ".length());
        return null;
    }

    public static Type getReturnType(Method method) {
        return Type.getType(method.getReturnType());
    }

    public static int getArgumentsAndReturnSizes(String string) {
        int n = 1;
        int n2 = 1;
        do {
            char c;
            if (Type.lIlIllIIlI(c = string.charAt(n2++), 41)) {
                int n3;
                c = string.charAt(n2);
                if (Type.lIlIllIIlI(c, 86)) {
                    n3 = 0;
                    "".length();
                    if (-" ".length() > 0) {
                        return (0xA9 ^ 0xB2 ^ (0x98 ^ 0xBE)) & (0x49 ^ 0x5E ^ (0xA7 ^ 0x8D) ^ -" ".length());
                    }
                } else if (!Type.lIlIllIlIl(c, 68) || Type.lIlIllIIlI(c, 74)) {
                    n3 = 2;
                    "".length();
                    if (((0x2B ^ 0x72) & ~(0x7F ^ 0x26)) != 0) {
                        return (0x5D ^ 0x49) & ~(0x29 ^ 0x3D);
                    }
                } else {
                    n3 = 1;
                }
                return n << 2 | n3;
            }
            if (Type.lIlIllIIlI(c, 76)) {
                while (Type.lIlIllIlIl(string.charAt(n2++), 59)) {
                    "".length();
                    if (((0x44 ^ 0x7F) & ~(0x87 ^ 0xBC)) != "  ".length()) continue;
                    return (0xE ^ 0x3A) & ~(0x39 ^ 0xD);
                }
                ++n;
                "".length();
                if (" ".length() < 0) {
                    return (0xC9 ^ 0x98 ^ (0x14 ^ 0x27)) & (0x26 ^ 0x55 ^ (0x80 ^ 0x91) ^ -" ".length());
                }
            } else if (Type.lIlIllIIlI(c, 91)) {
                while (Type.lIlIllIIlI(c = string.charAt(n2), 91)) {
                    ++n2;
                    "".length();
                    if (-" ".length() < (0x38 ^ 0x3C)) continue;
                    return (0xA7 ^ 0x91) & ~(0x79 ^ 0x4F);
                }
                if (!Type.lIlIllIlIl(c, 68) || Type.lIlIllIIlI(c, 74)) {
                    --n;
                    "".length();
                    if ("   ".length() < 0) {
                        return (0x56 ^ 0x34) & ~(0x40 ^ 0x22);
                    }
                }
            } else if (!Type.lIlIllIlIl(c, 68) || Type.lIlIllIIlI(c, 74)) {
                n += 2;
                "".length();
                if (((0x57 ^ 0x45) & ~(4 ^ 0x16)) > 0) {
                    return (0x50 ^ 0x4F) & ~(0x75 ^ 0x6A);
                }
            } else {
                ++n;
            }
            "".length();
        } while (-(0x2D ^ 8 ^ (0xBF ^ 0x9E)) <= 0);
        return (0x74 ^ 0x44 ^ (0x45 ^ 0x3C)) & (49 + 130 - 163 + 120 ^ 39 + 47 - -96 + 11 ^ -" ".length());
    }

    private static Type getType(char[] cArray, int n) {
        switch (cArray[n]) {
            case 'V': {
                return VOID_TYPE;
            }
            case 'Z': {
                return BOOLEAN_TYPE;
            }
            case 'C': {
                return CHAR_TYPE;
            }
            case 'B': {
                return BYTE_TYPE;
            }
            case 'S': {
                return SHORT_TYPE;
            }
            case 'I': {
                return INT_TYPE;
            }
            case 'F': {
                return FLOAT_TYPE;
            }
            case 'J': {
                return LONG_TYPE;
            }
            case 'D': {
                return DOUBLE_TYPE;
            }
            case '[': {
                int n2 = 1;
                while (Type.lIlIllIIlI(cArray[n + n2], 91)) {
                    ++n2;
                    "".length();
                    if (null == null) continue;
                    return null;
                }
                if (Type.lIlIllIIlI(cArray[n + n2], 76)) {
                    ++n2;
                    while (Type.lIlIllIlIl(cArray[n + n2], 59)) {
                        ++n2;
                        "".length();
                        if (((0x9B ^ 0xB9) & ~(0x22 ^ 0)) == ((0x93 ^ 0x96) & ~(0xBB ^ 0xBE))) continue;
                        return null;
                    }
                }
                return new Type(9, cArray, n, n2 + 1);
            }
            case 'L': {
                int n3 = 1;
                while (Type.lIlIllIlIl(cArray[n + n3], 59)) {
                    ++n3;
                    "".length();
                    if (((0x3F ^ 0x66) & ~(0x28 ^ 0x71)) < " ".length()) continue;
                    return null;
                }
                return new Type(10, cArray, n + 1, n3 - 1);
            }
        }
        return new Type(11, cArray, n, cArray.length - n);
    }

    public int getSort() {
        return this.sort;
    }

    public int getDimensions() {
        int n = 1;
        while (Type.lIlIllIIlI(this.buf[this.off + n], 91)) {
            ++n;
            "".length();
            if (" ".length() > -" ".length()) continue;
            return (0x24 ^ 2) & ~(0xA5 ^ 0x83);
        }
        return n;
    }

    public Type getElementType() {
        return Type.getType(this.buf, this.off + this.getDimensions());
    }

    public String getClassName() {
        switch (this.sort) {
            case 0: {
                return "void";
            }
            case 1: {
                return "boolean";
            }
            case 2: {
                return "char";
            }
            case 3: {
                return "byte";
            }
            case 4: {
                return "short";
            }
            case 5: {
                return "int";
            }
            case 6: {
                return "float";
            }
            case 7: {
                return "long";
            }
            case 8: {
                return "double";
            }
            case 9: {
                StringBuilder stringBuilder = new StringBuilder(this.getElementType().getClassName());
                int n = this.getDimensions();
                while (Type.lIlIlllIII(n)) {
                    stringBuilder.append("[]");
                    "".length();
                    --n;
                    "".length();
                    if (-(0x74 ^ 0x3B ^ (0x3F ^ 0x74)) < 0) continue;
                    return null;
                }
                return String.valueOf(stringBuilder);
            }
            case 10: {
                return new String(this.buf, this.off, this.len).replace('/', '.');
            }
        }
        return null;
    }

    public String getInternalName() {
        return new String(this.buf, this.off, this.len);
    }

    public Type[] getArgumentTypes() {
        return Type.getArgumentTypes(this.getDescriptor());
    }

    public Type getReturnType() {
        return Type.getReturnType(this.getDescriptor());
    }

    public int getArgumentsAndReturnSizes() {
        return Type.getArgumentsAndReturnSizes(this.getDescriptor());
    }

    public String getDescriptor() {
        StringBuilder stringBuilder = new StringBuilder();
        this.getDescriptor(stringBuilder);
        return String.valueOf(stringBuilder);
    }

    public static String getMethodDescriptor(Type type, Type ... typeArray) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        "".length();
        int n = 0;
        while (Type.lIlIlllIlI(n, typeArray.length)) {
            typeArray[n].getDescriptor(stringBuilder);
            ++n;
            "".length();
            if ("   ".length() > 0) continue;
            return null;
        }
        stringBuilder.append(')');
        "".length();
        type.getDescriptor(stringBuilder);
        return String.valueOf(stringBuilder);
    }

    private void getDescriptor(StringBuilder stringBuilder) {
        if (Type.lIlIlllIll(this.buf)) {
            stringBuilder.append((char)((this.off & 0xFF000000) >>> 24));
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (Type.lIlIllIIlI(this.sort, 10)) {
            stringBuilder.append('L');
            "".length();
            stringBuilder.append(this.buf, this.off, this.len);
            "".length();
            stringBuilder.append(';');
            "".length();
            "".length();
            if (-(0xB5 ^ 0x8A ^ (0x63 ^ 0x58)) > 0) {
                return;
            }
        } else {
            stringBuilder.append(this.buf, this.off, this.len);
            "".length();
        }
    }

    public static String getInternalName(Class<?> clazz) {
        return clazz.getName().replace('.', '/');
    }

    public static String getDescriptor(Class<?> clazz) {
        StringBuilder stringBuilder = new StringBuilder();
        Type.getDescriptor(stringBuilder, clazz);
        return String.valueOf(stringBuilder);
    }

    public static String getConstructorDescriptor(Constructor<?> constructor) {
        Class<?>[] classArray = constructor.getParameterTypes();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        "".length();
        int n = 0;
        while (Type.lIlIlllIlI(n, classArray.length)) {
            Type.getDescriptor(stringBuilder, classArray[n]);
            ++n;
            "".length();
            if ("   ".length() > 0) continue;
            return null;
        }
        return String.valueOf(stringBuilder.append(")V"));
    }

    public static String getMethodDescriptor(Method method) {
        Class<?>[] classArray = method.getParameterTypes();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('(');
        "".length();
        int n = 0;
        while (Type.lIlIlllIlI(n, classArray.length)) {
            Type.getDescriptor(stringBuilder, classArray[n]);
            ++n;
            "".length();
            if ("   ".length() < (0x88 ^ 0x8C)) continue;
            return null;
        }
        stringBuilder.append(')');
        "".length();
        Type.getDescriptor(stringBuilder, method.getReturnType());
        return String.valueOf(stringBuilder);
    }

    private static void getDescriptor(StringBuilder stringBuilder, Class<?> clazz) {
        Class<?> clazz2;
        block30: {
            clazz2 = clazz;
            do {
                if (Type.lIlIllIIll(clazz2.isPrimitive() ? 1 : 0)) {
                    int n;
                    if (Type.lIlIllIlII(clazz2, Integer.TYPE)) {
                        n = 73;
                        "".length();
                        if (((115 + 151 - 236 + 173 ^ 90 + 124 - 196 + 152) & (150 + 167 - 154 + 70 ^ 118 + 133 - 164 + 49 ^ -" ".length())) != 0) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Void.TYPE)) {
                        n = 86;
                        "".length();
                        if (" ".length() < 0) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Boolean.TYPE)) {
                        n = 90;
                        "".length();
                        if (((101 + 97 - 118 + 63 ^ 106 + 97 - 170 + 150) & (162 + 135 - 270 + 164 ^ 47 + 74 - 51 + 65 ^ -" ".length())) < -" ".length()) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Byte.TYPE)) {
                        n = 66;
                        "".length();
                        if ("  ".length() == 0) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Character.TYPE)) {
                        n = 67;
                        "".length();
                        if (-" ".length() >= 0) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Short.TYPE)) {
                        n = 83;
                        "".length();
                        if (null != null) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Double.TYPE)) {
                        n = 68;
                        "".length();
                        if (null != null) {
                            return;
                        }
                    } else if (Type.lIlIllIlII(clazz2, Float.TYPE)) {
                        n = 70;
                        "".length();
                        if (-" ".length() == "   ".length()) {
                            return;
                        }
                    } else {
                        n = 74;
                    }
                    stringBuilder.append((char)n);
                    "".length();
                    return;
                }
                if (!Type.lIlIllIIll(clazz2.isArray() ? 1 : 0)) break block30;
                stringBuilder.append('[');
                "".length();
                clazz2 = clazz2.getComponentType();
                "".length();
            } while ("  ".length() != ((0x1C ^ 0x3B) & ~(0x7F ^ 0x58)));
            return;
        }
        stringBuilder.append('L');
        "".length();
        String string = clazz2.getName();
        int n = string.length();
        int n2 = 0;
        while (Type.lIlIlllIlI(n2, n)) {
            char c;
            char c2 = string.charAt(n2);
            if (Type.lIlIllIIlI(c2, 46)) {
                c = '/';
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                c = c2;
            }
            stringBuilder.append(c);
            "".length();
            ++n2;
            "".length();
            if (-" ".length() != " ".length()) continue;
            return;
        }
        stringBuilder.append(';');
        "".length();
    }

    public int getSize() {
        int n;
        if (Type.lIlIlllIll(this.buf)) {
            n = this.off & 0xFF;
            "".length();
            if ("  ".length() == 0) {
                return (45 + 70 - -37 + 49 ^ 14 + 7 - -5 + 122) & (0xB3 ^ 0xC4 ^ (0x86 ^ 0xAC) ^ -" ".length());
            }
        } else {
            n = 1;
        }
        return n;
    }

    public int getOpcode(int n) {
        int n2;
        if (!Type.lIlIllIlIl(n, 46) || Type.lIlIllIIlI(n, 79)) {
            int n3;
            if (Type.lIlIlllIll(this.buf)) {
                n3 = (this.off & 0xFF00) >> 8;
                "".length();
                if (" ".length() >= (0x35 ^ 0x31)) {
                    return (0x72 ^ 0x58) & ~(0xEB ^ 0xC1);
                }
            } else {
                n3 = 4;
            }
            return n + n3;
        }
        if (Type.lIlIlllIll(this.buf)) {
            n2 = (this.off & 0xFF0000) >> 16;
            "".length();
            if (null != null) {
                return (0xDD ^ 0x9B) & ~(0x5A ^ 0x1C);
            }
        } else {
            n2 = 4;
        }
        return n + n2;
    }

    public boolean equals(Object object) {
        if (Type.lIlIllIlII(this, object)) {
            return true;
        }
        if (Type.lIlIllllII(object instanceof Type)) {
            return false;
        }
        Type type = (Type)object;
        if (Type.lIlIllIlIl(this.sort, type.sort)) {
            return false;
        }
        if (Type.lIlIllllIl(this.sort, 9)) {
            if (Type.lIlIllIlIl(this.len, type.len)) {
                return false;
            }
            int n = this.off;
            int n2 = type.off;
            int n3 = n + this.len;
            while (Type.lIlIlllIlI(n, n3)) {
                if (Type.lIlIllIlIl(this.buf[n], type.buf[n2])) {
                    return false;
                }
                ++n;
                ++n2;
                "".length();
                if (null == null) continue;
                return ((0xC7 ^ 0x8E) & ~(0x8B ^ 0xC2)) != 0;
            }
        }
        return true;
    }

    public int hashCode() {
        int n = 13 * this.sort;
        if (Type.lIlIllllIl(this.sort, 9)) {
            int n2 = this.off;
            int n3 = n2 + this.len;
            while (Type.lIlIlllIlI(n2, n3)) {
                n = 17 * (n + this.buf[n2]);
                ++n2;
                "".length();
                if ("  ".length() >= -" ".length()) continue;
                return (0xF5 ^ 0xC1) & ~(0x16 ^ 0x22);
            }
        }
        return n;
    }

    public String toString() {
        return this.getDescriptor();
    }

    static {
        FLOAT = 6;
        LONG = 7;
        DOUBLE = 8;
        ARRAY = 9;
        VOID = 0;
        BYTE = 3;
        INT = 5;
        METHOD = 11;
        CHAR = 2;
        SHORT = 4;
        OBJECT = 10;
        BOOLEAN = 1;
        VOID_TYPE = new Type(0, null, 0x56050000, 1);
        BOOLEAN_TYPE = new Type(1, null, 1509950721, 1);
        CHAR_TYPE = new Type(2, null, 1124075009, 1);
        BYTE_TYPE = new Type(3, null, 1107297537, 1);
        SHORT_TYPE = new Type(4, null, 1392510721, 1);
        INT_TYPE = new Type(5, null, 1224736769, 1);
        FLOAT_TYPE = new Type(6, null, 1174536705, 1);
        LONG_TYPE = new Type(7, null, 1241579778, 1);
        DOUBLE_TYPE = new Type(8, null, 1141048066, 1);
    }

    private static boolean lIlIllIIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlIllllIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIlIlllIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIllIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIlIlllIll(Object object) {
        return object == null;
    }

    private static boolean lIlIllIIll(int n) {
        return n != 0;
    }

    private static boolean lIlIllllII(int n) {
        return n == 0;
    }

    private static boolean lIlIllIllI(int n) {
        return n >= 0;
    }

    private static boolean lIlIlllIII(int n) {
        return n > 0;
    }

    private static boolean lIlIllIlIl(int n, int n2) {
        return n != n2;
    }
}

