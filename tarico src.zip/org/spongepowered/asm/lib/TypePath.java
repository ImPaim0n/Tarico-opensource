/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

import org.spongepowered.asm.lib.ByteVector;

public class TypePath {
    public static final int ARRAY_ELEMENT;
    public static final int INNER_TYPE;
    public static final int WILDCARD_BOUND;
    public static final int TYPE_ARGUMENT;
    byte[] b;
    int offset;

    TypePath(byte[] byArray, int n) {
        this.b = byArray;
        this.offset = n;
    }

    public int getLength() {
        return this.b[this.offset];
    }

    public int getStep(int n) {
        return this.b[this.offset + 2 * n + 1];
    }

    public int getStepArgument(int n) {
        return this.b[this.offset + 2 * n + 2];
    }

    public static TypePath fromString(String string) {
        if (!TypePath.llIIlIllIII(string) || TypePath.llIIlIllIIl(string.length())) {
            return null;
        }
        int n = string.length();
        ByteVector byteVector = new ByteVector(n);
        byteVector.putByte(0);
        "".length();
        int n2 = 0;
        while (TypePath.llIIlIllIlI(n2, n)) {
            char c;
            if (TypePath.llIIlIllIll(c = string.charAt(n2++), 91)) {
                byteVector.put11(0, 0);
                "".length();
                "".length();
                if ("   ".length() <= -" ".length()) {
                    return null;
                }
            } else if (TypePath.llIIlIllIll(c, 46)) {
                byteVector.put11(1, 0);
                "".length();
                "".length();
                if ("   ".length() != "   ".length()) {
                    return null;
                }
            } else if (TypePath.llIIlIllIll(c, 42)) {
                byteVector.put11(2, 0);
                "".length();
                "".length();
                if (null != null) {
                    return null;
                }
            } else if (TypePath.llIIlIlllII(c, 48) && TypePath.llIIlIlllIl(c, 57)) {
                int n3 = c - 48;
                while (TypePath.llIIlIllIlI(n2, n) && TypePath.llIIlIlllII(c = string.charAt(n2), 48) && TypePath.llIIlIlllIl(c, 57)) {
                    n3 = n3 * 10 + c - 48;
                    ++n2;
                    "".length();
                    if (((86 + 206 - 68 + 30 ^ 109 + 109 - 92 + 41) & (0x9F ^ 0x95 ^ (0xC4 ^ 0x97) ^ -" ".length())) == 0) continue;
                    return null;
                }
                if (TypePath.llIIlIllIlI(n2, n) && TypePath.llIIlIllIll(string.charAt(n2), 59)) {
                    ++n2;
                }
                byteVector.put11(3, n3);
                "".length();
            }
            "".length();
            if ("  ".length() != 0) continue;
            return null;
        }
        byteVector.data[0] = (byte)(byteVector.length / 2);
        return new TypePath(byteVector.data, 0);
    }

    public String toString() {
        int n = this.getLength();
        StringBuilder stringBuilder = new StringBuilder(n * 2);
        int n2 = 0;
        while (TypePath.llIIlIllIlI(n2, n)) {
            switch (this.getStep(n2)) {
                case 0: {
                    stringBuilder.append('[');
                    "".length();
                    "".length();
                    if (null == null) break;
                    return null;
                }
                case 1: {
                    stringBuilder.append('.');
                    "".length();
                    "".length();
                    if ("  ".length() >= -" ".length()) break;
                    return null;
                }
                case 2: {
                    stringBuilder.append('*');
                    "".length();
                    "".length();
                    if ((0x76 ^ 0x72) >= ((0xBF ^ 0xAE) & ~(0xB1 ^ 0xA0))) break;
                    return null;
                }
                case 3: {
                    stringBuilder.append(this.getStepArgument(n2)).append(';');
                    "".length();
                    "".length();
                    if ("  ".length() >= ((0x93 ^ 0xC6) & ~(0xFA ^ 0xAF))) break;
                    return null;
                }
                default: {
                    stringBuilder.append('_');
                    "".length();
                }
            }
            ++n2;
            "".length();
            if ("  ".length() != 0) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    static {
        INNER_TYPE = 1;
        WILDCARD_BOUND = 2;
        TYPE_ARGUMENT = 3;
        ARRAY_ELEMENT = 0;
    }

    private static boolean llIIlIllIll(int n, int n2) {
        return n == n2;
    }

    private static boolean llIIlIlllII(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIIlIllIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean llIIlIlllIl(int n, int n2) {
        return n <= n2;
    }

    private static boolean llIIlIllIII(Object object) {
        return object != null;
    }

    private static boolean llIIlIllIIl(int n) {
        return n == 0;
    }
}

