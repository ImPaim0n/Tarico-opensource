/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib;

public class TypeReference {
    public static final int CLASS_TYPE_PARAMETER;
    public static final int METHOD_TYPE_PARAMETER;
    public static final int CLASS_EXTENDS;
    public static final int CLASS_TYPE_PARAMETER_BOUND;
    public static final int METHOD_TYPE_PARAMETER_BOUND;
    public static final int FIELD;
    public static final int METHOD_RETURN;
    public static final int METHOD_RECEIVER;
    public static final int METHOD_FORMAL_PARAMETER;
    public static final int THROWS;
    public static final int LOCAL_VARIABLE;
    public static final int RESOURCE_VARIABLE;
    public static final int EXCEPTION_PARAMETER;
    public static final int INSTANCEOF;
    public static final int NEW;
    public static final int CONSTRUCTOR_REFERENCE;
    public static final int METHOD_REFERENCE;
    public static final int CAST;
    public static final int CONSTRUCTOR_INVOCATION_TYPE_ARGUMENT;
    public static final int METHOD_INVOCATION_TYPE_ARGUMENT;
    public static final int CONSTRUCTOR_REFERENCE_TYPE_ARGUMENT;
    public static final int METHOD_REFERENCE_TYPE_ARGUMENT;
    private int value;

    public TypeReference(int n) {
        this.value = n;
    }

    public static TypeReference newTypeReference(int n) {
        return new TypeReference(n << 24);
    }

    public static TypeReference newTypeParameterReference(int n, int n2) {
        return new TypeReference(n << 24 | n2 << 16);
    }

    public static TypeReference newTypeParameterBoundReference(int n, int n2, int n3) {
        return new TypeReference(n << 24 | n2 << 16 | n3 << 8);
    }

    public static TypeReference newSuperTypeReference(int n) {
        return new TypeReference(0x10000000 | (n &= 0xFFFF) << 8);
    }

    public static TypeReference newFormalParameterReference(int n) {
        return new TypeReference(0x16000000 | n << 16);
    }

    public static TypeReference newExceptionReference(int n) {
        return new TypeReference(0x17000000 | n << 8);
    }

    public static TypeReference newTryCatchReference(int n) {
        return new TypeReference(0x42000000 | n << 8);
    }

    public static TypeReference newTypeArgumentReference(int n, int n2) {
        return new TypeReference(n << 24 | n2);
    }

    public int getSort() {
        return this.value >>> 24;
    }

    public int getTypeParameterIndex() {
        return (this.value & 0xFF0000) >> 16;
    }

    public int getTypeParameterBoundIndex() {
        return (this.value & 0xFF00) >> 8;
    }

    public int getSuperTypeIndex() {
        return (short)((this.value & 0xFFFF00) >> 8);
    }

    public int getFormalParameterIndex() {
        return (this.value & 0xFF0000) >> 16;
    }

    public int getExceptionIndex() {
        return (this.value & 0xFFFF00) >> 8;
    }

    public int getTryCatchBlockIndex() {
        return (this.value & 0xFFFF00) >> 8;
    }

    public int getTypeArgumentIndex() {
        return this.value & 0xFF;
    }

    public int getValue() {
        return this.value;
    }

    static {
        CONSTRUCTOR_REFERENCE = 69;
        LOCAL_VARIABLE = 64;
        METHOD_TYPE_PARAMETER_BOUND = 18;
        METHOD_FORMAL_PARAMETER = 22;
        METHOD_INVOCATION_TYPE_ARGUMENT = 73;
        RESOURCE_VARIABLE = 65;
        METHOD_TYPE_PARAMETER = 1;
        INSTANCEOF = 67;
        CLASS_TYPE_PARAMETER = 0;
        METHOD_REFERENCE = 70;
        METHOD_REFERENCE_TYPE_ARGUMENT = 75;
        CLASS_EXTENDS = 16;
        CLASS_TYPE_PARAMETER_BOUND = 17;
        THROWS = 23;
        NEW = 68;
        CAST = 71;
        FIELD = 19;
        EXCEPTION_PARAMETER = 66;
        METHOD_RETURN = 20;
        CONSTRUCTOR_INVOCATION_TYPE_ARGUMENT = 72;
        CONSTRUCTOR_REFERENCE_TYPE_ARGUMENT = 74;
        METHOD_RECEIVER = 21;
    }
}

