/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.commons.Remapper;

public class AnnotationRemapper
extends AnnotationVisitor {
    protected final Remapper remapper;

    public AnnotationRemapper(AnnotationVisitor annotationVisitor, Remapper remapper) {
        this(327680, annotationVisitor, remapper);
    }

    protected AnnotationRemapper(int n, AnnotationVisitor annotationVisitor, Remapper remapper) {
        super(n, annotationVisitor);
        this.remapper = remapper;
    }

    public void visit(String string, Object object) {
        this.av.visit(string, this.remapper.mapValue(object));
    }

    public void visitEnum(String string, String string2, String string3) {
        this.av.visitEnum(string, this.remapper.mapDesc(string2), string3);
    }

    public AnnotationVisitor visitAnnotation(String string, String string2) {
        AnnotationRemapper annotationRemapper;
        AnnotationVisitor annotationVisitor = this.av.visitAnnotation(string, this.remapper.mapDesc(string2));
        if (AnnotationRemapper.llIlIIII(annotationVisitor)) {
            annotationRemapper = null;
            "".length();
            if (-" ".length() >= " ".length()) {
                return null;
            }
        } else if (AnnotationRemapper.llIlIIlI(annotationVisitor, this.av)) {
            annotationRemapper = this;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            annotationRemapper = new AnnotationRemapper(annotationVisitor, this.remapper);
        }
        return annotationRemapper;
    }

    public AnnotationVisitor visitArray(String string) {
        AnnotationRemapper annotationRemapper;
        AnnotationVisitor annotationVisitor = this.av.visitArray(string);
        if (AnnotationRemapper.llIlIIII(annotationVisitor)) {
            annotationRemapper = null;
            "".length();
            if (-"  ".length() >= 0) {
                return null;
            }
        } else if (AnnotationRemapper.llIlIIlI(annotationVisitor, this.av)) {
            annotationRemapper = this;
            "".length();
            if ("   ".length() <= ((18 + 227 - 52 + 45 ^ 11 + 67 - -15 + 67) & (190 + 191 - 351 + 167 ^ 57 + 33 - -29 + 20 ^ -" ".length()))) {
                return null;
            }
        } else {
            annotationRemapper = new AnnotationRemapper(annotationVisitor, this.remapper);
        }
        return annotationRemapper;
    }

    private static boolean llIlIIlI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIlIIII(Object object) {
        return object == null;
    }
}

