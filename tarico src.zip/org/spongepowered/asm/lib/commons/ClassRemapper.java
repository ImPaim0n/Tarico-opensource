/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.commons.AnnotationRemapper;
import org.spongepowered.asm.lib.commons.FieldRemapper;
import org.spongepowered.asm.lib.commons.MethodRemapper;
import org.spongepowered.asm.lib.commons.Remapper;

public class ClassRemapper
extends ClassVisitor {
    protected final Remapper remapper;
    protected String className;

    public ClassRemapper(ClassVisitor classVisitor, Remapper remapper) {
        this(327680, classVisitor, remapper);
    }

    protected ClassRemapper(int n, ClassVisitor classVisitor, Remapper remapper) {
        super(n, classVisitor);
        this.remapper = remapper;
    }

    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        String[] stringArray2;
        this.className = string;
        String string4 = this.remapper.mapType(string);
        String string5 = this.remapper.mapSignature(string2, false);
        String string6 = this.remapper.mapType(string3);
        if (ClassRemapper.lIIIIIIIIll(stringArray)) {
            stringArray2 = null;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            stringArray2 = this.remapper.mapTypes(stringArray);
        }
        super.visit(n, n2, string4, string5, string6, stringArray2);
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitAnnotation(this.remapper.mapDesc(string), bl);
        if (ClassRemapper.lIIIIIIIIll(annotationVisitor2)) {
            annotationVisitor = null;
            "".length();
            if (((0x4C ^ 6) & ~(0x70 ^ 0x3A)) != ((0x43 ^ 0x54) & ~(0x8B ^ 0x9C))) {
                return null;
            }
        } else {
            annotationVisitor = this.createAnnotationRemapper(annotationVisitor2);
        }
        return annotationVisitor;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitTypeAnnotation(n, typePath, this.remapper.mapDesc(string), bl);
        if (ClassRemapper.lIIIIIIIIll(annotationVisitor2)) {
            annotationVisitor = null;
            "".length();
            if (" ".length() != " ".length()) {
                return null;
            }
        } else {
            annotationVisitor = this.createAnnotationRemapper(annotationVisitor2);
        }
        return annotationVisitor;
    }

    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        FieldVisitor fieldVisitor;
        FieldVisitor fieldVisitor2 = super.visitField(n, this.remapper.mapFieldName(this.className, string, string2), this.remapper.mapDesc(string2), this.remapper.mapSignature(string3, true), this.remapper.mapValue(object));
        if (ClassRemapper.lIIIIIIIIll(fieldVisitor2)) {
            fieldVisitor = null;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            fieldVisitor = this.createFieldRemapper(fieldVisitor2);
        }
        return fieldVisitor;
    }

    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor;
        MethodVisitor methodVisitor2;
        String[] stringArray2;
        String string4 = this.remapper.mapMethodDesc(string2);
        String string5 = this.remapper.mapMethodName(this.className, string, string2);
        String string6 = this.remapper.mapSignature(string3, false);
        if (ClassRemapper.lIIIIIIIIll(stringArray)) {
            stringArray2 = null;
            "".length();
            if ((164 + 98 - 142 + 65 ^ 38 + 27 - 20 + 144) <= 0) {
                return null;
            }
        } else {
            stringArray2 = this.remapper.mapTypes(stringArray);
        }
        if (ClassRemapper.lIIIIIIIIll(methodVisitor2 = super.visitMethod(n, string5, string4, string6, stringArray2))) {
            methodVisitor = null;
            "".length();
            if (-" ".length() >= ((1 ^ 0x3B) & ~(0x1B ^ 0x21))) {
                return null;
            }
        } else {
            methodVisitor = this.createMethodRemapper(methodVisitor2);
        }
        return methodVisitor;
    }

    public void visitInnerClass(String string, String string2, String string3, int n) {
        String string4;
        String string5 = this.remapper.mapType(string);
        if (ClassRemapper.lIIIIIIIIll(string2)) {
            string4 = null;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            string4 = this.remapper.mapType(string2);
        }
        super.visitInnerClass(string5, string4, string3, n);
    }

    public void visitOuterClass(String string, String string2, String string3) {
        String string4;
        String string5;
        String string6 = this.remapper.mapType(string);
        if (ClassRemapper.lIIIIIIIIll(string2)) {
            string5 = null;
            "".length();
            if ("  ".length() == (0x4B ^ 0x7D ^ (0xA1 ^ 0x93))) {
                return;
            }
        } else {
            string5 = this.remapper.mapMethodName(string, string2, string3);
        }
        if (ClassRemapper.lIIIIIIIIll(string3)) {
            string4 = null;
            "".length();
            if (((0x3E ^ 0x1D ^ (0x72 ^ 0x4B)) & (0x44 ^ 0x15 ^ (0xDD ^ 0x96) ^ -" ".length())) <= -" ".length()) {
                return;
            }
        } else {
            string4 = this.remapper.mapMethodDesc(string3);
        }
        super.visitOuterClass(string6, string5, string4);
    }

    protected FieldVisitor createFieldRemapper(FieldVisitor fieldVisitor) {
        return new FieldRemapper(fieldVisitor, this.remapper);
    }

    protected MethodVisitor createMethodRemapper(MethodVisitor methodVisitor) {
        return new MethodRemapper(methodVisitor, this.remapper);
    }

    protected AnnotationVisitor createAnnotationRemapper(AnnotationVisitor annotationVisitor) {
        return new AnnotationRemapper(annotationVisitor, this.remapper);
    }

    private static boolean lIIIIIIIIll(Object object) {
        return object == null;
    }
}

