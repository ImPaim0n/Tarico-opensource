/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.commons.AnnotationRemapper;
import org.spongepowered.asm.lib.commons.Remapper;

public class FieldRemapper
extends FieldVisitor {
    private final Remapper remapper;

    public FieldRemapper(FieldVisitor fieldVisitor, Remapper remapper) {
        this(327680, fieldVisitor, remapper);
    }

    protected FieldRemapper(int n, FieldVisitor fieldVisitor, Remapper remapper) {
        super(n, fieldVisitor);
        this.remapper = remapper;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationRemapper annotationRemapper;
        AnnotationVisitor annotationVisitor = this.fv.visitAnnotation(this.remapper.mapDesc(string), bl);
        if (FieldRemapper.llIllllIIll(annotationVisitor)) {
            annotationRemapper = null;
            "".length();
            if (((0xB8 ^ 0x9C ^ (0x34 ^ 0x5C)) & (0xB5 ^ 0x81 ^ (0x52 ^ 0x2A) ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            annotationRemapper = new AnnotationRemapper(annotationVisitor, this.remapper);
        }
        return annotationRemapper;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationRemapper annotationRemapper;
        AnnotationVisitor annotationVisitor = super.visitTypeAnnotation(n, typePath, this.remapper.mapDesc(string), bl);
        if (FieldRemapper.llIllllIIll(annotationVisitor)) {
            annotationRemapper = null;
            "".length();
            if (" ".length() < " ".length()) {
                return null;
            }
        } else {
            annotationRemapper = new AnnotationRemapper(annotationVisitor, this.remapper);
        }
        return annotationRemapper;
    }

    private static boolean llIllllIIll(Object object) {
        return object == null;
    }
}

