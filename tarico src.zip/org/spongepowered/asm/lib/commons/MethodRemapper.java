/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.commons.AnnotationRemapper;
import org.spongepowered.asm.lib.commons.Remapper;

public class MethodRemapper
extends MethodVisitor {
    protected final Remapper remapper;

    public MethodRemapper(MethodVisitor methodVisitor, Remapper remapper) {
        this(327680, methodVisitor, remapper);
    }

    protected MethodRemapper(int n, MethodVisitor methodVisitor, Remapper remapper) {
        super(n, methodVisitor);
        this.remapper = remapper;
    }

    public AnnotationVisitor visitAnnotationDefault() {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitAnnotationDefault();
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if (" ".length() == 0) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitAnnotation(this.remapper.mapDesc(string), bl);
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if ((0x1B ^ 0x1F) <= 0) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitTypeAnnotation(n, typePath, this.remapper.mapDesc(string), bl);
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if ("   ".length() < 0) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    public AnnotationVisitor visitParameterAnnotation(int n, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitParameterAnnotation(n, this.remapper.mapDesc(string), bl);
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        super.visitFrame(n, n2, this.remapEntries(n2, objectArray), n3, this.remapEntries(n3, objectArray2));
    }

    private Object[] remapEntries(int n, Object[] objectArray) {
        int n2 = 0;
        while (MethodRemapper.lIIIIlIIllI(n2, n)) {
            if (MethodRemapper.lIIIIlIIlll(objectArray[n2] instanceof String)) {
                Object[] objectArray2 = new Object[n];
                if (MethodRemapper.lIIIIlIlIII(n2)) {
                    System.arraycopy(objectArray, 0, objectArray2, 0, n2);
                }
                do {
                    Object object;
                    Object object2 = objectArray[n2];
                    int n3 = n2++;
                    if (MethodRemapper.lIIIIlIIlll(object2 instanceof String)) {
                        object = this.remapper.mapType((String)object2);
                        "".length();
                        if ("  ".length() != " ".length()) continue;
                        return null;
                    }
                    object = objectArray2[n3] = object2;
                } while (!MethodRemapper.lIIIIlIlIIl(n2, n));
                return objectArray2;
            }
            ++n2;
            "".length();
            if (((100 + 52 - 101 + 112 ^ 34 + 130 - 9 + 20) & (126 + 10 - 89 + 85 ^ 98 + 7 - -12 + 19 ^ -" ".length())) == 0) continue;
            return null;
        }
        return objectArray;
    }

    public void visitFieldInsn(int n, String string, String string2, String string3) {
        super.visitFieldInsn(n, this.remapper.mapType(string), this.remapper.mapFieldName(string, string2, string3), this.remapper.mapDesc(string3));
    }

    @Deprecated
    public void visitMethodInsn(int n, String string, String string2, String string3) {
        boolean bl;
        if (MethodRemapper.lIIIIlIlIIl(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3);
            return;
        }
        if (MethodRemapper.lIIIIlIlIll(n, 185)) {
            bl = true;
            "".length();
            if ((0x61 ^ 7 ^ (0x23 ^ 0x41)) == "   ".length()) {
                return;
            }
        } else {
            bl = false;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (MethodRemapper.lIIIIlIIllI(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3, bl);
            return;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    private void doVisitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (MethodRemapper.lIIIIlIllII(this.mv)) {
            this.mv.visitMethodInsn(n, this.remapper.mapType(string), this.remapper.mapMethodName(string, string2, string3), this.remapper.mapMethodDesc(string3), bl);
        }
    }

    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        int n = 0;
        while (MethodRemapper.lIIIIlIIllI(n, objectArray.length)) {
            objectArray[n] = this.remapper.mapValue(objectArray[n]);
            ++n;
            "".length();
            if ("   ".length() >= ((0x48 ^ 0x57 ^ (0x29 ^ 0x2C)) & (0x17 ^ 0x7C ^ (0x19 ^ 0x68) ^ -" ".length()))) continue;
            return;
        }
        super.visitInvokeDynamicInsn(this.remapper.mapInvokeDynamicMethodName(string, string2), this.remapper.mapMethodDesc(string2), (Handle)this.remapper.mapValue(handle), objectArray);
    }

    public void visitTypeInsn(int n, String string) {
        super.visitTypeInsn(n, this.remapper.mapType(string));
    }

    public void visitLdcInsn(Object object) {
        super.visitLdcInsn(this.remapper.mapValue(object));
    }

    public void visitMultiANewArrayInsn(String string, int n) {
        super.visitMultiANewArrayInsn(this.remapper.mapDesc(string), n);
    }

    public AnnotationVisitor visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitInsnAnnotation(n, typePath, this.remapper.mapDesc(string), bl);
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if (-"   ".length() >= 0) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        String string2;
        if (MethodRemapper.lIIIIlIIlIl(string)) {
            string2 = null;
            "".length();
            if (-(131 + 24 - 128 + 127 ^ 106 + 139 - 215 + 128) >= 0) {
                return;
            }
        } else {
            string2 = this.remapper.mapType(string);
        }
        super.visitTryCatchBlock(label, label2, label3, string2);
    }

    public AnnotationVisitor visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitTryCatchAnnotation(n, typePath, this.remapper.mapDesc(string), bl);
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if (-"  ".length() > 0) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        super.visitLocalVariable(string, this.remapper.mapDesc(string2), this.remapper.mapSignature(string3, true), label, label2, n);
    }

    public AnnotationVisitor visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        AnnotationVisitor annotationVisitor2 = super.visitLocalVariableAnnotation(n, typePath, labelArray, labelArray2, nArray, this.remapper.mapDesc(string), bl);
        if (MethodRemapper.lIIIIlIIlIl(annotationVisitor2)) {
            annotationVisitor = annotationVisitor2;
            "".length();
            if (-" ".length() != -" ".length()) {
                return null;
            }
        } else {
            annotationVisitor = new AnnotationRemapper(annotationVisitor2, this.remapper);
        }
        return annotationVisitor;
    }

    private static boolean lIIIIlIlIll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIlIlIIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIIlIIllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIlIllII(Object object) {
        return object != null;
    }

    private static boolean lIIIIlIIlIl(Object object) {
        return object == null;
    }

    private static boolean lIIIIlIIlll(int n) {
        return n != 0;
    }

    private static boolean lIIIIlIlIII(int n) {
        return n > 0;
    }
}

