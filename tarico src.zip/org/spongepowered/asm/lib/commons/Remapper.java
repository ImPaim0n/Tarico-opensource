/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.commons.SignatureRemapper;
import org.spongepowered.asm.lib.signature.SignatureReader;
import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.lib.signature.SignatureWriter;

public abstract class Remapper {
    public String mapDesc(String string) {
        Type type = Type.getType(string);
        switch (type.getSort()) {
            case 9: {
                String string2 = this.mapDesc(type.getElementType().getDescriptor());
                int n = 0;
                while (Remapper.llllIlIllll(n, type.getDimensions())) {
                    string2 = String.valueOf(new StringBuilder().append('[').append(string2));
                    ++n;
                    "".length();
                    if (" ".length() > 0) continue;
                    return null;
                }
                return string2;
            }
            case 10: {
                String string3 = this.map(type.getInternalName());
                if (!Remapper.llllIllIIII(string3)) break;
                return String.valueOf(new StringBuilder().append('L').append(string3).append(';'));
            }
        }
        return string;
    }

    private Type mapType(Type type) {
        switch (type.getSort()) {
            case 9: {
                String string = this.mapDesc(type.getElementType().getDescriptor());
                int n = 0;
                while (Remapper.llllIlIllll(n, type.getDimensions())) {
                    string = String.valueOf(new StringBuilder().append('[').append(string));
                    ++n;
                    "".length();
                    if (-" ".length() <= 0) continue;
                    return null;
                }
                return Type.getType(string);
            }
            case 10: {
                Type type2;
                String string = this.map(type.getInternalName());
                if (Remapper.llllIllIIII(string)) {
                    type2 = Type.getObjectType(string);
                    "".length();
                    if (" ".length() < 0) {
                        return null;
                    }
                } else {
                    type2 = type;
                }
                return type2;
            }
            case 11: {
                return Type.getMethodType(this.mapMethodDesc(type.getDescriptor()));
            }
        }
        return type;
    }

    public String mapType(String string) {
        if (Remapper.llllIllIIIl(string)) {
            return null;
        }
        return this.mapType(Type.getObjectType(string)).getInternalName();
    }

    public String[] mapTypes(String[] stringArray) {
        String[] stringArray2;
        String[] stringArray3 = null;
        int n = 0;
        int n2 = 0;
        while (Remapper.llllIlIllll(n2, stringArray.length)) {
            String string = stringArray[n2];
            String string2 = this.map(string);
            if (Remapper.llllIllIIII(string2) && Remapper.llllIllIIIl(stringArray3)) {
                stringArray3 = new String[stringArray.length];
                if (Remapper.llllIllIIlI(n2)) {
                    System.arraycopy(stringArray, 0, stringArray3, 0, n2);
                }
                n = 1;
            }
            if (Remapper.llllIllIIll(n)) {
                String string3;
                if (Remapper.llllIllIIIl(string2)) {
                    string3 = string;
                    "".length();
                    if ("   ".length() != "   ".length()) {
                        return null;
                    }
                } else {
                    string3 = string2;
                }
                stringArray3[n2] = string3;
            }
            ++n2;
            "".length();
            if ((0x3C ^ 0x38) > "  ".length()) continue;
            return null;
        }
        if (Remapper.llllIllIIll(n)) {
            stringArray2 = stringArray3;
            "".length();
            if ("   ".length() == ((0x62 ^ 0x34) & ~(0xB ^ 0x5D))) {
                return null;
            }
        } else {
            stringArray2 = stringArray;
        }
        return stringArray2;
    }

    public String mapMethodDesc(String string) {
        if (Remapper.llllIllIIll("()V".equals(string) ? 1 : 0)) {
            return string;
        }
        Type[] typeArray = Type.getArgumentTypes(string);
        StringBuilder stringBuilder = new StringBuilder("(");
        int n = 0;
        while (Remapper.llllIlIllll(n, typeArray.length)) {
            stringBuilder.append(this.mapDesc(typeArray[n].getDescriptor()));
            "".length();
            ++n;
            "".length();
            if (null == null) continue;
            return null;
        }
        Type type = Type.getReturnType(string);
        if (Remapper.llllIllIlII(type, Type.VOID_TYPE)) {
            stringBuilder.append(")V");
            "".length();
            return String.valueOf(stringBuilder);
        }
        stringBuilder.append(')').append(this.mapDesc(type.getDescriptor()));
        "".length();
        return String.valueOf(stringBuilder);
    }

    public Object mapValue(Object object) {
        if (Remapper.llllIllIIll(object instanceof Type)) {
            return this.mapType((Type)object);
        }
        if (Remapper.llllIllIIll(object instanceof Handle)) {
            Handle handle = (Handle)object;
            return new Handle(handle.getTag(), this.mapType(handle.getOwner()), this.mapMethodName(handle.getOwner(), handle.getName(), handle.getDesc()), this.mapMethodDesc(handle.getDesc()), handle.isInterface());
        }
        return object;
    }

    public String mapSignature(String string, boolean bl) {
        if (Remapper.llllIllIIIl(string)) {
            return null;
        }
        SignatureReader signatureReader = new SignatureReader(string);
        SignatureWriter signatureWriter = new SignatureWriter();
        SignatureVisitor signatureVisitor = this.createSignatureRemapper(signatureWriter);
        if (Remapper.llllIllIIll(bl ? 1 : 0)) {
            signatureReader.acceptType(signatureVisitor);
            "".length();
            if (" ".length() < 0) {
                return null;
            }
        } else {
            signatureReader.accept(signatureVisitor);
        }
        return signatureWriter.toString();
    }

    @Deprecated
    protected SignatureVisitor createRemappingSignatureAdapter(SignatureVisitor signatureVisitor) {
        return new SignatureRemapper(signatureVisitor, this);
    }

    protected SignatureVisitor createSignatureRemapper(SignatureVisitor signatureVisitor) {
        return this.createRemappingSignatureAdapter(signatureVisitor);
    }

    public String mapMethodName(String string, String string2, String string3) {
        return string2;
    }

    public String mapInvokeDynamicMethodName(String string, String string2) {
        return string;
    }

    public String mapFieldName(String string, String string2, String string3) {
        return string2;
    }

    public String map(String string) {
        return string;
    }

    private static boolean llllIlIllll(int n, int n2) {
        return n < n2;
    }

    private static boolean llllIllIIII(Object object) {
        return object != null;
    }

    private static boolean llllIllIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llllIllIIIl(Object object) {
        return object == null;
    }

    private static boolean llllIllIIll(int n) {
        return n != 0;
    }

    private static boolean llllIllIIlI(int n) {
        return n > 0;
    }
}

