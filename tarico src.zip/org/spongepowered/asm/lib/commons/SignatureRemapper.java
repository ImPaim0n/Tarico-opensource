/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import java.util.Stack;
import org.spongepowered.asm.lib.commons.Remapper;
import org.spongepowered.asm.lib.signature.SignatureVisitor;

public class SignatureRemapper
extends SignatureVisitor {
    private final SignatureVisitor v;
    private final Remapper remapper;
    private Stack<String> classNames = new Stack();

    public SignatureRemapper(SignatureVisitor signatureVisitor, Remapper remapper) {
        this(327680, signatureVisitor, remapper);
    }

    protected SignatureRemapper(int n, SignatureVisitor signatureVisitor, Remapper remapper) {
        super(n);
        this.v = signatureVisitor;
        this.remapper = remapper;
    }

    public void visitClassType(String string) {
        this.classNames.push(string);
        "".length();
        this.v.visitClassType(this.remapper.mapType(string));
    }

    public void visitInnerClassType(String string) {
        int n;
        String string2 = this.classNames.pop();
        String string3 = String.valueOf(new StringBuilder().append(string2).append('$').append(string));
        this.classNames.push(string3);
        "".length();
        String string4 = String.valueOf(new StringBuilder().append(this.remapper.mapType(string2)).append('$'));
        String string5 = this.remapper.mapType(string3);
        if (SignatureRemapper.llIlIIlIIII(string5.startsWith(string4) ? 1 : 0)) {
            n = string4.length();
            "".length();
            if ("   ".length() <= "  ".length()) {
                return;
            }
        } else {
            n = string5.lastIndexOf(36) + 1;
        }
        int n2 = n;
        this.v.visitInnerClassType(string5.substring(n2));
    }

    public void visitFormalTypeParameter(String string) {
        this.v.visitFormalTypeParameter(string);
    }

    public void visitTypeVariable(String string) {
        this.v.visitTypeVariable(string);
    }

    public SignatureVisitor visitArrayType() {
        this.v.visitArrayType();
        "".length();
        return this;
    }

    public void visitBaseType(char c) {
        this.v.visitBaseType(c);
    }

    public SignatureVisitor visitClassBound() {
        this.v.visitClassBound();
        "".length();
        return this;
    }

    public SignatureVisitor visitExceptionType() {
        this.v.visitExceptionType();
        "".length();
        return this;
    }

    public SignatureVisitor visitInterface() {
        this.v.visitInterface();
        "".length();
        return this;
    }

    public SignatureVisitor visitInterfaceBound() {
        this.v.visitInterfaceBound();
        "".length();
        return this;
    }

    public SignatureVisitor visitParameterType() {
        this.v.visitParameterType();
        "".length();
        return this;
    }

    public SignatureVisitor visitReturnType() {
        this.v.visitReturnType();
        "".length();
        return this;
    }

    public SignatureVisitor visitSuperclass() {
        this.v.visitSuperclass();
        "".length();
        return this;
    }

    public void visitTypeArgument() {
        this.v.visitTypeArgument();
    }

    public SignatureVisitor visitTypeArgument(char c) {
        this.v.visitTypeArgument(c);
        "".length();
        return this;
    }

    public void visitEnd() {
        this.v.visitEnd();
        this.classNames.pop();
        "".length();
    }

    private static boolean llIlIIlIIII(int n) {
        return n != 0;
    }
}

