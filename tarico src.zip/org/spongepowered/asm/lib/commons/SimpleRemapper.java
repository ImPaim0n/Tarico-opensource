/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.commons;

import java.util.Collections;
import java.util.Map;
import org.spongepowered.asm.lib.commons.Remapper;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class SimpleRemapper
extends Remapper {
    private final Map<String, String> mapping;

    public SimpleRemapper(Map<String, String> map) {
        this.mapping = map;
    }

    public SimpleRemapper(String string, String string2) {
        this.mapping = Collections.singletonMap(string, string2);
    }

    @Override
    public String mapMethodName(String string, String string2, String string3) {
        String string4;
        String string5 = this.map(String.valueOf(new StringBuilder().append(string).append('.').append(string2).append(string3)));
        if (SimpleRemapper.lIlllIlIIlI(string5)) {
            string4 = string2;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string4 = string5;
        }
        return string4;
    }

    @Override
    public String mapInvokeDynamicMethodName(String string, String string2) {
        String string3;
        String string4 = this.map(String.valueOf(new StringBuilder().append('.').append(string).append(string2)));
        if (SimpleRemapper.lIlllIlIIlI(string4)) {
            string3 = string;
            "".length();
            if ((0x16 ^ 0x3B ^ (0x62 ^ 0x4B)) < -" ".length()) {
                return null;
            }
        } else {
            string3 = string4;
        }
        return string3;
    }

    @Override
    public String mapFieldName(String string, String string2, String string3) {
        String string4;
        String string5 = this.map(String.valueOf(new StringBuilder().append(string).append('.').append(string2)));
        if (SimpleRemapper.lIlllIlIIlI(string5)) {
            string4 = string2;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string4 = string5;
        }
        return string4;
    }

    @Override
    public String map(String string) {
        return this.mapping.get(string);
    }

    private static boolean lIlllIlIIlI(Object object) {
        return object == null;
    }
}

