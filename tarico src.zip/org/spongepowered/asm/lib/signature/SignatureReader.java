/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.signature;

import org.spongepowered.asm.lib.signature.SignatureVisitor;

public class SignatureReader {
    private final String signature;

    public SignatureReader(String string) {
        this.signature = string;
    }

    public void accept(SignatureVisitor signatureVisitor) {
        int n;
        String string = this.signature;
        int n2 = string.length();
        if (SignatureReader.lIIIIlIlllll(string.charAt(0), 60)) {
            char c;
            n = 2;
            do {
                int n3 = string.indexOf(58, n);
                signatureVisitor.visitFormalTypeParameter(string.substring(n - 1, n3));
                n = n3 + 1;
                c = string.charAt(n);
                if (!SignatureReader.lIIIIllIIIII(c, 76) || !SignatureReader.lIIIIllIIIII(c, 91) || SignatureReader.lIIIIlIlllll(c, 84)) {
                    n = SignatureReader.parseType(string, n, signatureVisitor.visitClassBound());
                }
                while (SignatureReader.lIIIIlIlllll(c = string.charAt(n++), 58)) {
                    n = SignatureReader.parseType(string, n, signatureVisitor.visitInterfaceBound());
                    "".length();
                    if ((" ".length() & (" ".length() ^ -" ".length())) == 0) continue;
                    return;
                }
            } while (!SignatureReader.lIIIIlIlllll(c, 62));
            "".length();
            if (" ".length() <= 0) {
                return;
            }
        } else {
            n = 0;
        }
        if (SignatureReader.lIIIIlIlllll(string.charAt(n), 40)) {
            ++n;
            while (SignatureReader.lIIIIllIIIII(string.charAt(n), 41)) {
                n = SignatureReader.parseType(string, n, signatureVisitor.visitParameterType());
                "".length();
                if ((167 + 86 - 145 + 62 ^ 105 + 14 - 84 + 139) != " ".length()) continue;
                return;
            }
            n = SignatureReader.parseType(string, n + 1, signatureVisitor.visitReturnType());
            while (SignatureReader.lIIIIllIIIIl(n, n2)) {
                n = SignatureReader.parseType(string, n + 1, signatureVisitor.visitExceptionType());
                "".length();
                if (null == null) continue;
                return;
            }
        } else {
            n = SignatureReader.parseType(string, n, signatureVisitor.visitSuperclass());
            while (SignatureReader.lIIIIllIIIIl(n, n2)) {
                n = SignatureReader.parseType(string, n, signatureVisitor.visitInterface());
                "".length();
                if (((104 + 58 - 25 + 17 ^ 111 + 160 - 118 + 31) & (12 + 2 - -78 + 79 ^ 15 + 31 - 0 + 91 ^ -" ".length())) != "  ".length()) continue;
                return;
            }
        }
    }

    public void acceptType(SignatureVisitor signatureVisitor) {
        SignatureReader.parseType(this.signature, 0, signatureVisitor);
        "".length();
    }

    private static int parseType(String string, int n, SignatureVisitor signatureVisitor) {
        char c = string.charAt(n++);
        switch (c) {
            case 'B': 
            case 'C': 
            case 'D': 
            case 'F': 
            case 'I': 
            case 'J': 
            case 'S': 
            case 'V': 
            case 'Z': {
                signatureVisitor.visitBaseType(c);
                return n;
            }
            case '[': {
                return SignatureReader.parseType(string, n, signatureVisitor.visitArrayType());
            }
            case 'T': {
                int n2 = string.indexOf(59, n);
                signatureVisitor.visitTypeVariable(string.substring(n, n2));
                return n2 + 1;
            }
        }
        int n3 = n;
        int n4 = 0;
        int n5 = 0;
        do {
            c = string.charAt(n++);
            block5 : switch (c) {
                case '.': 
                case ';': {
                    String string2;
                    if (SignatureReader.lIIIIllIIIlI(n4)) {
                        string2 = string.substring(n3, n - 1);
                        if (SignatureReader.lIIIIllIIIll(n5)) {
                            signatureVisitor.visitInnerClassType(string2);
                            "".length();
                            if (-"  ".length() > 0) {
                                return "  ".length() & ("  ".length() ^ -" ".length());
                            }
                        } else {
                            signatureVisitor.visitClassType(string2);
                        }
                    }
                    if (SignatureReader.lIIIIlIlllll(c, 59)) {
                        signatureVisitor.visitEnd();
                        return n;
                    }
                    n3 = n;
                    n4 = 0;
                    n5 = 1;
                    "".length();
                    if (((0x5D ^ 0x66) & ~(0xB6 ^ 0x8D)) == 0) break;
                    return (0xA3 ^ 0xC2) & ~(0x79 ^ 0x18);
                }
                case '<': {
                    String string2 = string.substring(n3, n - 1);
                    if (SignatureReader.lIIIIllIIIll(n5)) {
                        signatureVisitor.visitInnerClassType(string2);
                        "".length();
                        if (-" ".length() > -" ".length()) {
                            return (0x7C ^ 0x6F) & ~(0xA ^ 0x19);
                        }
                    } else {
                        signatureVisitor.visitClassType(string2);
                    }
                    n4 = 1;
                    block15: while (true) {
                        c = string.charAt(n);
                        switch (c) {
                            case '>': {
                                "".length();
                                if (null == null) break block5;
                                return (111 + 103 - 131 + 46 ^ 7 + 118 - 85 + 150) & (134 + 130 - 134 + 48 ^ 132 + 70 - 162 + 101 ^ -" ".length());
                            }
                            case '*': {
                                ++n;
                                signatureVisitor.visitTypeArgument();
                                "".length();
                                if (" ".length() < "  ".length()) continue block15;
                                return (0x66 ^ 0x36) & ~(0x7B ^ 0x2B);
                            }
                            case '+': 
                            case '-': {
                                n = SignatureReader.parseType(string, n + 1, signatureVisitor.visitTypeArgument(c));
                                "".length();
                                if (((0xA0 ^ 0x94 ^ (0xB ^ 1)) & (0x47 ^ 0x20 ^ (0xE1 ^ 0xB8) ^ -" ".length())) >= ((0x91 ^ 0xB6 ^ (0xBB ^ 0xC6)) & (0x4C ^ 5 ^ (0x87 ^ 0x94) ^ -" ".length()))) continue block15;
                                return (136 + 88 - 52 + 16 ^ 102 + 99 - 177 + 123) & (0xD2 ^ 0xC3 ^ (0x40 ^ 0x7E) ^ -" ".length());
                            }
                        }
                        n = SignatureReader.parseType(string, n, signatureVisitor.visitTypeArgument('='));
                        "".length();
                        if (-(0x94 ^ 0x91) >= 0) break;
                    }
                    return (0x95 ^ 0x9E) & ~(0x48 ^ 0x43);
                }
            }
            "".length();
        } while ("   ".length() >= 0);
        return (0x25 ^ 5 ^ (0x69 ^ 0x40)) & (0xD1 ^ 0xA0 ^ (0x18 ^ 0x60) ^ -" ".length()) & ((0xB1 ^ 0xA9 ^ (0x59 ^ 0x51)) & (0xDF ^ 0xB0 ^ 78 + 105 - 150 + 94 ^ -" ".length()) ^ -" ".length());
    }

    private static boolean lIIIIlIlllll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIllIIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIllIIIll(int n) {
        return n != 0;
    }

    private static boolean lIIIIllIIIlI(int n) {
        return n == 0;
    }

    private static boolean lIIIIllIIIII(int n, int n2) {
        return n != n2;
    }
}

