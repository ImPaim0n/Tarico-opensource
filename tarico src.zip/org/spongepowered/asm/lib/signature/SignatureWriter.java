/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.signature;

import org.spongepowered.asm.lib.signature.SignatureVisitor;

public class SignatureWriter
extends SignatureVisitor {
    private final StringBuilder buf = new StringBuilder();
    private boolean hasFormals;
    private boolean hasParameters;
    private int argumentStack;

    public SignatureWriter() {
        super(327680);
    }

    public void visitFormalTypeParameter(String string) {
        if (SignatureWriter.lIlIIIlIlII(this.hasFormals ? 1 : 0)) {
            this.hasFormals = true;
            this.buf.append('<');
            "".length();
        }
        this.buf.append(string);
        "".length();
        this.buf.append(':');
        "".length();
    }

    public SignatureVisitor visitClassBound() {
        return this;
    }

    public SignatureVisitor visitInterfaceBound() {
        this.buf.append(':');
        "".length();
        return this;
    }

    public SignatureVisitor visitSuperclass() {
        this.endFormals();
        return this;
    }

    public SignatureVisitor visitInterface() {
        return this;
    }

    public SignatureVisitor visitParameterType() {
        this.endFormals();
        if (SignatureWriter.lIlIIIlIlII(this.hasParameters ? 1 : 0)) {
            this.hasParameters = true;
            this.buf.append('(');
            "".length();
        }
        return this;
    }

    public SignatureVisitor visitReturnType() {
        this.endFormals();
        if (SignatureWriter.lIlIIIlIlII(this.hasParameters ? 1 : 0)) {
            this.buf.append('(');
            "".length();
        }
        this.buf.append(')');
        "".length();
        return this;
    }

    public SignatureVisitor visitExceptionType() {
        this.buf.append('^');
        "".length();
        return this;
    }

    public void visitBaseType(char c) {
        this.buf.append(c);
        "".length();
    }

    public void visitTypeVariable(String string) {
        this.buf.append('T');
        "".length();
        this.buf.append(string);
        "".length();
        this.buf.append(';');
        "".length();
    }

    public SignatureVisitor visitArrayType() {
        this.buf.append('[');
        "".length();
        return this;
    }

    public void visitClassType(String string) {
        this.buf.append('L');
        "".length();
        this.buf.append(string);
        "".length();
        this.argumentStack *= 2;
    }

    public void visitInnerClassType(String string) {
        this.endArguments();
        this.buf.append('.');
        "".length();
        this.buf.append(string);
        "".length();
        this.argumentStack *= 2;
    }

    public void visitTypeArgument() {
        if (SignatureWriter.lIlIIIlIlII(this.argumentStack % 2)) {
            ++this.argumentStack;
            this.buf.append('<');
            "".length();
        }
        this.buf.append('*');
        "".length();
    }

    public SignatureVisitor visitTypeArgument(char c) {
        if (SignatureWriter.lIlIIIlIlII(this.argumentStack % 2)) {
            ++this.argumentStack;
            this.buf.append('<');
            "".length();
        }
        if (SignatureWriter.lIlIIIlIllI(c, 61)) {
            this.buf.append(c);
            "".length();
        }
        return this;
    }

    public void visitEnd() {
        this.endArguments();
        this.buf.append(';');
        "".length();
    }

    public String toString() {
        return String.valueOf(this.buf);
    }

    private void endFormals() {
        if (SignatureWriter.lIlIIIlIlll(this.hasFormals ? 1 : 0)) {
            this.hasFormals = false;
            this.buf.append('>');
            "".length();
        }
    }

    private void endArguments() {
        if (SignatureWriter.lIlIIIlIlll(this.argumentStack % 2)) {
            this.buf.append('>');
            "".length();
        }
        this.argumentStack /= 2;
    }

    private static boolean lIlIIIlIlll(int n) {
        return n != 0;
    }

    private static boolean lIlIIIlIlII(int n) {
        return n == 0;
    }

    private static boolean lIlIIIlIllI(int n, int n2) {
        return n != n2;
    }
}

