/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.TypeAnnotationNode;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public abstract class AbstractInsnNode {
    public static final int INSN;
    public static final int INT_INSN;
    public static final int VAR_INSN;
    public static final int TYPE_INSN;
    public static final int FIELD_INSN;
    public static final int METHOD_INSN;
    public static final int INVOKE_DYNAMIC_INSN;
    public static final int JUMP_INSN;
    public static final int LABEL;
    public static final int LDC_INSN;
    public static final int IINC_INSN;
    public static final int TABLESWITCH_INSN;
    public static final int LOOKUPSWITCH_INSN;
    public static final int MULTIANEWARRAY_INSN;
    public static final int FRAME;
    public static final int LINE;
    protected int opcode;
    public List<TypeAnnotationNode> visibleTypeAnnotations;
    public List<TypeAnnotationNode> invisibleTypeAnnotations;
    AbstractInsnNode prev;
    AbstractInsnNode next;
    int index;

    protected AbstractInsnNode(int n) {
        this.opcode = n;
        this.index = -1;
    }

    public int getOpcode() {
        return this.opcode;
    }

    public abstract int getType();

    public AbstractInsnNode getPrevious() {
        return this.prev;
    }

    public AbstractInsnNode getNext() {
        return this.next;
    }

    public abstract void accept(MethodVisitor var1);

    protected final void acceptAnnotations(MethodVisitor methodVisitor) {
        int n;
        TypeAnnotationNode typeAnnotationNode;
        int n2;
        if (AbstractInsnNode.lIIIlllIIIlI(this.visibleTypeAnnotations)) {
            n2 = 0;
            "".length();
            if (-" ".length() > "  ".length()) {
                return;
            }
        } else {
            n2 = this.visibleTypeAnnotations.size();
        }
        int n3 = n2;
        int n4 = 0;
        while (AbstractInsnNode.lIIIlllIIIll(n4, n3)) {
            typeAnnotationNode = this.visibleTypeAnnotations.get(n4);
            typeAnnotationNode.accept(methodVisitor.visitInsnAnnotation(typeAnnotationNode.typeRef, typeAnnotationNode.typePath, typeAnnotationNode.desc, true));
            ++n4;
            "".length();
            if (-"   ".length() <= 0) continue;
            return;
        }
        if (AbstractInsnNode.lIIIlllIIIlI(this.invisibleTypeAnnotations)) {
            n = 0;
            "".length();
            if ((0xAC ^ 0xB8 ^ (0xC ^ 0x1D)) == 0) {
                return;
            }
        } else {
            n = this.invisibleTypeAnnotations.size();
        }
        n3 = n;
        n4 = 0;
        while (AbstractInsnNode.lIIIlllIIIll(n4, n3)) {
            typeAnnotationNode = this.invisibleTypeAnnotations.get(n4);
            typeAnnotationNode.accept(methodVisitor.visitInsnAnnotation(typeAnnotationNode.typeRef, typeAnnotationNode.typePath, typeAnnotationNode.desc, false));
            ++n4;
            "".length();
            if ((0xC0 ^ 0xC5) > 0) continue;
            return;
        }
    }

    public abstract AbstractInsnNode clone(Map<LabelNode, LabelNode> var1);

    static LabelNode clone(LabelNode labelNode, Map<LabelNode, LabelNode> map) {
        return map.get(labelNode);
    }

    static LabelNode[] clone(List<LabelNode> list, Map<LabelNode, LabelNode> map) {
        LabelNode[] labelNodeArray = new LabelNode[list.size()];
        int n = 0;
        while (AbstractInsnNode.lIIIlllIIIll(n, labelNodeArray.length)) {
            labelNodeArray[n] = map.get(list.get(n));
            ++n;
            "".length();
            if (((0x7F ^ 0x53 ^ (0x12 ^ 7)) & (9 ^ 0x77 ^ (0x72 ^ 0x35) ^ -" ".length())) == ((0x17 ^ 0x6D ^ (0x2F ^ 8)) & (0x43 ^ 0x46 ^ (0xCA ^ 0x92) ^ -" ".length()))) continue;
            return null;
        }
        return labelNodeArray;
    }

    protected final AbstractInsnNode cloneAnnotations(AbstractInsnNode abstractInsnNode) {
        TypeAnnotationNode typeAnnotationNode;
        TypeAnnotationNode typeAnnotationNode2;
        int n;
        if (AbstractInsnNode.lIIIlllIIlII(abstractInsnNode.visibleTypeAnnotations)) {
            this.visibleTypeAnnotations = new ArrayList<TypeAnnotationNode>();
            n = 0;
            while (AbstractInsnNode.lIIIlllIIIll(n, abstractInsnNode.visibleTypeAnnotations.size())) {
                typeAnnotationNode2 = abstractInsnNode.visibleTypeAnnotations.get(n);
                typeAnnotationNode = new TypeAnnotationNode(typeAnnotationNode2.typeRef, typeAnnotationNode2.typePath, typeAnnotationNode2.desc);
                typeAnnotationNode2.accept(typeAnnotationNode);
                this.visibleTypeAnnotations.add(typeAnnotationNode);
                "".length();
                ++n;
                "".length();
                if ("   ".length() == "   ".length()) continue;
                return null;
            }
        }
        if (AbstractInsnNode.lIIIlllIIlII(abstractInsnNode.invisibleTypeAnnotations)) {
            this.invisibleTypeAnnotations = new ArrayList<TypeAnnotationNode>();
            n = 0;
            while (AbstractInsnNode.lIIIlllIIIll(n, abstractInsnNode.invisibleTypeAnnotations.size())) {
                typeAnnotationNode2 = abstractInsnNode.invisibleTypeAnnotations.get(n);
                typeAnnotationNode = new TypeAnnotationNode(typeAnnotationNode2.typeRef, typeAnnotationNode2.typePath, typeAnnotationNode2.desc);
                typeAnnotationNode2.accept(typeAnnotationNode);
                this.invisibleTypeAnnotations.add(typeAnnotationNode);
                "".length();
                ++n;
                "".length();
                if ((0x29 ^ 0x32 ^ (0x2B ^ 0x35)) > 0) continue;
                return null;
            }
        }
        return this;
    }

    static {
        INT_INSN = 1;
        TYPE_INSN = 3;
        INVOKE_DYNAMIC_INSN = 6;
        TABLESWITCH_INSN = 11;
        INSN = 0;
        JUMP_INSN = 7;
        LDC_INSN = 9;
        IINC_INSN = 10;
        LABEL = 8;
        FRAME = 14;
        MULTIANEWARRAY_INSN = 13;
        VAR_INSN = 2;
        LOOKUPSWITCH_INSN = 12;
        FIELD_INSN = 4;
        METHOD_INSN = 5;
        LINE = 15;
    }

    private static boolean lIIIlllIIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlllIIlII(Object object) {
        return object != null;
    }

    private static boolean lIIIlllIIIlI(Object object) {
        return object == null;
    }
}

