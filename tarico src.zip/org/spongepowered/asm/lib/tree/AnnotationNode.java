/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.List;
import org.spongepowered.asm.lib.AnnotationVisitor;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class AnnotationNode
extends AnnotationVisitor {
    public String desc;
    public List<Object> values;

    public AnnotationNode(String string) {
        this(327680, string);
        if (AnnotationNode.llIlIlIIIII(this.getClass(), AnnotationNode.class)) {
            throw new IllegalStateException();
        }
    }

    public AnnotationNode(int n, String string) {
        super(n);
        this.desc = string;
    }

    AnnotationNode(List<Object> list) {
        super(327680);
        this.values = list;
    }

    @Override
    public void visit(String string, Object object) {
        if (AnnotationNode.llIlIlIIIIl(this.values)) {
            int n;
            if (AnnotationNode.llIlIlIIIlI(this.desc)) {
                n = 2;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n = 1;
            }
            this.values = new ArrayList<Object>(n);
        }
        if (AnnotationNode.llIlIlIIIlI(this.desc)) {
            this.values.add(string);
            "".length();
        }
        if (AnnotationNode.llIlIlIIIll(object instanceof byte[])) {
            byte[] byArray = (byte[])object;
            ArrayList<Byte> arrayList = new ArrayList<Byte>(byArray.length);
            byte[] byArray2 = byArray;
            int n = byArray2.length;
            int n2 = 0;
            while (AnnotationNode.llIlIlIIlII(n2, n)) {
                byte by = byArray2[n2];
                arrayList.add(by);
                "".length();
                ++n2;
                "".length();
                if ("   ".length() > "  ".length()) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if (" ".length() == 0) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof boolean[])) {
            boolean[] blArray = (boolean[])object;
            ArrayList<Boolean> arrayList = new ArrayList<Boolean>(blArray.length);
            boolean[] blArray2 = blArray;
            int n = blArray2.length;
            int n3 = 0;
            while (AnnotationNode.llIlIlIIlII(n3, n)) {
                boolean bl = blArray2[n3];
                arrayList.add(bl);
                "".length();
                ++n3;
                "".length();
                if (((0x64 ^ 0x63 ^ (0xE5 ^ 0x81)) & (0x3F ^ 0x10 ^ (0xDB ^ 0x97) ^ -" ".length())) > -" ".length()) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if ("   ".length() <= 0) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof short[])) {
            short[] sArray = (short[])object;
            ArrayList<Short> arrayList = new ArrayList<Short>(sArray.length);
            short[] sArray2 = sArray;
            int n = sArray2.length;
            int n4 = 0;
            while (AnnotationNode.llIlIlIIlII(n4, n)) {
                short s = sArray2[n4];
                arrayList.add(s);
                "".length();
                ++n4;
                "".length();
                if (-"  ".length() <= 0) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if (((166 + 62 - 69 + 19 ^ 114 + 21 - 84 + 77) & (53 + 88 - 45 + 31 ^ (0x25 ^ 0x68) ^ -" ".length())) < 0) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof char[])) {
            char[] cArray = (char[])object;
            ArrayList<Character> arrayList = new ArrayList<Character>(cArray.length);
            char[] cArray2 = cArray;
            int n = cArray2.length;
            int n5 = 0;
            while (AnnotationNode.llIlIlIIlII(n5, n)) {
                char c = cArray2[n5];
                arrayList.add(Character.valueOf(c));
                "".length();
                ++n5;
                "".length();
                if ("  ".length() > ((0x84 ^ 0x9F ^ (0x1C ^ 0x58)) & (0xB ^ 0x7D ^ (0xB2 ^ 0x9B) ^ -" ".length()) & ((0x8A ^ 0x8D ^ (0x16 ^ 0x24)) & (0x5B ^ 0x75 ^ (8 ^ 0x13) ^ -" ".length()) ^ -" ".length()))) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if ((0x99 ^ 0x9D) == ((0x4C ^ 0x52) & ~(0x2D ^ 0x33))) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof int[])) {
            int[] nArray = (int[])object;
            ArrayList<Integer> arrayList = new ArrayList<Integer>(nArray.length);
            int[] nArray2 = nArray;
            int n = nArray2.length;
            int n6 = 0;
            while (AnnotationNode.llIlIlIIlII(n6, n)) {
                int n7 = nArray2[n6];
                arrayList.add(n7);
                "".length();
                ++n6;
                "".length();
                if ("  ".length() >= 0) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if (-(0x41 ^ 0x45) > 0) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof long[])) {
            long[] lArray = (long[])object;
            ArrayList<Long> arrayList = new ArrayList<Long>(lArray.length);
            long[] lArray2 = lArray;
            int n = lArray2.length;
            int n8 = 0;
            while (AnnotationNode.llIlIlIIlII(n8, n)) {
                long l = lArray2[n8];
                arrayList.add(l);
                "".length();
                ++n8;
                "".length();
                if (((0x1C ^ 0x16) & ~(0xB6 ^ 0xBC)) >= 0) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if ((19 + 132 - -18 + 9 ^ 37 + 127 - 154 + 172) != (20 + 50 - -48 + 27 ^ 116 + 51 - 113 + 95)) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof float[])) {
            float[] fArray = (float[])object;
            ArrayList<Float> arrayList = new ArrayList<Float>(fArray.length);
            float[] fArray2 = fArray;
            int n = fArray2.length;
            int n9 = 0;
            while (AnnotationNode.llIlIlIIlII(n9, n)) {
                float f = fArray2[n9];
                arrayList.add(Float.valueOf(f));
                "".length();
                ++n9;
                "".length();
                if (-" ".length() <= -" ".length()) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if (((0x38 ^ 0x10) & ~(0x77 ^ 0x5F)) != 0) {
                return;
            }
        } else if (AnnotationNode.llIlIlIIIll(object instanceof double[])) {
            double[] dArray = (double[])object;
            ArrayList<Double> arrayList = new ArrayList<Double>(dArray.length);
            double[] dArray2 = dArray;
            int n = dArray2.length;
            int n10 = 0;
            while (AnnotationNode.llIlIlIIlII(n10, n)) {
                double d = dArray2[n10];
                arrayList.add(d);
                "".length();
                ++n10;
                "".length();
                if ((0x6D ^ 0x3D ^ (0x27 ^ 0x72)) > 0) continue;
                return;
            }
            this.values.add(arrayList);
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else {
            this.values.add(object);
            "".length();
        }
    }

    @Override
    public void visitEnum(String string, String string2, String string3) {
        if (AnnotationNode.llIlIlIIIIl(this.values)) {
            int n;
            if (AnnotationNode.llIlIlIIIlI(this.desc)) {
                n = 2;
                "".length();
                if (((175 + 187 - 151 + 24 ^ 132 + 123 - 234 + 117) & (211 + 244 - 379 + 173 ^ 15 + 36 - 40 + 141 ^ -" ".length())) != 0) {
                    return;
                }
            } else {
                n = 1;
            }
            this.values = new ArrayList<Object>(n);
        }
        if (AnnotationNode.llIlIlIIIlI(this.desc)) {
            this.values.add(string);
            "".length();
        }
        this.values.add(new String[]{string2, string3});
        "".length();
    }

    @Override
    public AnnotationVisitor visitAnnotation(String string, String string2) {
        if (AnnotationNode.llIlIlIIIIl(this.values)) {
            int n;
            if (AnnotationNode.llIlIlIIIlI(this.desc)) {
                n = 2;
                "".length();
                if (-" ".length() > (0x6D ^ 0x69)) {
                    return null;
                }
            } else {
                n = 1;
            }
            this.values = new ArrayList<Object>(n);
        }
        if (AnnotationNode.llIlIlIIIlI(this.desc)) {
            this.values.add(string);
            "".length();
        }
        AnnotationNode annotationNode = new AnnotationNode(string2);
        this.values.add(annotationNode);
        "".length();
        return annotationNode;
    }

    @Override
    public AnnotationVisitor visitArray(String string) {
        if (AnnotationNode.llIlIlIIIIl(this.values)) {
            int n;
            if (AnnotationNode.llIlIlIIIlI(this.desc)) {
                n = 2;
                "".length();
                if (((0x9A ^ 0xA3) & ~(0x55 ^ 0x6C)) > 0) {
                    return null;
                }
            } else {
                n = 1;
            }
            this.values = new ArrayList<Object>(n);
        }
        if (AnnotationNode.llIlIlIIIlI(this.desc)) {
            this.values.add(string);
            "".length();
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        this.values.add(arrayList);
        "".length();
        return new AnnotationNode(arrayList);
    }

    @Override
    public void visitEnd() {
    }

    public void check(int n) {
    }

    public void accept(AnnotationVisitor annotationVisitor) {
        if (AnnotationNode.llIlIlIIIlI(annotationVisitor)) {
            if (AnnotationNode.llIlIlIIIlI(this.values)) {
                int n = 0;
                while (AnnotationNode.llIlIlIIlII(n, this.values.size())) {
                    String string = (String)this.values.get(n);
                    Object object = this.values.get(n + 1);
                    AnnotationNode.accept(annotationVisitor, string, object);
                    n += 2;
                    "".length();
                    if (-"  ".length() <= 0) continue;
                    return;
                }
            }
            annotationVisitor.visitEnd();
        }
    }

    static void accept(AnnotationVisitor annotationVisitor, String string, Object object) {
        if (AnnotationNode.llIlIlIIIlI(annotationVisitor)) {
            if (AnnotationNode.llIlIlIIIll(object instanceof String[])) {
                String[] stringArray = (String[])object;
                annotationVisitor.visitEnum(string, stringArray[0], stringArray[1]);
                "".length();
                if (-" ".length() >= "   ".length()) {
                    return;
                }
            } else if (AnnotationNode.llIlIlIIIll(object instanceof AnnotationNode)) {
                AnnotationNode annotationNode = (AnnotationNode)object;
                annotationNode.accept(annotationVisitor.visitAnnotation(string, annotationNode.desc));
                "".length();
                if ("  ".length() != "  ".length()) {
                    return;
                }
            } else if (AnnotationNode.llIlIlIIIll(object instanceof List)) {
                AnnotationVisitor annotationVisitor2 = annotationVisitor.visitArray(string);
                if (AnnotationNode.llIlIlIIIlI(annotationVisitor2)) {
                    List list = (List)object;
                    int n = 0;
                    while (AnnotationNode.llIlIlIIlII(n, list.size())) {
                        AnnotationNode.accept(annotationVisitor2, null, list.get(n));
                        ++n;
                        "".length();
                        if ((0x93 ^ 0x96) > 0) continue;
                        return;
                    }
                    annotationVisitor2.visitEnd();
                }
                "".length();
                if (((0xD2 ^ 0xA5 ^ (0x77 ^ 0x5C)) & (0xA8 ^ 0x8F ^ (0x43 ^ 0x38) ^ -" ".length())) < ((105 + 127 - 146 + 65 ^ 78 + 83 - 64 + 43) & (0x7E ^ 0x59 ^ (0xFF ^ 0xC3) ^ -" ".length()))) {
                    return;
                }
            } else {
                annotationVisitor.visit(string, object);
            }
        }
    }

    private static boolean llIlIlIIlII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIlIIIII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlIlIIIlI(Object object) {
        return object != null;
    }

    private static boolean llIlIlIIIIl(Object object) {
        return object == null;
    }

    private static boolean llIlIlIIIll(int n) {
        return n != 0;
    }
}

