/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.InnerClassNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.TypeAnnotationNode;

public class ClassNode
extends ClassVisitor {
    public int version;
    public int access;
    public String name;
    public String signature;
    public String superName;
    public List<String> interfaces = new ArrayList<String>();
    public String sourceFile;
    public String sourceDebug;
    public String outerClass;
    public String outerMethod;
    public String outerMethodDesc;
    public List<AnnotationNode> visibleAnnotations;
    public List<AnnotationNode> invisibleAnnotations;
    public List<TypeAnnotationNode> visibleTypeAnnotations;
    public List<TypeAnnotationNode> invisibleTypeAnnotations;
    public List<Attribute> attrs;
    public List<InnerClassNode> innerClasses = new ArrayList<InnerClassNode>();
    public List<FieldNode> fields = new ArrayList<FieldNode>();
    public List<MethodNode> methods = new ArrayList<MethodNode>();

    public ClassNode() {
        this(327680);
        if (ClassNode.lIIllIlIlIl(this.getClass(), ClassNode.class)) {
            throw new IllegalStateException();
        }
    }

    public ClassNode(int n) {
        super(n);
    }

    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        this.version = n;
        this.access = n2;
        this.name = string;
        this.signature = string2;
        this.superName = string3;
        if (ClassNode.lIIllIlIllI(stringArray)) {
            this.interfaces.addAll(Arrays.asList(stringArray));
            "".length();
        }
    }

    public void visitSource(String string, String string2) {
        this.sourceFile = string;
        this.sourceDebug = string2;
    }

    public void visitOuterClass(String string, String string2, String string3) {
        this.outerClass = string;
        this.outerMethod = string2;
        this.outerMethodDesc = string3;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationNode annotationNode = new AnnotationNode(string);
        if (ClassNode.lIIllIlIlll(bl ? 1 : 0)) {
            if (ClassNode.lIIllIllIII(this.visibleAnnotations)) {
                this.visibleAnnotations = new ArrayList<AnnotationNode>(1);
            }
            this.visibleAnnotations.add(annotationNode);
            "".length();
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            if (ClassNode.lIIllIllIII(this.invisibleAnnotations)) {
                this.invisibleAnnotations = new ArrayList<AnnotationNode>(1);
            }
            this.invisibleAnnotations.add(annotationNode);
            "".length();
        }
        return annotationNode;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        TypeAnnotationNode typeAnnotationNode = new TypeAnnotationNode(n, typePath, string);
        if (ClassNode.lIIllIlIlll(bl ? 1 : 0)) {
            if (ClassNode.lIIllIllIII(this.visibleTypeAnnotations)) {
                this.visibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            this.visibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
            "".length();
            if (((0x31 ^ 0x2A ^ (0xBB ^ 0x89)) & (8 ^ 0x71 ^ (0x31 ^ 0x61) ^ -" ".length())) < ((0x22 ^ 0x7E ^ (0x2D ^ 0x4C)) & (157 + 33 - 183 + 246 ^ 77 + 62 - 6 + 59 ^ -" ".length()))) {
                return null;
            }
        } else {
            if (ClassNode.lIIllIllIII(this.invisibleTypeAnnotations)) {
                this.invisibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            this.invisibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
        }
        return typeAnnotationNode;
    }

    public void visitAttribute(Attribute attribute) {
        if (ClassNode.lIIllIllIII(this.attrs)) {
            this.attrs = new ArrayList<Attribute>(1);
        }
        this.attrs.add(attribute);
        "".length();
    }

    public void visitInnerClass(String string, String string2, String string3, int n) {
        InnerClassNode innerClassNode = new InnerClassNode(string, string2, string3, n);
        this.innerClasses.add(innerClassNode);
        "".length();
    }

    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        FieldNode fieldNode = new FieldNode(n, string, string2, string3, object);
        this.fields.add(fieldNode);
        "".length();
        return fieldNode;
    }

    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodNode methodNode = new MethodNode(n, string, string2, string3, stringArray);
        this.methods.add(methodNode);
        "".length();
        return methodNode;
    }

    public void visitEnd() {
    }

    public void check(int n) {
        if (ClassNode.lIIllIllIIl(n, 262144)) {
            Object object;
            if (ClassNode.lIIllIlIllI(this.visibleTypeAnnotations) && ClassNode.lIIllIllIlI(this.visibleTypeAnnotations.size())) {
                throw new RuntimeException();
            }
            if (ClassNode.lIIllIlIllI(this.invisibleTypeAnnotations) && ClassNode.lIIllIllIlI(this.invisibleTypeAnnotations.size())) {
                throw new RuntimeException();
            }
            Iterator<Object> iterator = this.fields.iterator();
            while (ClassNode.lIIllIlIlll(iterator.hasNext() ? 1 : 0)) {
                object = iterator.next();
                ((FieldNode)object).check(n);
                "".length();
                if ("  ".length() >= " ".length()) continue;
                return;
            }
            iterator = this.methods.iterator();
            while (ClassNode.lIIllIlIlll(iterator.hasNext() ? 1 : 0)) {
                object = (MethodNode)iterator.next();
                ((MethodNode)object).check(n);
                "".length();
                if (((0x6C ^ 0x4A) & ~(0x6A ^ 0x4C)) == 0) continue;
                return;
            }
        }
    }

    public void accept(ClassVisitor classVisitor) {
        int n;
        int n2;
        int n3;
        int n4;
        AnnotationNode annotationNode;
        int n5;
        String[] stringArray = new String[this.interfaces.size()];
        this.interfaces.toArray(stringArray);
        "".length();
        classVisitor.visit(this.version, this.access, this.name, this.signature, this.superName, stringArray);
        if (!ClassNode.lIIllIllIII(this.sourceFile) || ClassNode.lIIllIlIllI(this.sourceDebug)) {
            classVisitor.visitSource(this.sourceFile, this.sourceDebug);
        }
        if (ClassNode.lIIllIlIllI(this.outerClass)) {
            classVisitor.visitOuterClass(this.outerClass, this.outerMethod, this.outerMethodDesc);
        }
        if (ClassNode.lIIllIllIII(this.visibleAnnotations)) {
            n5 = 0;
            "".length();
            if ((0xE ^ 0xA) < " ".length()) {
                return;
            }
        } else {
            n5 = this.visibleAnnotations.size();
        }
        int n6 = n5;
        int n7 = 0;
        while (ClassNode.lIIllIllllI(n7, n6)) {
            annotationNode = this.visibleAnnotations.get(n7);
            annotationNode.accept(classVisitor.visitAnnotation(annotationNode.desc, true));
            ++n7;
            "".length();
            if (" ".length() >= " ".length()) continue;
            return;
        }
        if (ClassNode.lIIllIllIII(this.invisibleAnnotations)) {
            n4 = 0;
            "".length();
            if ("  ".length() <= " ".length()) {
                return;
            }
        } else {
            n4 = this.invisibleAnnotations.size();
        }
        n6 = n4;
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, n6)) {
            annotationNode = this.invisibleAnnotations.get(n7);
            annotationNode.accept(classVisitor.visitAnnotation(annotationNode.desc, false));
            ++n7;
            "".length();
            if (((144 + 162 - 303 + 175 ^ 40 + 52 - 79 + 122) & (109 + 82 - 103 + 51 ^ 112 + 154 - 130 + 54 ^ -" ".length())) < " ".length()) continue;
            return;
        }
        if (ClassNode.lIIllIllIII(this.visibleTypeAnnotations)) {
            n3 = 0;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            n3 = this.visibleTypeAnnotations.size();
        }
        n6 = n3;
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, n6)) {
            annotationNode = this.visibleTypeAnnotations.get(n7);
            annotationNode.accept(classVisitor.visitTypeAnnotation(((TypeAnnotationNode)annotationNode).typeRef, ((TypeAnnotationNode)annotationNode).typePath, ((TypeAnnotationNode)annotationNode).desc, true));
            ++n7;
            "".length();
            if (-" ".length() != (84 + 96 - 49 + 3 ^ 105 + 99 - 137 + 63)) continue;
            return;
        }
        if (ClassNode.lIIllIllIII(this.invisibleTypeAnnotations)) {
            n2 = 0;
            "".length();
            if (-"  ".length() > 0) {
                return;
            }
        } else {
            n2 = this.invisibleTypeAnnotations.size();
        }
        n6 = n2;
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, n6)) {
            annotationNode = this.invisibleTypeAnnotations.get(n7);
            annotationNode.accept(classVisitor.visitTypeAnnotation(((TypeAnnotationNode)annotationNode).typeRef, ((TypeAnnotationNode)annotationNode).typePath, ((TypeAnnotationNode)annotationNode).desc, false));
            ++n7;
            "".length();
            if (-" ".length() < 0) continue;
            return;
        }
        if (ClassNode.lIIllIllIII(this.attrs)) {
            n = 0;
            "".length();
            if (((0xAC ^ 0xBF) & ~(0x2C ^ 0x3F)) != ((0x15 ^ 0x30) & ~(0xBD ^ 0x98))) {
                return;
            }
        } else {
            n = this.attrs.size();
        }
        n6 = n;
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, n6)) {
            classVisitor.visitAttribute(this.attrs.get(n7));
            ++n7;
            "".length();
            if ("   ".length() <= (0x79 ^ 0x7D)) continue;
            return;
        }
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, this.innerClasses.size())) {
            this.innerClasses.get(n7).accept(classVisitor);
            ++n7;
            "".length();
            if (-" ".length() != " ".length()) continue;
            return;
        }
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, this.fields.size())) {
            this.fields.get(n7).accept(classVisitor);
            ++n7;
            "".length();
            if ((0xB0 ^ 0xB4) > " ".length()) continue;
            return;
        }
        n7 = 0;
        while (ClassNode.lIIllIllllI(n7, this.methods.size())) {
            this.methods.get(n7).accept(classVisitor);
            ++n7;
            "".length();
            if ("   ".length() <= (0xA6 ^ 0xA2)) continue;
            return;
        }
        classVisitor.visitEnd();
    }

    private static boolean lIIllIllIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIllIllllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIllIlIlIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIllIlIllI(Object object) {
        return object != null;
    }

    private static boolean lIIllIllIII(Object object) {
        return object == null;
    }

    private static boolean lIIllIlIlll(int n) {
        return n != 0;
    }

    private static boolean lIIllIllIlI(int n) {
        return n > 0;
    }
}

