/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.List;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.TypeAnnotationNode;

public class FieldNode
extends FieldVisitor {
    public int access;
    public String name;
    public String desc;
    public String signature;
    public Object value;
    public List<AnnotationNode> visibleAnnotations;
    public List<AnnotationNode> invisibleAnnotations;
    public List<TypeAnnotationNode> visibleTypeAnnotations;
    public List<TypeAnnotationNode> invisibleTypeAnnotations;
    public List<Attribute> attrs;

    public FieldNode(int n, String string, String string2, String string3, Object object) {
        this(327680, n, string, string2, string3, object);
        if (FieldNode.lIIlIllIII(this.getClass(), FieldNode.class)) {
            throw new IllegalStateException();
        }
    }

    public FieldNode(int n, int n2, String string, String string2, String string3, Object object) {
        super(n);
        this.access = n2;
        this.name = string;
        this.desc = string2;
        this.signature = string3;
        this.value = object;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationNode annotationNode = new AnnotationNode(string);
        if (FieldNode.lIIlIllIIl(bl ? 1 : 0)) {
            if (FieldNode.lIIlIllIlI(this.visibleAnnotations)) {
                this.visibleAnnotations = new ArrayList<AnnotationNode>(1);
            }
            this.visibleAnnotations.add(annotationNode);
            "".length();
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            if (FieldNode.lIIlIllIlI(this.invisibleAnnotations)) {
                this.invisibleAnnotations = new ArrayList<AnnotationNode>(1);
            }
            this.invisibleAnnotations.add(annotationNode);
            "".length();
        }
        return annotationNode;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        TypeAnnotationNode typeAnnotationNode = new TypeAnnotationNode(n, typePath, string);
        if (FieldNode.lIIlIllIIl(bl ? 1 : 0)) {
            if (FieldNode.lIIlIllIlI(this.visibleTypeAnnotations)) {
                this.visibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            this.visibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
            "".length();
            if (((119 + 57 - -38 + 13 ^ 165 + 156 - 275 + 134) & (101 + 137 - 98 + 61 ^ 71 + 85 - 128 + 130 ^ -" ".length())) < 0) {
                return null;
            }
        } else {
            if (FieldNode.lIIlIllIlI(this.invisibleTypeAnnotations)) {
                this.invisibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            this.invisibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
        }
        return typeAnnotationNode;
    }

    public void visitAttribute(Attribute attribute) {
        if (FieldNode.lIIlIllIlI(this.attrs)) {
            this.attrs = new ArrayList<Attribute>(1);
        }
        this.attrs.add(attribute);
        "".length();
    }

    public void visitEnd() {
    }

    public void check(int n) {
        if (FieldNode.lIIlIllIll(n, 262144)) {
            if (FieldNode.lIIlIlllII(this.visibleTypeAnnotations) && FieldNode.lIIlIlllIl(this.visibleTypeAnnotations.size())) {
                throw new RuntimeException();
            }
            if (FieldNode.lIIlIlllII(this.invisibleTypeAnnotations) && FieldNode.lIIlIlllIl(this.invisibleTypeAnnotations.size())) {
                throw new RuntimeException();
            }
        }
    }

    public void accept(ClassVisitor classVisitor) {
        int n;
        int n2;
        int n3;
        int n4;
        AnnotationNode annotationNode;
        int n5;
        FieldVisitor fieldVisitor = classVisitor.visitField(this.access, this.name, this.desc, this.signature, this.value);
        if (FieldNode.lIIlIllIlI(fieldVisitor)) {
            return;
        }
        if (FieldNode.lIIlIllIlI(this.visibleAnnotations)) {
            n5 = 0;
            "".length();
            if ("   ".length() < "  ".length()) {
                return;
            }
        } else {
            n5 = this.visibleAnnotations.size();
        }
        int n6 = n5;
        int n7 = 0;
        while (FieldNode.lIIlIllllI(n7, n6)) {
            annotationNode = this.visibleAnnotations.get(n7);
            annotationNode.accept(fieldVisitor.visitAnnotation(annotationNode.desc, true));
            ++n7;
            "".length();
            if (" ".length() == " ".length()) continue;
            return;
        }
        if (FieldNode.lIIlIllIlI(this.invisibleAnnotations)) {
            n4 = 0;
            "".length();
            if (((0xCC ^ 0xAC ^ (0xC2 ^ 0x98)) & (87 + 157 - 173 + 92 ^ 151 + 42 - 67 + 27 ^ -" ".length())) == "  ".length()) {
                return;
            }
        } else {
            n4 = this.invisibleAnnotations.size();
        }
        n6 = n4;
        n7 = 0;
        while (FieldNode.lIIlIllllI(n7, n6)) {
            annotationNode = this.invisibleAnnotations.get(n7);
            annotationNode.accept(fieldVisitor.visitAnnotation(annotationNode.desc, false));
            ++n7;
            "".length();
            if (((0xFD ^ 0xB0 ^ (0x7A ^ 0x29)) & (132 + 31 - 158 + 141 ^ 100 + 115 - 141 + 66 ^ -" ".length())) <= "  ".length()) continue;
            return;
        }
        if (FieldNode.lIIlIllIlI(this.visibleTypeAnnotations)) {
            n3 = 0;
            "".length();
            if (((0x8E ^ 0xB5) & ~(0x4C ^ 0x77)) > (0x25 ^ 0x21)) {
                return;
            }
        } else {
            n3 = this.visibleTypeAnnotations.size();
        }
        n6 = n3;
        n7 = 0;
        while (FieldNode.lIIlIllllI(n7, n6)) {
            annotationNode = this.visibleTypeAnnotations.get(n7);
            annotationNode.accept(fieldVisitor.visitTypeAnnotation(((TypeAnnotationNode)annotationNode).typeRef, ((TypeAnnotationNode)annotationNode).typePath, ((TypeAnnotationNode)annotationNode).desc, true));
            ++n7;
            "".length();
            if ((0x72 ^ 0x76) == (0x1A ^ 0x1E)) continue;
            return;
        }
        if (FieldNode.lIIlIllIlI(this.invisibleTypeAnnotations)) {
            n2 = 0;
            "".length();
            if ("   ".length() != "   ".length()) {
                return;
            }
        } else {
            n2 = this.invisibleTypeAnnotations.size();
        }
        n6 = n2;
        n7 = 0;
        while (FieldNode.lIIlIllllI(n7, n6)) {
            annotationNode = this.invisibleTypeAnnotations.get(n7);
            annotationNode.accept(fieldVisitor.visitTypeAnnotation(((TypeAnnotationNode)annotationNode).typeRef, ((TypeAnnotationNode)annotationNode).typePath, ((TypeAnnotationNode)annotationNode).desc, false));
            ++n7;
            "".length();
            if (-" ".length() < "   ".length()) continue;
            return;
        }
        if (FieldNode.lIIlIllIlI(this.attrs)) {
            n = 0;
            "".length();
            if (((0x71 ^ 0x3C ^ (0xCB ^ 0xB0)) & (0xF9 ^ 0xC0 ^ (0x7C ^ 0x73) ^ -" ".length())) > "  ".length()) {
                return;
            }
        } else {
            n = this.attrs.size();
        }
        n6 = n;
        n7 = 0;
        while (FieldNode.lIIlIllllI(n7, n6)) {
            fieldVisitor.visitAttribute(this.attrs.get(n7));
            ++n7;
            "".length();
            if (((102 + 8 - 25 + 73 ^ 64 + 65 - -10 + 41) & (33 + 14 - -65 + 15 ^ (0xCE ^ 0x9B) ^ -" ".length())) < " ".length()) continue;
            return;
        }
        fieldVisitor.visitEnd();
    }

    private static boolean lIIlIllIll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIlIllllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIlIllIII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIlIlllII(Object object) {
        return object != null;
    }

    private static boolean lIIlIllIlI(Object object) {
        return object == null;
    }

    private static boolean lIIlIllIIl(int n) {
        return n != 0;
    }

    private static boolean lIIlIlllIl(int n) {
        return n > 0;
    }
}

