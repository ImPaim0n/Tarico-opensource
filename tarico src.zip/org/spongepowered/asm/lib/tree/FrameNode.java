/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class FrameNode
extends AbstractInsnNode {
    public int type;
    public List<Object> local;
    public List<Object> stack;

    private FrameNode() {
        super(-1);
    }

    public FrameNode(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        super(-1);
        this.type = n;
        switch (n) {
            case -1: 
            case 0: {
                this.local = FrameNode.asList(n2, objectArray);
                this.stack = FrameNode.asList(n3, objectArray2);
                "".length();
                if (-" ".length() == -" ".length()) break;
                throw null;
            }
            case 1: {
                this.local = FrameNode.asList(n2, objectArray);
                "".length();
                if (" ".length() <= "  ".length()) break;
                throw null;
            }
            case 2: {
                this.local = Arrays.asList(new Object[n2]);
                "".length();
                if ("  ".length() < "   ".length()) break;
                throw null;
            }
            case 3: {
                "".length();
                if (-" ".length() == -" ".length()) break;
                throw null;
            }
            case 4: {
                this.stack = FrameNode.asList(1, objectArray2);
            }
        }
    }

    @Override
    public int getType() {
        return 14;
    }

    @Override
    public void accept(MethodVisitor methodVisitor) {
        switch (this.type) {
            case -1: 
            case 0: {
                methodVisitor.visitFrame(this.type, this.local.size(), FrameNode.asArray(this.local), this.stack.size(), FrameNode.asArray(this.stack));
                "".length();
                if ("  ".length() != " ".length()) break;
                return;
            }
            case 1: {
                methodVisitor.visitFrame(this.type, this.local.size(), FrameNode.asArray(this.local), 0, null);
                "".length();
                if ("  ".length() < (0x7E ^ 0x7A)) break;
                return;
            }
            case 2: {
                methodVisitor.visitFrame(this.type, this.local.size(), null, 0, null);
                "".length();
                if (null == null) break;
                return;
            }
            case 3: {
                methodVisitor.visitFrame(this.type, 0, null, 0, null);
                "".length();
                if (-(0x1E ^ 0x1A) < 0) break;
                return;
            }
            case 4: {
                methodVisitor.visitFrame(this.type, 0, null, 1, FrameNode.asArray(this.stack));
            }
        }
    }

    @Override
    public AbstractInsnNode clone(Map<LabelNode, LabelNode> map) {
        Object object;
        int n;
        FrameNode frameNode = new FrameNode();
        frameNode.type = this.type;
        if (FrameNode.llllIlIlIl(this.local)) {
            frameNode.local = new ArrayList<Object>();
            n = 0;
            while (FrameNode.llllIlIllI(n, this.local.size())) {
                object = this.local.get(n);
                if (FrameNode.llllIlIlll(object instanceof LabelNode)) {
                    object = map.get(object);
                }
                frameNode.local.add(object);
                "".length();
                ++n;
                "".length();
                if (-" ".length() <= " ".length()) continue;
                return null;
            }
        }
        if (FrameNode.llllIlIlIl(this.stack)) {
            frameNode.stack = new ArrayList<Object>();
            n = 0;
            while (FrameNode.llllIlIllI(n, this.stack.size())) {
                object = this.stack.get(n);
                if (FrameNode.llllIlIlll(object instanceof LabelNode)) {
                    object = map.get(object);
                }
                frameNode.stack.add(object);
                "".length();
                ++n;
                "".length();
                if (" ".length() >= ((0x83 ^ 0x95 ^ (0x2B ^ 9)) & (0x4F ^ 4 ^ 99 + 103 - 144 + 69 ^ -" ".length()))) continue;
                return null;
            }
        }
        return frameNode;
    }

    private static List<Object> asList(int n, Object[] objectArray) {
        return Arrays.asList(objectArray).subList(0, n);
    }

    private static Object[] asArray(List<Object> list) {
        Object[] objectArray = new Object[list.size()];
        int n = 0;
        while (FrameNode.llllIlIllI(n, objectArray.length)) {
            Object object = list.get(n);
            if (FrameNode.llllIlIlll(object instanceof LabelNode)) {
                object = ((LabelNode)object).getLabel();
            }
            objectArray[n] = object;
            ++n;
            "".length();
            if ("  ".length() >= -" ".length()) continue;
            return null;
        }
        return objectArray;
    }

    private static boolean llllIlIllI(int n, int n2) {
        return n < n2;
    }

    private static boolean llllIlIlIl(Object object) {
        return object != null;
    }

    private static boolean llllIlIlll(int n) {
        return n != 0;
    }
}

