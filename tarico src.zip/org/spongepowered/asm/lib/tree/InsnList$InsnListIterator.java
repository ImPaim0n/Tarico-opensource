/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ListIterator;
import java.util.NoSuchElementException;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;

final class InsnList$InsnListIterator
implements ListIterator {
    AbstractInsnNode next;
    AbstractInsnNode prev;
    AbstractInsnNode remove;
    final /* synthetic */ InsnList this$0;

    InsnList$InsnListIterator(InsnList insnList, int n) {
        this.this$0 = insnList;
        if (InsnList$InsnListIterator.llIIlIlllI(n, insnList.size())) {
            this.next = null;
            this.prev = insnList.getLast();
            "".length();
            if ("   ".length() < "   ".length()) {
                throw null;
            }
        } else {
            this.next = insnList.get(n);
            this.prev = this.next.prev;
        }
    }

    public boolean hasNext() {
        boolean bl;
        if (InsnList$InsnListIterator.llIIlIllll(this.next)) {
            bl = true;
            "".length();
            if (" ".length() < -" ".length()) {
                return ((0x43 ^ 0x16 ^ "   ".length()) & (0x4D ^ 0x40 ^ (0x7E ^ 0x25) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public Object next() {
        AbstractInsnNode abstractInsnNode;
        if (InsnList$InsnListIterator.llIIllIIII(this.next)) {
            throw new NoSuchElementException();
        }
        this.prev = abstractInsnNode = this.next;
        this.next = abstractInsnNode.next;
        this.remove = abstractInsnNode;
        return abstractInsnNode;
    }

    public void remove() {
        if (InsnList$InsnListIterator.llIIlIllll(this.remove)) {
            if (InsnList$InsnListIterator.llIIllIIll(this.remove, this.next)) {
                this.next = this.next.next;
                "".length();
                if ((0x58 ^ 0x5D) <= 0) {
                    return;
                }
            } else {
                this.prev = this.prev.prev;
            }
            this.this$0.remove(this.remove);
            this.remove = null;
            "".length();
            if (-(0xC1 ^ 0xC5) > 0) {
                return;
            }
        } else {
            throw new IllegalStateException();
        }
    }

    public boolean hasPrevious() {
        boolean bl;
        if (InsnList$InsnListIterator.llIIlIllll(this.prev)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x29 ^ 0x2C) & ~(0x82 ^ 0x87)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public Object previous() {
        AbstractInsnNode abstractInsnNode;
        this.next = abstractInsnNode = this.prev;
        this.prev = abstractInsnNode.prev;
        this.remove = abstractInsnNode;
        return abstractInsnNode;
    }

    public int nextIndex() {
        if (InsnList$InsnListIterator.llIIllIIII(this.next)) {
            return this.this$0.size();
        }
        if (InsnList$InsnListIterator.llIIllIIII(this.this$0.cache)) {
            this.this$0.cache = this.this$0.toArray();
        }
        return this.next.index;
    }

    public int previousIndex() {
        if (InsnList$InsnListIterator.llIIllIIII(this.prev)) {
            return -1;
        }
        if (InsnList$InsnListIterator.llIIllIIII(this.this$0.cache)) {
            this.this$0.cache = this.this$0.toArray();
        }
        return this.prev.index;
    }

    public void add(Object object) {
        if (InsnList$InsnListIterator.llIIlIllll(this.next)) {
            this.this$0.insertBefore(this.next, (AbstractInsnNode)object);
            "".length();
            if ("   ".length() <= " ".length()) {
                return;
            }
        } else if (InsnList$InsnListIterator.llIIlIllll(this.prev)) {
            this.this$0.insert(this.prev, (AbstractInsnNode)object);
            "".length();
            if ("  ".length() <= 0) {
                return;
            }
        } else {
            this.this$0.add((AbstractInsnNode)object);
        }
        this.prev = (AbstractInsnNode)object;
        this.remove = null;
    }

    public void set(Object object) {
        if (InsnList$InsnListIterator.llIIlIllll(this.remove)) {
            this.this$0.set(this.remove, (AbstractInsnNode)object);
            if (InsnList$InsnListIterator.llIIllIIll(this.remove, this.prev)) {
                this.prev = (AbstractInsnNode)object;
                "".length();
                if ((0x3C ^ 0x38) == " ".length()) {
                    return;
                }
            } else {
                this.next = (AbstractInsnNode)object;
                "".length();
                if ("   ".length() < 0) {
                    return;
                }
            }
        } else {
            throw new IllegalStateException();
        }
    }

    private static boolean llIIlIlllI(int n, int n2) {
        return n == n2;
    }

    private static boolean llIIlIllll(Object object) {
        return object != null;
    }

    private static boolean llIIllIIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIIllIIII(Object object) {
        return object == null;
    }
}

