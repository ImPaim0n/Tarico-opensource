/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ListIterator;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList$InsnListIterator;
import org.spongepowered.asm.lib.tree.LabelNode;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class InsnList {
    private int size;
    private AbstractInsnNode first;
    private AbstractInsnNode last;
    AbstractInsnNode[] cache;

    public int size() {
        return this.size;
    }

    public AbstractInsnNode getFirst() {
        return this.first;
    }

    public AbstractInsnNode getLast() {
        return this.last;
    }

    public AbstractInsnNode get(int n) {
        if (!InsnList.lIlllIlIll(n) || InsnList.lIlllIllII(n, this.size)) {
            throw new IndexOutOfBoundsException();
        }
        if (InsnList.lIlllIllIl(this.cache)) {
            this.cache = this.toArray();
        }
        return this.cache[n];
    }

    public boolean contains(AbstractInsnNode abstractInsnNode) {
        boolean bl;
        AbstractInsnNode abstractInsnNode2 = this.first;
        while (InsnList.lIlllIlllI(abstractInsnNode2) && InsnList.lIlllIllll(abstractInsnNode2, abstractInsnNode)) {
            abstractInsnNode2 = abstractInsnNode2.next;
            "".length();
            if ((0x66 ^ 0x50 ^ (0x70 ^ 0x42)) != 0) continue;
            return ((13 + 78 - 87 + 179 ^ 175 + 89 - 177 + 100) & (99 + 111 - 128 + 74 ^ 15 + 8 - -10 + 111 ^ -" ".length())) != 0;
        }
        if (InsnList.lIlllIlllI(abstractInsnNode2)) {
            bl = true;
            "".length();
            if (" ".length() == 0) {
                return ((0x27 ^ 0x68) & ~(0x75 ^ 0x3A)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int indexOf(AbstractInsnNode abstractInsnNode) {
        if (InsnList.lIlllIllIl(this.cache)) {
            this.cache = this.toArray();
        }
        return abstractInsnNode.index;
    }

    public void accept(MethodVisitor methodVisitor) {
        AbstractInsnNode abstractInsnNode = this.first;
        while (InsnList.lIlllIlllI(abstractInsnNode)) {
            abstractInsnNode.accept(methodVisitor);
            abstractInsnNode = abstractInsnNode.next;
            "".length();
            if ((0xBC ^ 0x86 ^ (0x68 ^ 0x56)) >= -" ".length()) continue;
            return;
        }
    }

    public ListIterator<AbstractInsnNode> iterator() {
        return this.iterator(0);
    }

    public ListIterator<AbstractInsnNode> iterator(int n) {
        return new InsnList$InsnListIterator(this, n);
    }

    public AbstractInsnNode[] toArray() {
        int n = 0;
        AbstractInsnNode abstractInsnNode = this.first;
        AbstractInsnNode[] abstractInsnNodeArray = new AbstractInsnNode[this.size];
        while (InsnList.lIlllIlllI(abstractInsnNode)) {
            abstractInsnNodeArray[n] = abstractInsnNode;
            abstractInsnNode.index = n++;
            abstractInsnNode = abstractInsnNode.next;
            "".length();
            if ("  ".length() > 0) continue;
            return null;
        }
        return abstractInsnNodeArray;
    }

    public void set(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        AbstractInsnNode abstractInsnNode3;
        AbstractInsnNode abstractInsnNode4;
        abstractInsnNode2.next = abstractInsnNode4 = abstractInsnNode.next;
        if (InsnList.lIlllIlllI(abstractInsnNode4)) {
            abstractInsnNode4.prev = abstractInsnNode2;
            "".length();
            if ("   ".length() < -" ".length()) {
                return;
            }
        } else {
            this.last = abstractInsnNode2;
        }
        abstractInsnNode2.prev = abstractInsnNode3 = abstractInsnNode.prev;
        if (InsnList.lIlllIlllI(abstractInsnNode3)) {
            abstractInsnNode3.next = abstractInsnNode2;
            "".length();
            if (" ".length() >= (0x40 ^ 0x13 ^ (0x1C ^ 0x4B))) {
                return;
            }
        } else {
            this.first = abstractInsnNode2;
        }
        if (InsnList.lIlllIlllI(this.cache)) {
            int n = abstractInsnNode.index;
            this.cache[n] = abstractInsnNode2;
            abstractInsnNode2.index = n;
            "".length();
            if (-(0x1F ^ 0x1B) >= 0) {
                return;
            }
        } else {
            abstractInsnNode2.index = 0;
        }
        abstractInsnNode.index = -1;
        abstractInsnNode.prev = null;
        abstractInsnNode.next = null;
    }

    public void add(AbstractInsnNode abstractInsnNode) {
        ++this.size;
        if (InsnList.lIlllIllIl(this.last)) {
            this.first = abstractInsnNode;
            this.last = abstractInsnNode;
            "".length();
            if ("  ".length() < 0) {
                return;
            }
        } else {
            this.last.next = abstractInsnNode;
            abstractInsnNode.prev = this.last;
        }
        this.last = abstractInsnNode;
        this.cache = null;
        abstractInsnNode.index = 0;
    }

    public void add(InsnList insnList) {
        if (InsnList.lIllllIIII(insnList.size)) {
            return;
        }
        this.size += insnList.size;
        if (InsnList.lIlllIllIl(this.last)) {
            this.first = insnList.first;
            this.last = insnList.last;
            "".length();
            if (" ".length() == 0) {
                return;
            }
        } else {
            AbstractInsnNode abstractInsnNode;
            this.last.next = abstractInsnNode = insnList.first;
            abstractInsnNode.prev = this.last;
            this.last = insnList.last;
        }
        this.cache = null;
        insnList.removeAll(false);
    }

    public void insert(AbstractInsnNode abstractInsnNode) {
        ++this.size;
        if (InsnList.lIlllIllIl(this.first)) {
            this.first = abstractInsnNode;
            this.last = abstractInsnNode;
            "".length();
            if (" ".length() < 0) {
                return;
            }
        } else {
            this.first.prev = abstractInsnNode;
            abstractInsnNode.next = this.first;
        }
        this.first = abstractInsnNode;
        this.cache = null;
        abstractInsnNode.index = 0;
    }

    public void insert(InsnList insnList) {
        if (InsnList.lIllllIIII(insnList.size)) {
            return;
        }
        this.size += insnList.size;
        if (InsnList.lIlllIllIl(this.first)) {
            this.first = insnList.first;
            this.last = insnList.last;
            "".length();
            if (-"   ".length() > 0) {
                return;
            }
        } else {
            AbstractInsnNode abstractInsnNode;
            this.first.prev = abstractInsnNode = insnList.last;
            abstractInsnNode.next = this.first;
            this.first = insnList.first;
        }
        this.cache = null;
        insnList.removeAll(false);
    }

    public void insert(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        ++this.size;
        AbstractInsnNode abstractInsnNode3 = abstractInsnNode.next;
        if (InsnList.lIlllIllIl(abstractInsnNode3)) {
            this.last = abstractInsnNode2;
            "".length();
            if (((0x51 ^ 0x5F) & ~(0x14 ^ 0x1A)) <= -" ".length()) {
                return;
            }
        } else {
            abstractInsnNode3.prev = abstractInsnNode2;
        }
        abstractInsnNode.next = abstractInsnNode2;
        abstractInsnNode2.next = abstractInsnNode3;
        abstractInsnNode2.prev = abstractInsnNode;
        this.cache = null;
        abstractInsnNode2.index = 0;
    }

    public void insert(AbstractInsnNode abstractInsnNode, InsnList insnList) {
        if (InsnList.lIllllIIII(insnList.size)) {
            return;
        }
        this.size += insnList.size;
        AbstractInsnNode abstractInsnNode2 = insnList.first;
        AbstractInsnNode abstractInsnNode3 = insnList.last;
        AbstractInsnNode abstractInsnNode4 = abstractInsnNode.next;
        if (InsnList.lIlllIllIl(abstractInsnNode4)) {
            this.last = abstractInsnNode3;
            "".length();
            if (((0x7B ^ 0x41) & ~(0x4B ^ 0x71) & ~((0x91 ^ 0xB2) & ~(0xE4 ^ 0xC7))) > 0) {
                return;
            }
        } else {
            abstractInsnNode4.prev = abstractInsnNode3;
        }
        abstractInsnNode.next = abstractInsnNode2;
        abstractInsnNode3.next = abstractInsnNode4;
        abstractInsnNode2.prev = abstractInsnNode;
        this.cache = null;
        insnList.removeAll(false);
    }

    public void insertBefore(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        ++this.size;
        AbstractInsnNode abstractInsnNode3 = abstractInsnNode.prev;
        if (InsnList.lIlllIllIl(abstractInsnNode3)) {
            this.first = abstractInsnNode2;
            "".length();
            if (((0x68 ^ 0x58 ^ (0xAA ^ 0x97)) & (0xD8 ^ 0x87 ^ (0xF3 ^ 0xA1) ^ -" ".length())) <= -" ".length()) {
                return;
            }
        } else {
            abstractInsnNode3.next = abstractInsnNode2;
        }
        abstractInsnNode.prev = abstractInsnNode2;
        abstractInsnNode2.next = abstractInsnNode;
        abstractInsnNode2.prev = abstractInsnNode3;
        this.cache = null;
        abstractInsnNode2.index = 0;
    }

    public void insertBefore(AbstractInsnNode abstractInsnNode, InsnList insnList) {
        if (InsnList.lIllllIIII(insnList.size)) {
            return;
        }
        this.size += insnList.size;
        AbstractInsnNode abstractInsnNode2 = insnList.first;
        AbstractInsnNode abstractInsnNode3 = insnList.last;
        AbstractInsnNode abstractInsnNode4 = abstractInsnNode.prev;
        if (InsnList.lIlllIllIl(abstractInsnNode4)) {
            this.first = abstractInsnNode2;
            "".length();
            if (((0x79 ^ 0x69) & ~(0x94 ^ 0x84)) > "  ".length()) {
                return;
            }
        } else {
            abstractInsnNode4.next = abstractInsnNode2;
        }
        abstractInsnNode.prev = abstractInsnNode3;
        abstractInsnNode3.next = abstractInsnNode;
        abstractInsnNode2.prev = abstractInsnNode4;
        this.cache = null;
        insnList.removeAll(false);
    }

    public void remove(AbstractInsnNode abstractInsnNode) {
        --this.size;
        AbstractInsnNode abstractInsnNode2 = abstractInsnNode.next;
        AbstractInsnNode abstractInsnNode3 = abstractInsnNode.prev;
        if (InsnList.lIlllIllIl(abstractInsnNode2)) {
            if (InsnList.lIlllIllIl(abstractInsnNode3)) {
                this.first = null;
                this.last = null;
                "".length();
                if (-"  ".length() > 0) {
                    return;
                }
            } else {
                abstractInsnNode3.next = null;
                this.last = abstractInsnNode3;
                "".length();
                if (null != null) {
                    return;
                }
            }
        } else if (InsnList.lIlllIllIl(abstractInsnNode3)) {
            this.first = abstractInsnNode2;
            abstractInsnNode2.prev = null;
            "".length();
            if (-(40 + 60 - -34 + 21 ^ 69 + 131 - 56 + 15) >= 0) {
                return;
            }
        } else {
            abstractInsnNode3.next = abstractInsnNode2;
            abstractInsnNode2.prev = abstractInsnNode3;
        }
        this.cache = null;
        abstractInsnNode.index = -1;
        abstractInsnNode.prev = null;
        abstractInsnNode.next = null;
    }

    void removeAll(boolean bl) {
        if (InsnList.lIllllIIIl(bl ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = this.first;
            while (InsnList.lIlllIlllI(abstractInsnNode)) {
                AbstractInsnNode abstractInsnNode2 = abstractInsnNode.next;
                abstractInsnNode.index = -1;
                abstractInsnNode.prev = null;
                abstractInsnNode.next = null;
                abstractInsnNode = abstractInsnNode2;
                "".length();
                if (" ".length() >= 0) continue;
                return;
            }
        }
        this.size = 0;
        this.first = null;
        this.last = null;
        this.cache = null;
    }

    public void clear() {
        this.removeAll(false);
    }

    public void resetLabels() {
        AbstractInsnNode abstractInsnNode = this.first;
        while (InsnList.lIlllIlllI(abstractInsnNode)) {
            if (InsnList.lIllllIIIl(abstractInsnNode instanceof LabelNode)) {
                ((LabelNode)abstractInsnNode).resetLabel();
            }
            abstractInsnNode = abstractInsnNode.next;
            "".length();
            if (" ".length() >= 0) continue;
            return;
        }
    }

    private static boolean lIlllIllII(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIlllIllll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIlllIlllI(Object object) {
        return object != null;
    }

    private static boolean lIlllIllIl(Object object) {
        return object == null;
    }

    private static boolean lIllllIIIl(int n) {
        return n != 0;
    }

    private static boolean lIllllIIII(int n) {
        return n == 0;
    }

    private static boolean lIlllIlIll(int n) {
        return n >= 0;
    }
}

