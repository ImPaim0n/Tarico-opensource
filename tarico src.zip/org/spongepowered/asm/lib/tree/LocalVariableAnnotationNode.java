/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.TypeAnnotationNode;

public class LocalVariableAnnotationNode
extends TypeAnnotationNode {
    public List<LabelNode> start;
    public List<LabelNode> end;
    public List<Integer> index;

    public LocalVariableAnnotationNode(int n, TypePath typePath, LabelNode[] labelNodeArray, LabelNode[] labelNodeArray2, int[] nArray, String string) {
        this(327680, n, typePath, labelNodeArray, labelNodeArray2, nArray, string);
    }

    public LocalVariableAnnotationNode(int n, int n2, TypePath typePath, LabelNode[] labelNodeArray, LabelNode[] labelNodeArray2, int[] nArray, String string) {
        super(n, n2, typePath, string);
        this.start = new ArrayList<LabelNode>(labelNodeArray.length);
        this.start.addAll(Arrays.asList(labelNodeArray));
        "".length();
        this.end = new ArrayList<LabelNode>(labelNodeArray2.length);
        this.end.addAll(Arrays.asList(labelNodeArray2));
        "".length();
        this.index = new ArrayList<Integer>(nArray.length);
        int[] nArray2 = nArray;
        int n3 = nArray2.length;
        int n4 = 0;
        while (LocalVariableAnnotationNode.lIIlIllIl(n4, n3)) {
            int n5 = nArray2[n4];
            this.index.add(n5);
            "".length();
            ++n4;
            "".length();
            if ("   ".length() != 0) continue;
            throw null;
        }
    }

    public void accept(MethodVisitor methodVisitor, boolean bl) {
        Label[] labelArray = new Label[this.start.size()];
        Label[] labelArray2 = new Label[this.end.size()];
        int[] nArray = new int[this.index.size()];
        int n = 0;
        while (LocalVariableAnnotationNode.lIIlIllIl(n, labelArray.length)) {
            labelArray[n] = this.start.get(n).getLabel();
            labelArray2[n] = this.end.get(n).getLabel();
            nArray[n] = this.index.get(n);
            ++n;
            "".length();
            if (" ".length() <= (0x30 ^ 0x3A ^ (0x9A ^ 0x94))) continue;
            return;
        }
        this.accept(methodVisitor.visitLocalVariableAnnotation(this.typeRef, this.typePath, labelArray, labelArray2, nArray, this.desc, true));
    }

    private static boolean lIIlIllIl(int n, int n2) {
        return n < n2;
    }
}

