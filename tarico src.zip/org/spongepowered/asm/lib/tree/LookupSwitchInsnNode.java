/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class LookupSwitchInsnNode
extends AbstractInsnNode {
    public LabelNode dflt;
    public List<Integer> keys;
    public List<LabelNode> labels;

    public LookupSwitchInsnNode(LabelNode labelNode, int[] nArray, LabelNode[] labelNodeArray) {
        super(171);
        int n;
        int n2;
        this.dflt = labelNode;
        if (LookupSwitchInsnNode.lllIlIIllIl(nArray)) {
            n2 = 0;
            "".length();
            if ("   ".length() < ((7 + 98 - 82 + 203 ^ 2 + 26 - 24 + 159) & (0x26 ^ 0x7B ^ (0x59 ^ 0x45) ^ -" ".length()))) {
                throw null;
            }
        } else {
            n2 = nArray.length;
        }
        this.keys = new ArrayList<Integer>(n2);
        if (LookupSwitchInsnNode.lllIlIIllIl(labelNodeArray)) {
            n = 0;
            "".length();
            if ((0x9F ^ 0x9B) < -" ".length()) {
                throw null;
            }
        } else {
            n = labelNodeArray.length;
        }
        this.labels = new ArrayList<LabelNode>(n);
        if (LookupSwitchInsnNode.lllIlIIllll(nArray)) {
            int n3 = 0;
            while (LookupSwitchInsnNode.lllIlIlIIII(n3, nArray.length)) {
                this.keys.add(nArray[n3]);
                "".length();
                ++n3;
                "".length();
                if (null == null) continue;
                throw null;
            }
        }
        if (LookupSwitchInsnNode.lllIlIIllll(labelNodeArray)) {
            this.labels.addAll(Arrays.asList(labelNodeArray));
            "".length();
        }
    }

    @Override
    public int getType() {
        return 12;
    }

    @Override
    public void accept(MethodVisitor methodVisitor) {
        int[] nArray = new int[this.keys.size()];
        int n = 0;
        while (LookupSwitchInsnNode.lllIlIlIIII(n, nArray.length)) {
            nArray[n] = this.keys.get(n);
            ++n;
            "".length();
            if (null == null) continue;
            return;
        }
        Label[] labelArray = new Label[this.labels.size()];
        int n2 = 0;
        while (LookupSwitchInsnNode.lllIlIlIIII(n2, labelArray.length)) {
            labelArray[n2] = this.labels.get(n2).getLabel();
            ++n2;
            "".length();
            if (-((0xF ^ 0x3B) & ~(0xF7 ^ 0xC3) ^ (8 ^ 0xD)) < 0) continue;
            return;
        }
        methodVisitor.visitLookupSwitchInsn(this.dflt.getLabel(), nArray, labelArray);
        this.acceptAnnotations(methodVisitor);
    }

    @Override
    public AbstractInsnNode clone(Map<LabelNode, LabelNode> map) {
        LookupSwitchInsnNode lookupSwitchInsnNode = new LookupSwitchInsnNode(LookupSwitchInsnNode.clone(this.dflt, map), null, LookupSwitchInsnNode.clone(this.labels, map));
        lookupSwitchInsnNode.keys.addAll(this.keys);
        "".length();
        return lookupSwitchInsnNode.cloneAnnotations(this);
    }

    private static boolean lllIlIlIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIlIIllll(Object object) {
        return object != null;
    }

    private static boolean lllIlIIllIl(Object object) {
        return object == null;
    }
}

