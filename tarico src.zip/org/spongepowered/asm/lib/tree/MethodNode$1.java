/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import org.spongepowered.asm.lib.tree.MethodNode;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
class MethodNode$1
extends ArrayList<Object> {
    final /* synthetic */ MethodNode this$0;

    MethodNode$1(MethodNode methodNode, int n) {
        this.this$0 = methodNode;
        super(n);
    }

    @Override
    public boolean add(Object object) {
        this.this$0.annotationDefault = object;
        return super.add(object);
    }
}

