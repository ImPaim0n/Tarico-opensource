/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.FrameNode;
import org.spongepowered.asm.lib.tree.IincInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.IntInsnNode;
import org.spongepowered.asm.lib.tree.InvokeDynamicInsnNode;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.LdcInsnNode;
import org.spongepowered.asm.lib.tree.LineNumberNode;
import org.spongepowered.asm.lib.tree.LocalVariableAnnotationNode;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.lib.tree.LookupSwitchInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode$1;
import org.spongepowered.asm.lib.tree.MultiANewArrayInsnNode;
import org.spongepowered.asm.lib.tree.ParameterNode;
import org.spongepowered.asm.lib.tree.TableSwitchInsnNode;
import org.spongepowered.asm.lib.tree.TryCatchBlockNode;
import org.spongepowered.asm.lib.tree.TypeAnnotationNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;

public class MethodNode
extends MethodVisitor {
    public int access;
    public String name;
    public String desc;
    public String signature;
    public List<String> exceptions;
    public List<ParameterNode> parameters;
    public List<AnnotationNode> visibleAnnotations;
    public List<AnnotationNode> invisibleAnnotations;
    public List<TypeAnnotationNode> visibleTypeAnnotations;
    public List<TypeAnnotationNode> invisibleTypeAnnotations;
    public List<Attribute> attrs;
    public Object annotationDefault;
    public List<AnnotationNode>[] visibleParameterAnnotations;
    public List<AnnotationNode>[] invisibleParameterAnnotations;
    public InsnList instructions;
    public List<TryCatchBlockNode> tryCatchBlocks;
    public int maxStack;
    public int maxLocals;
    public List<LocalVariableNode> localVariables;
    public List<LocalVariableAnnotationNode> visibleLocalVariableAnnotations;
    public List<LocalVariableAnnotationNode> invisibleLocalVariableAnnotations;
    private boolean visited;

    public MethodNode() {
        this(327680);
        if (MethodNode.llIIIlIllll(this.getClass(), MethodNode.class)) {
            throw new IllegalStateException();
        }
    }

    public MethodNode(int n) {
        super(n);
        this.instructions = new InsnList();
    }

    public MethodNode(int n, String string, String string2, String string3, String[] stringArray) {
        this(327680, n, string, string2, string3, stringArray);
        if (MethodNode.llIIIlIllll(this.getClass(), MethodNode.class)) {
            throw new IllegalStateException();
        }
    }

    public MethodNode(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        super(n);
        int n3;
        int n4;
        int n5;
        this.access = n2;
        this.name = string;
        this.desc = string2;
        this.signature = string3;
        if (MethodNode.llIIIllIIII(stringArray)) {
            n5 = 0;
            "".length();
            if (null != null) {
                throw null;
            }
        } else {
            n5 = stringArray.length;
        }
        this.exceptions = new ArrayList<String>(n5);
        if (MethodNode.llIIIllIIIl(n2 & 0x400)) {
            n4 = 1;
            "".length();
            if ("   ".length() <= 0) {
                throw null;
            }
        } else {
            n4 = 0;
        }
        if (MethodNode.llIIIllIIlI(n3 = n4)) {
            this.localVariables = new ArrayList<LocalVariableNode>(5);
        }
        this.tryCatchBlocks = new ArrayList<TryCatchBlockNode>();
        if (MethodNode.llIIIllIIll(stringArray)) {
            this.exceptions.addAll(Arrays.asList(stringArray));
            "".length();
        }
        this.instructions = new InsnList();
    }

    public void visitParameter(String string, int n) {
        if (MethodNode.llIIIllIIII(this.parameters)) {
            this.parameters = new ArrayList<ParameterNode>(5);
        }
        this.parameters.add(new ParameterNode(string, n));
        "".length();
    }

    public AnnotationVisitor visitAnnotationDefault() {
        return new AnnotationNode(new MethodNode$1(this, 0));
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationNode annotationNode = new AnnotationNode(string);
        if (MethodNode.llIIIllIIIl(bl ? 1 : 0)) {
            if (MethodNode.llIIIllIIII(this.visibleAnnotations)) {
                this.visibleAnnotations = new ArrayList<AnnotationNode>(1);
            }
            this.visibleAnnotations.add(annotationNode);
            "".length();
            "".length();
            if ((0x58 ^ 0x30 ^ (0xC8 ^ 0xA4)) == -" ".length()) {
                return null;
            }
        } else {
            if (MethodNode.llIIIllIIII(this.invisibleAnnotations)) {
                this.invisibleAnnotations = new ArrayList<AnnotationNode>(1);
            }
            this.invisibleAnnotations.add(annotationNode);
            "".length();
        }
        return annotationNode;
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        TypeAnnotationNode typeAnnotationNode = new TypeAnnotationNode(n, typePath, string);
        if (MethodNode.llIIIllIIIl(bl ? 1 : 0)) {
            if (MethodNode.llIIIllIIII(this.visibleTypeAnnotations)) {
                this.visibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            this.visibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
            "".length();
            if (((0x8A ^ 0xC5) & ~(0x39 ^ 0x76)) > (0x55 ^ 0x51)) {
                return null;
            }
        } else {
            if (MethodNode.llIIIllIIII(this.invisibleTypeAnnotations)) {
                this.invisibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            this.invisibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
        }
        return typeAnnotationNode;
    }

    public AnnotationVisitor visitParameterAnnotation(int n, String string, boolean bl) {
        AnnotationNode annotationNode = new AnnotationNode(string);
        if (MethodNode.llIIIllIIIl(bl ? 1 : 0)) {
            if (MethodNode.llIIIllIIII(this.visibleParameterAnnotations)) {
                int n2 = Type.getArgumentTypes(this.desc).length;
                this.visibleParameterAnnotations = new List[n2];
            }
            if (MethodNode.llIIIllIIII(this.visibleParameterAnnotations[n])) {
                this.visibleParameterAnnotations[n] = new ArrayList<AnnotationNode>(1);
            }
            this.visibleParameterAnnotations[n].add(annotationNode);
            "".length();
            "".length();
            if ((0x57 ^ 0x52) <= 0) {
                return null;
            }
        } else {
            if (MethodNode.llIIIllIIII(this.invisibleParameterAnnotations)) {
                int n3 = Type.getArgumentTypes(this.desc).length;
                this.invisibleParameterAnnotations = new List[n3];
            }
            if (MethodNode.llIIIllIIII(this.invisibleParameterAnnotations[n])) {
                this.invisibleParameterAnnotations[n] = new ArrayList<AnnotationNode>(1);
            }
            this.invisibleParameterAnnotations[n].add(annotationNode);
            "".length();
        }
        return annotationNode;
    }

    public void visitAttribute(Attribute attribute) {
        if (MethodNode.llIIIllIIII(this.attrs)) {
            this.attrs = new ArrayList<Attribute>(1);
        }
        this.attrs.add(attribute);
        "".length();
    }

    public void visitCode() {
    }

    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        Object[] objectArray3;
        Object[] objectArray4;
        if (MethodNode.llIIIllIIII(objectArray)) {
            objectArray4 = null;
            "".length();
            if ("   ".length() != "   ".length()) {
                return;
            }
        } else {
            objectArray4 = this.getLabelNodes(objectArray);
        }
        if (MethodNode.llIIIllIIII(objectArray2)) {
            objectArray3 = null;
            "".length();
            if (-" ".length() > (0x6D ^ 0x69)) {
                return;
            }
        } else {
            objectArray3 = this.getLabelNodes(objectArray2);
        }
        this.instructions.add(new FrameNode(n, n2, objectArray4, n3, objectArray3));
    }

    public void visitInsn(int n) {
        this.instructions.add(new InsnNode(n));
    }

    public void visitIntInsn(int n, int n2) {
        this.instructions.add(new IntInsnNode(n, n2));
    }

    public void visitVarInsn(int n, int n2) {
        this.instructions.add(new VarInsnNode(n, n2));
    }

    public void visitTypeInsn(int n, String string) {
        this.instructions.add(new TypeInsnNode(n, string));
    }

    public void visitFieldInsn(int n, String string, String string2, String string3) {
        this.instructions.add(new FieldInsnNode(n, string, string2, string3));
    }

    @Deprecated
    public void visitMethodInsn(int n, String string, String string2, String string3) {
        if (MethodNode.llIIIllIlII(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3);
            return;
        }
        this.instructions.add(new MethodInsnNode(n, string, string2, string3));
    }

    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (MethodNode.llIIIllIlIl(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3, bl);
            return;
        }
        this.instructions.add(new MethodInsnNode(n, string, string2, string3, bl));
    }

    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        this.instructions.add(new InvokeDynamicInsnNode(string, string2, handle, objectArray));
    }

    public void visitJumpInsn(int n, Label label) {
        this.instructions.add(new JumpInsnNode(n, this.getLabelNode(label)));
    }

    public void visitLabel(Label label) {
        this.instructions.add(this.getLabelNode(label));
    }

    public void visitLdcInsn(Object object) {
        this.instructions.add(new LdcInsnNode(object));
    }

    public void visitIincInsn(int n, int n2) {
        this.instructions.add(new IincInsnNode(n, n2));
    }

    public void visitTableSwitchInsn(int n, int n2, Label label, Label ... labelArray) {
        this.instructions.add(new TableSwitchInsnNode(n, n2, this.getLabelNode(label), this.getLabelNodes(labelArray)));
    }

    public void visitLookupSwitchInsn(Label label, int[] nArray, Label[] labelArray) {
        this.instructions.add(new LookupSwitchInsnNode(this.getLabelNode(label), nArray, this.getLabelNodes(labelArray)));
    }

    public void visitMultiANewArrayInsn(String string, int n) {
        this.instructions.add(new MultiANewArrayInsnNode(string, n));
    }

    public AnnotationVisitor visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AbstractInsnNode abstractInsnNode = this.instructions.getLast();
        while (MethodNode.llIIIllIllI(abstractInsnNode.getOpcode(), -1)) {
            abstractInsnNode = abstractInsnNode.getPrevious();
            "".length();
            if (" ".length() <= (0xA3 ^ 0x95 ^ (0xF3 ^ 0xC1))) continue;
            return null;
        }
        TypeAnnotationNode typeAnnotationNode = new TypeAnnotationNode(n, typePath, string);
        if (MethodNode.llIIIllIIIl(bl ? 1 : 0)) {
            if (MethodNode.llIIIllIIII(abstractInsnNode.visibleTypeAnnotations)) {
                abstractInsnNode.visibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            abstractInsnNode.visibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
            "".length();
            if (((0xE ^ 0x20 ^ (0xA6 ^ 0x87)) & (0xA3 ^ 0x9F ^ (0x79 ^ 0x4A) ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            if (MethodNode.llIIIllIIII(abstractInsnNode.invisibleTypeAnnotations)) {
                abstractInsnNode.invisibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            abstractInsnNode.invisibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
        }
        return typeAnnotationNode;
    }

    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        this.tryCatchBlocks.add(new TryCatchBlockNode(this.getLabelNode(label), this.getLabelNode(label2), this.getLabelNode(label3), string));
        "".length();
    }

    public AnnotationVisitor visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        TryCatchBlockNode tryCatchBlockNode = this.tryCatchBlocks.get((n & 0xFFFF00) >> 8);
        TypeAnnotationNode typeAnnotationNode = new TypeAnnotationNode(n, typePath, string);
        if (MethodNode.llIIIllIIIl(bl ? 1 : 0)) {
            if (MethodNode.llIIIllIIII(tryCatchBlockNode.visibleTypeAnnotations)) {
                tryCatchBlockNode.visibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            tryCatchBlockNode.visibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
            "".length();
            if (-(77 + 127 - 39 + 2 ^ 158 + 96 - 121 + 30) > 0) {
                return null;
            }
        } else {
            if (MethodNode.llIIIllIIII(tryCatchBlockNode.invisibleTypeAnnotations)) {
                tryCatchBlockNode.invisibleTypeAnnotations = new ArrayList<TypeAnnotationNode>(1);
            }
            tryCatchBlockNode.invisibleTypeAnnotations.add(typeAnnotationNode);
            "".length();
        }
        return typeAnnotationNode;
    }

    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        this.localVariables.add(new LocalVariableNode(string, string2, string3, this.getLabelNode(label), this.getLabelNode(label2), n));
        "".length();
    }

    public AnnotationVisitor visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        LocalVariableAnnotationNode localVariableAnnotationNode = new LocalVariableAnnotationNode(n, typePath, this.getLabelNodes(labelArray), this.getLabelNodes(labelArray2), nArray, string);
        if (MethodNode.llIIIllIIIl(bl ? 1 : 0)) {
            if (MethodNode.llIIIllIIII(this.visibleLocalVariableAnnotations)) {
                this.visibleLocalVariableAnnotations = new ArrayList<LocalVariableAnnotationNode>(1);
            }
            this.visibleLocalVariableAnnotations.add(localVariableAnnotationNode);
            "".length();
            "".length();
            if (-" ".length() >= 0) {
                return null;
            }
        } else {
            if (MethodNode.llIIIllIIII(this.invisibleLocalVariableAnnotations)) {
                this.invisibleLocalVariableAnnotations = new ArrayList<LocalVariableAnnotationNode>(1);
            }
            this.invisibleLocalVariableAnnotations.add(localVariableAnnotationNode);
            "".length();
        }
        return localVariableAnnotationNode;
    }

    public void visitLineNumber(int n, Label label) {
        this.instructions.add(new LineNumberNode(n, this.getLabelNode(label)));
    }

    public void visitMaxs(int n, int n2) {
        this.maxStack = n;
        this.maxLocals = n2;
    }

    public void visitEnd() {
    }

    protected LabelNode getLabelNode(Label label) {
        if (MethodNode.llIIIllIIlI(label.info instanceof LabelNode)) {
            label.info = new LabelNode();
        }
        return (LabelNode)label.info;
    }

    private LabelNode[] getLabelNodes(Label[] labelArray) {
        LabelNode[] labelNodeArray = new LabelNode[labelArray.length];
        int n = 0;
        while (MethodNode.llIIIllIlIl(n, labelArray.length)) {
            labelNodeArray[n] = this.getLabelNode(labelArray[n]);
            ++n;
            "".length();
            if (((153 + 123 - 103 + 5 ^ 141 + 137 - 173 + 77) & (0xBC ^ 0x84 ^ (0xBD ^ 0x81) ^ -" ".length())) <= (0xBA ^ 0x82 ^ (0x87 ^ 0xBB))) continue;
            return null;
        }
        return labelNodeArray;
    }

    private Object[] getLabelNodes(Object[] objectArray) {
        Object[] objectArray2 = new Object[objectArray.length];
        int n = 0;
        while (MethodNode.llIIIllIlIl(n, objectArray.length)) {
            Object object = objectArray[n];
            if (MethodNode.llIIIllIIIl(object instanceof Label)) {
                object = this.getLabelNode((Label)object);
            }
            objectArray2[n] = object;
            ++n;
            "".length();
            if (((0xD5 ^ 0x91 ^ (0 ^ 0x1A)) & (0xB7 ^ 0x86 ^ (0x40 ^ 0x2F) ^ -" ".length())) == 0) continue;
            return null;
        }
        return objectArray2;
    }

    public void check(int n) {
        if (MethodNode.llIIIllIllI(n, 262144)) {
            Object object;
            int n2;
            if (MethodNode.llIIIllIIll(this.visibleTypeAnnotations) && MethodNode.llIIIllIlll(this.visibleTypeAnnotations.size())) {
                throw new RuntimeException();
            }
            if (MethodNode.llIIIllIIll(this.invisibleTypeAnnotations) && MethodNode.llIIIllIlll(this.invisibleTypeAnnotations.size())) {
                throw new RuntimeException();
            }
            if (MethodNode.llIIIllIIII(this.tryCatchBlocks)) {
                n2 = 0;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n2 = this.tryCatchBlocks.size();
            }
            int n3 = n2;
            int n4 = 0;
            while (MethodNode.llIIIllIlIl(n4, n3)) {
                object = this.tryCatchBlocks.get(n4);
                if (MethodNode.llIIIllIIll(((TryCatchBlockNode)object).visibleTypeAnnotations) && MethodNode.llIIIllIlll(((TryCatchBlockNode)object).visibleTypeAnnotations.size())) {
                    throw new RuntimeException();
                }
                if (MethodNode.llIIIllIIll(((TryCatchBlockNode)object).invisibleTypeAnnotations) && MethodNode.llIIIllIlll(((TryCatchBlockNode)object).invisibleTypeAnnotations.size())) {
                    throw new RuntimeException();
                }
                ++n4;
                "".length();
                if (((0x89 ^ 0x9C) & ~(0x2C ^ 0x39)) != " ".length()) continue;
                return;
            }
            n4 = 0;
            while (MethodNode.llIIIllIlIl(n4, this.instructions.size())) {
                object = this.instructions.get(n4);
                if (MethodNode.llIIIllIIll(((AbstractInsnNode)object).visibleTypeAnnotations) && MethodNode.llIIIllIlll(((AbstractInsnNode)object).visibleTypeAnnotations.size())) {
                    throw new RuntimeException();
                }
                if (MethodNode.llIIIllIIll(((AbstractInsnNode)object).invisibleTypeAnnotations) && MethodNode.llIIIllIlll(((AbstractInsnNode)object).invisibleTypeAnnotations.size())) {
                    throw new RuntimeException();
                }
                if (MethodNode.llIIIllIIIl(object instanceof MethodInsnNode)) {
                    int n5;
                    int n6 = ((MethodInsnNode)object).itf;
                    if (MethodNode.llIIIllIllI(((AbstractInsnNode)object).opcode, 185)) {
                        n5 = 1;
                        "".length();
                        if ((0xB9 ^ 0xBD) < 0) {
                            return;
                        }
                    } else {
                        n5 = 0;
                    }
                    if (MethodNode.llIIIlllIII(n6, n5)) {
                        throw new RuntimeException();
                    }
                }
                ++n4;
                "".length();
                if (null == null) continue;
                return;
            }
            if (MethodNode.llIIIllIIll(this.visibleLocalVariableAnnotations) && MethodNode.llIIIllIlll(this.visibleLocalVariableAnnotations.size())) {
                throw new RuntimeException();
            }
            if (MethodNode.llIIIllIIll(this.invisibleLocalVariableAnnotations) && MethodNode.llIIIllIlll(this.invisibleLocalVariableAnnotations.size())) {
                throw new RuntimeException();
            }
        }
    }

    public void accept(ClassVisitor classVisitor) {
        String[] stringArray = new String[this.exceptions.size()];
        this.exceptions.toArray(stringArray);
        "".length();
        MethodVisitor methodVisitor = classVisitor.visitMethod(this.access, this.name, this.desc, this.signature, stringArray);
        if (MethodNode.llIIIllIIll(methodVisitor)) {
            this.accept(methodVisitor);
        }
    }

    public void accept(MethodVisitor methodVisitor) {
        int n;
        int n2;
        AnnotationNode annotationNode;
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        List<AnnotationNode> list;
        int n9;
        if (MethodNode.llIIIllIIII(this.parameters)) {
            n9 = 0;
            "".length();
            if (((0x42 ^ 0x53) & ~(0x8D ^ 0x9C)) != 0) {
                return;
            }
        } else {
            n9 = this.parameters.size();
        }
        int n10 = n9;
        int n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.parameters.get(n11);
            methodVisitor.visitParameter(((ParameterNode)((Object)list)).name, ((ParameterNode)((Object)list)).access);
            ++n11;
            "".length();
            if (((0xEC ^ 0xA2 ^ (0xA ^ 0xD)) & (0x56 ^ 0x11 ^ (0x12 ^ 0x1C) ^ -" ".length())) <= " ".length()) continue;
            return;
        }
        if (MethodNode.llIIIllIIll(this.annotationDefault)) {
            list = methodVisitor.visitAnnotationDefault();
            AnnotationNode.accept((AnnotationVisitor)((Object)list), null, this.annotationDefault);
            if (MethodNode.llIIIllIIll(list)) {
                ((AnnotationVisitor)((Object)list)).visitEnd();
            }
        }
        if (MethodNode.llIIIllIIII(this.visibleAnnotations)) {
            n8 = 0;
            "".length();
            if (-(0x16 ^ 0x36 ^ (0xF ^ 0x2A)) >= 0) {
                return;
            }
        } else {
            n8 = this.visibleAnnotations.size();
        }
        n10 = n8;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.visibleAnnotations.get(n11);
            ((AnnotationNode)((Object)list)).accept(methodVisitor.visitAnnotation(((AnnotationNode)((Object)list)).desc, true));
            ++n11;
            "".length();
            if (null == null) continue;
            return;
        }
        if (MethodNode.llIIIllIIII(this.invisibleAnnotations)) {
            n7 = 0;
            "".length();
            if (((6 + 13 - -110 + 24 ^ 122 + 57 - 71 + 34) & (139 + 120 - 202 + 152 ^ 127 + 190 - 139 + 20 ^ -" ".length())) > " ".length()) {
                return;
            }
        } else {
            n7 = this.invisibleAnnotations.size();
        }
        n10 = n7;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.invisibleAnnotations.get(n11);
            ((AnnotationNode)((Object)list)).accept(methodVisitor.visitAnnotation(((AnnotationNode)((Object)list)).desc, false));
            ++n11;
            "".length();
            if (((0x21 ^ 0x66 ^ (0x4B ^ 0x27)) & (0x44 ^ 0x2A ^ (0xE5 ^ 0xA0) ^ -" ".length())) == 0) continue;
            return;
        }
        if (MethodNode.llIIIllIIII(this.visibleTypeAnnotations)) {
            n6 = 0;
            "".length();
            if (" ".length() == (0xC8 ^ 0xBB ^ (0xE8 ^ 0x9F))) {
                return;
            }
        } else {
            n6 = this.visibleTypeAnnotations.size();
        }
        n10 = n6;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.visibleTypeAnnotations.get(n11);
            ((AnnotationNode)((Object)list)).accept(methodVisitor.visitTypeAnnotation(((TypeAnnotationNode)((Object)list)).typeRef, ((TypeAnnotationNode)((Object)list)).typePath, ((TypeAnnotationNode)((Object)list)).desc, true));
            ++n11;
            "".length();
            if ((0x8B ^ 0x8F) > 0) continue;
            return;
        }
        if (MethodNode.llIIIllIIII(this.invisibleTypeAnnotations)) {
            n5 = 0;
            "".length();
            if ((0x48 ^ 0x4D) == 0) {
                return;
            }
        } else {
            n5 = this.invisibleTypeAnnotations.size();
        }
        n10 = n5;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.invisibleTypeAnnotations.get(n11);
            ((AnnotationNode)((Object)list)).accept(methodVisitor.visitTypeAnnotation(((TypeAnnotationNode)((Object)list)).typeRef, ((TypeAnnotationNode)((Object)list)).typePath, ((TypeAnnotationNode)((Object)list)).desc, false));
            ++n11;
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return;
        }
        if (MethodNode.llIIIllIIII(this.visibleParameterAnnotations)) {
            n4 = 0;
            "".length();
            if (-"  ".length() >= 0) {
                return;
            }
        } else {
            n4 = this.visibleParameterAnnotations.length;
        }
        n10 = n4;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.visibleParameterAnnotations[n11];
            if (MethodNode.llIIIllIIII(list)) {
                "".length();
                if (-"  ".length() > 0) {
                    return;
                }
            } else {
                n3 = 0;
                while (MethodNode.llIIIllIlIl(n3, list.size())) {
                    annotationNode = list.get(n3);
                    annotationNode.accept(methodVisitor.visitParameterAnnotation(n11, annotationNode.desc, true));
                    ++n3;
                    "".length();
                    if ("  ".length() != 0) continue;
                    return;
                }
            }
            ++n11;
            "".length();
            if ("  ".length() > -" ".length()) continue;
            return;
        }
        if (MethodNode.llIIIllIIII(this.invisibleParameterAnnotations)) {
            n2 = 0;
            "".length();
            if (-" ".length() != -" ".length()) {
                return;
            }
        } else {
            n2 = this.invisibleParameterAnnotations.length;
        }
        n10 = n2;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            list = this.invisibleParameterAnnotations[n11];
            if (MethodNode.llIIIllIIII(list)) {
                "".length();
                if (((0xFA ^ 0x82 ^ (0xF9 ^ 0x97)) & (0x7A ^ 0x6C ^ (0x53 ^ 0x67) & ~(0xAF ^ 0x9B) ^ -" ".length())) != 0) {
                    return;
                }
            } else {
                n3 = 0;
                while (MethodNode.llIIIllIlIl(n3, list.size())) {
                    annotationNode = list.get(n3);
                    annotationNode.accept(methodVisitor.visitParameterAnnotation(n11, annotationNode.desc, false));
                    ++n3;
                    "".length();
                    if (-"   ".length() <= 0) continue;
                    return;
                }
            }
            ++n11;
            "".length();
            if (((0x47 ^ 0x59) & ~(0x5C ^ 0x42)) >= -" ".length()) continue;
            return;
        }
        if (MethodNode.llIIIllIIIl(this.visited ? 1 : 0)) {
            this.instructions.resetLabels();
        }
        if (MethodNode.llIIIllIIII(this.attrs)) {
            n = 0;
            "".length();
            if ("   ".length() < 0) {
                return;
            }
        } else {
            n = this.attrs.size();
        }
        n10 = n;
        n11 = 0;
        while (MethodNode.llIIIllIlIl(n11, n10)) {
            methodVisitor.visitAttribute(this.attrs.get(n11));
            ++n11;
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
        if (MethodNode.llIIIllIlll(this.instructions.size())) {
            int n12;
            int n13;
            int n14;
            int n15;
            methodVisitor.visitCode();
            if (MethodNode.llIIIllIIII(this.tryCatchBlocks)) {
                n15 = 0;
                "".length();
                if ("   ".length() < -" ".length()) {
                    return;
                }
            } else {
                n15 = this.tryCatchBlocks.size();
            }
            n10 = n15;
            n11 = 0;
            while (MethodNode.llIIIllIlIl(n11, n10)) {
                this.tryCatchBlocks.get(n11).updateIndex(n11);
                this.tryCatchBlocks.get(n11).accept(methodVisitor);
                ++n11;
                "".length();
                if (" ".length() > -" ".length()) continue;
                return;
            }
            this.instructions.accept(methodVisitor);
            if (MethodNode.llIIIllIIII(this.localVariables)) {
                n14 = 0;
                "".length();
                if (((0x6E ^ 0x55 ^ (0xD4 ^ 0xC4)) & (76 + 39 - 107 + 124 ^ 42 + 121 - 111 + 123 ^ -" ".length())) > 0) {
                    return;
                }
            } else {
                n14 = this.localVariables.size();
            }
            n10 = n14;
            n11 = 0;
            while (MethodNode.llIIIllIlIl(n11, n10)) {
                this.localVariables.get(n11).accept(methodVisitor);
                ++n11;
                "".length();
                if ("  ".length() != 0) continue;
                return;
            }
            if (MethodNode.llIIIllIIII(this.visibleLocalVariableAnnotations)) {
                n13 = 0;
                "".length();
                if ("   ".length() < 0) {
                    return;
                }
            } else {
                n13 = this.visibleLocalVariableAnnotations.size();
            }
            n10 = n13;
            n11 = 0;
            while (MethodNode.llIIIllIlIl(n11, n10)) {
                this.visibleLocalVariableAnnotations.get(n11).accept(methodVisitor, true);
                ++n11;
                "".length();
                if (((0x4B ^ 0x72 ^ (0x60 ^ 0x12)) & (0x6E ^ 7 ^ (0x21 ^ 3) ^ -" ".length())) == 0) continue;
                return;
            }
            if (MethodNode.llIIIllIIII(this.invisibleLocalVariableAnnotations)) {
                n12 = 0;
                "".length();
                if (" ".length() < 0) {
                    return;
                }
            } else {
                n12 = this.invisibleLocalVariableAnnotations.size();
            }
            n10 = n12;
            n11 = 0;
            while (MethodNode.llIIIllIlIl(n11, n10)) {
                this.invisibleLocalVariableAnnotations.get(n11).accept(methodVisitor, false);
                ++n11;
                "".length();
                if (((0xCE ^ 0x9E) & ~(0x71 ^ 0x21)) <= ((0xF0 ^ 0x93) & ~(0x3F ^ 0x5C))) continue;
                return;
            }
            methodVisitor.visitMaxs(this.maxStack, this.maxLocals);
            this.visited = true;
        }
        methodVisitor.visitEnd();
    }

    private static boolean llIIIllIllI(int n, int n2) {
        return n == n2;
    }

    private static boolean llIIIllIlII(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIIIllIlIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIIIlIllll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIIIllIIll(Object object) {
        return object != null;
    }

    private static boolean llIIIllIIII(Object object) {
        return object == null;
    }

    private static boolean llIIIllIIIl(int n) {
        return n != 0;
    }

    private static boolean llIIIllIIlI(int n) {
        return n == 0;
    }

    private static boolean llIIIllIlll(int n) {
        return n > 0;
    }

    private static boolean llIIIlllIII(int n, int n2) {
        return n != n2;
    }
}

