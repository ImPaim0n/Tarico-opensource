/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class TableSwitchInsnNode
extends AbstractInsnNode {
    public int min;
    public int max;
    public LabelNode dflt;
    public List<LabelNode> labels;

    public TableSwitchInsnNode(int n, int n2, LabelNode labelNode, LabelNode ... labelNodeArray) {
        super(170);
        this.min = n;
        this.max = n2;
        this.dflt = labelNode;
        this.labels = new ArrayList<LabelNode>();
        if (TableSwitchInsnNode.lIIIIlIIIlI(labelNodeArray)) {
            this.labels.addAll(Arrays.asList(labelNodeArray));
            "".length();
        }
    }

    @Override
    public int getType() {
        return 11;
    }

    @Override
    public void accept(MethodVisitor methodVisitor) {
        Label[] labelArray = new Label[this.labels.size()];
        int n = 0;
        while (TableSwitchInsnNode.lIIIIlIIlII(n, labelArray.length)) {
            labelArray[n] = this.labels.get(n).getLabel();
            ++n;
            "".length();
            if ((0x3B ^ 0x68 ^ (0 ^ 0x57)) >= ((0x17 ^ 0x34 ^ (0xA4 ^ 0xAE)) & (0x1E ^ 0x2C ^ (0xA3 ^ 0xB8) ^ -" ".length()))) continue;
            return;
        }
        methodVisitor.visitTableSwitchInsn(this.min, this.max, this.dflt.getLabel(), labelArray);
        this.acceptAnnotations(methodVisitor);
    }

    @Override
    public AbstractInsnNode clone(Map<LabelNode, LabelNode> map) {
        return new TableSwitchInsnNode(this.min, this.max, TableSwitchInsnNode.clone(this.dflt, map), TableSwitchInsnNode.clone(this.labels, map)).cloneAnnotations(this);
    }

    private static boolean lIIIIlIIlII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIlIIIlI(Object object) {
        return object != null;
    }
}

