/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree;

import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.TypeAnnotationNode;

public class TryCatchBlockNode {
    public LabelNode start;
    public LabelNode end;
    public LabelNode handler;
    public String type;
    public List<TypeAnnotationNode> visibleTypeAnnotations;
    public List<TypeAnnotationNode> invisibleTypeAnnotations;

    public TryCatchBlockNode(LabelNode labelNode, LabelNode labelNode2, LabelNode labelNode3, String string) {
        this.start = labelNode;
        this.end = labelNode2;
        this.handler = labelNode3;
        this.type = string;
    }

    public void updateIndex(int n) {
        TypeAnnotationNode typeAnnotationNode;
        Iterator<TypeAnnotationNode> iterator;
        int n2 = 0x42000000 | n << 8;
        if (TryCatchBlockNode.lIlIlIIIlIl(this.visibleTypeAnnotations)) {
            iterator = this.visibleTypeAnnotations.iterator();
            while (TryCatchBlockNode.lIlIlIIIllI(iterator.hasNext() ? 1 : 0)) {
                typeAnnotationNode = iterator.next();
                typeAnnotationNode.typeRef = n2;
                "".length();
                if (null == null) continue;
                return;
            }
        }
        if (TryCatchBlockNode.lIlIlIIIlIl(this.invisibleTypeAnnotations)) {
            iterator = this.invisibleTypeAnnotations.iterator();
            while (TryCatchBlockNode.lIlIlIIIllI(iterator.hasNext() ? 1 : 0)) {
                typeAnnotationNode = iterator.next();
                typeAnnotationNode.typeRef = n2;
                "".length();
                if ((0x2F ^ 0x37 ^ (0x5F ^ 0x42)) > 0) continue;
                return;
            }
        }
    }

    public void accept(MethodVisitor methodVisitor) {
        int n;
        TypeAnnotationNode typeAnnotationNode;
        int n2;
        Label label;
        Label label2 = this.start.getLabel();
        Label label3 = this.end.getLabel();
        if (TryCatchBlockNode.lIlIlIIlIII(this.handler)) {
            label = null;
            "".length();
            if (((6 ^ 0x4C) & ~(0xF5 ^ 0xBF)) != 0) {
                return;
            }
        } else {
            label = this.handler.getLabel();
        }
        methodVisitor.visitTryCatchBlock(label2, label3, label, this.type);
        if (TryCatchBlockNode.lIlIlIIlIII(this.visibleTypeAnnotations)) {
            n2 = 0;
            "".length();
            if (-" ".length() == "  ".length()) {
                return;
            }
        } else {
            n2 = this.visibleTypeAnnotations.size();
        }
        int n3 = n2;
        int n4 = 0;
        while (TryCatchBlockNode.lIlIlIIlIIl(n4, n3)) {
            typeAnnotationNode = this.visibleTypeAnnotations.get(n4);
            typeAnnotationNode.accept(methodVisitor.visitTryCatchAnnotation(typeAnnotationNode.typeRef, typeAnnotationNode.typePath, typeAnnotationNode.desc, true));
            ++n4;
            "".length();
            if (((0xDC ^ 0xBD) & ~(0x71 ^ 0x10)) == 0) continue;
            return;
        }
        if (TryCatchBlockNode.lIlIlIIlIII(this.invisibleTypeAnnotations)) {
            n = 0;
            "".length();
            if ((0xA8 ^ 0xAD) <= 0) {
                return;
            }
        } else {
            n = this.invisibleTypeAnnotations.size();
        }
        n3 = n;
        n4 = 0;
        while (TryCatchBlockNode.lIlIlIIlIIl(n4, n3)) {
            typeAnnotationNode = this.invisibleTypeAnnotations.get(n4);
            typeAnnotationNode.accept(methodVisitor.visitTryCatchAnnotation(typeAnnotationNode.typeRef, typeAnnotationNode.typePath, typeAnnotationNode.desc, false));
            ++n4;
            "".length();
            if (null == null) continue;
            return;
        }
    }

    private static boolean lIlIlIIlIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIlIIIlIl(Object object) {
        return object != null;
    }

    private static boolean lIlIlIIlIII(Object object) {
        return object == null;
    }

    private static boolean lIlIlIIIllI(int n) {
        return n != 0;
    }
}

