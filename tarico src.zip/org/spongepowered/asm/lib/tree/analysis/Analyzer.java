/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.IincInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.LookupSwitchInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.TableSwitchInsnNode;
import org.spongepowered.asm.lib.tree.TryCatchBlockNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.lib.tree.analysis.AnalyzerException;
import org.spongepowered.asm.lib.tree.analysis.Frame;
import org.spongepowered.asm.lib.tree.analysis.Interpreter;
import org.spongepowered.asm.lib.tree.analysis.Subroutine;
import org.spongepowered.asm.lib.tree.analysis.Value;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class Analyzer<V extends Value>
implements Opcodes {
    private final Interpreter<V> interpreter;
    private int n;
    private InsnList insns;
    private List<TryCatchBlockNode>[] handlers;
    private Frame<V>[] frames;
    private Subroutine[] subroutines;
    private boolean[] queued;
    private int[] queue;
    private int top;

    public Analyzer(Interpreter<V> interpreter) {
        this.interpreter = interpreter;
    }

    public Frame<V>[] analyze(String string, MethodNode methodNode) {
        Type[] typeArray;
        Object object;
        if (Analyzer.lIIIIllllIlI(methodNode.access & 0x500)) {
            this.frames = new Frame[0];
            return this.frames;
        }
        this.n = methodNode.instructions.size();
        this.insns = methodNode.instructions;
        this.handlers = new List[this.n];
        this.frames = new Frame[this.n];
        this.subroutines = new Subroutine[this.n];
        this.queued = new boolean[this.n];
        this.queue = new int[this.n];
        this.top = 0;
        int n = 0;
        while (Analyzer.lIIIIllllIll(n, methodNode.tryCatchBlocks.size())) {
            object = methodNode.tryCatchBlocks.get(n);
            int n2 = this.insns.indexOf(((TryCatchBlockNode)object).start);
            int n3 = this.insns.indexOf(((TryCatchBlockNode)object).end);
            int n4 = n2;
            while (Analyzer.lIIIIllllIll(n4, n3)) {
                typeArray = this.handlers[n4];
                if (Analyzer.lIIIIlllllII(typeArray)) {
                    typeArray = new ArrayList<TryCatchBlockNode>();
                    this.handlers[n4] = typeArray;
                }
                typeArray.add((TryCatchBlockNode)object);
                "".length();
                ++n4;
                "".length();
                if (" ".length() >= 0) continue;
                return null;
            }
            ++n;
            "".length();
            if ("   ".length() <= "   ".length()) continue;
            return null;
        }
        Subroutine subroutine = new Subroutine(null, methodNode.maxLocals, null);
        object = new ArrayList();
        HashMap<LabelNode, Subroutine> hashMap = new HashMap<LabelNode, Subroutine>();
        this.findSubroutine(0, subroutine, (List<AbstractInsnNode>)object);
        while (Analyzer.lIIIIlllllIl(object.isEmpty() ? 1 : 0)) {
            JumpInsnNode jumpInsnNode = (JumpInsnNode)object.remove(0);
            Subroutine subroutine2 = (Subroutine)hashMap.get(jumpInsnNode.label);
            if (Analyzer.lIIIIlllllII(subroutine2)) {
                subroutine2 = new Subroutine(jumpInsnNode.label, methodNode.maxLocals, jumpInsnNode);
                hashMap.put(jumpInsnNode.label, subroutine2);
                "".length();
                this.findSubroutine(this.insns.indexOf(jumpInsnNode.label), subroutine2, (List<AbstractInsnNode>)object);
                "".length();
                if (" ".length() >= "   ".length()) {
                    return null;
                }
            } else {
                subroutine2.callers.add(jumpInsnNode);
                "".length();
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        int n5 = 0;
        while (Analyzer.lIIIIllllIll(n5, this.n)) {
            if (Analyzer.lIIIIllllllI(this.subroutines[n5]) && Analyzer.lIIIIlllllII(this.subroutines[n5].start)) {
                this.subroutines[n5] = null;
            }
            ++n5;
            "".length();
            if (-(114 + 126 - 104 + 56 ^ 144 + 6 - 143 + 189) <= 0) continue;
            return null;
        }
        Frame<V> frame = this.newFrame(methodNode.maxLocals, methodNode.maxStack);
        Frame<V> frame2 = this.newFrame(methodNode.maxLocals, methodNode.maxStack);
        frame.setReturn(this.interpreter.newValue(Type.getReturnType(methodNode.desc)));
        typeArray = Type.getArgumentTypes(methodNode.desc);
        int n6 = 0;
        if (Analyzer.lIIIIlllllIl(methodNode.access & 8)) {
            Type type = Type.getObjectType(string);
            frame.setLocal(n6++, this.interpreter.newValue(type));
        }
        int n7 = 0;
        while (Analyzer.lIIIIllllIll(n7, typeArray.length)) {
            frame.setLocal(n6++, this.interpreter.newValue(typeArray[n7]));
            if (Analyzer.lIIIIlllllll(typeArray[n7].getSize(), 2)) {
                frame.setLocal(n6++, this.interpreter.newValue(null));
            }
            ++n7;
            "".length();
            if ((0x55 ^ 0x51) >= 0) continue;
            return null;
        }
        while (Analyzer.lIIIIllllIll(n6, methodNode.maxLocals)) {
            frame.setLocal(n6++, this.interpreter.newValue(null));
            "".length();
            if (null == null) continue;
            return null;
        }
        this.merge(0, frame, null);
        this.init(string, methodNode);
        while (Analyzer.lIIIlIIIIIII(this.top)) {
            n7 = this.queue[--this.top];
            Frame<V> frame3 = this.frames[n7];
            Subroutine subroutine3 = this.subroutines[n7];
            this.queued[n7] = false;
            AbstractInsnNode abstractInsnNode = null;
            try {
                Object object2;
                int n8;
                Object object3;
                abstractInsnNode = methodNode.instructions.get(n7);
                int n9 = abstractInsnNode.getOpcode();
                int n10 = abstractInsnNode.getType();
                if (!Analyzer.lIIIlIIIIIIl(n10, 8) || !Analyzer.lIIIlIIIIIIl(n10, 15) || Analyzer.lIIIIlllllll(n10, 14)) {
                    this.merge(n7 + 1, frame3, subroutine3);
                    this.newControlFlowEdge(n7, n7 + 1);
                    "".length();
                    if (-"   ".length() > 0) {
                        return null;
                    }
                } else {
                    int n11;
                    Subroutine subroutine4;
                    frame.init(frame3).execute(abstractInsnNode, this.interpreter);
                    if (Analyzer.lIIIIlllllII(subroutine3)) {
                        subroutine4 = null;
                        "".length();
                        if ("  ".length() == ((0xAC ^ 0xAB ^ (0xB ^ 0x5C)) & (76 + 14 - 74 + 189 ^ 102 + 1 - -16 + 38 ^ -" ".length()))) {
                            return null;
                        }
                    } else {
                        subroutine4 = subroutine3 = subroutine3.copy();
                    }
                    if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof JumpInsnNode)) {
                        object3 = (JumpInsnNode)abstractInsnNode;
                        if (Analyzer.lIIIlIIIIIIl(n9, 167) && Analyzer.lIIIlIIIIIIl(n9, 168)) {
                            this.merge(n7 + 1, frame, subroutine3);
                            this.newControlFlowEdge(n7, n7 + 1);
                        }
                        n8 = this.insns.indexOf(((JumpInsnNode)object3).label);
                        if (Analyzer.lIIIIlllllll(n9, 168)) {
                            this.merge(n8, frame, new Subroutine(((JumpInsnNode)object3).label, methodNode.maxLocals, (JumpInsnNode)object3));
                            "".length();
                            if (null != null) {
                                return null;
                            }
                        } else {
                            this.merge(n8, frame, subroutine3);
                        }
                        this.newControlFlowEdge(n7, n8);
                        "".length();
                        if ("   ".length() >= (0x7A ^ 0x7E)) {
                            return null;
                        }
                    } else if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof LookupSwitchInsnNode)) {
                        object3 = (LookupSwitchInsnNode)abstractInsnNode;
                        n8 = this.insns.indexOf(((LookupSwitchInsnNode)object3).dflt);
                        this.merge(n8, frame, subroutine3);
                        this.newControlFlowEdge(n7, n8);
                        n11 = 0;
                        while (Analyzer.lIIIIllllIll(n11, ((LookupSwitchInsnNode)object3).labels.size())) {
                            object2 = ((LookupSwitchInsnNode)object3).labels.get(n11);
                            n8 = this.insns.indexOf((AbstractInsnNode)object2);
                            this.merge(n8, frame, subroutine3);
                            this.newControlFlowEdge(n7, n8);
                            ++n11;
                            "".length();
                            if ("   ".length() >= -" ".length()) continue;
                            return null;
                        }
                        "".length();
                        if (((0x45 ^ 0x11 ^ (0x41 ^ 0x2C)) & (124 + 124 - 86 + 15 ^ 50 + 98 - 90 + 78 ^ -" ".length())) > 0) {
                            return null;
                        }
                    } else if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof TableSwitchInsnNode)) {
                        object3 = (TableSwitchInsnNode)abstractInsnNode;
                        n8 = this.insns.indexOf(((TableSwitchInsnNode)object3).dflt);
                        this.merge(n8, frame, subroutine3);
                        this.newControlFlowEdge(n7, n8);
                        n11 = 0;
                        while (Analyzer.lIIIIllllIll(n11, ((TableSwitchInsnNode)object3).labels.size())) {
                            object2 = ((TableSwitchInsnNode)object3).labels.get(n11);
                            n8 = this.insns.indexOf((AbstractInsnNode)object2);
                            this.merge(n8, frame, subroutine3);
                            this.newControlFlowEdge(n7, n8);
                            ++n11;
                            "".length();
                            if (((0x34 ^ 6) & ~(0x1C ^ 0x2E)) == 0) continue;
                            return null;
                        }
                        "".length();
                        if ("   ".length() == " ".length()) {
                            return null;
                        }
                    } else if (Analyzer.lIIIIlllllll(n9, 169)) {
                        if (Analyzer.lIIIIlllllII(subroutine3)) {
                            throw new AnalyzerException(abstractInsnNode, "RET instruction outside of a sub routine");
                        }
                        int n12 = 0;
                        while (Analyzer.lIIIIllllIll(n12, subroutine3.callers.size())) {
                            JumpInsnNode jumpInsnNode = subroutine3.callers.get(n12);
                            n11 = this.insns.indexOf(jumpInsnNode);
                            if (Analyzer.lIIIIllllllI(this.frames[n11])) {
                                this.merge(n11 + 1, this.frames[n11], frame, this.subroutines[n11], subroutine3.access);
                                this.newControlFlowEdge(n7, n11 + 1);
                            }
                            ++n12;
                            "".length();
                            if (" ".length() >= 0) continue;
                            return null;
                        }
                        "".length();
                        if ((0x7B ^ 0xE ^ (0x6C ^ 0x1D)) <= -" ".length()) {
                            return null;
                        }
                    } else if (Analyzer.lIIIlIIIIIIl(n9, 191) && (!Analyzer.lIIIlIIIIIlI(n9, 172) || Analyzer.lIIIlIIIIIll(n9, 177))) {
                        if (Analyzer.lIIIIllllllI(subroutine3)) {
                            if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof VarInsnNode)) {
                                int n13 = ((VarInsnNode)abstractInsnNode).var;
                                subroutine3.access[n13] = true;
                                if (!Analyzer.lIIIlIIIIIIl(n9, 22) || !Analyzer.lIIIlIIIIIIl(n9, 24) || !Analyzer.lIIIlIIIIIIl(n9, 55) || Analyzer.lIIIIlllllll(n9, 57)) {
                                    subroutine3.access[n13 + 1] = true;
                                }
                                "".length();
                                if (-" ".length() > 0) {
                                    return null;
                                }
                            } else if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof IincInsnNode)) {
                                int n14 = ((IincInsnNode)abstractInsnNode).var;
                                subroutine3.access[n14] = true;
                            }
                        }
                        this.merge(n7 + 1, frame, subroutine3);
                        this.newControlFlowEdge(n7, n7 + 1);
                    }
                }
                if (Analyzer.lIIIIllllllI(object3 = this.handlers[n7])) {
                    n8 = 0;
                    while (Analyzer.lIIIIllllIll(n8, object3.size())) {
                        TryCatchBlockNode tryCatchBlockNode = (TryCatchBlockNode)object3.get(n8);
                        if (Analyzer.lIIIIlllllII(tryCatchBlockNode.type)) {
                            object2 = Type.getObjectType("java/lang/Throwable");
                            "".length();
                            if (-" ".length() > 0) {
                                return null;
                            }
                        } else {
                            object2 = Type.getObjectType(tryCatchBlockNode.type);
                        }
                        int n15 = this.insns.indexOf(tryCatchBlockNode.handler);
                        if (Analyzer.lIIIIllllIlI(this.newControlFlowExceptionEdge(n7, tryCatchBlockNode) ? 1 : 0)) {
                            frame2.init(frame3);
                            "".length();
                            frame2.clearStack();
                            frame2.push(this.interpreter.newValue((Type)object2));
                            this.merge(n15, frame2, subroutine3);
                        }
                        ++n8;
                        "".length();
                        if (-(51 + 71 - 77 + 110 ^ 113 + 46 - 96 + 96) <= 0) continue;
                        return null;
                    }
                }
                "".length();
            }
            catch (AnalyzerException analyzerException) {
                throw new AnalyzerException(analyzerException.node, String.valueOf(new StringBuilder().append("Error at instruction ").append(n7).append(": ").append(analyzerException.getMessage())), analyzerException);
            }
            catch (Exception exception) {
                throw new AnalyzerException(abstractInsnNode, String.valueOf(new StringBuilder().append("Error at instruction ").append(n7).append(": ").append(exception.getMessage())), exception);
            }
            if (null != null) {
                return null;
            }
            "".length();
            if ((0x39 ^ 0x62 ^ (0x3F ^ 0x61)) != 0) continue;
            return null;
        }
        return this.frames;
    }

    private void findSubroutine(int n, Subroutine subroutine, List<AbstractInsnNode> list) {
        do {
            Object object;
            int n2;
            Object object2;
            if (!Analyzer.lIIIlIIIIlII(n) || Analyzer.lIIIlIIIIIlI(n, this.n)) {
                throw new AnalyzerException(null, "Execution can fall off end of the code");
            }
            if (Analyzer.lIIIIllllllI(this.subroutines[n])) {
                return;
            }
            this.subroutines[n] = subroutine.copy();
            AbstractInsnNode abstractInsnNode = this.insns.get(n);
            if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof JumpInsnNode)) {
                if (Analyzer.lIIIIlllllll(abstractInsnNode.getOpcode(), 168)) {
                    list.add(abstractInsnNode);
                    "".length();
                    "".length();
                    if (-" ".length() > 0) {
                        return;
                    }
                } else {
                    object2 = (JumpInsnNode)abstractInsnNode;
                    this.findSubroutine(this.insns.indexOf(((JumpInsnNode)object2).label), subroutine, list);
                    "".length();
                    if (" ".length() <= -" ".length()) {
                        return;
                    }
                }
            } else if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof TableSwitchInsnNode)) {
                object2 = (TableSwitchInsnNode)abstractInsnNode;
                this.findSubroutine(this.insns.indexOf(((TableSwitchInsnNode)object2).dflt), subroutine, list);
                n2 = ((TableSwitchInsnNode)object2).labels.size() - 1;
                while (Analyzer.lIIIlIIIIlII(n2)) {
                    object = ((TableSwitchInsnNode)object2).labels.get(n2);
                    this.findSubroutine(this.insns.indexOf((AbstractInsnNode)object), subroutine, list);
                    --n2;
                    "".length();
                    if ((90 + 133 - 100 + 30 ^ 7 + 146 - 50 + 54) != 0) continue;
                    return;
                }
                "".length();
                if (((0x1D ^ 0x39 ^ (0x72 ^ 3)) & (1 ^ 0x4A ^ (0x9F ^ 0x81) ^ -" ".length())) >= (0x10 ^ 0x29 ^ (0x23 ^ 0x1E))) {
                    return;
                }
            } else if (Analyzer.lIIIIllllIlI(abstractInsnNode instanceof LookupSwitchInsnNode)) {
                object2 = (LookupSwitchInsnNode)abstractInsnNode;
                this.findSubroutine(this.insns.indexOf(((LookupSwitchInsnNode)object2).dflt), subroutine, list);
                n2 = ((LookupSwitchInsnNode)object2).labels.size() - 1;
                while (Analyzer.lIIIlIIIIlII(n2)) {
                    object = ((LookupSwitchInsnNode)object2).labels.get(n2);
                    this.findSubroutine(this.insns.indexOf((AbstractInsnNode)object), subroutine, list);
                    --n2;
                    "".length();
                    if ("   ".length() > -" ".length()) continue;
                    return;
                }
            }
            if (Analyzer.lIIIIllllllI(object2 = this.handlers[n])) {
                n2 = 0;
                while (Analyzer.lIIIIllllIll(n2, object2.size())) {
                    object = (TryCatchBlockNode)object2.get(n2);
                    this.findSubroutine(this.insns.indexOf(((TryCatchBlockNode)object).handler), subroutine, list);
                    ++n2;
                    "".length();
                    if ("   ".length() != ((0x48 ^ 1) & ~(0x2B ^ 0x62))) continue;
                    return;
                }
            }
            switch (abstractInsnNode.getOpcode()) {
                case 167: 
                case 169: 
                case 170: 
                case 171: 
                case 172: 
                case 173: 
                case 174: 
                case 175: 
                case 176: 
                case 177: 
                case 191: {
                    return;
                }
            }
            ++n;
            "".length();
        } while ("  ".length() > 0);
    }

    public Frame<V>[] getFrames() {
        return this.frames;
    }

    public List<TryCatchBlockNode> getHandlers(int n) {
        return this.handlers[n];
    }

    protected void init(String string, MethodNode methodNode) {
    }

    protected Frame<V> newFrame(int n, int n2) {
        return new Frame(n, n2);
    }

    protected Frame<V> newFrame(Frame<? extends V> frame) {
        return new Frame<V>(frame);
    }

    protected void newControlFlowEdge(int n, int n2) {
    }

    protected boolean newControlFlowExceptionEdge(int n, int n2) {
        return true;
    }

    protected boolean newControlFlowExceptionEdge(int n, TryCatchBlockNode tryCatchBlockNode) {
        return this.newControlFlowExceptionEdge(n, this.insns.indexOf(tryCatchBlockNode.handler));
    }

    /*
     * WARNING - void declaration
     */
    private void merge(int n, Frame<V> frame, Subroutine subroutine) {
        void var6_11;
        Frame<V> frame2 = this.frames[n];
        Subroutine subroutine2 = this.subroutines[n];
        if (Analyzer.lIIIIlllllII(frame2)) {
            this.frames[n] = this.newFrame(frame);
            boolean n2 = true;
            "".length();
            if ("  ".length() <= 0) {
                return;
            }
        } else {
            boolean bl = frame2.merge(frame, this.interpreter);
        }
        if (Analyzer.lIIIIlllllII(subroutine2)) {
            if (Analyzer.lIIIIllllllI(subroutine)) {
                this.subroutines[n] = subroutine.copy();
                boolean bl = true;
                "".length();
                if ("   ".length() == " ".length()) {
                    return;
                }
            }
        } else if (Analyzer.lIIIIllllllI(subroutine)) {
            void var6_8;
            int n2 = var6_8 | subroutine2.merge(subroutine);
        }
        if (Analyzer.lIIIIllllIlI((int)var6_11) && Analyzer.lIIIIlllllIl(this.queued[n])) {
            this.queued[n] = true;
            this.queue[this.top++] = n;
        }
    }

    /*
     * WARNING - void declaration
     */
    private void merge(int n, Frame<V> frame, Frame<V> frame2, Subroutine subroutine, boolean[] blArray) {
        int n2;
        Frame<V> frame3 = this.frames[n];
        Subroutine subroutine2 = this.subroutines[n];
        frame2.merge(frame, blArray);
        "".length();
        if (Analyzer.lIIIIlllllII(frame3)) {
            this.frames[n] = this.newFrame(frame2);
            boolean n22 = true;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            boolean bl = frame3.merge(frame2, this.interpreter);
        }
        if (Analyzer.lIIIIllllllI(subroutine2) && Analyzer.lIIIIllllllI(subroutine)) {
            void var8_10;
            n2 = var8_10 | subroutine2.merge(subroutine);
        }
        if (Analyzer.lIIIIllllIlI(n2) && Analyzer.lIIIIlllllIl(this.queued[n])) {
            this.queued[n] = true;
            this.queue[this.top++] = n;
        }
    }

    private static boolean lIIIIlllllll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIIIIIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIIllllIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIIIIIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIIllllllI(Object object) {
        return object != null;
    }

    private static boolean lIIIIlllllII(Object object) {
        return object == null;
    }

    private static boolean lIIIIllllIlI(int n) {
        return n != 0;
    }

    private static boolean lIIIIlllllIl(int n) {
        return n == 0;
    }

    private static boolean lIIIlIIIIlII(int n) {
        return n >= 0;
    }

    private static boolean lIIIlIIIIIII(int n) {
        return n > 0;
    }

    private static boolean lIIIlIIIIIIl(int n, int n2) {
        return n != n2;
    }
}

