/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.analysis.Value;

public class AnalyzerException
extends Exception {
    public final AbstractInsnNode node;

    public AnalyzerException(AbstractInsnNode abstractInsnNode, String string) {
        super(string);
        this.node = abstractInsnNode;
    }

    public AnalyzerException(AbstractInsnNode abstractInsnNode, String string, Throwable throwable) {
        super(string, throwable);
        this.node = abstractInsnNode;
    }

    public AnalyzerException(AbstractInsnNode abstractInsnNode, String string, Object object, Value value) {
        String string2;
        StringBuilder stringBuilder = new StringBuilder();
        if (AnalyzerException.lIIIIIlIll(string)) {
            string2 = "Expected ";
            "".length();
            if ((0x94 ^ 0x91) <= 0) {
                throw null;
            }
        } else {
            string2 = String.valueOf(new StringBuilder().append(string).append(": expected "));
        }
        super(String.valueOf(stringBuilder.append(string2).append(object).append(", but found ").append(value)));
        this.node = abstractInsnNode;
    }

    private static boolean lIIIIIlIll(Object object) {
        return object == null;
    }
}

