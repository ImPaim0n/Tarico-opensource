/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.analysis.Value;

public class BasicValue
implements Value {
    public static final BasicValue UNINITIALIZED_VALUE = new BasicValue(null);
    public static final BasicValue INT_VALUE = new BasicValue(Type.INT_TYPE);
    public static final BasicValue FLOAT_VALUE = new BasicValue(Type.FLOAT_TYPE);
    public static final BasicValue LONG_VALUE = new BasicValue(Type.LONG_TYPE);
    public static final BasicValue DOUBLE_VALUE = new BasicValue(Type.DOUBLE_TYPE);
    public static final BasicValue REFERENCE_VALUE = new BasicValue(Type.getObjectType("java/lang/Object"));
    public static final BasicValue RETURNADDRESS_VALUE = new BasicValue(Type.VOID_TYPE);
    private final Type type;

    public BasicValue(Type type) {
        this.type = type;
    }

    public Type getType() {
        return this.type;
    }

    public int getSize() {
        int n;
        if (!BasicValue.lIIIIlIll(this.type, Type.LONG_TYPE) || BasicValue.lIIIIllII(this.type, Type.DOUBLE_TYPE)) {
            n = 2;
            "".length();
            if ((62 + 179 - 125 + 67 ^ 92 + 8 - -34 + 45) <= " ".length()) {
                return (0xD2 ^ 0xA2 ^ (0xAF ^ 0x88)) & (0x2C ^ 0x6A ^ (2 ^ 0x13) ^ -" ".length());
            }
        } else {
            n = 1;
        }
        return n;
    }

    public boolean isReference() {
        boolean bl;
        if (BasicValue.lIIIIlllI(this.type) && (!BasicValue.lIIIIllll(this.type.getSort(), 10) || BasicValue.lIIIlIIII(this.type.getSort(), 9))) {
            bl = true;
            "".length();
            if (-"  ".length() >= 0) {
                return ((0x4E ^ 0x1D) & ~(0xCC ^ 0x9F)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean equals(Object object) {
        if (BasicValue.lIIIIllII(object, this)) {
            return true;
        }
        if (BasicValue.lIIIlIIlI(object instanceof BasicValue)) {
            if (BasicValue.lIIIlIIll(this.type)) {
                boolean bl;
                if (BasicValue.lIIIlIIll(((BasicValue)object).type)) {
                    bl = true;
                    "".length();
                    if ("   ".length() <= -" ".length()) {
                        return ((9 + 0 - -138 + 7 ^ 146 + 45 - 149 + 109) & (140 + 70 - 155 + 90 ^ 75 + 102 - 124 + 103 ^ -" ".length())) != 0;
                    }
                } else {
                    bl = false;
                }
                return bl;
            }
            return this.type.equals(((BasicValue)object).type);
        }
        return false;
    }

    public int hashCode() {
        int n;
        if (BasicValue.lIIIlIIll(this.type)) {
            n = 0;
            "".length();
            if (" ".length() <= -" ".length()) {
                return (0x8F ^ 0x94 ^ (0x5F ^ 0x24)) & (0x4F ^ 0x71 ^ (0x2E ^ 0x70) ^ -" ".length());
            }
        } else {
            n = this.type.hashCode();
        }
        return n;
    }

    public String toString() {
        if (BasicValue.lIIIIllII(this, UNINITIALIZED_VALUE)) {
            return ".";
        }
        if (BasicValue.lIIIIllII(this, RETURNADDRESS_VALUE)) {
            return "A";
        }
        if (BasicValue.lIIIIllII(this, REFERENCE_VALUE)) {
            return "R";
        }
        return this.type.getDescriptor();
    }

    private static boolean lIIIlIIII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIlIll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIIllII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIIlllI(Object object) {
        return object != null;
    }

    private static boolean lIIIlIIll(Object object) {
        return object == null;
    }

    private static boolean lIIIlIIlI(int n) {
        return n != 0;
    }

    private static boolean lIIIIllll(int n, int n2) {
        return n != n2;
    }
}

