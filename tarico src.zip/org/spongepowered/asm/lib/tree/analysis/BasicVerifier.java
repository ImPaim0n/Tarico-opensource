/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.List;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.InvokeDynamicInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.analysis.AnalyzerException;
import org.spongepowered.asm.lib.tree.analysis.BasicInterpreter;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class BasicVerifier
extends BasicInterpreter {
    public BasicVerifier() {
        super(327680);
    }

    protected BasicVerifier(int n) {
        super(n);
    }

    @Override
    public BasicValue copyOperation(AbstractInsnNode abstractInsnNode, BasicValue basicValue) {
        BasicValue basicValue2;
        switch (abstractInsnNode.getOpcode()) {
            case 21: 
            case 54: {
                basicValue2 = BasicValue.INT_VALUE;
                "".length();
                if (((101 + 79 - -52 + 3 ^ 85 + 99 - 82 + 61) & (8 ^ 0x16 ^ (0xF6 ^ 0xA0) ^ -" ".length())) >= -" ".length()) break;
                return null;
            }
            case 23: 
            case 56: {
                basicValue2 = BasicValue.FLOAT_VALUE;
                "".length();
                if (-"  ".length() <= 0) break;
                return null;
            }
            case 22: 
            case 55: {
                basicValue2 = BasicValue.LONG_VALUE;
                "".length();
                if ("   ".length() != (0x75 ^ 0x71)) break;
                return null;
            }
            case 24: 
            case 57: {
                basicValue2 = BasicValue.DOUBLE_VALUE;
                "".length();
                if (((136 + 56 - 137 + 131 ^ 97 + 132 - 93 + 37) & (106 + 53 - 58 + 27 ^ 37 + 90 - 37 + 61 ^ -" ".length())) <= "   ".length()) break;
                return null;
            }
            case 25: {
                if (BasicVerifier.lIlIlllIl(basicValue.isReference() ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, null, "an object reference", basicValue);
                }
                return basicValue;
            }
            case 58: {
                if (BasicVerifier.lIlIlllIl(basicValue.isReference() ? 1 : 0) && BasicVerifier.lIlIlllIl(BasicValue.RETURNADDRESS_VALUE.equals(basicValue) ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, null, "an object reference or a return address", basicValue);
                }
                return basicValue;
            }
            default: {
                return basicValue;
            }
        }
        if (BasicVerifier.lIlIlllIl(((Object)basicValue2).equals(basicValue) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, null, basicValue2, basicValue);
        }
        return basicValue;
    }

    @Override
    public BasicValue unaryOperation(AbstractInsnNode abstractInsnNode, BasicValue basicValue) {
        BasicValue basicValue2;
        switch (abstractInsnNode.getOpcode()) {
            case 116: 
            case 132: 
            case 133: 
            case 134: 
            case 135: 
            case 145: 
            case 146: 
            case 147: 
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: 
            case 170: 
            case 171: 
            case 172: 
            case 188: 
            case 189: {
                basicValue2 = BasicValue.INT_VALUE;
                "".length();
                if (((38 + 154 - 112 + 80 ^ 127 + 56 - 119 + 105) & (120 + 137 - 139 + 72 ^ 71 + 6 - 22 + 128 ^ -" ".length())) < "   ".length()) break;
                return null;
            }
            case 118: 
            case 139: 
            case 140: 
            case 141: 
            case 174: {
                basicValue2 = BasicValue.FLOAT_VALUE;
                "".length();
                if (-" ".length() <= (26 + 33 - -75 + 38 ^ 121 + 144 - 252 + 155)) break;
                return null;
            }
            case 117: 
            case 136: 
            case 137: 
            case 138: 
            case 173: {
                basicValue2 = BasicValue.LONG_VALUE;
                "".length();
                if (" ".length() < (81 + 128 - 127 + 50 ^ 108 + 115 - 113 + 18)) break;
                return null;
            }
            case 119: 
            case 142: 
            case 143: 
            case 144: 
            case 175: {
                basicValue2 = BasicValue.DOUBLE_VALUE;
                "".length();
                if (((3 ^ 0x3A ^ (0x5B ^ 0x5F)) & (0xA7 ^ 0xC0 ^ (0x58 ^ 2) ^ -" ".length())) == 0) break;
                return null;
            }
            case 180: {
                basicValue2 = this.newValue(Type.getObjectType(((FieldInsnNode)abstractInsnNode).owner));
                "".length();
                if ("  ".length() <= "  ".length()) break;
                return null;
            }
            case 192: {
                if (BasicVerifier.lIlIlllIl(basicValue.isReference() ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, null, "an object reference", basicValue);
                }
                return super.unaryOperation(abstractInsnNode, basicValue);
            }
            case 190: {
                if (BasicVerifier.lIlIlllIl(this.isArrayValue(basicValue) ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, null, "an array reference", basicValue);
                }
                return super.unaryOperation(abstractInsnNode, basicValue);
            }
            case 176: 
            case 191: 
            case 193: 
            case 194: 
            case 195: 
            case 198: 
            case 199: {
                if (BasicVerifier.lIlIlllIl(basicValue.isReference() ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, null, "an object reference", basicValue);
                }
                return super.unaryOperation(abstractInsnNode, basicValue);
            }
            case 179: {
                basicValue2 = this.newValue(Type.getType(((FieldInsnNode)abstractInsnNode).desc));
                "".length();
                if (("   ".length() & ~"   ".length()) > -" ".length()) break;
                return null;
            }
            default: {
                throw new Error("Internal error.");
            }
        }
        if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue, basicValue2) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, null, basicValue2, basicValue);
        }
        return super.unaryOperation(abstractInsnNode, basicValue);
    }

    @Override
    public BasicValue binaryOperation(AbstractInsnNode abstractInsnNode, BasicValue basicValue, BasicValue basicValue2) {
        BasicValue basicValue3;
        BasicValue basicValue4;
        switch (abstractInsnNode.getOpcode()) {
            case 46: {
                basicValue4 = this.newValue(Type.getType("[I"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if ("   ".length() >= 0) break;
                return null;
            }
            case 51: {
                if (BasicVerifier.lIllIIIII(this.isSubTypeOf(basicValue, this.newValue(Type.getType("[Z"))) ? 1 : 0)) {
                    basicValue4 = this.newValue(Type.getType("[Z"));
                    "".length();
                    if ("   ".length() <= "  ".length()) {
                        return null;
                    }
                } else {
                    basicValue4 = this.newValue(Type.getType("[B"));
                }
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (" ".length() < "  ".length()) break;
                return null;
            }
            case 52: {
                basicValue4 = this.newValue(Type.getType("[C"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (((0x7A ^ 0x2E) & ~(0x14 ^ 0x40)) == 0) break;
                return null;
            }
            case 53: {
                basicValue4 = this.newValue(Type.getType("[S"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (-" ".length() < "  ".length()) break;
                return null;
            }
            case 47: {
                basicValue4 = this.newValue(Type.getType("[J"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (-"   ".length() < 0) break;
                return null;
            }
            case 48: {
                basicValue4 = this.newValue(Type.getType("[F"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (-" ".length() < 0) break;
                return null;
            }
            case 49: {
                basicValue4 = this.newValue(Type.getType("[D"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (-"  ".length() < 0) break;
                return null;
            }
            case 50: {
                basicValue4 = this.newValue(Type.getType("[Ljava/lang/Object;"));
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (null == null) break;
                return null;
            }
            case 96: 
            case 100: 
            case 104: 
            case 108: 
            case 112: 
            case 120: 
            case 122: 
            case 124: 
            case 126: 
            case 128: 
            case 130: 
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: {
                basicValue4 = BasicValue.INT_VALUE;
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (null == null) break;
                return null;
            }
            case 98: 
            case 102: 
            case 106: 
            case 110: 
            case 114: 
            case 149: 
            case 150: {
                basicValue4 = BasicValue.FLOAT_VALUE;
                basicValue3 = BasicValue.FLOAT_VALUE;
                "".length();
                if (" ".length() >= -" ".length()) break;
                return null;
            }
            case 97: 
            case 101: 
            case 105: 
            case 109: 
            case 113: 
            case 127: 
            case 129: 
            case 131: 
            case 148: {
                basicValue4 = BasicValue.LONG_VALUE;
                basicValue3 = BasicValue.LONG_VALUE;
                "".length();
                if (" ".length() > -" ".length()) break;
                return null;
            }
            case 121: 
            case 123: 
            case 125: {
                basicValue4 = BasicValue.LONG_VALUE;
                basicValue3 = BasicValue.INT_VALUE;
                "".length();
                if (((0xBF ^ 0xB0) & ~(0x57 ^ 0x58)) == 0) break;
                return null;
            }
            case 99: 
            case 103: 
            case 107: 
            case 111: 
            case 115: 
            case 151: 
            case 152: {
                basicValue4 = BasicValue.DOUBLE_VALUE;
                basicValue3 = BasicValue.DOUBLE_VALUE;
                "".length();
                if ("  ".length() >= -" ".length()) break;
                return null;
            }
            case 165: 
            case 166: {
                basicValue4 = BasicValue.REFERENCE_VALUE;
                basicValue3 = BasicValue.REFERENCE_VALUE;
                "".length();
                if (-"  ".length() < 0) break;
                return null;
            }
            case 181: {
                FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
                basicValue4 = this.newValue(Type.getObjectType(fieldInsnNode.owner));
                basicValue3 = this.newValue(Type.getType(fieldInsnNode.desc));
                "".length();
                if (" ".length() == " ".length()) break;
                return null;
            }
            default: {
                throw new Error("Internal error.");
            }
        }
        if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue, basicValue4) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, "First argument", basicValue4, basicValue);
        }
        if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue2, basicValue3) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, "Second argument", basicValue3, basicValue2);
        }
        if (BasicVerifier.lIllIIlII(abstractInsnNode.getOpcode(), 50)) {
            return this.getElementValue(basicValue);
        }
        return super.binaryOperation(abstractInsnNode, basicValue, basicValue2);
    }

    @Override
    public BasicValue ternaryOperation(AbstractInsnNode abstractInsnNode, BasicValue basicValue, BasicValue basicValue2, BasicValue basicValue3) {
        BasicValue basicValue4;
        BasicValue basicValue5;
        switch (abstractInsnNode.getOpcode()) {
            case 79: {
                basicValue5 = this.newValue(Type.getType("[I"));
                basicValue4 = BasicValue.INT_VALUE;
                "".length();
                if ("  ".length() >= 0) break;
                return null;
            }
            case 84: {
                if (BasicVerifier.lIllIIIII(this.isSubTypeOf(basicValue, this.newValue(Type.getType("[Z"))) ? 1 : 0)) {
                    basicValue5 = this.newValue(Type.getType("[Z"));
                    "".length();
                    if (((0x6A ^ 0x35) & ~(0 ^ 0x5F)) != 0) {
                        return null;
                    }
                } else {
                    basicValue5 = this.newValue(Type.getType("[B"));
                }
                basicValue4 = BasicValue.INT_VALUE;
                "".length();
                if (-"   ".length() < 0) break;
                return null;
            }
            case 85: {
                basicValue5 = this.newValue(Type.getType("[C"));
                basicValue4 = BasicValue.INT_VALUE;
                "".length();
                if ("  ".length() > 0) break;
                return null;
            }
            case 86: {
                basicValue5 = this.newValue(Type.getType("[S"));
                basicValue4 = BasicValue.INT_VALUE;
                "".length();
                if ("   ".length() > ((0x28 ^ 0x39) & ~(0xD ^ 0x1C))) break;
                return null;
            }
            case 80: {
                basicValue5 = this.newValue(Type.getType("[J"));
                basicValue4 = BasicValue.LONG_VALUE;
                "".length();
                if ((0x8E ^ 0x8A) > 0) break;
                return null;
            }
            case 81: {
                basicValue5 = this.newValue(Type.getType("[F"));
                basicValue4 = BasicValue.FLOAT_VALUE;
                "".length();
                if (null == null) break;
                return null;
            }
            case 82: {
                basicValue5 = this.newValue(Type.getType("[D"));
                basicValue4 = BasicValue.DOUBLE_VALUE;
                "".length();
                if ("  ".length() > -" ".length()) break;
                return null;
            }
            case 83: {
                basicValue5 = basicValue;
                basicValue4 = BasicValue.REFERENCE_VALUE;
                "".length();
                if (null == null) break;
                return null;
            }
            default: {
                throw new Error("Internal error.");
            }
        }
        if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue, basicValue5) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, "First argument", String.valueOf(new StringBuilder().append("a ").append(basicValue5).append(" array reference")), basicValue);
        }
        if (BasicVerifier.lIlIlllIl(BasicValue.INT_VALUE.equals(basicValue2) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, "Second argument", BasicValue.INT_VALUE, basicValue2);
        }
        if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue3, basicValue4) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, "Third argument", basicValue4, basicValue3);
        }
        return null;
    }

    @Override
    public BasicValue naryOperation(AbstractInsnNode abstractInsnNode, List<? extends BasicValue> list) {
        int n = abstractInsnNode.getOpcode();
        if (BasicVerifier.lIllIIlII(n, 197)) {
            int n2 = 0;
            while (BasicVerifier.lIllIIlll(n2, list.size())) {
                if (BasicVerifier.lIlIlllIl(BasicValue.INT_VALUE.equals(list.get(n2)) ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, null, BasicValue.INT_VALUE, list.get(n2));
                }
                ++n2;
                "".length();
                if ("   ".length() != 0) continue;
                return null;
            }
            "".length();
            if (-"   ".length() >= 0) {
                return null;
            }
        } else {
            String string;
            Object object;
            int n3 = 0;
            int n4 = 0;
            if (BasicVerifier.lIllIlIII(n, 184) && BasicVerifier.lIllIlIII(n, 186)) {
                object = Type.getObjectType(((MethodInsnNode)abstractInsnNode).owner);
                if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(list.get(n3++), this.newValue((Type)object)) ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, "Method owner", this.newValue((Type)object), list.get(0));
                }
            }
            if (BasicVerifier.lIllIIlII(n, 186)) {
                string = ((InvokeDynamicInsnNode)abstractInsnNode).desc;
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                string = ((MethodInsnNode)abstractInsnNode).desc;
            }
            object = string;
            Type[] typeArray = Type.getArgumentTypes((String)object);
            while (BasicVerifier.lIllIIlll(n3, list.size())) {
                BasicValue basicValue;
                BasicValue basicValue2 = this.newValue(typeArray[n4++]);
                if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue = list.get(n3++), basicValue2) ? 1 : 0)) {
                    throw new AnalyzerException(abstractInsnNode, String.valueOf(new StringBuilder().append("Argument ").append(n4)), basicValue2, basicValue);
                }
                "".length();
                if (" ".length() < "   ".length()) continue;
                return null;
            }
        }
        return super.naryOperation(abstractInsnNode, (List)list);
    }

    @Override
    public void returnOperation(AbstractInsnNode abstractInsnNode, BasicValue basicValue, BasicValue basicValue2) {
        if (BasicVerifier.lIlIlllIl(this.isSubTypeOf(basicValue, basicValue2) ? 1 : 0)) {
            throw new AnalyzerException(abstractInsnNode, "Incompatible return type", basicValue2, basicValue);
        }
    }

    protected boolean isArrayValue(BasicValue basicValue) {
        return basicValue.isReference();
    }

    protected BasicValue getElementValue(BasicValue basicValue) {
        return BasicValue.REFERENCE_VALUE;
    }

    protected boolean isSubTypeOf(BasicValue basicValue, BasicValue basicValue2) {
        return basicValue.equals(basicValue2);
    }

    private static boolean lIllIIlII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIllIIlll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllIIIII(int n) {
        return n != 0;
    }

    private static boolean lIlIlllIl(int n) {
        return n == 0;
    }

    private static boolean lIllIlIII(int n, int n2) {
        return n != n2;
    }
}

