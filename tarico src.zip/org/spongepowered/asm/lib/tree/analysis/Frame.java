/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.ArrayList;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.IincInsnNode;
import org.spongepowered.asm.lib.tree.InvokeDynamicInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MultiANewArrayInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.lib.tree.analysis.AnalyzerException;
import org.spongepowered.asm.lib.tree.analysis.Interpreter;
import org.spongepowered.asm.lib.tree.analysis.Value;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class Frame<V extends Value> {
    private V returnValue;
    private V[] values;
    private int locals;
    private int top;

    public Frame(int n, int n2) {
        this.values = new Value[n + n2];
        this.locals = n;
    }

    public Frame(Frame<? extends V> frame) {
        this(frame.locals, frame.values.length - frame.locals);
        this.init(frame);
        "".length();
    }

    public Frame<V> init(Frame<? extends V> frame) {
        this.returnValue = frame.returnValue;
        System.arraycopy(frame.values, 0, this.values, 0, this.values.length);
        this.top = frame.top;
        return this;
    }

    public void setReturn(V v) {
        this.returnValue = v;
    }

    public int getLocals() {
        return this.locals;
    }

    public int getMaxStackSize() {
        return this.values.length - this.locals;
    }

    public V getLocal(int n) {
        if (Frame.llIlllIlll(n, this.locals)) {
            throw new IndexOutOfBoundsException("Trying to access an inexistant local variable");
        }
        return this.values[n];
    }

    public void setLocal(int n, V v) {
        if (Frame.llIlllIlll(n, this.locals)) {
            throw new IndexOutOfBoundsException(String.valueOf(new StringBuilder().append("Trying to access an inexistant local variable ").append(n)));
        }
        this.values[n] = v;
    }

    public int getStackSize() {
        return this.top;
    }

    public V getStack(int n) {
        return this.values[n + this.locals];
    }

    public void clearStack() {
        this.top = 0;
    }

    public V pop() {
        if (Frame.llIllllIII(this.top)) {
            throw new IndexOutOfBoundsException("Cannot pop operand off an empty stack.");
        }
        return this.values[--this.top + this.locals];
    }

    public void push(V v) {
        if (Frame.llIlllIlll(this.top + this.locals, this.values.length)) {
            throw new IndexOutOfBoundsException("Insufficient maximum stack size.");
        }
        this.values[this.top++ + this.locals] = v;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void execute(AbstractInsnNode abstractInsnNode, Interpreter<V> interpreter) {
        switch (abstractInsnNode.getOpcode()) {
            case 0: {
                "".length();
                if (" ".length() >= ((0xE1 ^ 0x80 ^ (0xC ^ 0x43)) & (0xF ^ 7 ^ (0x10 ^ 0x36) ^ -" ".length()))) return;
                return;
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 14: 
            case 15: 
            case 16: 
            case 17: 
            case 18: {
                this.push(interpreter.newOperation(abstractInsnNode));
                "".length();
                if (null == null) return;
                return;
            }
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: {
                this.push(interpreter.copyOperation(abstractInsnNode, this.getLocal(((VarInsnNode)abstractInsnNode).var)));
                "".length();
                if (" ".length() <= "   ".length()) return;
                return;
            }
            case 46: 
            case 47: 
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: {
                V v = this.pop();
                V v2 = this.pop();
                this.push(interpreter.binaryOperation(abstractInsnNode, v2, v));
                "".length();
                if ("  ".length() > 0) return;
                return;
            }
            case 54: 
            case 55: 
            case 56: 
            case 57: 
            case 58: {
                Object e = interpreter.copyOperation(abstractInsnNode, this.pop());
                int n = ((VarInsnNode)abstractInsnNode).var;
                this.setLocal(n, e);
                if (Frame.llIllllIIl(e.getSize(), 2)) {
                    this.setLocal(n + 1, interpreter.newValue(null));
                }
                if (!Frame.llIllllIll(n)) return;
                V v = this.getLocal(n - 1);
                if (Frame.llIlllllII(v) && Frame.llIllllIIl(v.getSize(), 2)) {
                    this.setLocal(n - 1, interpreter.newValue(null));
                }
                "".length();
                if ((0x26 ^ 0x22) >= ((0x5C ^ 0x43) & ~(0x47 ^ 0x58))) return;
                return;
            }
            case 79: 
            case 80: 
            case 81: 
            case 82: 
            case 83: 
            case 84: 
            case 85: 
            case 86: {
                V v = this.pop();
                V v3 = this.pop();
                V v4 = this.pop();
                interpreter.ternaryOperation(abstractInsnNode, v4, v3, v);
                "".length();
                "".length();
                if ((3 + 115 - -9 + 67 ^ 103 + 64 - 153 + 184) >= (39 + 94 - 78 + 79 ^ 72 + 104 - 119 + 73)) return;
                return;
            }
            case 87: {
                if (!Frame.llIllllIIl(this.pop().getSize(), 2)) return;
                throw new AnalyzerException(abstractInsnNode, "Illegal use of POP");
            }
            case 88: {
                if (!Frame.llIllllIIl(this.pop().getSize(), 1) || !Frame.lllIIIIIII(this.pop().getSize(), 1)) return;
                throw new AnalyzerException(abstractInsnNode, "Illegal use of POP2");
            }
            case 89: {
                V v = this.pop();
                if (Frame.lllIIIIIII(v.getSize(), 1)) {
                    throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP");
                }
                this.push(v);
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                "".length();
                if ((0x13 ^ 0x16) > 0) return;
                return;
            }
            case 90: {
                V v = this.pop();
                V v5 = this.pop();
                if (!Frame.llIllllIIl(v.getSize(), 1) || Frame.lllIIIIIII(v5.getSize(), 1)) {
                    throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP_X1");
                }
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                this.push(v5);
                this.push(v);
                "".length();
                if ("   ".length() > " ".length()) return;
                return;
            }
            case 91: {
                V v = this.pop();
                if (!Frame.llIllllIIl(v.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP_X2");
                V v6 = this.pop();
                if (Frame.llIllllIIl(v6.getSize(), 1)) {
                    V v7 = this.pop();
                    if (!Frame.llIllllIIl(v7.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP_X2");
                    this.push(interpreter.copyOperation(abstractInsnNode, v));
                    this.push(v7);
                    this.push(v6);
                    this.push(v);
                    "".length();
                    if (((157 + 12 - 111 + 122 ^ 29 + 66 - -12 + 41) & (131 + 87 - 187 + 155 ^ 97 + 65 - 30 + 22 ^ -" ".length())) == 0) return;
                    return;
                }
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                this.push(v6);
                this.push(v);
                "".length();
                if (-"   ".length() < 0) return;
                return;
            }
            case 92: {
                V v = this.pop();
                if (Frame.llIllllIIl(v.getSize(), 1)) {
                    V v8 = this.pop();
                    if (!Frame.llIllllIIl(v8.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP2");
                    this.push(v8);
                    this.push(v);
                    this.push(interpreter.copyOperation(abstractInsnNode, v8));
                    this.push(interpreter.copyOperation(abstractInsnNode, v));
                    "".length();
                    if ("  ".length() >= 0) return;
                    return;
                }
                this.push(v);
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                "".length();
                if (" ".length() <= "  ".length()) return;
                return;
            }
            case 93: {
                V v = this.pop();
                if (Frame.llIllllIIl(v.getSize(), 1)) {
                    V v9;
                    V v10 = this.pop();
                    if (!Frame.llIllllIIl(v10.getSize(), 1) || !Frame.llIllllIIl((v9 = this.pop()).getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP2_X1");
                    this.push(interpreter.copyOperation(abstractInsnNode, v10));
                    this.push(interpreter.copyOperation(abstractInsnNode, v));
                    this.push(v9);
                    this.push(v10);
                    this.push(v);
                    "".length();
                    if ((0xF3 ^ 0xC7 ^ (0x5C ^ 0x6D)) > 0) return;
                    return;
                }
                V v11 = this.pop();
                if (!Frame.llIllllIIl(v11.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP2_X1");
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                this.push(v11);
                this.push(v);
                "".length();
                if ((0x29 ^ 0x2D) > 0) return;
                return;
            }
            case 94: {
                V v = this.pop();
                if (Frame.llIllllIIl(v.getSize(), 1)) {
                    V v12 = this.pop();
                    if (!Frame.llIllllIIl(v12.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP2_X2");
                    V v13 = this.pop();
                    if (Frame.llIllllIIl(v13.getSize(), 1)) {
                        V v14 = this.pop();
                        if (!Frame.llIllllIIl(v14.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP2_X2");
                        this.push(interpreter.copyOperation(abstractInsnNode, v12));
                        this.push(interpreter.copyOperation(abstractInsnNode, v));
                        this.push(v14);
                        this.push(v13);
                        this.push(v12);
                        this.push(v);
                        "".length();
                        if ("   ".length() > 0) return;
                        return;
                    }
                    this.push(interpreter.copyOperation(abstractInsnNode, v12));
                    this.push(interpreter.copyOperation(abstractInsnNode, v));
                    this.push(v13);
                    this.push(v12);
                    this.push(v);
                    "".length();
                    if (null == null) return;
                    return;
                }
                V v15 = this.pop();
                if (Frame.llIllllIIl(v15.getSize(), 1)) {
                    V v16 = this.pop();
                    if (!Frame.llIllllIIl(v16.getSize(), 1)) throw new AnalyzerException(abstractInsnNode, "Illegal use of DUP2_X2");
                    this.push(interpreter.copyOperation(abstractInsnNode, v));
                    this.push(v16);
                    this.push(v15);
                    this.push(v);
                    "".length();
                    if ("   ".length() >= -" ".length()) return;
                    return;
                }
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                this.push(v15);
                this.push(v);
                "".length();
                if ("   ".length() > ((0x9F ^ 0xBB) & ~(5 ^ 0x21))) return;
                return;
            }
            case 95: {
                V v = this.pop();
                V v17 = this.pop();
                if (!Frame.llIllllIIl(v17.getSize(), 1) || Frame.lllIIIIIII(v.getSize(), 1)) {
                    throw new AnalyzerException(abstractInsnNode, "Illegal use of SWAP");
                }
                this.push(interpreter.copyOperation(abstractInsnNode, v));
                this.push(interpreter.copyOperation(abstractInsnNode, v17));
                "".length();
                if (("  ".length() & ("  ".length() ^ -" ".length())) >= 0) return;
                return;
            }
            case 96: 
            case 97: 
            case 98: 
            case 99: 
            case 100: 
            case 101: 
            case 102: 
            case 103: 
            case 104: 
            case 105: 
            case 106: 
            case 107: 
            case 108: 
            case 109: 
            case 110: 
            case 111: 
            case 112: 
            case 113: 
            case 114: 
            case 115: {
                V v = this.pop();
                V v18 = this.pop();
                this.push(interpreter.binaryOperation(abstractInsnNode, v18, v));
                "".length();
                if (-" ".length() != ((0xC7 ^ 0x9B) & ~(0x6A ^ 0x36))) return;
                return;
            }
            case 116: 
            case 117: 
            case 118: 
            case 119: {
                this.push(interpreter.unaryOperation(abstractInsnNode, this.pop()));
                "".length();
                if ("  ".length() != " ".length()) return;
                return;
            }
            case 120: 
            case 121: 
            case 122: 
            case 123: 
            case 124: 
            case 125: 
            case 126: 
            case 127: 
            case 128: 
            case 129: 
            case 130: 
            case 131: {
                V v = this.pop();
                V v19 = this.pop();
                this.push(interpreter.binaryOperation(abstractInsnNode, v19, v));
                "".length();
                if (((39 + 8 - -108 + 7 ^ 76 + 72 - 123 + 112) & (0x54 ^ 0x3A ^ (0xEC ^ 0xA9) ^ -" ".length())) < " ".length()) return;
                return;
            }
            case 132: {
                int n = ((IincInsnNode)abstractInsnNode).var;
                this.setLocal(n, interpreter.unaryOperation(abstractInsnNode, this.getLocal(n)));
                "".length();
                if (((123 + 23 - 45 + 112 ^ 56 + 69 - 45 + 52) & (0x9D ^ 0x8F ^ (0x49 ^ 0xA) ^ -" ".length())) <= 0) return;
                return;
            }
            case 133: 
            case 134: 
            case 135: 
            case 136: 
            case 137: 
            case 138: 
            case 139: 
            case 140: 
            case 141: 
            case 142: 
            case 143: 
            case 144: 
            case 145: 
            case 146: 
            case 147: {
                this.push(interpreter.unaryOperation(abstractInsnNode, this.pop()));
                "".length();
                if (" ".length() >= -" ".length()) return;
                return;
            }
            case 148: 
            case 149: 
            case 150: 
            case 151: 
            case 152: {
                V v = this.pop();
                V v20 = this.pop();
                this.push(interpreter.binaryOperation(abstractInsnNode, v20, v));
                "".length();
                if ((113 + 88 - 67 + 44 ^ 8 + 131 - 138 + 181) >= -" ".length()) return;
                return;
            }
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: {
                interpreter.unaryOperation(abstractInsnNode, this.pop());
                "".length();
                "".length();
                if (-" ".length() <= 0) return;
                return;
            }
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: 
            case 165: 
            case 166: {
                V v = this.pop();
                V v21 = this.pop();
                interpreter.binaryOperation(abstractInsnNode, v21, v);
                "".length();
                "".length();
                if ("   ".length() > -" ".length()) return;
                return;
            }
            case 167: {
                "".length();
                if (((126 + 3 - 9 + 54 ^ 151 + 94 - 136 + 58) & (0xE8 ^ 0x9B ^ (0xBF ^ 0xC5) ^ -" ".length())) <= 0) return;
                return;
            }
            case 168: {
                this.push(interpreter.newOperation(abstractInsnNode));
                "".length();
                if (((6 ^ 0x2A ^ (0x10 ^ 0x2E)) & (0xBD ^ 0x89 ^ (0x28 ^ 0xE) ^ -" ".length())) == 0) return;
                return;
            }
            case 169: {
                "".length();
                if ("  ".length() != 0) return;
                return;
            }
            case 170: 
            case 171: {
                interpreter.unaryOperation(abstractInsnNode, this.pop());
                "".length();
                "".length();
                if ((0xC2 ^ 0xB1 ^ (0xEF ^ 0x99)) != 0) return;
                return;
            }
            case 172: 
            case 173: 
            case 174: 
            case 175: 
            case 176: {
                V v = this.pop();
                interpreter.unaryOperation(abstractInsnNode, v);
                "".length();
                interpreter.returnOperation(abstractInsnNode, v, this.returnValue);
                "".length();
                if (((0xA8 ^ 0xBF ^ (5 ^ 0x3F)) & (0xAA ^ 0xB0 ^ (0xAF ^ 0x98) ^ -" ".length())) >= 0) return;
                return;
            }
            case 177: {
                if (!Frame.llIlllllII(this.returnValue)) return;
                throw new AnalyzerException(abstractInsnNode, "Incompatible return type");
            }
            case 178: {
                this.push(interpreter.newOperation(abstractInsnNode));
                "".length();
                if (-" ".length() == -" ".length()) return;
                return;
            }
            case 179: {
                interpreter.unaryOperation(abstractInsnNode, this.pop());
                "".length();
                "".length();
                if (-" ".length() < " ".length()) return;
                return;
            }
            case 180: {
                this.push(interpreter.unaryOperation(abstractInsnNode, this.pop()));
                "".length();
                if (null == null) return;
                return;
            }
            case 181: {
                V v = this.pop();
                V v22 = this.pop();
                interpreter.binaryOperation(abstractInsnNode, v22, v);
                "".length();
                "".length();
                if (-" ".length() < "  ".length()) return;
                return;
            }
            case 182: 
            case 183: 
            case 184: 
            case 185: {
                ArrayList<V> arrayList = new ArrayList<V>();
                String string = ((MethodInsnNode)abstractInsnNode).desc;
                int n = Type.getArgumentTypes(string).length;
                while (Frame.llIllllIll(n)) {
                    arrayList.add(0, this.pop());
                    --n;
                    "".length();
                    if (((0x28 ^ 0xB ^ (0x88 ^ 0x86)) & (0x19 ^ 0x6E ^ (0xE8 ^ 0xB2) ^ -" ".length())) >= -" ".length()) continue;
                    return;
                }
                if (Frame.lllIIIIIII(abstractInsnNode.getOpcode(), 184)) {
                    arrayList.add(0, this.pop());
                }
                if (Frame.lllIIIIIIl(Type.getReturnType(string), Type.VOID_TYPE)) {
                    interpreter.naryOperation(abstractInsnNode, arrayList);
                    "".length();
                    "".length();
                    if ("  ".length() >= "  ".length()) return;
                    return;
                }
                this.push(interpreter.naryOperation(abstractInsnNode, arrayList));
                "".length();
                if (((0xE7 ^ 0xB8) & ~(0x68 ^ 0x37)) == 0) return;
                return;
            }
            case 186: {
                ArrayList<V> arrayList = new ArrayList<V>();
                String string = ((InvokeDynamicInsnNode)abstractInsnNode).desc;
                int n = Type.getArgumentTypes(string).length;
                while (Frame.llIllllIll(n)) {
                    arrayList.add(0, this.pop());
                    --n;
                    "".length();
                    if (" ".length() >= ((0xAD ^ 0xB6 ^ (0x87 ^ 0x81)) & (4 ^ 0x4A ^ (0xCA ^ 0x99) ^ -" ".length()))) continue;
                    return;
                }
                if (Frame.lllIIIIIIl(Type.getReturnType(string), Type.VOID_TYPE)) {
                    interpreter.naryOperation(abstractInsnNode, arrayList);
                    "".length();
                    "".length();
                    if (((112 + 18 - 125 + 139 ^ 176 + 4 - 98 + 109) & (0xE5 ^ 0xAD ^ (0xA7 ^ 0xC0) ^ -" ".length())) == ((237 + 118 - 246 + 137 ^ 98 + 45 - 46 + 75) & (0x3E ^ 0x63 ^ (0xC6 ^ 0xC1) ^ -" ".length()))) return;
                    return;
                }
                this.push(interpreter.naryOperation(abstractInsnNode, arrayList));
                "".length();
                if (((0x5C ^ 0x1D ^ (0xF0 ^ 0xB7)) & (0x5E ^ 0x69 ^ (0x38 ^ 9) ^ -" ".length())) == 0) return;
                return;
            }
            case 187: {
                this.push(interpreter.newOperation(abstractInsnNode));
                "".length();
                if (-" ".length() <= " ".length()) return;
                return;
            }
            case 188: 
            case 189: 
            case 190: {
                this.push(interpreter.unaryOperation(abstractInsnNode, this.pop()));
                "".length();
                if (null == null) return;
                return;
            }
            case 191: {
                interpreter.unaryOperation(abstractInsnNode, this.pop());
                "".length();
                "".length();
                if ((0x27 ^ 0x22) > 0) return;
                return;
            }
            case 192: 
            case 193: {
                this.push(interpreter.unaryOperation(abstractInsnNode, this.pop()));
                "".length();
                if ((0x69 ^ 0x6D) != ((8 ^ 0) & ~(0x50 ^ 0x58))) return;
                return;
            }
            case 194: 
            case 195: {
                interpreter.unaryOperation(abstractInsnNode, this.pop());
                "".length();
                "".length();
                if ("   ".length() > 0) return;
                return;
            }
            case 197: {
                ArrayList<V> arrayList = new ArrayList<V>();
                int n = ((MultiANewArrayInsnNode)abstractInsnNode).dims;
                while (Frame.llIllllIll(n)) {
                    arrayList.add(0, this.pop());
                    --n;
                    "".length();
                    if (-" ".length() != "   ".length()) continue;
                    return;
                }
                this.push(interpreter.naryOperation(abstractInsnNode, arrayList));
                "".length();
                if (null == null) return;
                return;
            }
            case 198: 
            case 199: {
                interpreter.unaryOperation(abstractInsnNode, this.pop());
                "".length();
                "".length();
                if (-"   ".length() <= 0) return;
                return;
            }
            default: {
                throw new RuntimeException(String.valueOf(new StringBuilder().append("Illegal opcode ").append(abstractInsnNode.getOpcode())));
            }
        }
    }

    public boolean merge(Frame<? extends V> frame, Interpreter<V> interpreter) {
        if (Frame.lllIIIIIII(this.top, frame.top)) {
            throw new AnalyzerException(null, "Incompatible stack heights");
        }
        boolean bl = false;
        int n = 0;
        while (Frame.lllIIIIIlI(n, this.locals + this.top)) {
            V v = interpreter.merge(this.values[n], frame.values[n]);
            if (Frame.llIllllIII(v.equals(this.values[n]) ? 1 : 0)) {
                this.values[n] = v;
                bl = true;
            }
            ++n;
            "".length();
            if (((0x5D ^ 0x55 ^ (0x46 ^ 0x66)) & (154 + 31 - 40 + 25 ^ 15 + 77 - 19 + 57 ^ -" ".length())) == 0) continue;
            return ((40 + 141 - 39 + 13 ^ 95 + 35 - 111 + 157) & (0xC9 ^ 0x86 ^ (0xC4 ^ 0xA0) ^ -" ".length())) != 0;
        }
        return bl;
    }

    public boolean merge(Frame<? extends V> frame, boolean[] blArray) {
        boolean bl = false;
        int n = 0;
        while (Frame.lllIIIIIlI(n, this.locals)) {
            if (Frame.llIllllIII(blArray[n]) && Frame.llIllllIII(this.values[n].equals(frame.values[n]) ? 1 : 0)) {
                this.values[n] = frame.values[n];
                bl = true;
            }
            ++n;
            "".length();
            if (-"   ".length() <= 0) continue;
            return ((203 + 27 - 72 + 72 ^ 128 + 74 - 171 + 104) & (136 + 148 - 163 + 109 ^ 110 + 33 - 20 + 12 ^ -" ".length())) != 0;
        }
        return bl;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        while (Frame.lllIIIIIlI(n, this.getLocals())) {
            stringBuilder.append(this.getLocal(n));
            "".length();
            ++n;
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return null;
        }
        stringBuilder.append(' ');
        "".length();
        n = 0;
        while (Frame.lllIIIIIlI(n, this.getStackSize())) {
            stringBuilder.append(this.getStack(n).toString());
            "".length();
            ++n;
            "".length();
            if (((0x4B ^ 0x57 ^ (0x7E ^ 0x43)) & (0x63 ^ 0x73 ^ (0x40 ^ 0x71) ^ -" ".length())) == 0) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    private static boolean llIllllIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean llIlllIlll(int n, int n2) {
        return n >= n2;
    }

    private static boolean lllIIIIIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlllllII(Object object) {
        return object != null;
    }

    private static boolean lllIIIIIIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIllllIII(int n) {
        return n == 0;
    }

    private static boolean llIllllIll(int n) {
        return n > 0;
    }

    private static boolean lllIIIIIII(int n, int n2) {
        return n != n2;
    }
}

