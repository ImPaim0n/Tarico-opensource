/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.List;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;
import org.spongepowered.asm.lib.tree.analysis.BasicVerifier;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class SimpleVerifier
extends BasicVerifier {
    private final Type currentClass;
    private final Type currentSuperClass;
    private final List<Type> currentClassInterfaces;
    private final boolean isInterface;
    private ClassLoader loader = this.getClass().getClassLoader();

    public SimpleVerifier() {
        this(null, null, false);
    }

    public SimpleVerifier(Type type, Type type2, boolean bl) {
        this(type, type2, null, bl);
    }

    public SimpleVerifier(Type type, Type type2, List<Type> list, boolean bl) {
        this(327680, type, type2, list, bl);
    }

    protected SimpleVerifier(int n, Type type, Type type2, List<Type> list, boolean bl) {
        super(n);
        this.currentClass = type;
        this.currentSuperClass = type2;
        this.currentClassInterfaces = list;
        this.isInterface = bl;
    }

    public void setClassLoader(ClassLoader classLoader) {
        this.loader = classLoader;
    }

    @Override
    public BasicValue newValue(Type type) {
        BasicValue basicValue;
        int n;
        int n2;
        if (SimpleVerifier.lllIllIlll(type)) {
            return BasicValue.UNINITIALIZED_VALUE;
        }
        if (SimpleVerifier.lllIlllIII(type.getSort(), 9)) {
            n2 = 1;
            "".length();
            if (" ".length() < " ".length()) {
                return null;
            }
        } else {
            n2 = 0;
        }
        if (SimpleVerifier.lllIlllIIl(n = n2)) {
            switch (type.getElementType().getSort()) {
                case 1: 
                case 2: 
                case 3: 
                case 4: {
                    return new BasicValue(type);
                }
            }
        }
        if (SimpleVerifier.lllIlllIIl(BasicValue.REFERENCE_VALUE.equals(basicValue = super.newValue(type)) ? 1 : 0)) {
            if (SimpleVerifier.lllIlllIIl(n)) {
                basicValue = this.newValue(type.getElementType());
                String string = basicValue.getType().getDescriptor();
                int n3 = 0;
                while (SimpleVerifier.lllIlllIlI(n3, type.getDimensions())) {
                    string = String.valueOf(new StringBuilder().append('[').append(string));
                    ++n3;
                    "".length();
                    if ((0x21 ^ 0x24) > 0) continue;
                    return null;
                }
                basicValue = new BasicValue(Type.getType(string));
                "".length();
                if (" ".length() != " ".length()) {
                    return null;
                }
            } else {
                basicValue = new BasicValue(type);
            }
        }
        return basicValue;
    }

    @Override
    protected boolean isArrayValue(BasicValue basicValue) {
        boolean bl;
        Type type = basicValue.getType();
        if (SimpleVerifier.lllIlllIll(type) && (!SimpleVerifier.lllIllllII("Lnull;".equals(type.getDescriptor()) ? 1 : 0) || SimpleVerifier.lllIlllIII(type.getSort(), 9))) {
            bl = true;
            "".length();
            if (" ".length() == (0x78 ^ 0x7C)) {
                return ((0x14 ^ 0x59) & ~(0x54 ^ 0x19)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    protected BasicValue getElementValue(BasicValue basicValue) {
        Type type = basicValue.getType();
        if (SimpleVerifier.lllIlllIll(type)) {
            if (SimpleVerifier.lllIlllIII(type.getSort(), 9)) {
                return this.newValue(Type.getType(type.getDescriptor().substring(1)));
            }
            if (SimpleVerifier.lllIlllIIl("Lnull;".equals(type.getDescriptor()) ? 1 : 0)) {
                return basicValue;
            }
        }
        throw new Error("Internal error");
    }

    @Override
    protected boolean isSubTypeOf(BasicValue basicValue, BasicValue basicValue2) {
        Type type = basicValue2.getType();
        Type type2 = basicValue.getType();
        switch (type.getSort()) {
            case 5: 
            case 6: 
            case 7: 
            case 8: {
                return type2.equals(type);
            }
            case 9: 
            case 10: {
                if (SimpleVerifier.lllIlllIIl("Lnull;".equals(type2.getDescriptor()) ? 1 : 0)) {
                    return true;
                }
                if (!SimpleVerifier.lllIlllllI(type2.getSort(), 10) || SimpleVerifier.lllIlllIII(type2.getSort(), 9)) {
                    return this.isAssignableFrom(type, type2);
                }
                return false;
            }
        }
        throw new Error("Internal error");
    }

    @Override
    public BasicValue merge(BasicValue basicValue, BasicValue basicValue2) {
        if (SimpleVerifier.lllIllllII(basicValue.equals(basicValue2) ? 1 : 0)) {
            Type type = basicValue.getType();
            Type type2 = basicValue2.getType();
            if (SimpleVerifier.lllIlllIll(type) && (!SimpleVerifier.lllIlllllI(type.getSort(), 10) || SimpleVerifier.lllIlllIII(type.getSort(), 9)) && SimpleVerifier.lllIlllIll(type2) && (!SimpleVerifier.lllIlllllI(type2.getSort(), 10) || SimpleVerifier.lllIlllIII(type2.getSort(), 9))) {
                if (SimpleVerifier.lllIlllIIl("Lnull;".equals(type.getDescriptor()) ? 1 : 0)) {
                    return basicValue2;
                }
                if (SimpleVerifier.lllIlllIIl("Lnull;".equals(type2.getDescriptor()) ? 1 : 0)) {
                    return basicValue;
                }
                if (SimpleVerifier.lllIlllIIl(this.isAssignableFrom(type, type2) ? 1 : 0)) {
                    return basicValue;
                }
                if (SimpleVerifier.lllIlllIIl(this.isAssignableFrom(type2, type) ? 1 : 0)) {
                    return basicValue2;
                }
                do {
                    if (SimpleVerifier.lllIlllIll(type) && !SimpleVerifier.lllIlllIIl(this.isInterface(type) ? 1 : 0)) continue;
                    return BasicValue.REFERENCE_VALUE;
                } while (!SimpleVerifier.lllIlllIIl(this.isAssignableFrom(type = this.getSuperClass(type), type2) ? 1 : 0));
                return this.newValue(type);
            }
            return BasicValue.UNINITIALIZED_VALUE;
        }
        return basicValue;
    }

    protected boolean isInterface(Type type) {
        if (SimpleVerifier.lllIlllIll(this.currentClass) && SimpleVerifier.lllIlllIIl(type.equals(this.currentClass) ? 1 : 0)) {
            return this.isInterface;
        }
        return this.getClass(type).isInterface();
    }

    protected Type getSuperClass(Type type) {
        Type type2;
        if (SimpleVerifier.lllIlllIll(this.currentClass) && SimpleVerifier.lllIlllIIl(type.equals(this.currentClass) ? 1 : 0)) {
            return this.currentSuperClass;
        }
        Class<?> clazz = this.getClass(type).getSuperclass();
        if (SimpleVerifier.lllIllIlll(clazz)) {
            type2 = null;
            "".length();
            if ("   ".length() < 0) {
                return null;
            }
        } else {
            type2 = Type.getType(clazz);
        }
        return type2;
    }

    protected boolean isAssignableFrom(Type type, Type type2) {
        if (SimpleVerifier.lllIlllIIl(type.equals(type2) ? 1 : 0)) {
            return true;
        }
        if (SimpleVerifier.lllIlllIll(this.currentClass) && SimpleVerifier.lllIlllIIl(type.equals(this.currentClass) ? 1 : 0)) {
            if (SimpleVerifier.lllIllIlll(this.getSuperClass(type2))) {
                return false;
            }
            if (SimpleVerifier.lllIlllIIl(this.isInterface ? 1 : 0)) {
                boolean bl;
                if (!SimpleVerifier.lllIlllllI(type2.getSort(), 10) || SimpleVerifier.lllIlllIII(type2.getSort(), 9)) {
                    bl = true;
                    "".length();
                    if (((0x98 ^ 0xB8) & ~(0x2C ^ 0xC)) != 0) {
                        return ((0x9C ^ 0xA2) & ~(0xA3 ^ 0x9D)) != 0;
                    }
                } else {
                    bl = false;
                }
                return bl;
            }
            return this.isAssignableFrom(type, this.getSuperClass(type2));
        }
        if (SimpleVerifier.lllIlllIll(this.currentClass) && SimpleVerifier.lllIlllIIl(type2.equals(this.currentClass) ? 1 : 0)) {
            if (SimpleVerifier.lllIlllIIl(this.isAssignableFrom(type, this.currentSuperClass) ? 1 : 0)) {
                return true;
            }
            if (SimpleVerifier.lllIlllIll(this.currentClassInterfaces)) {
                int n = 0;
                while (SimpleVerifier.lllIlllIlI(n, this.currentClassInterfaces.size())) {
                    Type type3 = this.currentClassInterfaces.get(n);
                    if (SimpleVerifier.lllIlllIIl(this.isAssignableFrom(type, type3) ? 1 : 0)) {
                        return true;
                    }
                    ++n;
                    "".length();
                    if (-(0x65 ^ 0x61) < 0) continue;
                    return ((0xB8 ^ 0xA0) & ~(0x87 ^ 0x9F)) != 0;
                }
            }
            return false;
        }
        Class<Object> clazz = this.getClass(type);
        if (SimpleVerifier.lllIlllIIl(clazz.isInterface() ? 1 : 0)) {
            clazz = Object.class;
        }
        return clazz.isAssignableFrom(this.getClass(type2));
    }

    protected Class<?> getClass(Type type) {
        try {
            if (SimpleVerifier.lllIlllIII(type.getSort(), 9)) {
                return Class.forName(type.getDescriptor().replace('/', '.'), false, this.loader);
            }
            return Class.forName(type.getClassName(), false, this.loader);
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new RuntimeException(classNotFoundException.toString());
        }
    }

    private static boolean lllIlllIII(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIlllIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIlllIll(Object object) {
        return object != null;
    }

    private static boolean lllIllIlll(Object object) {
        return object == null;
    }

    private static boolean lllIlllIIl(int n) {
        return n != 0;
    }

    private static boolean lllIllllII(int n) {
        return n == 0;
    }

    private static boolean lllIlllllI(int n, int n2) {
        return n != n2;
    }
}

