/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.AbstractSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
class SmallSet<E>
extends AbstractSet<E>
implements Iterator<E> {
    E e1;
    E e2;

    static final <T> Set<T> emptySet() {
        return new SmallSet<Object>(null, null);
    }

    SmallSet(E e, E e2) {
        this.e1 = e;
        this.e2 = e2;
    }

    @Override
    public Iterator<E> iterator() {
        return new SmallSet<E>(this.e1, this.e2);
    }

    @Override
    public int size() {
        int n;
        if (SmallSet.lIIlIlIllII(this.e1)) {
            n = 0;
            "".length();
            if (null != null) {
                return (0x95 ^ 0xBE) & ~(0x34 ^ 0x1F);
            }
        } else if (SmallSet.lIIlIlIllII(this.e2)) {
            n = 1;
            "".length();
            if (((0x66 ^ 0x5C) & ~(0xB7 ^ 0x8D)) != 0) {
                return (0xB2 ^ 0xA9) & ~(0xA5 ^ 0xBE);
            }
        } else {
            n = 2;
        }
        return n;
    }

    @Override
    public boolean hasNext() {
        boolean bl;
        if (SmallSet.lIIlIlIllIl(this.e1)) {
            bl = true;
            "".length();
            if (((0x4D ^ 0x59) & ~(0x21 ^ 0x35)) > ((0x22 ^ 0x1A) & ~(6 ^ 0x3E))) {
                return ((0xAA ^ 0x82) & ~(0xB9 ^ 0x91)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public E next() {
        if (SmallSet.lIIlIlIllII(this.e1)) {
            throw new NoSuchElementException();
        }
        E e = this.e1;
        this.e1 = this.e2;
        this.e2 = null;
        return e;
    }

    @Override
    public void remove() {
    }

    Set<E> union(SmallSet<E> smallSet) {
        if (SmallSet.lIIlIlIlllI(smallSet.e1, this.e1) && !SmallSet.lIIlIlIllll(smallSet.e2, this.e2) || SmallSet.lIIlIlIlllI(smallSet.e1, this.e2) && SmallSet.lIIlIlIlllI(smallSet.e2, this.e1)) {
            return this;
        }
        if (SmallSet.lIIlIlIllII(smallSet.e1)) {
            return this;
        }
        if (SmallSet.lIIlIlIllII(this.e1)) {
            return smallSet;
        }
        if (SmallSet.lIIlIlIllII(smallSet.e2)) {
            if (SmallSet.lIIlIlIllII(this.e2)) {
                return new SmallSet<E>(this.e1, smallSet.e1);
            }
            if (!SmallSet.lIIlIlIllll(smallSet.e1, this.e1) || SmallSet.lIIlIlIlllI(smallSet.e1, this.e2)) {
                return this;
            }
        }
        if (SmallSet.lIIlIlIllII(this.e2) && (!SmallSet.lIIlIlIllll(this.e1, smallSet.e1) || SmallSet.lIIlIlIlllI(this.e1, smallSet.e2))) {
            return smallSet;
        }
        HashSet<E> hashSet = new HashSet<E>(4);
        hashSet.add(this.e1);
        "".length();
        if (SmallSet.lIIlIlIllIl(this.e2)) {
            hashSet.add(this.e2);
            "".length();
        }
        hashSet.add(smallSet.e1);
        "".length();
        if (SmallSet.lIIlIlIllIl(smallSet.e2)) {
            hashSet.add(smallSet.e2);
            "".length();
        }
        return hashSet;
    }

    private static boolean lIIlIlIllll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIlIlIllIl(Object object) {
        return object != null;
    }

    private static boolean lIIlIlIlllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIlIlIllII(Object object) {
        return object == null;
    }
}

