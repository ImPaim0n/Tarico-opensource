/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.InvokeDynamicInsnNode;
import org.spongepowered.asm.lib.tree.LdcInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.analysis.Interpreter;
import org.spongepowered.asm.lib.tree.analysis.SmallSet;
import org.spongepowered.asm.lib.tree.analysis.SourceValue;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class SourceInterpreter
extends Interpreter<SourceValue>
implements Opcodes {
    public SourceInterpreter() {
        super(327680);
    }

    protected SourceInterpreter(int n) {
        super(n);
    }

    @Override
    public SourceValue newValue(Type type) {
        int n;
        if (SourceInterpreter.lIIIIllIlllI(type, Type.VOID_TYPE)) {
            return null;
        }
        if (SourceInterpreter.lIIIIllIllll(type)) {
            n = 1;
            "".length();
            if (((119 + 104 - 135 + 74 ^ 31 + 14 - -12 + 96) & (0x34 ^ 0x7E ^ (0x2C ^ 0x5D) ^ -" ".length())) < -" ".length()) {
                return null;
            }
        } else {
            n = type.getSize();
        }
        return new SourceValue(n);
    }

    @Override
    public SourceValue newOperation(AbstractInsnNode abstractInsnNode) {
        int n;
        switch (abstractInsnNode.getOpcode()) {
            case 9: 
            case 10: 
            case 14: 
            case 15: {
                n = 2;
                "".length();
                if ("  ".length() < "   ".length()) break;
                return null;
            }
            case 18: {
                int n2;
                Object object = ((LdcInsnNode)abstractInsnNode).cst;
                if (!SourceInterpreter.lIIIIlllIIII(object instanceof Long) || SourceInterpreter.lIIIIlllIIIl(object instanceof Double)) {
                    n2 = 2;
                    "".length();
                    if (-" ".length() != -" ".length()) {
                        return null;
                    }
                } else {
                    n2 = 1;
                }
                n = n2;
                "".length();
                if ((0x93 ^ 0x97) >= 0) break;
                return null;
            }
            case 178: {
                n = Type.getType(((FieldInsnNode)abstractInsnNode).desc).getSize();
                "".length();
                if (-(7 ^ 0x15 ^ (0xA4 ^ 0xB3)) < 0) break;
                return null;
            }
            default: {
                n = 1;
            }
        }
        return new SourceValue(n, abstractInsnNode);
    }

    @Override
    public SourceValue copyOperation(AbstractInsnNode abstractInsnNode, SourceValue sourceValue) {
        return new SourceValue(sourceValue.getSize(), abstractInsnNode);
    }

    @Override
    public SourceValue unaryOperation(AbstractInsnNode abstractInsnNode, SourceValue sourceValue) {
        int n;
        switch (abstractInsnNode.getOpcode()) {
            case 117: 
            case 119: 
            case 133: 
            case 135: 
            case 138: 
            case 140: 
            case 141: 
            case 143: {
                n = 2;
                "".length();
                if ("  ".length() == "  ".length()) break;
                return null;
            }
            case 180: {
                n = Type.getType(((FieldInsnNode)abstractInsnNode).desc).getSize();
                "".length();
                if ("  ".length() != ((7 ^ 0x3C) & ~(0xAC ^ 0x97))) break;
                return null;
            }
            default: {
                n = 1;
            }
        }
        return new SourceValue(n, abstractInsnNode);
    }

    @Override
    public SourceValue binaryOperation(AbstractInsnNode abstractInsnNode, SourceValue sourceValue, SourceValue sourceValue2) {
        int n;
        switch (abstractInsnNode.getOpcode()) {
            case 47: 
            case 49: 
            case 97: 
            case 99: 
            case 101: 
            case 103: 
            case 105: 
            case 107: 
            case 109: 
            case 111: 
            case 113: 
            case 115: 
            case 121: 
            case 123: 
            case 125: 
            case 127: 
            case 129: 
            case 131: {
                n = 2;
                "".length();
                if ("  ".length() <= "   ".length()) break;
                return null;
            }
            default: {
                n = 1;
            }
        }
        return new SourceValue(n, abstractInsnNode);
    }

    @Override
    public SourceValue ternaryOperation(AbstractInsnNode abstractInsnNode, SourceValue sourceValue, SourceValue sourceValue2, SourceValue sourceValue3) {
        return new SourceValue(1, abstractInsnNode);
    }

    @Override
    public SourceValue naryOperation(AbstractInsnNode abstractInsnNode, List<? extends SourceValue> list) {
        int n;
        int n2 = abstractInsnNode.getOpcode();
        if (SourceInterpreter.lIIIIlllIIlI(n2, 197)) {
            n = 1;
            "".length();
            if ((0x7E ^ 0x7A) == " ".length()) {
                return null;
            }
        } else {
            String string;
            if (SourceInterpreter.lIIIIlllIIlI(n2, 186)) {
                string = ((InvokeDynamicInsnNode)abstractInsnNode).desc;
                "".length();
                if ((0x39 ^ 0x3D) < 0) {
                    return null;
                }
            } else {
                string = ((MethodInsnNode)abstractInsnNode).desc;
            }
            String string2 = string;
            n = Type.getReturnType(string2).getSize();
        }
        return new SourceValue(n, abstractInsnNode);
    }

    @Override
    public void returnOperation(AbstractInsnNode abstractInsnNode, SourceValue sourceValue, SourceValue sourceValue2) {
    }

    @Override
    public SourceValue merge(SourceValue sourceValue, SourceValue sourceValue2) {
        if (SourceInterpreter.lIIIIlllIIIl(sourceValue.insns instanceof SmallSet) && SourceInterpreter.lIIIIlllIIIl(sourceValue2.insns instanceof SmallSet)) {
            Set<AbstractInsnNode> set = ((SmallSet)sourceValue.insns).union((SmallSet)sourceValue2.insns);
            if (SourceInterpreter.lIIIIllIlllI(set, sourceValue.insns) && SourceInterpreter.lIIIIlllIIlI(sourceValue.size, sourceValue2.size)) {
                return sourceValue;
            }
            return new SourceValue(Math.min(sourceValue.size, sourceValue2.size), set);
        }
        if (!SourceInterpreter.lIIIIlllIIlI(sourceValue.size, sourceValue2.size) || SourceInterpreter.lIIIIlllIIII(sourceValue.insns.containsAll(sourceValue2.insns) ? 1 : 0)) {
            HashSet<AbstractInsnNode> hashSet = new HashSet<AbstractInsnNode>();
            hashSet.addAll(sourceValue.insns);
            "".length();
            hashSet.addAll(sourceValue2.insns);
            "".length();
            return new SourceValue(Math.min(sourceValue.size, sourceValue2.size), hashSet);
        }
        return sourceValue;
    }

    private static boolean lIIIIlllIIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIllIlllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIIllIllll(Object object) {
        return object == null;
    }

    private static boolean lIIIIlllIIIl(int n) {
        return n != 0;
    }

    private static boolean lIIIIlllIIII(int n) {
        return n == 0;
    }
}

