/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.Set;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.analysis.SmallSet;
import org.spongepowered.asm.lib.tree.analysis.Value;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class SourceValue
implements Value {
    public final int size;
    public final Set<AbstractInsnNode> insns;

    public SourceValue(int n) {
        this(n, SmallSet.emptySet());
    }

    public SourceValue(int n, AbstractInsnNode abstractInsnNode) {
        this.size = n;
        this.insns = new SmallSet<Object>(abstractInsnNode, null);
    }

    public SourceValue(int n, Set<AbstractInsnNode> set) {
        this.size = n;
        this.insns = set;
    }

    @Override
    public int getSize() {
        return this.size;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (SourceValue.lIIIlIIlIllI(object instanceof SourceValue)) {
            return false;
        }
        SourceValue sourceValue = (SourceValue)object;
        if (SourceValue.lIIIlIIlIlll(this.size, sourceValue.size) && SourceValue.lIIIlIIllIII(this.insns.equals(sourceValue.insns) ? 1 : 0)) {
            bl = true;
            "".length();
            if (((0x4F ^ 0x11 ^ (0x58 ^ 0xE)) & (105 + 89 - 157 + 92 ^ 111 + 101 - 163 + 88 ^ -" ".length())) < 0) {
                return ((0x41 ^ 0x19 ^ (0xB8 ^ 0xAA)) & (0xF8 ^ 0xAA ^ (0x18 ^ 0) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.insns.hashCode();
    }

    private static boolean lIIIlIIlIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIIllIII(int n) {
        return n != 0;
    }

    private static boolean lIIIlIIlIllI(int n) {
        return n == 0;
    }
}

