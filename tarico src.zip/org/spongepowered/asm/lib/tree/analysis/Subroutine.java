/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.tree.analysis;

import java.util.ArrayList;
import java.util.List;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;

class Subroutine {
    LabelNode start;
    boolean[] access;
    List<JumpInsnNode> callers;

    private Subroutine() {
    }

    Subroutine(LabelNode labelNode, int n, JumpInsnNode jumpInsnNode) {
        this.start = labelNode;
        this.access = new boolean[n];
        this.callers = new ArrayList<JumpInsnNode>();
        this.callers.add(jumpInsnNode);
        "".length();
    }

    public Subroutine copy() {
        Subroutine subroutine = new Subroutine();
        subroutine.start = this.start;
        subroutine.access = new boolean[this.access.length];
        System.arraycopy(this.access, 0, subroutine.access, 0, this.access.length);
        subroutine.callers = new ArrayList<JumpInsnNode>(this.callers);
        return subroutine;
    }

    public boolean merge(Subroutine subroutine) {
        boolean bl = false;
        int n = 0;
        while (Subroutine.lIlIIIIl(n, this.access.length)) {
            if (Subroutine.lIlIIIlI(subroutine.access[n]) && Subroutine.lIlIIIll(this.access[n])) {
                this.access[n] = true;
                bl = true;
            }
            ++n;
            "".length();
            if (" ".length() >= 0) continue;
            return ((0x9A ^ 0xB5) & ~(0x50 ^ 0x7F)) != 0;
        }
        if (Subroutine.lIlIIlII(subroutine.start, this.start)) {
            n = 0;
            while (Subroutine.lIlIIIIl(n, subroutine.callers.size())) {
                JumpInsnNode jumpInsnNode = subroutine.callers.get(n);
                if (Subroutine.lIlIIIll(this.callers.contains(jumpInsnNode) ? 1 : 0)) {
                    this.callers.add(jumpInsnNode);
                    "".length();
                    bl = true;
                }
                ++n;
                "".length();
                if ("  ".length() < "   ".length()) continue;
                return ((0xD6 ^ 0x96) & ~(0x27 ^ 0x67)) != 0;
            }
        }
        return bl;
    }

    private static boolean lIlIIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIlIIIlI(int n) {
        return n != 0;
    }

    private static boolean lIlIIIll(int n) {
        return n == 0;
    }
}

