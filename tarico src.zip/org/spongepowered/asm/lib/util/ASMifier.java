/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.util.ASMifiable;
import org.spongepowered.asm.lib.util.Printer;
import org.spongepowered.asm.lib.util.TraceClassVisitor;

public class ASMifier
extends Printer {
    protected final String name;
    protected final int id;
    protected Map<Label, String> labelNames;
    private static final int ACCESS_CLASS;
    private static final int ACCESS_FIELD;
    private static final int ACCESS_INNER;

    public ASMifier() {
        this(327680, "cw", 0);
        if (ASMifier.lIllIlll(this.getClass(), ASMifier.class)) {
            throw new IllegalStateException();
        }
    }

    protected ASMifier(int n, String string, int n2) {
        super(n);
        this.name = string;
        this.id = n2;
    }

    public static void main(String[] stringArray) {
        ClassReader classReader;
        int n = 0;
        int n2 = 2;
        int n3 = 1;
        if (!ASMifier.lIlllIII(stringArray.length, 1) || ASMifier.lIlllIIl(stringArray.length, 2)) {
            n3 = 0;
        }
        if (ASMifier.lIlllIlI(n3) && ASMifier.lIlllIlI("-debug".equals(stringArray[0]) ? 1 : 0)) {
            n = 1;
            n2 = 0;
            if (ASMifier.lIlllIll(stringArray.length, 2)) {
                n3 = 0;
            }
        }
        if (ASMifier.lIllllII(n3)) {
            System.err.println("Prints the ASM code to generate the given class.");
            System.err.println("Usage: ASMifier [-debug] <fully qualified class name or class file name>");
            return;
        }
        if (!ASMifier.lIllllII(stringArray[n].endsWith(".class") ? 1 : 0) || !ASMifier.lIllllIl(stringArray[n].indexOf(92), -1) || ASMifier.lIlllIIl(stringArray[n].indexOf(47), -1)) {
            classReader = new ClassReader(new FileInputStream(stringArray[n]));
            "".length();
            if (((0xE ^ 0x2A) & ~(0x6E ^ 0x4A)) == " ".length()) {
                return;
            }
        } else {
            classReader = new ClassReader(stringArray[n]);
        }
        classReader.accept(new TraceClassVisitor(null, new ASMifier(), new PrintWriter(System.out)), n2);
    }

    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        String string4;
        int n3 = string.lastIndexOf(47);
        if (ASMifier.lIlllllI(n3, -1)) {
            string4 = string;
            "".length();
            if (((0x74 ^ 0x1F ^ (0x4C ^ 0x2B)) & (0x17 ^ 0x63 ^ (0x42 ^ 0x3A) ^ -" ".length())) <= -" ".length()) {
                return;
            }
        } else {
            this.text.add(String.valueOf(new StringBuilder().append("package asm.").append(string.substring(0, n3).replace('/', '.')).append(";\n")));
            "".length();
            string4 = string.substring(n3 + 1);
        }
        this.text.add("import java.util.*;\n");
        "".length();
        this.text.add("import org.objectweb.asm.*;\n");
        "".length();
        this.text.add(String.valueOf(new StringBuilder().append("public class ").append(string4).append("Dump implements Opcodes {\n\n")));
        "".length();
        this.text.add("public static byte[] dump () throws Exception {\n\n");
        "".length();
        this.text.add("ClassWriter cw = new ClassWriter(0);\n");
        "".length();
        this.text.add("FieldVisitor fv;\n");
        "".length();
        this.text.add("MethodVisitor mv;\n");
        "".length();
        this.text.add("AnnotationVisitor av0;\n\n");
        "".length();
        this.buf.setLength(0);
        this.buf.append("cw.visit(");
        "".length();
        switch (n) {
            case 196653: {
                this.buf.append("V1_1");
                "".length();
                "".length();
                if (null == null) break;
                return;
            }
            case 46: {
                this.buf.append("V1_2");
                "".length();
                "".length();
                if ("  ".length() == "  ".length()) break;
                return;
            }
            case 47: {
                this.buf.append("V1_3");
                "".length();
                "".length();
                if ("  ".length() != " ".length()) break;
                return;
            }
            case 48: {
                this.buf.append("V1_4");
                "".length();
                "".length();
                if ("  ".length() > 0) break;
                return;
            }
            case 49: {
                this.buf.append("V1_5");
                "".length();
                "".length();
                if (" ".length() > ((0x85 ^ 0x9A) & ~(0xAA ^ 0xB5))) break;
                return;
            }
            case 50: {
                this.buf.append("V1_6");
                "".length();
                "".length();
                if (-"   ".length() <= 0) break;
                return;
            }
            case 51: {
                this.buf.append("V1_7");
                "".length();
                "".length();
                if (" ".length() <= "   ".length()) break;
                return;
            }
            default: {
                this.buf.append(n);
                "".length();
            }
        }
        this.buf.append(", ");
        "".length();
        this.appendAccess(n2 | 0x40000);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(", ");
        "".length();
        if (ASMifier.lIllllll(stringArray) && ASMifier.llIIIIII(stringArray.length)) {
            this.buf.append("new String[] {");
            "".length();
            int n4 = 0;
            while (ASMifier.llIIIIIl(n4, stringArray.length)) {
                String string5;
                if (ASMifier.lIllllII(n4)) {
                    string5 = " ";
                    "".length();
                    if (null != null) {
                        return;
                    }
                } else {
                    string5 = ", ";
                }
                this.buf.append(string5);
                "".length();
                this.appendConstant(stringArray[n4]);
                ++n4;
                "".length();
                if (null == null) continue;
                return;
            }
            this.buf.append(" }");
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else {
            this.buf.append("null");
            "".length();
        }
        this.buf.append(");\n\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitSource(String string, String string2) {
        this.buf.setLength(0);
        this.buf.append("cw.visitSource(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(");\n\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitOuterClass(String string, String string2, String string3) {
        this.buf.setLength(0);
        this.buf.append("cw.visitOuterClass(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(");\n\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitClassAnnotation(String string, boolean bl) {
        return this.visitAnnotation(string, bl);
    }

    public ASMifier visitClassTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public void visitClassAttribute(Attribute attribute) {
        this.visitAttribute(attribute);
    }

    public void visitInnerClass(String string, String string2, String string3, int n) {
        this.buf.setLength(0);
        this.buf.append("cw.visitInnerClass(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(", ");
        "".length();
        this.appendAccess(n | 0x100000);
        this.buf.append(");\n\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitField(int n, String string, String string2, String string3, Object object) {
        this.buf.setLength(0);
        this.buf.append("{\n");
        "".length();
        this.buf.append("fv = cw.visitField(");
        "".length();
        this.appendAccess(n | 0x80000);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(", ");
        "".length();
        this.appendConstant(object);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("fv", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public ASMifier visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        this.buf.setLength(0);
        this.buf.append("{\n");
        "".length();
        this.buf.append("mv = cw.visitMethod(");
        "".length();
        this.appendAccess(n);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(", ");
        "".length();
        if (ASMifier.lIllllll(stringArray) && ASMifier.llIIIIII(stringArray.length)) {
            this.buf.append("new String[] {");
            "".length();
            int n2 = 0;
            while (ASMifier.llIIIIIl(n2, stringArray.length)) {
                String string4;
                if (ASMifier.lIllllII(n2)) {
                    string4 = " ";
                    "".length();
                    if (null != null) {
                        return null;
                    }
                } else {
                    string4 = ", ";
                }
                this.buf.append(string4);
                "".length();
                this.appendConstant(stringArray[n2]);
                ++n2;
                "".length();
                if (null == null) continue;
                return null;
            }
            this.buf.append(" }");
            "".length();
            "".length();
            if ((0x40 ^ 0x30 ^ (0x61 ^ 0x15)) < 0) {
                return null;
            }
        } else {
            this.buf.append("null");
            "".length();
        }
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("mv", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public void visitClassEnd() {
        this.text.add("cw.visitEnd();\n\n");
        "".length();
        this.text.add("return cw.toByteArray();\n");
        "".length();
        this.text.add("}\n");
        "".length();
        this.text.add("}\n");
        "".length();
    }

    public void visit(String string, Object object) {
        this.buf.setLength(0);
        this.buf.append("av").append(this.id).append(".visit(");
        "".length();
        ASMifier.appendConstant(this.buf, string);
        this.buf.append(", ");
        "".length();
        ASMifier.appendConstant(this.buf, object);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitEnum(String string, String string2, String string3) {
        this.buf.setLength(0);
        this.buf.append("av").append(this.id).append(".visitEnum(");
        "".length();
        ASMifier.appendConstant(this.buf, string);
        this.buf.append(", ");
        "".length();
        ASMifier.appendConstant(this.buf, string2);
        this.buf.append(", ");
        "".length();
        ASMifier.appendConstant(this.buf, string3);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitAnnotation(String string, String string2) {
        this.buf.setLength(0);
        this.buf.append("{\n");
        "".length();
        this.buf.append("AnnotationVisitor av").append(this.id + 1).append(" = av");
        "".length();
        this.buf.append(this.id).append(".visitAnnotation(");
        "".length();
        ASMifier.appendConstant(this.buf, string);
        this.buf.append(", ");
        "".length();
        ASMifier.appendConstant(this.buf, string2);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", this.id + 1);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public ASMifier visitArray(String string) {
        this.buf.setLength(0);
        this.buf.append("{\n");
        "".length();
        this.buf.append("AnnotationVisitor av").append(this.id + 1).append(" = av");
        "".length();
        this.buf.append(this.id).append(".visitArray(");
        "".length();
        ASMifier.appendConstant(this.buf, string);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", this.id + 1);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public void visitAnnotationEnd() {
        this.buf.setLength(0);
        this.buf.append("av").append(this.id).append(".visitEnd();\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitFieldAnnotation(String string, boolean bl) {
        return this.visitAnnotation(string, bl);
    }

    public ASMifier visitFieldTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public void visitFieldAttribute(Attribute attribute) {
        this.visitAttribute(attribute);
    }

    public void visitFieldEnd() {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitEnd();\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitParameter(String string, int n) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitParameter(");
        "".length();
        ASMifier.appendString(this.buf, string);
        this.buf.append(", ");
        "".length();
        this.appendAccess(n);
        this.text.add(this.buf.append(");\n").toString());
        "".length();
    }

    public ASMifier visitAnnotationDefault() {
        this.buf.setLength(0);
        this.buf.append("{\n").append("av0 = ").append(this.name).append(".visitAnnotationDefault();\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public ASMifier visitMethodAnnotation(String string, boolean bl) {
        return this.visitAnnotation(string, bl);
    }

    public ASMifier visitMethodTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public ASMifier visitParameterAnnotation(int n, String string, boolean bl) {
        this.buf.setLength(0);
        this.buf.append("{\n").append("av0 = ").append(this.name).append(".visitParameterAnnotation(").append(n).append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ").append(bl).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public void visitMethodAttribute(Attribute attribute) {
        this.visitAttribute(attribute);
    }

    public void visitCode() {
        this.text.add(String.valueOf(new StringBuilder().append(this.name).append(".visitCode();\n")));
        "".length();
    }

    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        this.buf.setLength(0);
        switch (n) {
            case -1: 
            case 0: {
                this.declareFrameTypes(n2, objectArray);
                this.declareFrameTypes(n3, objectArray2);
                if (ASMifier.lIlllllI(n, -1)) {
                    this.buf.append(this.name).append(".visitFrame(Opcodes.F_NEW, ");
                    "".length();
                    "".length();
                    if ((0x6D ^ 8 ^ (0x4B ^ 0x2A)) == 0) {
                        return;
                    }
                } else {
                    this.buf.append(this.name).append(".visitFrame(Opcodes.F_FULL, ");
                    "".length();
                }
                this.buf.append(n2).append(", new Object[] {");
                "".length();
                this.appendFrameTypes(n2, objectArray);
                this.buf.append("}, ").append(n3).append(", new Object[] {");
                "".length();
                this.appendFrameTypes(n3, objectArray2);
                this.buf.append('}');
                "".length();
                "".length();
                if (-" ".length() <= 0) break;
                return;
            }
            case 1: {
                this.declareFrameTypes(n2, objectArray);
                this.buf.append(this.name).append(".visitFrame(Opcodes.F_APPEND,").append(n2).append(", new Object[] {");
                "".length();
                this.appendFrameTypes(n2, objectArray);
                this.buf.append("}, 0, null");
                "".length();
                "".length();
                if (-" ".length() < "   ".length()) break;
                return;
            }
            case 2: {
                this.buf.append(this.name).append(".visitFrame(Opcodes.F_CHOP,").append(n2).append(", null, 0, null");
                "".length();
                "".length();
                if (-" ".length() <= 0) break;
                return;
            }
            case 3: {
                this.buf.append(this.name).append(".visitFrame(Opcodes.F_SAME, 0, null, 0, null");
                "".length();
                "".length();
                if ("  ".length() > -" ".length()) break;
                return;
            }
            case 4: {
                this.declareFrameTypes(1, objectArray2);
                this.buf.append(this.name).append(".visitFrame(Opcodes.F_SAME1, 0, null, 1, new Object[] {");
                "".length();
                this.appendFrameTypes(1, objectArray2);
                this.buf.append('}');
                "".length();
            }
        }
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitInsn(int n) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitInsn(").append(OPCODES[n]).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitIntInsn(int n, int n2) {
        String string;
        this.buf.setLength(0);
        StringBuffer stringBuffer = this.buf.append(this.name).append(".visitIntInsn(").append(OPCODES[n]).append(", ");
        if (ASMifier.lIlllllI(n, 188)) {
            string = TYPES[n2];
            "".length();
            if (((41 + 77 - 91 + 153 ^ 74 + 14 - 43 + 87) & (0x6C ^ 0x1D ^ (0x4F ^ 0xE) ^ -" ".length())) != 0) {
                return;
            }
        } else {
            string = Integer.toString(n2);
        }
        stringBuffer.append(string).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitVarInsn(int n, int n2) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitVarInsn(").append(OPCODES[n]).append(", ").append(n2).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitTypeInsn(int n, String string) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitTypeInsn(").append(OPCODES[n]).append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitFieldInsn(int n, String string, String string2, String string3) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitFieldInsn(").append(OPCODES[n]).append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    @Deprecated
    public void visitMethodInsn(int n, String string, String string2, String string3) {
        boolean bl;
        if (ASMifier.lIlllIII(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3);
            return;
        }
        if (ASMifier.lIlllllI(n, 185)) {
            bl = true;
            "".length();
            if ("   ".length() <= ((0x33 ^ 0x2E) & ~(0x3B ^ 0x26))) {
                return;
            }
        } else {
            bl = false;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (ASMifier.llIIIIIl(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3, bl);
            return;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    private void doVisitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        String string4;
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitMethodInsn(").append(OPCODES[n]).append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(", ");
        "".length();
        if (ASMifier.lIlllIlI(bl ? 1 : 0)) {
            string4 = "true";
            "".length();
            if (-(0x62 ^ 0x66) > 0) {
                return;
            }
        } else {
            string4 = "false";
        }
        this.buf.append(string4);
        "".length();
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitInvokeDynamicInsn(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(handle);
        this.buf.append(", new Object[]{");
        "".length();
        int n = 0;
        while (ASMifier.llIIIIIl(n, objectArray.length)) {
            this.appendConstant(objectArray[n]);
            if (ASMifier.lIlllIll(n, objectArray.length - 1)) {
                this.buf.append(", ");
                "".length();
            }
            ++n;
            "".length();
            if (null == null) continue;
            return;
        }
        this.buf.append("});\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitJumpInsn(int n, Label label) {
        this.buf.setLength(0);
        this.declareLabel(label);
        this.buf.append(this.name).append(".visitJumpInsn(").append(OPCODES[n]).append(", ");
        "".length();
        this.appendLabel(label);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitLabel(Label label) {
        this.buf.setLength(0);
        this.declareLabel(label);
        this.buf.append(this.name).append(".visitLabel(");
        "".length();
        this.appendLabel(label);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitLdcInsn(Object object) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitLdcInsn(");
        "".length();
        this.appendConstant(object);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitIincInsn(int n, int n2) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitIincInsn(").append(n).append(", ").append(n2).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitTableSwitchInsn(int n, int n2, Label label, Label ... labelArray) {
        this.buf.setLength(0);
        int n3 = 0;
        while (ASMifier.llIIIIIl(n3, labelArray.length)) {
            this.declareLabel(labelArray[n3]);
            ++n3;
            "".length();
            if (-(0x92 ^ 0xB5 ^ (0x81 ^ 0xA2)) <= 0) continue;
            return;
        }
        this.declareLabel(label);
        this.buf.append(this.name).append(".visitTableSwitchInsn(").append(n).append(", ").append(n2).append(", ");
        "".length();
        this.appendLabel(label);
        this.buf.append(", new Label[] {");
        "".length();
        n3 = 0;
        while (ASMifier.llIIIIIl(n3, labelArray.length)) {
            String string;
            if (ASMifier.lIllllII(n3)) {
                string = " ";
                "".length();
                if ("  ".length() == -" ".length()) {
                    return;
                }
            } else {
                string = ", ";
            }
            this.buf.append(string);
            "".length();
            this.appendLabel(labelArray[n3]);
            ++n3;
            "".length();
            if (" ".length() > -" ".length()) continue;
            return;
        }
        this.buf.append(" });\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitLookupSwitchInsn(Label label, int[] nArray, Label[] labelArray) {
        this.buf.setLength(0);
        int n = 0;
        while (ASMifier.llIIIIIl(n, labelArray.length)) {
            this.declareLabel(labelArray[n]);
            ++n;
            "".length();
            if (" ".length() == " ".length()) continue;
            return;
        }
        this.declareLabel(label);
        this.buf.append(this.name).append(".visitLookupSwitchInsn(");
        "".length();
        this.appendLabel(label);
        this.buf.append(", new int[] {");
        "".length();
        n = 0;
        while (ASMifier.llIIIIIl(n, nArray.length)) {
            String string;
            if (ASMifier.lIllllII(n)) {
                string = " ";
                "".length();
                if (((0x7E ^ 0x56) & ~(0x3F ^ 0x17)) == (0x28 ^ 0x2C)) {
                    return;
                }
            } else {
                string = ", ";
            }
            this.buf.append(string).append(nArray[n]);
            "".length();
            ++n;
            "".length();
            if (null == null) continue;
            return;
        }
        this.buf.append(" }, new Label[] {");
        "".length();
        n = 0;
        while (ASMifier.llIIIIIl(n, labelArray.length)) {
            String string;
            if (ASMifier.lIllllII(n)) {
                string = " ";
                "".length();
                if ((140 + 139 - 257 + 134 ^ 88 + 19 - 106 + 151) <= 0) {
                    return;
                }
            } else {
                string = ", ";
            }
            this.buf.append(string);
            "".length();
            this.appendLabel(labelArray[n]);
            ++n;
            "".length();
            if ("  ".length() > ((0x32 ^ 0x37) & ~(0x58 ^ 0x5D))) continue;
            return;
        }
        this.buf.append(" });\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitMultiANewArrayInsn(String string, int n) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitMultiANewArrayInsn(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ").append(n).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation("visitInsnAnnotation", n, typePath, string, bl);
    }

    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        this.buf.setLength(0);
        this.declareLabel(label);
        this.declareLabel(label2);
        this.declareLabel(label3);
        this.buf.append(this.name).append(".visitTryCatchBlock(");
        "".length();
        this.appendLabel(label);
        this.buf.append(", ");
        "".length();
        this.appendLabel(label2);
        this.buf.append(", ");
        "".length();
        this.appendLabel(label3);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation("visitTryCatchAnnotation", n, typePath, string, bl);
    }

    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitLocalVariable(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string2);
        this.buf.append(", ");
        "".length();
        this.appendConstant(string3);
        this.buf.append(", ");
        "".length();
        this.appendLabel(label);
        this.buf.append(", ");
        "".length();
        this.appendLabel(label2);
        this.buf.append(", ").append(n).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Printer visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        this.buf.setLength(0);
        this.buf.append("{\n").append("av0 = ").append(this.name).append(".visitLocalVariableAnnotation(");
        "".length();
        this.buf.append(n);
        "".length();
        if (ASMifier.llIIIIlI(typePath)) {
            this.buf.append(", null, ");
            "".length();
            "".length();
            if (((77 + 53 - 75 + 95 ^ 95 + 105 - 31 + 18) & (0x71 ^ 0 ^ (0x9E ^ 0xC2) ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            this.buf.append(", TypePath.fromString(\"").append(typePath).append("\"), ");
            "".length();
        }
        this.buf.append("new Label[] {");
        "".length();
        int n2 = 0;
        while (ASMifier.llIIIIIl(n2, labelArray.length)) {
            String string2;
            if (ASMifier.lIllllII(n2)) {
                string2 = " ";
                "".length();
                if ("   ".length() <= 0) {
                    return null;
                }
            } else {
                string2 = ", ";
            }
            this.buf.append(string2);
            "".length();
            this.appendLabel(labelArray[n2]);
            ++n2;
            "".length();
            if (((0x71 ^ 0x29) & ~(0x47 ^ 0x1F)) >= 0) continue;
            return null;
        }
        this.buf.append(" }, new Label[] {");
        "".length();
        n2 = 0;
        while (ASMifier.llIIIIIl(n2, labelArray2.length)) {
            String string3;
            if (ASMifier.lIllllII(n2)) {
                string3 = " ";
                "".length();
                if (((0x5B ^ 0x73 ^ (0xB2 ^ 0x81)) & (99 + 39 - 29 + 23 ^ 134 + 99 - 127 + 53 ^ -" ".length())) < -" ".length()) {
                    return null;
                }
            } else {
                string3 = ", ";
            }
            this.buf.append(string3);
            "".length();
            this.appendLabel(labelArray2[n2]);
            ++n2;
            "".length();
            if (" ".length() <= "   ".length()) continue;
            return null;
        }
        this.buf.append(" }, new int[] {");
        "".length();
        n2 = 0;
        while (ASMifier.llIIIIIl(n2, nArray.length)) {
            String string4;
            if (ASMifier.lIllllII(n2)) {
                string4 = " ";
                "".length();
                if ((0x2F ^ 0x2B) <= ((0xA2 ^ 0xA7) & ~(0x6E ^ 0x6B))) {
                    return null;
                }
            } else {
                string4 = ", ";
            }
            this.buf.append(string4).append(nArray[n2]);
            "".length();
            ++n2;
            "".length();
            if ("  ".length() > -" ".length()) continue;
            return null;
        }
        this.buf.append(" }, ");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ").append(bl).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public void visitLineNumber(int n, Label label) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitLineNumber(").append(n).append(", ");
        "".length();
        this.appendLabel(label);
        this.buf.append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitMaxs(int n, int n2) {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitMaxs(").append(n).append(", ").append(n2).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitMethodEnd() {
        this.buf.setLength(0);
        this.buf.append(this.name).append(".visitEnd();\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public ASMifier visitAnnotation(String string, boolean bl) {
        this.buf.setLength(0);
        this.buf.append("{\n").append("av0 = ").append(this.name).append(".visitAnnotation(");
        "".length();
        this.appendConstant(string);
        this.buf.append(", ").append(bl).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public ASMifier visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation("visitTypeAnnotation", n, typePath, string, bl);
    }

    public ASMifier visitTypeAnnotation(String string, int n, TypePath typePath, String string2, boolean bl) {
        this.buf.setLength(0);
        this.buf.append("{\n").append("av0 = ").append(this.name).append(".").append(string).append("(");
        "".length();
        this.buf.append(n);
        "".length();
        if (ASMifier.llIIIIlI(typePath)) {
            this.buf.append(", null, ");
            "".length();
            "".length();
            if (-" ".length() >= 0) {
                return null;
            }
        } else {
            this.buf.append(", TypePath.fromString(\"").append(typePath).append("\"), ");
            "".length();
        }
        this.appendConstant(string2);
        this.buf.append(", ").append(bl).append(");\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        ASMifier aSMifier = this.createASMifier("av", 0);
        this.text.add(aSMifier.getText());
        "".length();
        this.text.add("}\n");
        "".length();
        return aSMifier;
    }

    public void visitAttribute(Attribute attribute) {
        this.buf.setLength(0);
        this.buf.append("// ATTRIBUTE ").append(attribute.type).append('\n');
        "".length();
        if (ASMifier.lIlllIlI(attribute instanceof ASMifiable)) {
            if (ASMifier.llIIIIlI(this.labelNames)) {
                this.labelNames = new HashMap<Label, String>();
            }
            this.buf.append("{\n");
            "".length();
            ((ASMifiable)((Object)attribute)).asmify(this.buf, "attr", this.labelNames);
            this.buf.append(this.name).append(".visitAttribute(attr);\n");
            "".length();
            this.buf.append("}\n");
            "".length();
        }
        this.text.add(this.buf.toString());
        "".length();
    }

    protected ASMifier createASMifier(String string, int n) {
        return new ASMifier(327680, string, n);
    }

    void appendAccess(int n) {
        int n2 = 1;
        if (ASMifier.lIlllIlI(n & 1)) {
            this.buf.append("ACC_PUBLIC");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 2)) {
            this.buf.append("ACC_PRIVATE");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 4)) {
            this.buf.append("ACC_PROTECTED");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x10)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_FINAL");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 8)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_STATIC");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x20)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            if (ASMifier.lIllllII(n & 0x40000)) {
                this.buf.append("ACC_SYNCHRONIZED");
                "".length();
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                this.buf.append("ACC_SUPER");
                "".length();
            }
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x40) && ASMifier.lIlllIlI(n & 0x80000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_VOLATILE");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x40) && ASMifier.lIllllII(n & 0x40000) && ASMifier.lIllllII(n & 0x80000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_BRIDGE");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x80) && ASMifier.lIllllII(n & 0x40000) && ASMifier.lIllllII(n & 0x80000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_VARARGS");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x80) && ASMifier.lIlllIlI(n & 0x80000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_TRANSIENT");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x100) && ASMifier.lIllllII(n & 0x40000) && ASMifier.lIllllII(n & 0x80000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_NATIVE");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x4000) && (!ASMifier.lIllllII(n & 0x40000) || !ASMifier.lIllllII(n & 0x80000) || ASMifier.lIlllIlI(n & 0x100000))) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_ENUM");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x2000) && (!ASMifier.lIllllII(n & 0x40000) || ASMifier.lIlllIlI(n & 0x100000))) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_ANNOTATION");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x400)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_ABSTRACT");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x200)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_INTERFACE");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x800)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_STRICT");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x1000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_SYNTHETIC");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x20000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_DEPRECATED");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n & 0x8000)) {
            if (ASMifier.lIllllII(n2)) {
                this.buf.append(" + ");
                "".length();
            }
            this.buf.append("ACC_MANDATED");
            "".length();
            n2 = 0;
        }
        if (ASMifier.lIlllIlI(n2)) {
            this.buf.append('0');
            "".length();
        }
    }

    protected void appendConstant(Object object) {
        ASMifier.appendConstant(this.buf, object);
    }

    static void appendConstant(StringBuffer stringBuffer, Object object) {
        if (ASMifier.llIIIIlI(object)) {
            stringBuffer.append("null");
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof String)) {
            ASMifier.appendString(stringBuffer, (String)object);
            "".length();
            if (-" ".length() >= 0) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Type)) {
            stringBuffer.append("Type.getType(\"");
            "".length();
            stringBuffer.append(((Type)object).getDescriptor());
            "".length();
            stringBuffer.append("\")");
            "".length();
            "".length();
            if (((0xD9 ^ 0x80 ^ (0xCE ^ 0xA0)) & (0x60 ^ 0x5C ^ (0xBB ^ 0xB0) ^ -" ".length())) > "   ".length()) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Handle)) {
            stringBuffer.append("new Handle(");
            "".length();
            Handle handle = (Handle)object;
            stringBuffer.append("Opcodes.").append(HANDLE_TAG[handle.getTag()]).append(", \"");
            "".length();
            stringBuffer.append(handle.getOwner()).append("\", \"");
            "".length();
            stringBuffer.append(handle.getName()).append("\", \"");
            "".length();
            stringBuffer.append(handle.getDesc()).append("\")");
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Byte)) {
            stringBuffer.append("new Byte((byte)").append(object).append(')');
            "".length();
            "".length();
            if (" ".length() < 0) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Boolean)) {
            String string;
            if (ASMifier.lIlllIlI(((Boolean)object).booleanValue() ? 1 : 0)) {
                string = "Boolean.TRUE";
                "".length();
                if (" ".length() >= "  ".length()) {
                    return;
                }
            } else {
                string = "Boolean.FALSE";
            }
            stringBuffer.append(string);
            "".length();
            "".length();
            if (((0x86 ^ 0x8B) & ~(0x43 ^ 0x4E)) > 0) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Short)) {
            stringBuffer.append("new Short((short)").append(object).append(')');
            "".length();
            "".length();
            if ((0x40 ^ 0x44) < " ".length()) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Character)) {
            char c = ((Character)object).charValue();
            stringBuffer.append("new Character((char)").append((int)c).append(')');
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Integer)) {
            stringBuffer.append("new Integer(").append(object).append(')');
            "".length();
            "".length();
            if ((104 + 59 - 118 + 101 ^ 5 + 82 - -7 + 57) == 0) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Float)) {
            stringBuffer.append("new Float(\"").append(object).append("\")");
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Long)) {
            stringBuffer.append("new Long(").append(object).append("L)");
            "".length();
            "".length();
            if ((0x8F ^ 0x8B) != (0x94 ^ 0x90)) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof Double)) {
            stringBuffer.append("new Double(\"").append(object).append("\")");
            "".length();
            "".length();
            if ("   ".length() < "  ".length()) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof byte[])) {
            byte[] byArray = (byte[])object;
            stringBuffer.append("new byte[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, byArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if ((0xB ^ 0xF) <= 0) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append(byArray[n]);
                "".length();
                ++n;
                "".length();
                if (-" ".length() < 0) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof boolean[])) {
            boolean[] blArray = (boolean[])object;
            stringBuffer.append("new boolean[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, blArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if (-"   ".length() >= 0) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append(blArray[n]);
                "".length();
                ++n;
                "".length();
                if (-"   ".length() < 0) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if ((0x31 ^ 0x73 ^ (0x4A ^ 0xC)) <= ((0xFC ^ 0xBA ^ (0x56 ^ 0x5D)) & (0x3A ^ 0x43 ^ (0x2D ^ 0x19) ^ -" ".length()))) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof short[])) {
            short[] sArray = (short[])object;
            stringBuffer.append("new short[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, sArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if (-"  ".length() > 0) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append("(short)").append(sArray[n]);
                "".length();
                ++n;
                "".length();
                if (((0x47 ^ 0x3A ^ (0x55 ^ 0x27)) & (0x37 ^ 0x62 ^ (0x45 ^ 0x1F) ^ -" ".length())) <= "  ".length()) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if (((0x7A ^ 0x2A) & ~(0x6C ^ 0x3C)) <= -" ".length()) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof char[])) {
            char[] cArray = (char[])object;
            stringBuffer.append("new char[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, cArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if (-"   ".length() > 0) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append("(char)").append((int)cArray[n]);
                "".length();
                ++n;
                "".length();
                if ("  ".length() >= 0) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if ("  ".length() == 0) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof int[])) {
            int[] nArray = (int[])object;
            stringBuffer.append("new int[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, nArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if (" ".length() == 0) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append(nArray[n]);
                "".length();
                ++n;
                "".length();
                if (((0x2D ^ 0x1E ^ (0x15 ^ 0x60)) & (0x4F ^ 0x37 ^ (0x93 ^ 0xAD) ^ -" ".length())) >= ((111 + 57 - 20 + 4 ^ 16 + 70 - 25 + 98) & (0x73 ^ 0x43 ^ (0x14 ^ 0x23) ^ -" ".length()))) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if ("  ".length() < "  ".length()) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof long[])) {
            long[] lArray = (long[])object;
            stringBuffer.append("new long[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, lArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if ((0x2C ^ 0x26 ^ (0x54 ^ 0x5A)) != (3 + 82 - 36 + 91 ^ 18 + 30 - 38 + 126)) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append(lArray[n]).append('L');
                "".length();
                ++n;
                "".length();
                if (-"   ".length() < 0) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if ((0x62 ^ 0x66) == 0) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof float[])) {
            float[] fArray = (float[])object;
            stringBuffer.append("new float[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, fArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if (((0xE0 ^ 0xBD) & ~(0x4D ^ 0x10)) >= " ".length()) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append(fArray[n]).append('f');
                "".length();
                ++n;
                "".length();
                if (" ".length() > ((0xE7 ^ 0xC7) & ~(0x42 ^ 0x62))) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
            "".length();
            if (null != null) {
                return;
            }
        } else if (ASMifier.lIlllIlI(object instanceof double[])) {
            double[] dArray = (double[])object;
            stringBuffer.append("new double[] {");
            "".length();
            int n = 0;
            while (ASMifier.llIIIIIl(n, dArray.length)) {
                String string;
                if (ASMifier.lIllllII(n)) {
                    string = "";
                    "".length();
                    if (-(0x8A ^ 0x92 ^ (0x7F ^ 0x63)) >= 0) {
                        return;
                    }
                } else {
                    string = ",";
                }
                stringBuffer.append(string).append(dArray[n]).append('d');
                "".length();
                ++n;
                "".length();
                if ("   ".length() > ((0xA2 ^ 0x9E) & ~(0x9B ^ 0xA7))) continue;
                return;
            }
            stringBuffer.append('}');
            "".length();
        }
    }

    private void declareFrameTypes(int n, Object[] objectArray) {
        int n2 = 0;
        while (ASMifier.llIIIIIl(n2, n)) {
            if (ASMifier.lIlllIlI(objectArray[n2] instanceof Label)) {
                this.declareLabel((Label)objectArray[n2]);
            }
            ++n2;
            "".length();
            if (-(0xFB ^ 0x98 ^ (0xFA ^ 0x9D)) < 0) continue;
            return;
        }
    }

    private void appendFrameTypes(int n, Object[] objectArray) {
        int n2 = 0;
        while (ASMifier.llIIIIIl(n2, n)) {
            if (ASMifier.llIIIIII(n2)) {
                this.buf.append(", ");
                "".length();
            }
            if (ASMifier.lIlllIlI(objectArray[n2] instanceof String)) {
                this.appendConstant(objectArray[n2]);
                "".length();
                if (null != null) {
                    return;
                }
            } else if (ASMifier.lIlllIlI(objectArray[n2] instanceof Integer)) {
                switch ((Integer)objectArray[n2]) {
                    case 0: {
                        this.buf.append("Opcodes.TOP");
                        "".length();
                        "".length();
                        if (" ".length() == " ".length()) break;
                        return;
                    }
                    case 1: {
                        this.buf.append("Opcodes.INTEGER");
                        "".length();
                        "".length();
                        if (((0xC2 ^ 0xA5 ^ (0x6E ^ 0x44)) & (4 + 95 - -88 + 43 ^ 40 + 83 - 68 + 116 ^ -" ".length())) != (70 + 137 - 116 + 63 ^ 140 + 120 - 194 + 92)) break;
                        return;
                    }
                    case 2: {
                        this.buf.append("Opcodes.FLOAT");
                        "".length();
                        "".length();
                        if (-" ".length() < "  ".length()) break;
                        return;
                    }
                    case 3: {
                        this.buf.append("Opcodes.DOUBLE");
                        "".length();
                        "".length();
                        if (-" ".length() != ((117 + 46 - 128 + 125 ^ 93 + 75 - 42 + 19) & (0x70 ^ 0x43 ^ "  ".length() ^ -" ".length()))) break;
                        return;
                    }
                    case 4: {
                        this.buf.append("Opcodes.LONG");
                        "".length();
                        "".length();
                        if ("   ".length() != ((101 + 136 - 135 + 95 ^ 63 + 67 - 106 + 171) & (4 + 74 - 16 + 73 ^ 85 + 61 - 119 + 102 ^ -" ".length()))) break;
                        return;
                    }
                    case 5: {
                        this.buf.append("Opcodes.NULL");
                        "".length();
                        "".length();
                        if (-" ".length() < 0) break;
                        return;
                    }
                    case 6: {
                        this.buf.append("Opcodes.UNINITIALIZED_THIS");
                        "".length();
                    }
                }
                "".length();
                if ((0x1B ^ 0x1F) == "  ".length()) {
                    return;
                }
            } else {
                this.appendLabel((Label)objectArray[n2]);
            }
            ++n2;
            "".length();
            if ("  ".length() != 0) continue;
            return;
        }
    }

    protected void declareLabel(Label label) {
        String string;
        if (ASMifier.llIIIIlI(this.labelNames)) {
            this.labelNames = new HashMap<Label, String>();
        }
        if (ASMifier.llIIIIlI(string = this.labelNames.get(label))) {
            string = String.valueOf(new StringBuilder().append("l").append(this.labelNames.size()));
            this.labelNames.put(label, string);
            "".length();
            this.buf.append("Label ").append(string).append(" = new Label();\n");
            "".length();
        }
    }

    protected void appendLabel(Label label) {
        this.buf.append(this.labelNames.get(label));
        "".length();
    }

    static {
        ACCESS_FIELD = 524288;
        ACCESS_INNER = 0x100000;
        ACCESS_CLASS = 262144;
    }

    private static boolean lIlllllI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlllIII(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIIIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllllIl(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIlllIIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllIlll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIllllll(Object object) {
        return object != null;
    }

    private static boolean llIIIIlI(Object object) {
        return object == null;
    }

    private static boolean lIlllIlI(int n) {
        return n != 0;
    }

    private static boolean lIllllII(int n) {
        return n == 0;
    }

    private static boolean llIIIIII(int n) {
        return n > 0;
    }

    private static boolean lIlllIll(int n, int n2) {
        return n != n2;
    }
}

