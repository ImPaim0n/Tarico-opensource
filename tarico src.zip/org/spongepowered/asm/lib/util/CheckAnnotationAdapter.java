/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.util.CheckMethodAdapter;

public class CheckAnnotationAdapter
extends AnnotationVisitor {
    private final boolean named;
    private boolean end;

    public CheckAnnotationAdapter(AnnotationVisitor annotationVisitor) {
        this(annotationVisitor, true);
    }

    CheckAnnotationAdapter(AnnotationVisitor annotationVisitor, boolean bl) {
        super(327680, annotationVisitor);
        this.named = bl;
    }

    public void visit(String string, Object object) {
        int n;
        this.checkEnd();
        this.checkName(string);
        if (CheckAnnotationAdapter.lIlIIIlllII(object instanceof Byte) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Boolean) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Character) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Short) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Integer) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Long) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Float) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Double) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof String) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof Type) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof byte[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof boolean[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof char[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof short[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof int[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof long[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof float[]) && CheckAnnotationAdapter.lIlIIIlllII(object instanceof double[])) {
            throw new IllegalArgumentException("Invalid annotation value");
        }
        if (CheckAnnotationAdapter.lIlIIIlllIl(object instanceof Type) && CheckAnnotationAdapter.lIlIIIllllI(n = ((Type)object).getSort(), 11)) {
            throw new IllegalArgumentException("Invalid annotation value");
        }
        if (CheckAnnotationAdapter.lIlIIlIIIII(this.av)) {
            this.av.visit(string, object);
        }
    }

    public void visitEnum(String string, String string2, String string3) {
        this.checkEnd();
        this.checkName(string);
        CheckMethodAdapter.checkDesc(string2, false);
        if (CheckAnnotationAdapter.lIlIIlIIIIl(string3)) {
            throw new IllegalArgumentException("Invalid enum value");
        }
        if (CheckAnnotationAdapter.lIlIIlIIIII(this.av)) {
            this.av.visitEnum(string, string2, string3);
        }
    }

    public AnnotationVisitor visitAnnotation(String string, String string2) {
        AnnotationVisitor annotationVisitor;
        this.checkEnd();
        this.checkName(string);
        CheckMethodAdapter.checkDesc(string2, false);
        if (CheckAnnotationAdapter.lIlIIlIIIIl(this.av)) {
            annotationVisitor = null;
            "".length();
            if (" ".length() <= ((0x51 ^ 0x68 ^ (0x78 ^ 0x6C)) & (132 + 83 - 124 + 92 ^ 10 + 2 - -42 + 100 ^ -" ".length()))) {
                return null;
            }
        } else {
            annotationVisitor = this.av.visitAnnotation(string, string2);
        }
        return new CheckAnnotationAdapter(annotationVisitor);
    }

    public AnnotationVisitor visitArray(String string) {
        AnnotationVisitor annotationVisitor;
        this.checkEnd();
        this.checkName(string);
        if (CheckAnnotationAdapter.lIlIIlIIIIl(this.av)) {
            annotationVisitor = null;
            "".length();
            if ((0x24 ^ 0x20) == -" ".length()) {
                return null;
            }
        } else {
            annotationVisitor = this.av.visitArray(string);
        }
        return new CheckAnnotationAdapter(annotationVisitor, false);
    }

    public void visitEnd() {
        this.checkEnd();
        this.end = true;
        if (CheckAnnotationAdapter.lIlIIlIIIII(this.av)) {
            this.av.visitEnd();
        }
    }

    private void checkEnd() {
        if (CheckAnnotationAdapter.lIlIIIlllIl(this.end ? 1 : 0)) {
            throw new IllegalStateException("Cannot call a visit method after visitEnd has been called");
        }
    }

    private void checkName(String string) {
        if (CheckAnnotationAdapter.lIlIIIlllIl(this.named ? 1 : 0) && CheckAnnotationAdapter.lIlIIlIIIIl(string)) {
            throw new IllegalArgumentException("Annotation value name must not be null");
        }
    }

    private static boolean lIlIIIllllI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlIIlIIIII(Object object) {
        return object != null;
    }

    private static boolean lIlIIlIIIIl(Object object) {
        return object == null;
    }

    private static boolean lIlIIIlllIl(int n) {
        return n != 0;
    }

    private static boolean lIlIIIlllII(int n) {
        return n == 0;
    }
}

