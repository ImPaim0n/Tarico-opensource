/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.analysis.Analyzer;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;
import org.spongepowered.asm.lib.tree.analysis.Frame;
import org.spongepowered.asm.lib.tree.analysis.SimpleVerifier;
import org.spongepowered.asm.lib.util.CheckAnnotationAdapter;
import org.spongepowered.asm.lib.util.CheckFieldAdapter;
import org.spongepowered.asm.lib.util.CheckMethodAdapter;
import org.spongepowered.asm.lib.util.Textifier;
import org.spongepowered.asm.lib.util.TraceMethodVisitor;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class CheckClassAdapter
extends ClassVisitor {
    private int version;
    private boolean start;
    private boolean source;
    private boolean outer;
    private boolean end;
    private Map<Label, Integer> labels = new HashMap<Label, Integer>();
    private boolean checkDataFlow;

    public static void main(String[] stringArray) {
        ClassReader classReader;
        if (CheckClassAdapter.lllIllIIIl(stringArray.length, 1)) {
            System.err.println("Verifies the given class.");
            System.err.println("Usage: CheckClassAdapter <fully qualified class name or class file name>");
            return;
        }
        if (CheckClassAdapter.lllIllIIlI(stringArray[0].endsWith(".class") ? 1 : 0)) {
            classReader = new ClassReader(new FileInputStream(stringArray[0]));
            "".length();
            if ((0xA4 ^ 0xA0) == 0) {
                return;
            }
        } else {
            classReader = new ClassReader(stringArray[0]);
        }
        CheckClassAdapter.verify(classReader, false, new PrintWriter(System.err));
    }

    public static void verify(ClassReader classReader, ClassLoader classLoader, boolean bl, PrintWriter printWriter) {
        Type type;
        ClassNode classNode = new ClassNode();
        classReader.accept(new CheckClassAdapter(classNode, false), 2);
        if (CheckClassAdapter.lllIllIIll(classNode.superName)) {
            type = null;
            "".length();
            if ("  ".length() < 0) {
                return;
            }
        } else {
            type = Type.getObjectType(classNode.superName);
        }
        Type type2 = type;
        List<MethodNode> list = classNode.methods;
        ArrayList<Type> arrayList = new ArrayList<Type>();
        Iterator<String> iterator = classNode.interfaces.iterator();
        while (CheckClassAdapter.lllIllIIlI(iterator.hasNext() ? 1 : 0)) {
            arrayList.add(Type.getObjectType(iterator.next()));
            "".length();
            "".length();
            if (-(0x4A ^ 0x4E) <= 0) continue;
            return;
        }
        int n = 0;
        while (CheckClassAdapter.lllIllIlII(n, list.size())) {
            block14: {
                Analyzer<BasicValue> analyzer;
                MethodNode methodNode;
                block13: {
                    boolean bl2;
                    methodNode = list.get(n);
                    Type type3 = Type.getObjectType(classNode.name);
                    if (CheckClassAdapter.lllIllIIlI(classNode.access & 0x200)) {
                        bl2 = true;
                        "".length();
                        if (((0x1C ^ 0x5A) & ~(0x75 ^ 0x33)) > "  ".length()) {
                            return;
                        }
                    } else {
                        bl2 = false;
                    }
                    SimpleVerifier simpleVerifier = new SimpleVerifier(type3, type2, arrayList, bl2);
                    analyzer = new Analyzer<BasicValue>(simpleVerifier);
                    if (CheckClassAdapter.lllIllIlIl(classLoader)) {
                        simpleVerifier.setClassLoader(classLoader);
                    }
                    try {
                        analyzer.analyze(classNode.name, methodNode);
                        "".length();
                        if (!CheckClassAdapter.lllIllIllI(bl ? 1 : 0)) break block13;
                        "".length();
                    }
                    catch (Exception exception) {
                        exception.printStackTrace(printWriter);
                    }
                    if (((0 ^ 0x48 ^ "  ".length()) & (0xE5 ^ 0x8C ^ (0xAF ^ 0x8C) ^ -" ".length())) != 0) {
                        return;
                    }
                    break block14;
                }
                "".length();
                if ((0x73 ^ 0x77) <= ((0x38 ^ 0x14) & ~(0x24 ^ 8))) {
                    return;
                }
                CheckClassAdapter.printAnalyzerResult(methodNode, analyzer, printWriter);
            }
            ++n;
            "".length();
            if (((125 + 91 - 100 + 29 ^ 122 + 39 - 75 + 42) & (27 + 160 - 135 + 163 ^ 89 + 62 - -46 + 1 ^ -" ".length())) == ((0xEF ^ 0x99 ^ (0x77 ^ 0x1A)) & (88 + 3 - 75 + 117 ^ 129 + 44 - 85 + 70 ^ -" ".length()))) continue;
            return;
        }
        printWriter.flush();
    }

    public static void verify(ClassReader classReader, boolean bl, PrintWriter printWriter) {
        CheckClassAdapter.verify(classReader, null, bl, printWriter);
    }

    static void printAnalyzerResult(MethodNode methodNode, Analyzer<BasicValue> analyzer, PrintWriter printWriter) {
        Frame<BasicValue>[] frameArray = analyzer.getFrames();
        Textifier textifier = new Textifier();
        TraceMethodVisitor traceMethodVisitor = new TraceMethodVisitor(textifier);
        printWriter.println(String.valueOf(new StringBuilder().append(methodNode.name).append(methodNode.desc)));
        int n = 0;
        while (CheckClassAdapter.lllIllIlII(n, methodNode.instructions.size())) {
            methodNode.instructions.get(n).accept(traceMethodVisitor);
            StringBuilder stringBuilder = new StringBuilder();
            Frame<BasicValue> frame = frameArray[n];
            if (CheckClassAdapter.lllIllIIll(frame)) {
                stringBuilder.append('?');
                "".length();
                "".length();
                if ("   ".length() >= (0x3B ^ 0x68 ^ (0x2F ^ 0x78))) {
                    return;
                }
            } else {
                int n2 = 0;
                while (CheckClassAdapter.lllIllIlII(n2, frame.getLocals())) {
                    stringBuilder.append(CheckClassAdapter.getShortName(frame.getLocal(n2).toString())).append(' ');
                    "".length();
                    ++n2;
                    "".length();
                    if ((0xD5 ^ 0xAF ^ 26 + 5 - 15 + 111) != 0) continue;
                    return;
                }
                stringBuilder.append(" : ");
                "".length();
                n2 = 0;
                while (CheckClassAdapter.lllIllIlII(n2, frame.getStackSize())) {
                    stringBuilder.append(CheckClassAdapter.getShortName(frame.getStack(n2).toString())).append(' ');
                    "".length();
                    ++n2;
                    "".length();
                    if (-"   ".length() < 0) continue;
                    return;
                }
            }
            while (CheckClassAdapter.lllIllIlII(stringBuilder.length(), methodNode.maxStack + methodNode.maxLocals + 1)) {
                stringBuilder.append(' ');
                "".length();
                "".length();
                if (" ".length() != 0) continue;
                return;
            }
            printWriter.print(Integer.toString(n + 100000).substring(1));
            printWriter.print(String.valueOf(new StringBuilder().append(" ").append((Object)stringBuilder).append(" : ").append(textifier.text.get(textifier.text.size() - 1))));
            ++n;
            "".length();
            if (-(4 ^ 0) < 0) continue;
            return;
        }
        n = 0;
        while (CheckClassAdapter.lllIllIlII(n, methodNode.tryCatchBlocks.size())) {
            methodNode.tryCatchBlocks.get(n).accept(traceMethodVisitor);
            printWriter.print(String.valueOf(new StringBuilder().append(" ").append(textifier.text.get(textifier.text.size() - 1))));
            ++n;
            "".length();
            if ("   ".length() >= -" ".length()) continue;
            return;
        }
        printWriter.println();
    }

    private static String getShortName(String string) {
        String string2;
        int n = string.lastIndexOf(47);
        int n2 = string.length();
        if (CheckClassAdapter.lllIllllIl(string.charAt(n2 - 1), 59)) {
            --n2;
        }
        if (CheckClassAdapter.lllIllllIl(n, -1)) {
            string2 = string;
            "".length();
            if (-(7 + 113 - 101 + 119 ^ 124 + 123 - 116 + 11) >= 0) {
                return null;
            }
        } else {
            string2 = string.substring(n + 1, n2);
        }
        return string2;
    }

    public CheckClassAdapter(ClassVisitor classVisitor) {
        this(classVisitor, true);
    }

    public CheckClassAdapter(ClassVisitor classVisitor, boolean bl) {
        this(327680, classVisitor, bl);
        if (CheckClassAdapter.lllIllllll(this.getClass(), CheckClassAdapter.class)) {
            throw new IllegalStateException();
        }
    }

    protected CheckClassAdapter(int n, ClassVisitor classVisitor, boolean bl) {
        super(n, classVisitor);
        this.checkDataFlow = bl;
    }

    @Override
    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        if (CheckClassAdapter.lllIllIIlI(this.start ? 1 : 0)) {
            throw new IllegalStateException("visit must be called only once");
        }
        this.start = true;
        this.checkState();
        CheckClassAdapter.checkAccess(n2, 423473);
        if (!CheckClassAdapter.lllIllIlIl(string) || CheckClassAdapter.lllIllIllI(string.endsWith("package-info") ? 1 : 0)) {
            CheckMethodAdapter.checkInternalName(string, "class name");
        }
        if (CheckClassAdapter.lllIllIIlI("java/lang/Object".equals(string) ? 1 : 0)) {
            if (CheckClassAdapter.lllIllIlIl(string3)) {
                throw new IllegalArgumentException("The super class name of the Object class must be 'null'");
            }
        } else {
            CheckMethodAdapter.checkInternalName(string3, "super class name");
        }
        if (CheckClassAdapter.lllIllIlIl(string2)) {
            CheckClassAdapter.checkClassSignature(string2);
        }
        if (CheckClassAdapter.lllIllIIlI(n2 & 0x200) && CheckClassAdapter.lllIllIllI("java/lang/Object".equals(string3) ? 1 : 0)) {
            throw new IllegalArgumentException("The super class name of interfaces must be 'java/lang/Object'");
        }
        if (CheckClassAdapter.lllIllIlIl(stringArray)) {
            int n3 = 0;
            while (CheckClassAdapter.lllIllIlII(n3, stringArray.length)) {
                CheckMethodAdapter.checkInternalName(stringArray[n3], String.valueOf(new StringBuilder().append("interface name at index ").append(n3)));
                ++n3;
                "".length();
                if ("  ".length() >= "  ".length()) continue;
                return;
            }
        }
        this.version = n;
        super.visit(n, n2, string, string2, string3, stringArray);
    }

    @Override
    public void visitSource(String string, String string2) {
        this.checkState();
        if (CheckClassAdapter.lllIllIIlI(this.source ? 1 : 0)) {
            throw new IllegalStateException("visitSource can be called only once.");
        }
        this.source = true;
        super.visitSource(string, string2);
    }

    @Override
    public void visitOuterClass(String string, String string2, String string3) {
        this.checkState();
        if (CheckClassAdapter.lllIllIIlI(this.outer ? 1 : 0)) {
            throw new IllegalStateException("visitOuterClass can be called only once.");
        }
        this.outer = true;
        if (CheckClassAdapter.lllIllIIll(string)) {
            throw new IllegalArgumentException("Illegal outer class owner");
        }
        if (CheckClassAdapter.lllIllIlIl(string3)) {
            CheckMethodAdapter.checkMethodDesc(string3);
        }
        super.visitOuterClass(string, string2, string3);
    }

    @Override
    public void visitInnerClass(String string, String string2, String string3, int n) {
        this.checkState();
        CheckMethodAdapter.checkInternalName(string, "class name");
        if (CheckClassAdapter.lllIllIlIl(string2)) {
            CheckMethodAdapter.checkInternalName(string2, "outer class name");
        }
        if (CheckClassAdapter.lllIllIlIl(string3)) {
            int n2 = 0;
            while (CheckClassAdapter.lllIllIlII(n2, string3.length()) && CheckClassAdapter.lllIllIIlI(Character.isDigit(string3.charAt(n2)) ? 1 : 0)) {
                ++n2;
                "".length();
                if (" ".length() != 0) continue;
                return;
            }
            if (!CheckClassAdapter.lllIllIIlI(n2) || CheckClassAdapter.lllIllIlII(n2, string3.length())) {
                CheckMethodAdapter.checkIdentifier(string3, n2, -1, "inner class name");
            }
        }
        CheckClassAdapter.checkAccess(n, 30239);
        super.visitInnerClass(string, string2, string3, n);
    }

    @Override
    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        this.checkState();
        CheckClassAdapter.checkAccess(n, 413919);
        CheckMethodAdapter.checkUnqualifiedName(this.version, string, "field name");
        CheckMethodAdapter.checkDesc(string2, false);
        if (CheckClassAdapter.lllIllIlIl(string3)) {
            CheckClassAdapter.checkFieldSignature(string3);
        }
        if (CheckClassAdapter.lllIllIlIl(object)) {
            CheckMethodAdapter.checkConstant(object);
        }
        FieldVisitor fieldVisitor = super.visitField(n, string, string2, string3, object);
        return new CheckFieldAdapter(fieldVisitor);
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        CheckMethodAdapter checkMethodAdapter;
        this.checkState();
        CheckClassAdapter.checkAccess(n, 400895);
        if (CheckClassAdapter.lllIllIllI("<init>".equals(string) ? 1 : 0) && CheckClassAdapter.lllIllIllI("<clinit>".equals(string) ? 1 : 0)) {
            CheckMethodAdapter.checkMethodIdentifier(this.version, string, "method name");
        }
        CheckMethodAdapter.checkMethodDesc(string2);
        if (CheckClassAdapter.lllIllIlIl(string3)) {
            CheckClassAdapter.checkMethodSignature(string3);
        }
        if (CheckClassAdapter.lllIllIlIl(stringArray)) {
            int n2 = 0;
            while (CheckClassAdapter.lllIllIlII(n2, stringArray.length)) {
                CheckMethodAdapter.checkInternalName(stringArray[n2], String.valueOf(new StringBuilder().append("exception name at index ").append(n2)));
                ++n2;
                "".length();
                if ("   ".length() > 0) continue;
                return null;
            }
        }
        if (CheckClassAdapter.lllIllIIlI(this.checkDataFlow ? 1 : 0)) {
            checkMethodAdapter = new CheckMethodAdapter(n, string, string2, super.visitMethod(n, string, string2, string3, stringArray), this.labels);
            "".length();
            if (-(0x52 ^ 0x56) >= 0) {
                return null;
            }
        } else {
            checkMethodAdapter = new CheckMethodAdapter(super.visitMethod(n, string, string2, string3, stringArray), this.labels);
        }
        checkMethodAdapter.version = this.version;
        return checkMethodAdapter;
    }

    @Override
    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        this.checkState();
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitAnnotation(string, bl));
    }

    @Override
    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        this.checkState();
        int n2 = n >>> 24;
        if (CheckClassAdapter.lllIllIIlI(n2) && CheckClassAdapter.lllIllIIIl(n2, 17) && CheckClassAdapter.lllIllIIIl(n2, 16)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference sort 0x").append(Integer.toHexString(n2))));
        }
        CheckClassAdapter.checkTypeRefAndPath(n, typePath);
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitTypeAnnotation(n, typePath, string, bl));
    }

    @Override
    public void visitAttribute(Attribute attribute) {
        this.checkState();
        if (CheckClassAdapter.lllIllIIll(attribute)) {
            throw new IllegalArgumentException("Invalid attribute (must not be null)");
        }
        super.visitAttribute(attribute);
    }

    @Override
    public void visitEnd() {
        this.checkState();
        this.end = true;
        super.visitEnd();
    }

    private void checkState() {
        if (CheckClassAdapter.lllIllIllI(this.start ? 1 : 0)) {
            throw new IllegalStateException("Cannot visit member before visit has been called.");
        }
        if (CheckClassAdapter.lllIllIIlI(this.end ? 1 : 0)) {
            throw new IllegalStateException("Cannot visit member after visitEnd has been called.");
        }
    }

    static void checkAccess(int n, int n2) {
        int n3;
        int n4;
        int n5;
        int n6;
        int n7;
        int n8;
        int n9;
        int n10;
        int n11;
        int n12;
        if (CheckClassAdapter.lllIllIIlI(n & ~n2)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid access flags: ").append(n)));
        }
        if (CheckClassAdapter.lllIllIllI(n & 1)) {
            n12 = 0;
            "".length();
            if (((137 + 16 - 75 + 83 ^ 99 + 39 - -2 + 44) & (114 + 46 - 140 + 125 ^ 106 + 106 - 190 + 114 ^ -" ".length())) != ((0x79 ^ 0x2B ^ (0x79 ^ 0x62)) & (0x1A ^ 5 ^ (0xCE ^ 0x98) ^ -" ".length()))) {
                return;
            }
        } else {
            n12 = n11 = 1;
        }
        if (CheckClassAdapter.lllIllIllI(n & 2)) {
            n10 = 0;
            "".length();
            if ((8 ^ 0xC) < 0) {
                return;
            }
        } else {
            n10 = n9 = 1;
        }
        if (CheckClassAdapter.lllIllIllI(n & 4)) {
            n8 = 0;
            "".length();
            if (-"  ".length() >= 0) {
                return;
            }
        } else {
            n8 = 1;
        }
        if (CheckClassAdapter.llllIIIIII(n11 + n9 + (n7 = n8), 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("public private and protected are mutually exclusive: ").append(n)));
        }
        if (CheckClassAdapter.lllIllIllI(n & 0x10)) {
            n6 = 0;
            "".length();
            if ((26 + 133 - 74 + 56 ^ 21 + 111 - 43 + 48) < 0) {
                return;
            }
        } else {
            n6 = n5 = 1;
        }
        if (CheckClassAdapter.lllIllIllI(n & 0x400)) {
            n4 = 0;
            "".length();
            if (((0x87 ^ 0x81) & ~(0x48 ^ 0x4E)) != 0) {
                return;
            }
        } else {
            n4 = 1;
        }
        if (CheckClassAdapter.llllIIIIII(n5 + (n3 = n4), 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("final and abstract are mutually exclusive: ").append(n)));
        }
    }

    public static void checkClassSignature(String string) {
        int n = 0;
        if (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, 0), 60)) {
            n = CheckClassAdapter.checkFormalTypeParameters(string, n);
        }
        n = CheckClassAdapter.checkClassTypeSignature(string, n);
        while (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), 76)) {
            n = CheckClassAdapter.checkClassTypeSignature(string, n);
            "".length();
            if (null == null) continue;
            return;
        }
        if (CheckClassAdapter.lllIllIIIl(n, string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(": error at index ").append(n)));
        }
    }

    public static void checkMethodSignature(String string) {
        int n = 0;
        if (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, 0), 60)) {
            n = CheckClassAdapter.checkFormalTypeParameters(string, n);
        }
        n = CheckClassAdapter.checkChar('(', string, n);
        while (CheckClassAdapter.lllIllIIIl("ZCBSIFJDL[T".indexOf(CheckClassAdapter.getChar(string, n)), -1)) {
            n = CheckClassAdapter.checkTypeSignature(string, n);
            "".length();
            if (-(0x1F ^ 0x2C ^ (0x18 ^ 0x2F)) <= 0) continue;
            return;
        }
        if (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n = CheckClassAdapter.checkChar(')', string, n)), 86)) {
            ++n;
            "".length();
            if ("  ".length() != "  ".length()) {
                return;
            }
        } else {
            n = CheckClassAdapter.checkTypeSignature(string, n);
        }
        while (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), 94)) {
            if (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, ++n), 76)) {
                n = CheckClassAdapter.checkClassTypeSignature(string, n);
                "".length();
                if (" ".length() != 0) continue;
                return;
            }
            n = CheckClassAdapter.checkTypeVariableSignature(string, n);
            "".length();
            if (null == null) continue;
            return;
        }
        if (CheckClassAdapter.lllIllIIIl(n, string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(": error at index ").append(n)));
        }
    }

    public static void checkFieldSignature(String string) {
        int n = CheckClassAdapter.checkFieldTypeSignature(string, 0);
        if (CheckClassAdapter.lllIllIIIl(n, string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(": error at index ").append(n)));
        }
    }

    static void checkTypeRefAndPath(int n, TypePath typePath) {
        int n2 = 0;
        switch (n >>> 24) {
            case 0: 
            case 1: 
            case 22: {
                n2 = -65536;
                "".length();
                if ("  ".length() > 0) break;
                return;
            }
            case 19: 
            case 20: 
            case 21: 
            case 64: 
            case 65: 
            case 67: 
            case 68: 
            case 69: 
            case 70: {
                n2 = -16777216;
                "".length();
                if (" ".length() >= " ".length()) break;
                return;
            }
            case 16: 
            case 17: 
            case 18: 
            case 23: 
            case 66: {
                n2 = -256;
                "".length();
                if ((0x21 ^ 0x25) >= ((0xA ^ 0x1E) & ~(5 ^ 0x11))) break;
                return;
            }
            case 71: 
            case 72: 
            case 73: 
            case 74: 
            case 75: {
                n2 = -16776961;
                "".length();
                if (null == null) break;
                return;
            }
            default: {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference sort 0x").append(Integer.toHexString(n >>> 24))));
            }
        }
        if (CheckClassAdapter.lllIllIIlI(n & ~n2)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference 0x").append(Integer.toHexString(n))));
        }
        if (CheckClassAdapter.lllIllIlIl(typePath)) {
            int n3 = 0;
            while (CheckClassAdapter.lllIllIlII(n3, typePath.getLength())) {
                int n4 = typePath.getStep(n3);
                if (CheckClassAdapter.lllIllIIlI(n4) && CheckClassAdapter.lllIllIIIl(n4, 1) && CheckClassAdapter.lllIllIIIl(n4, 3) && CheckClassAdapter.lllIllIIIl(n4, 2)) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type path step ").append(n3).append(" in ").append(typePath)));
                }
                if (CheckClassAdapter.lllIllIIIl(n4, 3) && CheckClassAdapter.lllIllIIlI(typePath.getStepArgument(n3))) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type path step argument for step ").append(n3).append(" in ").append(typePath)));
                }
                ++n3;
                "".length();
                if (-" ".length() < "   ".length()) continue;
                return;
            }
        }
    }

    private static int checkFormalTypeParameters(String string, int n) {
        n = CheckClassAdapter.checkChar('<', string, n);
        n = CheckClassAdapter.checkFormalTypeParameter(string, n);
        while (CheckClassAdapter.lllIllIIIl(CheckClassAdapter.getChar(string, n), 62)) {
            n = CheckClassAdapter.checkFormalTypeParameter(string, n);
            "".length();
            if (" ".length() >= ((0x27 ^ 0x41 ^ (0x64 ^ 0x2A)) & (0x3F ^ 0x1C ^ (0x98 ^ 0x93) ^ -" ".length()))) continue;
            return (0x9E ^ 0x8C ^ (0x1A ^ 0x4F)) & (0xB4 ^ 0x81 ^ (0x5E ^ 0x2C) ^ -" ".length());
        }
        return n + 1;
    }

    private static int checkFormalTypeParameter(String string, int n) {
        n = CheckClassAdapter.checkIdentifier(string, n);
        if (CheckClassAdapter.lllIllIIIl("L[T".indexOf(CheckClassAdapter.getChar(string, n = CheckClassAdapter.checkChar(':', string, n))), -1)) {
            n = CheckClassAdapter.checkFieldTypeSignature(string, n);
        }
        while (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), 58)) {
            n = CheckClassAdapter.checkFieldTypeSignature(string, n + 1);
            "".length();
            if (" ".length() >= 0) continue;
            return (0xC ^ 0x30) & ~(0x9C ^ 0xA0);
        }
        return n;
    }

    private static int checkFieldTypeSignature(String string, int n) {
        switch (CheckClassAdapter.getChar(string, n)) {
            case 'L': {
                return CheckClassAdapter.checkClassTypeSignature(string, n);
            }
            case '[': {
                return CheckClassAdapter.checkTypeSignature(string, n + 1);
            }
        }
        return CheckClassAdapter.checkTypeVariableSignature(string, n);
    }

    private static int checkClassTypeSignature(String string, int n) {
        n = CheckClassAdapter.checkChar('L', string, n);
        n = CheckClassAdapter.checkIdentifier(string, n);
        while (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), 47)) {
            n = CheckClassAdapter.checkIdentifier(string, n + 1);
            "".length();
            if (null == null) continue;
            return (0xAC ^ 0xB1) & ~(0x95 ^ 0x88);
        }
        if (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), 60)) {
            n = CheckClassAdapter.checkTypeArguments(string, n);
        }
        while (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), 46)) {
            if (!CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n = CheckClassAdapter.checkIdentifier(string, n + 1)), 60)) continue;
            n = CheckClassAdapter.checkTypeArguments(string, n);
            "".length();
            if (null == null) continue;
            return (0x9B ^ 0x9C) & ~(0xB9 ^ 0xBE);
        }
        return CheckClassAdapter.checkChar(';', string, n);
    }

    private static int checkTypeArguments(String string, int n) {
        n = CheckClassAdapter.checkChar('<', string, n);
        n = CheckClassAdapter.checkTypeArgument(string, n);
        while (CheckClassAdapter.lllIllIIIl(CheckClassAdapter.getChar(string, n), 62)) {
            n = CheckClassAdapter.checkTypeArgument(string, n);
            "".length();
            if (((94 + 12 - 40 + 82 ^ 88 + 75 - 35 + 19) & (0x26 ^ 2 ^ (0x74 ^ 0x57) ^ -" ".length())) < "   ".length()) continue;
            return (137 + 80 - -10 + 8 ^ 128 + 166 - 137 + 23) & (0x42 ^ 0x4D ^ (0xE1 ^ 0xB1) ^ -" ".length());
        }
        return n + 1;
    }

    private static int checkTypeArgument(String string, int n) {
        char c = CheckClassAdapter.getChar(string, n);
        if (CheckClassAdapter.lllIllllIl(c, 42)) {
            return n + 1;
        }
        if (!CheckClassAdapter.lllIllIIIl(c, 43) || CheckClassAdapter.lllIllllIl(c, 45)) {
            ++n;
        }
        return CheckClassAdapter.checkFieldTypeSignature(string, n);
    }

    private static int checkTypeVariableSignature(String string, int n) {
        n = CheckClassAdapter.checkChar('T', string, n);
        n = CheckClassAdapter.checkIdentifier(string, n);
        return CheckClassAdapter.checkChar(';', string, n);
    }

    private static int checkTypeSignature(String string, int n) {
        switch (CheckClassAdapter.getChar(string, n)) {
            case 'B': 
            case 'C': 
            case 'D': 
            case 'F': 
            case 'I': 
            case 'J': 
            case 'S': 
            case 'Z': {
                return n + 1;
            }
        }
        return CheckClassAdapter.checkFieldTypeSignature(string, n);
    }

    private static int checkIdentifier(String string, int n) {
        if (CheckClassAdapter.lllIllIllI(Character.isJavaIdentifierStart(CheckClassAdapter.getChar(string, n)) ? 1 : 0)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(": identifier expected at index ").append(n)));
        }
        ++n;
        while (CheckClassAdapter.lllIllIIlI(Character.isJavaIdentifierPart(CheckClassAdapter.getChar(string, n)) ? 1 : 0)) {
            ++n;
            "".length();
            if ("   ".length() > 0) continue;
            return (2 ^ 0x1C ^ (0x55 ^ 0x59)) & (0x75 ^ 3 ^ (0xD5 ^ 0xB1) ^ -" ".length());
        }
        return n;
    }

    private static int checkChar(char c, String string, int n) {
        if (CheckClassAdapter.lllIllllIl(CheckClassAdapter.getChar(string, n), c)) {
            return n + 1;
        }
        throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(": '").append(c).append("' expected at index ").append(n)));
    }

    private static char getChar(String string, int n) {
        char c;
        if (CheckClassAdapter.lllIllIlII(n, string.length())) {
            c = string.charAt(n);
            "".length();
            if (((0xE1 ^ 0x8E ^ (0x5B ^ 4)) & (0x41 ^ 0x72 ^ "   ".length() ^ -" ".length())) >= "  ".length()) {
                return (char)((0x5D ^ 0x68 ^ "  ".length()) & (31 + 40 - -45 + 13 ^ 35 + 122 - 11 + 36 ^ -" ".length()));
            }
        } else {
            c = '\u0000';
        }
        return c;
    }

    private static boolean lllIllllIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIllIlII(int n, int n2) {
        return n < n2;
    }

    private static boolean llllIIIIII(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIllllll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lllIllIlIl(Object object) {
        return object != null;
    }

    private static boolean lllIllIIll(Object object) {
        return object == null;
    }

    private static boolean lllIllIIlI(int n) {
        return n != 0;
    }

    private static boolean lllIllIllI(int n) {
        return n == 0;
    }

    private static boolean lllIllIIIl(int n, int n2) {
        return n != n2;
    }
}

