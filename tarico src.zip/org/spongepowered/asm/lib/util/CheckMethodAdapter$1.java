/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.analysis.Analyzer;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;
import org.spongepowered.asm.lib.tree.analysis.BasicVerifier;
import org.spongepowered.asm.lib.util.CheckClassAdapter;

class CheckMethodAdapter$1
extends MethodNode {
    final /* synthetic */ MethodVisitor val$cmv;

    CheckMethodAdapter$1(int n, int n2, String string, String string2, String string3, String[] stringArray, MethodVisitor methodVisitor) {
        this.val$cmv = methodVisitor;
        super(n, n2, string, string2, string3, stringArray);
    }

    public void visitEnd() {
        Analyzer<BasicValue> analyzer = new Analyzer<BasicValue>(new BasicVerifier());
        try {
            analyzer.analyze("dummy", this);
            "".length();
            "".length();
        }
        catch (Exception exception) {
            if (CheckMethodAdapter$1.llIIIIlll(exception instanceof IndexOutOfBoundsException) && CheckMethodAdapter$1.llIIIlIII(this.maxLocals) && CheckMethodAdapter$1.llIIIlIII(this.maxStack)) {
                throw new RuntimeException("Data flow checking option requires valid, non zero maxLocals and maxStack values.");
            }
            exception.printStackTrace();
            StringWriter stringWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stringWriter, true);
            CheckClassAdapter.printAnalyzerResult(this, analyzer, printWriter);
            printWriter.close();
            throw new RuntimeException(String.valueOf(new StringBuilder().append(exception.getMessage()).append(' ').append(stringWriter.toString())));
        }
        if (-"   ".length() >= 0) {
            return;
        }
        this.accept(this.val$cmv);
    }

    private static boolean llIIIIlll(int n) {
        return n != 0;
    }

    private static boolean llIIIlIII(int n) {
        return n == 0;
    }
}

