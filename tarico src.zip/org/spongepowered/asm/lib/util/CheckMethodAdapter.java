/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.util.CheckAnnotationAdapter;
import org.spongepowered.asm.lib.util.CheckClassAdapter;
import org.spongepowered.asm.lib.util.CheckMethodAdapter$1;

/*
 * This class specifies class file version 49.0 but uses Java 6 signatures.  Assumed Java 6.
 */
public class CheckMethodAdapter
extends MethodVisitor {
    public int version;
    private int access;
    private boolean startCode;
    private boolean endCode;
    private boolean endMethod;
    private int insnCount;
    private final Map<Label, Integer> labels;
    private Set<Label> usedLabels;
    private int expandedFrames;
    private int compressedFrames;
    private int lastFrame = -1;
    private List<Label> handlers;
    private static final int[] TYPE;
    private static Field labelStatusField;

    public CheckMethodAdapter(MethodVisitor methodVisitor) {
        this(methodVisitor, new HashMap<Label, Integer>());
    }

    public CheckMethodAdapter(MethodVisitor methodVisitor, Map<Label, Integer> map) {
        this(327680, methodVisitor, map);
        if (CheckMethodAdapter.lIIIlIlIIlII(this.getClass(), CheckMethodAdapter.class)) {
            throw new IllegalStateException();
        }
    }

    protected CheckMethodAdapter(int n, MethodVisitor methodVisitor, Map<Label, Integer> map) {
        super(n, methodVisitor);
        this.labels = map;
        this.usedLabels = new HashSet<Label>();
        this.handlers = new ArrayList<Label>();
    }

    public CheckMethodAdapter(int n, String string, String string2, MethodVisitor methodVisitor, Map<Label, Integer> map) {
        this(new CheckMethodAdapter$1(327680, n, string, string2, null, null, methodVisitor), map);
        this.access = n;
    }

    @Override
    public void visitParameter(String string, int n) {
        if (CheckMethodAdapter.lIIIlIlIIlIl(string)) {
            CheckMethodAdapter.checkUnqualifiedName(this.version, string, "name");
        }
        CheckClassAdapter.checkAccess(n, 36880);
        super.visitParameter(string, n);
    }

    @Override
    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        this.checkEndMethod();
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitAnnotation(string, bl));
    }

    @Override
    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        this.checkEndMethod();
        int n2 = n >>> 24;
        if (CheckMethodAdapter.lIIIlIlIIllI(n2, 1) && CheckMethodAdapter.lIIIlIlIIllI(n2, 18) && CheckMethodAdapter.lIIIlIlIIllI(n2, 20) && CheckMethodAdapter.lIIIlIlIIllI(n2, 21) && CheckMethodAdapter.lIIIlIlIIllI(n2, 22) && CheckMethodAdapter.lIIIlIlIIllI(n2, 23)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference sort 0x").append(Integer.toHexString(n2))));
        }
        CheckClassAdapter.checkTypeRefAndPath(n, typePath);
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitTypeAnnotation(n, typePath, string, bl));
    }

    @Override
    public AnnotationVisitor visitAnnotationDefault() {
        this.checkEndMethod();
        return new CheckAnnotationAdapter(super.visitAnnotationDefault(), false);
    }

    @Override
    public AnnotationVisitor visitParameterAnnotation(int n, String string, boolean bl) {
        this.checkEndMethod();
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitParameterAnnotation(n, string, bl));
    }

    @Override
    public void visitAttribute(Attribute attribute) {
        this.checkEndMethod();
        if (CheckMethodAdapter.lIIIlIlIIlll(attribute)) {
            throw new IllegalArgumentException("Invalid attribute (must not be null)");
        }
        super.visitAttribute(attribute);
    }

    @Override
    public void visitCode() {
        if (CheckMethodAdapter.lIIIlIlIlIII(this.access & 0x400)) {
            throw new RuntimeException("Abstract methods cannot have code");
        }
        this.startCode = true;
        super.visitCode();
    }

    @Override
    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        int n4;
        int n5;
        int n6;
        if (CheckMethodAdapter.lIIIlIlIlIIl(this.insnCount, this.lastFrame)) {
            throw new IllegalStateException("At most one frame can be visited at a given code location.");
        }
        this.lastFrame = this.insnCount;
        switch (n) {
            case -1: 
            case 0: {
                n6 = Integer.MAX_VALUE;
                n5 = Integer.MAX_VALUE;
                "".length();
                if (((0x48 ^ 0x69) & ~(0x76 ^ 0x57)) == 0) break;
                return;
            }
            case 3: {
                n6 = 0;
                n5 = 0;
                "".length();
                if (((0x73 ^ 0x7A ^ (9 ^ 0x1B)) & (23 + 6 - -104 + 9 ^ 91 + 29 - 55 + 84 ^ -" ".length())) < "   ".length()) break;
                return;
            }
            case 4: {
                n6 = 0;
                n5 = 1;
                "".length();
                if (("   ".length() & ("   ".length() ^ -" ".length())) < "  ".length()) break;
                return;
            }
            case 1: 
            case 2: {
                n6 = 3;
                n5 = 0;
                "".length();
                if (-" ".length() < 0) break;
                return;
            }
            default: {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid frame type ").append(n)));
            }
        }
        if (CheckMethodAdapter.lIIIlIlIlIlI(n2, n6)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid nLocal=").append(n2).append(" for frame type ").append(n)));
        }
        if (CheckMethodAdapter.lIIIlIlIlIlI(n3, n5)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid nStack=").append(n3).append(" for frame type ").append(n)));
        }
        if (CheckMethodAdapter.lIIIlIlIIllI(n, 2)) {
            if (CheckMethodAdapter.lIIIlIlIlIll(n2) && (!CheckMethodAdapter.lIIIlIlIIlIl(objectArray) || CheckMethodAdapter.lIIIlIlIllII(objectArray.length, n2))) {
                throw new IllegalArgumentException("Array local[] is shorter than nLocal");
            }
            n4 = 0;
            while (CheckMethodAdapter.lIIIlIlIllII(n4, n2)) {
                this.checkFrameValue(objectArray[n4]);
                ++n4;
                "".length();
                if (-" ".length() < 0) continue;
                return;
            }
        }
        if (CheckMethodAdapter.lIIIlIlIlIll(n3) && (!CheckMethodAdapter.lIIIlIlIIlIl(objectArray2) || CheckMethodAdapter.lIIIlIlIllII(objectArray2.length, n3))) {
            throw new IllegalArgumentException("Array stack[] is shorter than nStack");
        }
        n4 = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n4, n3)) {
            this.checkFrameValue(objectArray2[n4]);
            ++n4;
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return;
        }
        if (CheckMethodAdapter.lIIIlIlIlIIl(n, -1)) {
            ++this.expandedFrames;
            "".length();
            if ((21 + 141 - 69 + 58 ^ 97 + 23 - -4 + 23) < 0) {
                return;
            }
        } else {
            ++this.compressedFrames;
        }
        if (CheckMethodAdapter.lIIIlIlIlIll(this.expandedFrames) && CheckMethodAdapter.lIIIlIlIlIll(this.compressedFrames)) {
            throw new RuntimeException("Expanded and compressed frames must not be mixed.");
        }
        super.visitFrame(n, n2, objectArray, n3, objectArray2);
    }

    @Override
    public void visitInsn(int n) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 0);
        super.visitInsn(n);
        ++this.insnCount;
    }

    @Override
    public void visitIntInsn(int n, int n2) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 1);
        switch (n) {
            case 16: {
                CheckMethodAdapter.checkSignedByte(n2, "Invalid operand");
                "".length();
                if (" ".length() >= ((0x77 ^ 0x3F ^ (0xD ^ 0x6C)) & (22 + 170 - 113 + 111 ^ 136 + 137 - 257 + 135 ^ -" ".length()))) break;
                return;
            }
            case 17: {
                CheckMethodAdapter.checkSignedShort(n2, "Invalid operand");
                "".length();
                if (-(0x45 ^ 7 ^ (0x20 ^ 0x67)) < 0) break;
                return;
            }
            default: {
                if (CheckMethodAdapter.lIIIlIlIllIl(n2, 4) && !CheckMethodAdapter.lIIIlIlIlIlI(n2, 11)) break;
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid operand (must be an array type code T_...): ").append(n2)));
            }
        }
        super.visitIntInsn(n, n2);
        ++this.insnCount;
    }

    @Override
    public void visitVarInsn(int n, int n2) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 2);
        CheckMethodAdapter.checkUnsignedShort(n2, "Invalid variable index");
        super.visitVarInsn(n, n2);
        ++this.insnCount;
    }

    @Override
    public void visitTypeInsn(int n, String string) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 3);
        CheckMethodAdapter.checkInternalName(string, "type");
        if (CheckMethodAdapter.lIIIlIlIlIIl(n, 187) && CheckMethodAdapter.lIIIlIlIlIIl(string.charAt(0), 91)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("NEW cannot be used to create arrays: ").append(string)));
        }
        super.visitTypeInsn(n, string);
        ++this.insnCount;
    }

    @Override
    public void visitFieldInsn(int n, String string, String string2, String string3) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 4);
        CheckMethodAdapter.checkInternalName(string, "owner");
        CheckMethodAdapter.checkUnqualifiedName(this.version, string2, "name");
        CheckMethodAdapter.checkDesc(string3, false);
        super.visitFieldInsn(n, string, string2, string3);
        ++this.insnCount;
    }

    @Override
    @Deprecated
    public void visitMethodInsn(int n, String string, String string2, String string3) {
        boolean bl;
        if (CheckMethodAdapter.lIIIlIlIllIl(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3);
            return;
        }
        if (CheckMethodAdapter.lIIIlIlIlIIl(n, 185)) {
            bl = true;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            bl = false;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    @Override
    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (CheckMethodAdapter.lIIIlIlIllII(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3, bl);
            return;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    private void doVisitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 5);
        if (!CheckMethodAdapter.lIIIlIlIlIIl(n, 183) || CheckMethodAdapter.lIIIlIlIlllI("<init>".equals(string2) ? 1 : 0)) {
            CheckMethodAdapter.checkMethodIdentifier(this.version, string2, "name");
        }
        CheckMethodAdapter.checkInternalName(string, "owner");
        CheckMethodAdapter.checkMethodDesc(string3);
        if (CheckMethodAdapter.lIIIlIlIlIIl(n, 182) && CheckMethodAdapter.lIIIlIlIlIII(bl ? 1 : 0)) {
            throw new IllegalArgumentException("INVOKEVIRTUAL can't be used with interfaces");
        }
        if (CheckMethodAdapter.lIIIlIlIlIIl(n, 185) && CheckMethodAdapter.lIIIlIlIlllI(bl ? 1 : 0)) {
            throw new IllegalArgumentException("INVOKEINTERFACE can't be used with classes");
        }
        if (CheckMethodAdapter.lIIIlIlIlIIl(n, 183) && CheckMethodAdapter.lIIIlIlIlIII(bl ? 1 : 0) && CheckMethodAdapter.lIIIlIlIllII(this.version & 0xFFFF, 52)) {
            throw new IllegalArgumentException("INVOKESPECIAL can't be used with interfaces prior to Java 8");
        }
        if (CheckMethodAdapter.lIIIlIlIIlIl(this.mv)) {
            this.mv.visitMethodInsn(n, string, string2, string3, bl);
        }
        ++this.insnCount;
    }

    @Override
    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkMethodIdentifier(this.version, string, "name");
        CheckMethodAdapter.checkMethodDesc(string2);
        if (CheckMethodAdapter.lIIIlIlIIllI(handle.getTag(), 6) && CheckMethodAdapter.lIIIlIlIIllI(handle.getTag(), 8)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("invalid handle tag ").append(handle.getTag())));
        }
        int n = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n, objectArray.length)) {
            this.checkLDCConstant(objectArray[n]);
            ++n;
            "".length();
            if ("  ".length() < "   ".length()) continue;
            return;
        }
        super.visitInvokeDynamicInsn(string, string2, handle, objectArray);
        ++this.insnCount;
    }

    @Override
    public void visitJumpInsn(int n, Label label) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkOpcode(n, 6);
        this.checkLabel(label, false, "label");
        CheckMethodAdapter.checkNonDebugLabel(label);
        super.visitJumpInsn(n, label);
        this.usedLabels.add(label);
        "".length();
        ++this.insnCount;
    }

    @Override
    public void visitLabel(Label label) {
        this.checkStartCode();
        this.checkEndCode();
        this.checkLabel(label, false, "label");
        if (CheckMethodAdapter.lIIIlIlIIlIl(this.labels.get(label))) {
            throw new IllegalArgumentException("Already visited label");
        }
        this.labels.put(label, this.insnCount);
        "".length();
        super.visitLabel(label);
    }

    @Override
    public void visitLdcInsn(Object object) {
        this.checkStartCode();
        this.checkEndCode();
        this.checkLDCConstant(object);
        super.visitLdcInsn(object);
        ++this.insnCount;
    }

    @Override
    public void visitIincInsn(int n, int n2) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkUnsignedShort(n, "Invalid variable index");
        CheckMethodAdapter.checkSignedShort(n2, "Invalid increment");
        super.visitIincInsn(n, n2);
        ++this.insnCount;
    }

    @Override
    public void visitTableSwitchInsn(int n, int n2, Label label, Label ... labelArray) {
        this.checkStartCode();
        this.checkEndCode();
        if (CheckMethodAdapter.lIIIlIlIllII(n2, n)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Max = ").append(n2).append(" must be greater than or equal to min = ").append(n)));
        }
        this.checkLabel(label, false, "default label");
        CheckMethodAdapter.checkNonDebugLabel(label);
        if (!CheckMethodAdapter.lIIIlIlIIlIl(labelArray) || CheckMethodAdapter.lIIIlIlIIllI(labelArray.length, n2 - n + 1)) {
            throw new IllegalArgumentException("There must be max - min + 1 labels");
        }
        int n3 = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n3, labelArray.length)) {
            this.checkLabel(labelArray[n3], false, String.valueOf(new StringBuilder().append("label at index ").append(n3)));
            CheckMethodAdapter.checkNonDebugLabel(labelArray[n3]);
            ++n3;
            "".length();
            if (null == null) continue;
            return;
        }
        super.visitTableSwitchInsn(n, n2, label, labelArray);
        n3 = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n3, labelArray.length)) {
            this.usedLabels.add(labelArray[n3]);
            "".length();
            ++n3;
            "".length();
            if (-"  ".length() < 0) continue;
            return;
        }
        ++this.insnCount;
    }

    @Override
    public void visitLookupSwitchInsn(Label label, int[] nArray, Label[] labelArray) {
        this.checkEndCode();
        this.checkStartCode();
        this.checkLabel(label, false, "default label");
        CheckMethodAdapter.checkNonDebugLabel(label);
        if (!CheckMethodAdapter.lIIIlIlIIlIl(nArray) || !CheckMethodAdapter.lIIIlIlIIlIl(labelArray) || CheckMethodAdapter.lIIIlIlIIllI(nArray.length, labelArray.length)) {
            throw new IllegalArgumentException("There must be the same number of keys and labels");
        }
        int n = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n, labelArray.length)) {
            this.checkLabel(labelArray[n], false, String.valueOf(new StringBuilder().append("label at index ").append(n)));
            CheckMethodAdapter.checkNonDebugLabel(labelArray[n]);
            ++n;
            "".length();
            if (null == null) continue;
            return;
        }
        super.visitLookupSwitchInsn(label, nArray, labelArray);
        this.usedLabels.add(label);
        "".length();
        n = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n, labelArray.length)) {
            this.usedLabels.add(labelArray[n]);
            "".length();
            ++n;
            "".length();
            if (((0x5A ^ 0x69) & ~(0x25 ^ 0x16) ^ (0x74 ^ 0x70)) > " ".length()) continue;
            return;
        }
        ++this.insnCount;
    }

    @Override
    public void visitMultiANewArrayInsn(String string, int n) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkDesc(string, false);
        if (CheckMethodAdapter.lIIIlIlIIllI(string.charAt(0), 91)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor (must be an array type descriptor): ").append(string)));
        }
        if (CheckMethodAdapter.lIIIlIlIllII(n, 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid dimensions (must be greater than 0): ").append(n)));
        }
        if (CheckMethodAdapter.lIIIlIlIlIlI(n, string.lastIndexOf(91) + 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid dimensions (must not be greater than dims(desc)): ").append(n)));
        }
        super.visitMultiANewArrayInsn(string, n);
        ++this.insnCount;
    }

    @Override
    public AnnotationVisitor visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        this.checkStartCode();
        this.checkEndCode();
        int n2 = n >>> 24;
        if (CheckMethodAdapter.lIIIlIlIIllI(n2, 67) && CheckMethodAdapter.lIIIlIlIIllI(n2, 68) && CheckMethodAdapter.lIIIlIlIIllI(n2, 69) && CheckMethodAdapter.lIIIlIlIIllI(n2, 70) && CheckMethodAdapter.lIIIlIlIIllI(n2, 71) && CheckMethodAdapter.lIIIlIlIIllI(n2, 72) && CheckMethodAdapter.lIIIlIlIIllI(n2, 73) && CheckMethodAdapter.lIIIlIlIIllI(n2, 74) && CheckMethodAdapter.lIIIlIlIIllI(n2, 75)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference sort 0x").append(Integer.toHexString(n2))));
        }
        CheckClassAdapter.checkTypeRefAndPath(n, typePath);
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitInsnAnnotation(n, typePath, string, bl));
    }

    @Override
    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        this.checkStartCode();
        this.checkEndCode();
        this.checkLabel(label, false, "start label");
        this.checkLabel(label2, false, "end label");
        this.checkLabel(label3, false, "handler label");
        CheckMethodAdapter.checkNonDebugLabel(label);
        CheckMethodAdapter.checkNonDebugLabel(label2);
        CheckMethodAdapter.checkNonDebugLabel(label3);
        if (!CheckMethodAdapter.lIIIlIlIIlll(this.labels.get(label)) || !CheckMethodAdapter.lIIIlIlIIlll(this.labels.get(label2)) || CheckMethodAdapter.lIIIlIlIIlIl(this.labels.get(label3))) {
            throw new IllegalStateException("Try catch blocks must be visited before their labels");
        }
        if (CheckMethodAdapter.lIIIlIlIIlIl(string)) {
            CheckMethodAdapter.checkInternalName(string, "type");
        }
        super.visitTryCatchBlock(label, label2, label3, string);
        this.handlers.add(label);
        "".length();
        this.handlers.add(label2);
        "".length();
    }

    @Override
    public AnnotationVisitor visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        this.checkStartCode();
        this.checkEndCode();
        int n2 = n >>> 24;
        if (CheckMethodAdapter.lIIIlIlIIllI(n2, 66)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference sort 0x").append(Integer.toHexString(n2))));
        }
        CheckClassAdapter.checkTypeRefAndPath(n, typePath);
        CheckMethodAdapter.checkDesc(string, false);
        return new CheckAnnotationAdapter(super.visitTryCatchAnnotation(n, typePath, string, bl));
    }

    @Override
    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkUnqualifiedName(this.version, string, "name");
        CheckMethodAdapter.checkDesc(string2, false);
        this.checkLabel(label, true, "start label");
        this.checkLabel(label2, true, "end label");
        CheckMethodAdapter.checkUnsignedShort(n, "Invalid variable index");
        int n2 = this.labels.get(label);
        int n3 = this.labels.get(label2);
        if (CheckMethodAdapter.lIIIlIlIllII(n3, n2)) {
            throw new IllegalArgumentException("Invalid start and end labels (end must be greater than start)");
        }
        super.visitLocalVariable(string, string2, string3, label, label2, n);
    }

    @Override
    public AnnotationVisitor visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        this.checkStartCode();
        this.checkEndCode();
        int n2 = n >>> 24;
        if (CheckMethodAdapter.lIIIlIlIIllI(n2, 64) && CheckMethodAdapter.lIIIlIlIIllI(n2, 65)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid type reference sort 0x").append(Integer.toHexString(n2))));
        }
        CheckClassAdapter.checkTypeRefAndPath(n, typePath);
        CheckMethodAdapter.checkDesc(string, false);
        if (!(CheckMethodAdapter.lIIIlIlIIlIl(labelArray) && CheckMethodAdapter.lIIIlIlIIlIl(labelArray2) && CheckMethodAdapter.lIIIlIlIIlIl(nArray) && CheckMethodAdapter.lIIIlIlIlIIl(labelArray2.length, labelArray.length) && !CheckMethodAdapter.lIIIlIlIIllI(nArray.length, labelArray.length))) {
            throw new IllegalArgumentException("Invalid start, end and index arrays (must be non null and of identical length");
        }
        int n3 = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n3, labelArray.length)) {
            this.checkLabel(labelArray[n3], true, "start label");
            this.checkLabel(labelArray2[n3], true, "end label");
            CheckMethodAdapter.checkUnsignedShort(nArray[n3], "Invalid variable index");
            int n4 = this.labels.get(labelArray[n3]);
            int n5 = this.labels.get(labelArray2[n3]);
            if (CheckMethodAdapter.lIIIlIlIllII(n5, n4)) {
                throw new IllegalArgumentException("Invalid start and end labels (end must be greater than start)");
            }
            ++n3;
            "".length();
            if (" ".length() >= ((0x70 ^ 0x13 ^ (0x77 ^ 0xD)) & (0x24 ^ 0x45 ^ (0xD ^ 0x75) ^ -" ".length()))) continue;
            return null;
        }
        return super.visitLocalVariableAnnotation(n, typePath, labelArray, labelArray2, nArray, string, bl);
    }

    @Override
    public void visitLineNumber(int n, Label label) {
        this.checkStartCode();
        this.checkEndCode();
        CheckMethodAdapter.checkUnsignedShort(n, "Invalid line number");
        this.checkLabel(label, true, "start label");
        super.visitLineNumber(n, label);
    }

    @Override
    public void visitMaxs(int n, int n2) {
        Object object;
        this.checkStartCode();
        this.checkEndCode();
        this.endCode = true;
        Iterator<Label> iterator = this.usedLabels.iterator();
        while (CheckMethodAdapter.lIIIlIlIlIII(iterator.hasNext() ? 1 : 0)) {
            object = iterator.next();
            if (CheckMethodAdapter.lIIIlIlIIlll(this.labels.get(object))) {
                throw new IllegalStateException("Undefined label used");
            }
            "".length();
            if ("   ".length() != 0) continue;
            return;
        }
        int n3 = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n3, this.handlers.size())) {
            object = this.labels.get(this.handlers.get(n3++));
            Integer n4 = this.labels.get(this.handlers.get(n3++));
            if (!CheckMethodAdapter.lIIIlIlIIlIl(object) || CheckMethodAdapter.lIIIlIlIIlll(n4)) {
                throw new IllegalStateException("Undefined try catch block labels");
            }
            if (CheckMethodAdapter.lIIIlIllIIlI(n4, (Integer)object)) {
                throw new IllegalStateException("Emty try catch block handler range");
            }
            "".length();
            if (null == null) continue;
            return;
        }
        CheckMethodAdapter.checkUnsignedShort(n, "Invalid max stack");
        CheckMethodAdapter.checkUnsignedShort(n2, "Invalid max locals");
        super.visitMaxs(n, n2);
    }

    @Override
    public void visitEnd() {
        this.checkEndMethod();
        this.endMethod = true;
        super.visitEnd();
    }

    void checkStartCode() {
        if (CheckMethodAdapter.lIIIlIlIlllI(this.startCode ? 1 : 0)) {
            throw new IllegalStateException("Cannot visit instructions before visitCode has been called.");
        }
    }

    void checkEndCode() {
        if (CheckMethodAdapter.lIIIlIlIlIII(this.endCode ? 1 : 0)) {
            throw new IllegalStateException("Cannot visit instructions after visitMaxs has been called.");
        }
    }

    void checkEndMethod() {
        if (CheckMethodAdapter.lIIIlIlIlIII(this.endMethod ? 1 : 0)) {
            throw new IllegalStateException("Cannot visit elements after visitEnd has been called.");
        }
    }

    void checkFrameValue(Object object) {
        if (!(CheckMethodAdapter.lIIIlIlIIlII(object, Opcodes.TOP) && CheckMethodAdapter.lIIIlIlIIlII(object, Opcodes.INTEGER) && CheckMethodAdapter.lIIIlIlIIlII(object, Opcodes.FLOAT) && CheckMethodAdapter.lIIIlIlIIlII(object, Opcodes.LONG) && CheckMethodAdapter.lIIIlIlIIlII(object, Opcodes.DOUBLE) && CheckMethodAdapter.lIIIlIlIIlII(object, Opcodes.NULL) && !CheckMethodAdapter.lIIIlIllIlII(object, Opcodes.UNINITIALIZED_THIS))) {
            return;
        }
        if (CheckMethodAdapter.lIIIlIlIlIII(object instanceof String)) {
            CheckMethodAdapter.checkInternalName((String)object, "Invalid stack frame value");
            return;
        }
        if (CheckMethodAdapter.lIIIlIlIlllI(object instanceof Label)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid stack frame value: ").append(object)));
        }
        this.usedLabels.add((Label)object);
        "".length();
    }

    static void checkOpcode(int n, int n2) {
        if (!CheckMethodAdapter.lIIIlIllIllI(n) || !CheckMethodAdapter.lIIIlIllIIlI(n, 199) || CheckMethodAdapter.lIIIlIlIIllI(TYPE[n], n2)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid opcode: ").append(n)));
        }
    }

    static void checkSignedByte(int n, String string) {
        if (!CheckMethodAdapter.lIIIlIlIllIl(n, -128) || CheckMethodAdapter.lIIIlIlIlIlI(n, 127)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(" (must be a signed byte): ").append(n)));
        }
    }

    static void checkSignedShort(int n, String string) {
        if (!CheckMethodAdapter.lIIIlIlIllIl(n, Short.MIN_VALUE) || CheckMethodAdapter.lIIIlIlIlIlI(n, Short.MAX_VALUE)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(" (must be a signed short): ").append(n)));
        }
    }

    static void checkUnsignedShort(int n, String string) {
        if (!CheckMethodAdapter.lIIIlIllIllI(n) || CheckMethodAdapter.lIIIlIlIlIlI(n, 65535)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(string).append(" (must be an unsigned short): ").append(n)));
        }
    }

    static void checkConstant(Object object) {
        if (CheckMethodAdapter.lIIIlIlIlllI(object instanceof Integer) && CheckMethodAdapter.lIIIlIlIlllI(object instanceof Float) && CheckMethodAdapter.lIIIlIlIlllI(object instanceof Long) && CheckMethodAdapter.lIIIlIlIlllI(object instanceof Double) && CheckMethodAdapter.lIIIlIlIlllI(object instanceof String)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid constant: ").append(object)));
        }
    }

    void checkLDCConstant(Object object) {
        if (CheckMethodAdapter.lIIIlIlIlIII(object instanceof Type)) {
            int n = ((Type)object).getSort();
            if (CheckMethodAdapter.lIIIlIlIIllI(n, 10) && CheckMethodAdapter.lIIIlIlIIllI(n, 9) && CheckMethodAdapter.lIIIlIlIIllI(n, 11)) {
                throw new IllegalArgumentException("Illegal LDC constant value");
            }
            if (CheckMethodAdapter.lIIIlIlIIllI(n, 11) && CheckMethodAdapter.lIIIlIlIllII(this.version & 0xFFFF, 49)) {
                throw new IllegalArgumentException("ldc of a constant class requires at least version 1.5");
            }
            if (CheckMethodAdapter.lIIIlIlIlIIl(n, 11) && CheckMethodAdapter.lIIIlIlIllII(this.version & 0xFFFF, 51)) {
                throw new IllegalArgumentException("ldc of a method type requires at least version 1.7");
            }
            "".length();
            if ("  ".length() <= ((0x79 ^ 0x64) & ~(0x6F ^ 0x72))) {
                return;
            }
        } else if (CheckMethodAdapter.lIIIlIlIlIII(object instanceof Handle)) {
            if (CheckMethodAdapter.lIIIlIlIllII(this.version & 0xFFFF, 51)) {
                throw new IllegalArgumentException("ldc of a handle requires at least version 1.7");
            }
            int n = ((Handle)object).getTag();
            if (!CheckMethodAdapter.lIIIlIlIllIl(n, 1) || CheckMethodAdapter.lIIIlIlIlIlI(n, 9)) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("invalid handle tag ").append(n)));
            }
            "".length();
            if (null != null) {
                return;
            }
        } else {
            CheckMethodAdapter.checkConstant(object);
        }
    }

    static void checkUnqualifiedName(int n, String string, String string2) {
        if (CheckMethodAdapter.lIIIlIlIllII(n & 0xFFFF, 49)) {
            CheckMethodAdapter.checkIdentifier(string, string2);
            "".length();
            if (" ".length() == 0) {
                return;
            }
        } else {
            int n2 = 0;
            while (CheckMethodAdapter.lIIIlIlIllII(n2, string.length())) {
                if (CheckMethodAdapter.lIIIlIlIIllI(".;[/".indexOf(string.charAt(n2)), -1)) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be a valid unqualified name): ").append(string)));
                }
                ++n2;
                "".length();
                if (null == null) continue;
                return;
            }
        }
    }

    static void checkIdentifier(String string, String string2) {
        CheckMethodAdapter.checkIdentifier(string, 0, -1, string2);
    }

    static void checkIdentifier(String string, int n, int n2, String string2) {
        int n3;
        block13: {
            block11: {
                block12: {
                    if (!CheckMethodAdapter.lIIIlIlIIlIl(string)) break block11;
                    if (!CheckMethodAdapter.lIIIlIlIlIIl(n2, -1)) break block12;
                    if (!CheckMethodAdapter.lIIIlIllIIlI(string.length(), n)) break block13;
                    "".length();
                    if (-" ".length() < -" ".length()) {
                        return;
                    }
                    break block11;
                }
                if (!CheckMethodAdapter.lIIIlIllIIlI(n2, n)) break block13;
            }
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must not be null or empty)")));
        }
        if (CheckMethodAdapter.lIIIlIlIlllI(Character.isJavaIdentifierStart(string.charAt(n)) ? 1 : 0)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be a valid Java identifier): ").append(string)));
        }
        if (CheckMethodAdapter.lIIIlIlIlIIl(n2, -1)) {
            n3 = string.length();
            "".length();
            if (-(0xB1 ^ 0xB5) > 0) {
                return;
            }
        } else {
            n3 = n2;
        }
        int n4 = n3;
        int n5 = n + 1;
        while (CheckMethodAdapter.lIIIlIlIllII(n5, n4)) {
            if (CheckMethodAdapter.lIIIlIlIlllI(Character.isJavaIdentifierPart(string.charAt(n5)) ? 1 : 0)) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be a valid Java identifier): ").append(string)));
            }
            ++n5;
            "".length();
            if ((0xB3 ^ 0xB7) > 0) continue;
            return;
        }
    }

    static void checkMethodIdentifier(int n, String string, String string2) {
        if (!CheckMethodAdapter.lIIIlIlIIlIl(string) || CheckMethodAdapter.lIIIlIlIlllI(string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must not be null or empty)")));
        }
        if (CheckMethodAdapter.lIIIlIlIllIl(n & 0xFFFF, 49)) {
            int n2 = 0;
            while (CheckMethodAdapter.lIIIlIlIllII(n2, string.length())) {
                if (CheckMethodAdapter.lIIIlIlIIllI(".;[/<>".indexOf(string.charAt(n2)), -1)) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be a valid unqualified name): ").append(string)));
                }
                ++n2;
                "".length();
                if (-(0xC6 ^ 0x83 ^ (0x35 ^ 0x75)) < 0) continue;
                return;
            }
            return;
        }
        if (CheckMethodAdapter.lIIIlIlIlllI(Character.isJavaIdentifierStart(string.charAt(0)) ? 1 : 0)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be a '<init>', '<clinit>' or a valid Java identifier): ").append(string)));
        }
        int n3 = 1;
        while (CheckMethodAdapter.lIIIlIlIllII(n3, string.length())) {
            if (CheckMethodAdapter.lIIIlIlIlllI(Character.isJavaIdentifierPart(string.charAt(n3)) ? 1 : 0)) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be '<init>' or '<clinit>' or a valid Java identifier): ").append(string)));
            }
            ++n3;
            "".length();
            if (" ".length() >= 0) continue;
            return;
        }
    }

    static void checkInternalName(String string, String string2) {
        if (!CheckMethodAdapter.lIIIlIlIIlIl(string) || CheckMethodAdapter.lIIIlIlIlllI(string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must not be null or empty)")));
        }
        if (CheckMethodAdapter.lIIIlIlIlIIl(string.charAt(0), 91)) {
            CheckMethodAdapter.checkDesc(string, false);
            "".length();
            if (((0x7D ^ 0x48) & ~(0xD ^ 0x38)) != 0) {
                return;
            }
        } else {
            CheckMethodAdapter.checkInternalName(string, 0, -1, string2);
        }
    }

    static void checkInternalName(String string, int n, int n2, String string2) {
        int n3;
        if (CheckMethodAdapter.lIIIlIlIlIIl(n2, -1)) {
            n3 = string.length();
            "".length();
            if ("   ".length() > "   ".length()) {
                return;
            }
        } else {
            n3 = n2;
        }
        int n4 = n3;
        try {
            int n5;
            int n6 = n;
            do {
                if (!CheckMethodAdapter.lIIIlIlIIllI(n5 = string.indexOf(47, n6 + 1), -1) || CheckMethodAdapter.lIIIlIlIlIlI(n5, n4)) {
                    n5 = n4;
                }
                CheckMethodAdapter.checkIdentifier(string, n6, n5, null);
                n6 = n5 + 1;
            } while (!CheckMethodAdapter.lIIIlIlIlIIl(n5, n4));
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string2).append(" (must be a fully qualified class name in internal form): ").append(string)));
        }
        "".length();
        if (-" ".length() != -" ".length()) {
            return;
        }
    }

    static void checkDesc(String string, boolean bl) {
        int n = CheckMethodAdapter.checkDesc(string, 0, bl);
        if (CheckMethodAdapter.lIIIlIlIIllI(n, string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
        }
    }

    static int checkDesc(String string, int n, boolean bl) {
        if (!CheckMethodAdapter.lIIIlIlIIlIl(string) || CheckMethodAdapter.lIIIlIlIllIl(n, string.length())) {
            throw new IllegalArgumentException("Invalid type descriptor (must not be null or empty)");
        }
        switch (string.charAt(n)) {
            case 'V': {
                if (CheckMethodAdapter.lIIIlIlIlIII(bl ? 1 : 0)) {
                    return n + 1;
                }
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
            }
            case 'B': 
            case 'C': 
            case 'D': 
            case 'F': 
            case 'I': 
            case 'J': 
            case 'S': 
            case 'Z': {
                return n + 1;
            }
            case '[': {
                int n2 = n + 1;
                while (CheckMethodAdapter.lIIIlIlIllII(n2, string.length()) && CheckMethodAdapter.lIIIlIlIlIIl(string.charAt(n2), 91)) {
                    ++n2;
                    "".length();
                    if (null == null) continue;
                    return (0x86 ^ 0xB2) & ~(0x72 ^ 0x46);
                }
                if (CheckMethodAdapter.lIIIlIlIllII(n2, string.length())) {
                    return CheckMethodAdapter.checkDesc(string, n2, false);
                }
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
            }
            case 'L': {
                int n3 = string.indexOf(59, n);
                if (!CheckMethodAdapter.lIIIlIlIIllI(n3, -1) || CheckMethodAdapter.lIIIlIlIllII(n3 - n, 2)) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
                }
                try {
                    CheckMethodAdapter.checkInternalName(string, n + 1, n3, null);
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
                }
                "".length();
                if (-" ".length() > "   ".length()) {
                    return (8 ^ 0x5E) & ~(0xF4 ^ 0xA2);
                }
                return n3 + 1;
            }
        }
        throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
    }

    static void checkMethodDesc(String string) {
        if (!CheckMethodAdapter.lIIIlIlIIlIl(string) || CheckMethodAdapter.lIIIlIlIlllI(string.length())) {
            throw new IllegalArgumentException("Invalid method descriptor (must not be null or empty)");
        }
        if (!CheckMethodAdapter.lIIIlIlIlIIl(string.charAt(0), 40) || CheckMethodAdapter.lIIIlIlIllII(string.length(), 3)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
        }
        int n = 1;
        if (CheckMethodAdapter.lIIIlIlIIllI(string.charAt(n), 41)) {
            do {
                if (!CheckMethodAdapter.lIIIlIlIlIIl(string.charAt(n), 86)) continue;
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
            } while (CheckMethodAdapter.lIIIlIlIllII(n = CheckMethodAdapter.checkDesc(string, n, false), string.length()) && !CheckMethodAdapter.lIIIlIlIlIIl(string.charAt(n), 41));
        }
        if (CheckMethodAdapter.lIIIlIlIIllI(n = CheckMethodAdapter.checkDesc(string, n + 1, true), string.length())) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(string)));
        }
    }

    void checkLabel(Label label, boolean bl, String string) {
        if (CheckMethodAdapter.lIIIlIlIIlll(label)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string).append(" (must not be null)")));
        }
        if (CheckMethodAdapter.lIIIlIlIlIII(bl ? 1 : 0) && CheckMethodAdapter.lIIIlIlIIlll(this.labels.get(label))) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid ").append(string).append(" (must be visited first)")));
        }
    }

    private static void checkNonDebugLabel(Label label) {
        Field field = CheckMethodAdapter.getLabelStatusField();
        int n = 0;
        try {
            int n2;
            if (CheckMethodAdapter.lIIIlIlIIlll(field)) {
                n2 = 0;
                "".length();
                if ("  ".length() < 0) {
                    return;
                }
            } else {
                n2 = (Integer)field.get(label);
            }
            n = n2;
            "".length();
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new Error("Internal error");
        }
        if (((0xB0 ^ 0xAE ^ (0x18 ^ 0x50)) & (0x47 ^ 0x57 ^ (0x67 ^ 0x21) ^ -" ".length())) < 0) {
            return;
        }
        if (CheckMethodAdapter.lIIIlIlIlIII(n & 1)) {
            throw new IllegalArgumentException("Labels used for debug info cannot be reused for control flow");
        }
    }

    private static Field getLabelStatusField() {
        if (CheckMethodAdapter.lIIIlIlIIlll(labelStatusField) && CheckMethodAdapter.lIIIlIlIIlll(labelStatusField = CheckMethodAdapter.getLabelField("a"))) {
            labelStatusField = CheckMethodAdapter.getLabelField("status");
        }
        return labelStatusField;
    }

    private static Field getLabelField(String string) {
        try {
            Field field = Label.class.getDeclaredField(string);
            field.setAccessible(true);
            return field;
        }
        catch (NoSuchFieldException noSuchFieldException) {
            return null;
        }
    }

    static {
        String string = "BBBBBBBBBBBBBBBBCCIAADDDDDAAAAAAAAAAAAAAAAAAAABBBBBBBBDDDDDAAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBJBBBBBBBBBBBBBBBBBBBBHHHHHHHHHHHHHHHHDKLBBBBBBFFFFGGGGAECEBBEEBBAMHHAA";
        TYPE = new int[string.length()];
        int n = 0;
        while (CheckMethodAdapter.lIIIlIlIllII(n, TYPE.length)) {
            CheckMethodAdapter.TYPE[n] = string.charAt(n) - 65 - 1;
            ++n;
            "".length();
            if (((0x3E ^ 0x54 ^ (0xCE ^ 0xBD)) & (0x7B ^ 0x76 ^ (0xAB ^ 0xBF) ^ -" ".length())) == 0) continue;
            break;
        }
    }

    private static boolean lIIIlIlIlIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIlIllIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIlIlIllII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIllIIlI(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIlIlIlIlI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlIlIIlII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIlIlIIlIl(Object object) {
        return object != null;
    }

    private static boolean lIIIlIllIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIlIlIIlll(Object object) {
        return object == null;
    }

    private static boolean lIIIlIlIlIII(int n) {
        return n != 0;
    }

    private static boolean lIIIlIlIlllI(int n) {
        return n == 0;
    }

    private static boolean lIIIlIllIllI(int n) {
        return n >= 0;
    }

    private static boolean lIIIlIlIlIll(int n) {
        return n > 0;
    }

    private static boolean lIIIlIlIIllI(int n, int n2) {
        return n != n2;
    }
}

