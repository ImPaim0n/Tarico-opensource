/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.lib.util.CheckMethodAdapter;

public class CheckSignatureAdapter
extends SignatureVisitor {
    public static final int CLASS_SIGNATURE;
    public static final int METHOD_SIGNATURE;
    public static final int TYPE_SIGNATURE;
    private static final int EMPTY;
    private static final int FORMAL;
    private static final int BOUND;
    private static final int SUPER;
    private static final int PARAM;
    private static final int RETURN;
    private static final int SIMPLE_TYPE;
    private static final int CLASS_TYPE;
    private static final int END;
    private final int type;
    private int state;
    private boolean canBeVoid;
    private final SignatureVisitor sv;

    public CheckSignatureAdapter(int n, SignatureVisitor signatureVisitor) {
        this(327680, n, signatureVisitor);
    }

    protected CheckSignatureAdapter(int n, int n2, SignatureVisitor signatureVisitor) {
        super(n);
        this.type = n2;
        this.state = 1;
        this.sv = signatureVisitor;
    }

    public void visitFormalTypeParameter(String string) {
        if (!CheckSignatureAdapter.lIlllIlIIll(this.type, 2) || CheckSignatureAdapter.lIlllIlIIll(this.state, 1) && CheckSignatureAdapter.lIlllIlIIll(this.state, 2) && CheckSignatureAdapter.lIlllIlIIll(this.state, 4)) {
            throw new IllegalStateException();
        }
        CheckMethodAdapter.checkIdentifier(string, "formal type parameter");
        this.state = 2;
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitFormalTypeParameter(string);
        }
    }

    public SignatureVisitor visitClassBound() {
        SignatureVisitor signatureVisitor;
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 2)) {
            throw new IllegalStateException();
        }
        this.state = 4;
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if (-"   ".length() > 0) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitClassBound();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public SignatureVisitor visitInterfaceBound() {
        SignatureVisitor signatureVisitor;
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 2) && CheckSignatureAdapter.lIlllIlIIll(this.state, 4)) {
            throw new IllegalArgumentException();
        }
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if (((" ".length() ^ (0x42 ^ 9)) & (0xC3 ^ 0x98 ^ (0x72 ^ 0x63) ^ -" ".length())) > " ".length()) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitInterfaceBound();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public SignatureVisitor visitSuperclass() {
        SignatureVisitor signatureVisitor;
        if (!CheckSignatureAdapter.lIlllIlIllI(this.type) || CheckSignatureAdapter.lIlllIlIllI(this.state & 7)) {
            throw new IllegalArgumentException();
        }
        this.state = 8;
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if ("   ".length() != "   ".length()) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitSuperclass();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public SignatureVisitor visitInterface() {
        SignatureVisitor signatureVisitor;
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 8)) {
            throw new IllegalStateException();
        }
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if (-" ".length() != -" ".length()) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitInterface();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public SignatureVisitor visitParameterType() {
        SignatureVisitor signatureVisitor;
        if (!CheckSignatureAdapter.lIlllIlIlll(this.type, 1) || CheckSignatureAdapter.lIlllIlIllI(this.state & 0x17)) {
            throw new IllegalArgumentException();
        }
        this.state = 16;
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if ("  ".length() != "  ".length()) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitParameterType();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public SignatureVisitor visitReturnType() {
        SignatureVisitor signatureVisitor;
        if (!CheckSignatureAdapter.lIlllIlIlll(this.type, 1) || CheckSignatureAdapter.lIlllIlIllI(this.state & 0x17)) {
            throw new IllegalArgumentException();
        }
        this.state = 32;
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if (((1 ^ 0x32 ^ (0x23 ^ 0x27)) & (0xF3 ^ 0xA3 ^ (0xD6 ^ 0xB1) ^ -" ".length())) != ((74 + 44 - 53 + 106 ^ 142 + 86 - 194 + 133) & (0x5D ^ 0x25 ^ (0xD2 ^ 0xA6) ^ -" ".length()))) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitReturnType();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        CheckSignatureAdapter checkSignatureAdapter = new CheckSignatureAdapter(2, signatureVisitor2);
        checkSignatureAdapter.canBeVoid = true;
        return checkSignatureAdapter;
    }

    public SignatureVisitor visitExceptionType() {
        SignatureVisitor signatureVisitor;
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 32)) {
            throw new IllegalStateException();
        }
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if ("   ".length() != "   ".length()) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitExceptionType();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public void visitBaseType(char c) {
        if (!CheckSignatureAdapter.lIlllIlIlll(this.type, 2) || CheckSignatureAdapter.lIlllIlIIll(this.state, 1)) {
            throw new IllegalStateException();
        }
        if (CheckSignatureAdapter.lIlllIlIlll(c, 86) ? CheckSignatureAdapter.lIlllIlIllI(this.canBeVoid ? 1 : 0) : CheckSignatureAdapter.lIlllIlIlll("ZCBSIFJD".indexOf(c), -1)) {
            throw new IllegalArgumentException();
        }
        this.state = 64;
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitBaseType(c);
        }
    }

    public void visitTypeVariable(String string) {
        if (!CheckSignatureAdapter.lIlllIlIlll(this.type, 2) || CheckSignatureAdapter.lIlllIlIIll(this.state, 1)) {
            throw new IllegalStateException();
        }
        CheckMethodAdapter.checkIdentifier(string, "type variable");
        this.state = 64;
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitTypeVariable(string);
        }
    }

    public SignatureVisitor visitArrayType() {
        SignatureVisitor signatureVisitor;
        if (!CheckSignatureAdapter.lIlllIlIlll(this.type, 2) || CheckSignatureAdapter.lIlllIlIIll(this.state, 1)) {
            throw new IllegalStateException();
        }
        this.state = 64;
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitArrayType();
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public void visitClassType(String string) {
        if (!CheckSignatureAdapter.lIlllIlIlll(this.type, 2) || CheckSignatureAdapter.lIlllIlIIll(this.state, 1)) {
            throw new IllegalStateException();
        }
        CheckMethodAdapter.checkInternalName(string, "class name");
        this.state = 128;
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitClassType(string);
        }
    }

    public void visitInnerClassType(String string) {
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 128)) {
            throw new IllegalStateException();
        }
        CheckMethodAdapter.checkIdentifier(string, "inner class name");
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitInnerClassType(string);
        }
    }

    public void visitTypeArgument() {
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 128)) {
            throw new IllegalStateException();
        }
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitTypeArgument();
        }
    }

    public SignatureVisitor visitTypeArgument(char c) {
        SignatureVisitor signatureVisitor;
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 128)) {
            throw new IllegalStateException();
        }
        if (CheckSignatureAdapter.lIlllIlIlll("+-=".indexOf(c), -1)) {
            throw new IllegalArgumentException();
        }
        if (CheckSignatureAdapter.lIlllIlIlIl(this.sv)) {
            signatureVisitor = null;
            "".length();
            if (((26 + 22 - -137 + 14 ^ 21 + 100 - -8 + 20) & (0x7F ^ 0x42 ^ (0x69 ^ 6) ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            signatureVisitor = this.sv.visitTypeArgument(c);
        }
        SignatureVisitor signatureVisitor2 = signatureVisitor;
        return new CheckSignatureAdapter(2, signatureVisitor2);
    }

    public void visitEnd() {
        if (CheckSignatureAdapter.lIlllIlIIll(this.state, 128)) {
            throw new IllegalStateException();
        }
        this.state = 256;
        if (CheckSignatureAdapter.lIlllIlIlII(this.sv)) {
            this.sv.visitEnd();
        }
    }

    static {
        PARAM = 16;
        EMPTY = 1;
        RETURN = 32;
        TYPE_SIGNATURE = 2;
        BOUND = 4;
        END = 256;
        METHOD_SIGNATURE = 1;
        SUPER = 8;
        CLASS_TYPE = 128;
        FORMAL = 2;
        SIMPLE_TYPE = 64;
        CLASS_SIGNATURE = 0;
    }

    private static boolean lIlllIlIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlllIlIlII(Object object) {
        return object != null;
    }

    private static boolean lIlllIlIlIl(Object object) {
        return object == null;
    }

    private static boolean lIlllIlIllI(int n) {
        return n == 0;
    }

    private static boolean lIlllIlIIll(int n, int n2) {
        return n != n2;
    }
}

