/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.TypeReference;
import org.spongepowered.asm.lib.signature.SignatureReader;
import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.lib.util.Printer;
import org.spongepowered.asm.lib.util.Textifiable;
import org.spongepowered.asm.lib.util.TraceClassVisitor;
import org.spongepowered.asm.lib.util.TraceSignatureVisitor;

public class Textifier
extends Printer {
    public static final int INTERNAL_NAME;
    public static final int FIELD_DESCRIPTOR;
    public static final int FIELD_SIGNATURE;
    public static final int METHOD_DESCRIPTOR;
    public static final int METHOD_SIGNATURE;
    public static final int CLASS_SIGNATURE;
    public static final int TYPE_DECLARATION;
    public static final int CLASS_DECLARATION;
    public static final int PARAMETERS_DECLARATION;
    public static final int HANDLE_DESCRIPTOR;
    protected String tab = "  ";
    protected String tab2 = "    ";
    protected String tab3 = "      ";
    protected String ltab = "   ";
    protected Map<Label, String> labelNames;
    private int access;
    private int valueNumber = 0;

    public Textifier() {
        this(327680);
        if (Textifier.lIIIlIllllII(this.getClass(), Textifier.class)) {
            throw new IllegalStateException();
        }
    }

    protected Textifier(int n) {
        super(n);
    }

    public static void main(String[] stringArray) {
        ClassReader classReader;
        int n = 0;
        int n2 = 2;
        int n3 = 1;
        if (!Textifier.lIIIlIllllIl(stringArray.length, 1) || Textifier.lIIIlIlllllI(stringArray.length, 2)) {
            n3 = 0;
        }
        if (Textifier.lIIIlIllllll(n3) && Textifier.lIIIlIllllll("-debug".equals(stringArray[0]) ? 1 : 0)) {
            n = 1;
            n2 = 0;
            if (Textifier.lIIIllIIIIII(stringArray.length, 2)) {
                n3 = 0;
            }
        }
        if (Textifier.lIIIllIIIIIl(n3)) {
            System.err.println("Prints a disassembled view of the given class.");
            System.err.println("Usage: Textifier [-debug] <fully qualified class name or class file name>");
            return;
        }
        if (!Textifier.lIIIllIIIIIl(stringArray[n].endsWith(".class") ? 1 : 0) || !Textifier.lIIIllIIIIlI(stringArray[n].indexOf(92), -1) || Textifier.lIIIlIlllllI(stringArray[n].indexOf(47), -1)) {
            classReader = new ClassReader(new FileInputStream(stringArray[n]));
            "".length();
            if (((0x96 ^ 0xA3) & ~(0xA2 ^ 0x97)) < 0) {
                return;
            }
        } else {
            classReader = new ClassReader(stringArray[n]);
        }
        classReader.accept(new TraceClassVisitor(new PrintWriter(System.out)), n2);
    }

    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        this.access = n2;
        int n3 = n & 0xFFFF;
        int n4 = n >>> 16;
        this.buf.setLength(0);
        this.buf.append("// class version ").append(n3).append('.').append(n4).append(" (").append(n).append(")\n");
        "".length();
        if (Textifier.lIIIlIllllll(n2 & 0x20000)) {
            this.buf.append("// DEPRECATED\n");
            "".length();
        }
        this.buf.append("// access flags 0x").append(Integer.toHexString(n2).toUpperCase()).append('\n');
        "".length();
        this.appendDescriptor(5, string2);
        if (Textifier.lIIIllIIIIll(string2)) {
            TraceSignatureVisitor traceSignatureVisitor = new TraceSignatureVisitor(n2);
            SignatureReader signatureReader = new SignatureReader(string2);
            signatureReader.accept(traceSignatureVisitor);
            this.buf.append("// declaration: ").append(string).append(traceSignatureVisitor.getDeclaration()).append('\n');
            "".length();
        }
        this.appendAccess(n2 & 0xFFFFFFDF);
        if (Textifier.lIIIlIllllll(n2 & 0x2000)) {
            this.buf.append("@interface ");
            "".length();
            "".length();
            if (((0x54 ^ 0x16) & ~(0x2D ^ 0x6F)) != 0) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(n2 & 0x200)) {
            this.buf.append("interface ");
            "".length();
            "".length();
            if (-(26 + 65 - 68 + 148 ^ 143 + 153 - 202 + 81) >= 0) {
                return;
            }
        } else if (Textifier.lIIIllIIIIIl(n2 & 0x4000)) {
            this.buf.append("class ");
            "".length();
        }
        this.appendDescriptor(0, string);
        if (Textifier.lIIIllIIIIll(string3) && Textifier.lIIIllIIIIIl("java/lang/Object".equals(string3) ? 1 : 0)) {
            this.buf.append(" extends ");
            "".length();
            this.appendDescriptor(0, string3);
            this.buf.append(' ');
            "".length();
        }
        if (Textifier.lIIIllIIIIll(stringArray) && Textifier.lIIIllIIIlII(stringArray.length)) {
            this.buf.append(" implements ");
            "".length();
            int n5 = 0;
            while (Textifier.lIIIllIIIlIl(n5, stringArray.length)) {
                this.appendDescriptor(0, stringArray[n5]);
                this.buf.append(' ');
                "".length();
                ++n5;
                "".length();
                if (null == null) continue;
                return;
            }
        }
        this.buf.append(" {\n\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitSource(String string, String string2) {
        this.buf.setLength(0);
        if (Textifier.lIIIllIIIIll(string)) {
            this.buf.append(this.tab).append("// compiled from: ").append(string).append('\n');
            "".length();
        }
        if (Textifier.lIIIllIIIIll(string2)) {
            this.buf.append(this.tab).append("// debug info: ").append(string2).append('\n');
            "".length();
        }
        if (Textifier.lIIIllIIIlII(this.buf.length())) {
            this.text.add(this.buf.toString());
            "".length();
        }
    }

    public void visitOuterClass(String string, String string2, String string3) {
        this.buf.setLength(0);
        this.buf.append(this.tab).append("OUTERCLASS ");
        "".length();
        this.appendDescriptor(0, string);
        this.buf.append(' ');
        "".length();
        if (Textifier.lIIIllIIIIll(string2)) {
            this.buf.append(string2).append(' ');
            "".length();
        }
        this.appendDescriptor(3, string3);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Textifier visitClassAnnotation(String string, boolean bl) {
        this.text.add("\n");
        "".length();
        return this.visitAnnotation(string, bl);
    }

    public Printer visitClassTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        this.text.add("\n");
        "".length();
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public void visitClassAttribute(Attribute attribute) {
        this.text.add("\n");
        "".length();
        this.visitAttribute(attribute);
    }

    public void visitInnerClass(String string, String string2, String string3, int n) {
        this.buf.setLength(0);
        this.buf.append(this.tab).append("// access flags 0x");
        "".length();
        this.buf.append(Integer.toHexString(n & 0xFFFFFFDF).toUpperCase()).append('\n');
        "".length();
        this.buf.append(this.tab);
        "".length();
        this.appendAccess(n);
        this.buf.append("INNERCLASS ");
        "".length();
        this.appendDescriptor(0, string);
        this.buf.append(' ');
        "".length();
        this.appendDescriptor(0, string2);
        this.buf.append(' ');
        "".length();
        this.appendDescriptor(0, string3);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Textifier visitField(int n, String string, String string2, String string3, Object object) {
        Object object2;
        this.buf.setLength(0);
        this.buf.append('\n');
        "".length();
        if (Textifier.lIIIlIllllll(n & 0x20000)) {
            this.buf.append(this.tab).append("// DEPRECATED\n");
            "".length();
        }
        this.buf.append(this.tab).append("// access flags 0x").append(Integer.toHexString(n).toUpperCase()).append('\n');
        "".length();
        if (Textifier.lIIIllIIIIll(string3)) {
            this.buf.append(this.tab);
            "".length();
            this.appendDescriptor(2, string3);
            object2 = new TraceSignatureVisitor(0);
            SignatureReader signatureReader = new SignatureReader(string3);
            signatureReader.acceptType((SignatureVisitor)object2);
            this.buf.append(this.tab).append("// declaration: ").append(((TraceSignatureVisitor)object2).getDeclaration()).append('\n');
            "".length();
        }
        this.buf.append(this.tab);
        "".length();
        this.appendAccess(n);
        this.appendDescriptor(1, string2);
        this.buf.append(' ').append(string);
        "".length();
        if (Textifier.lIIIllIIIIll(object)) {
            this.buf.append(" = ");
            "".length();
            if (Textifier.lIIIlIllllll(object instanceof String)) {
                this.buf.append('\"').append(object).append('\"');
                "".length();
                "".length();
                if ((0xAB ^ 0xAF) == 0) {
                    return null;
                }
            } else {
                this.buf.append(object);
                "".length();
            }
        }
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        object2 = this.createTextifier();
        this.text.add(((Printer)object2).getText());
        "".length();
        return object2;
    }

    public Textifier visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        Object object;
        this.buf.setLength(0);
        this.buf.append('\n');
        "".length();
        if (Textifier.lIIIlIllllll(n & 0x20000)) {
            this.buf.append(this.tab).append("// DEPRECATED\n");
            "".length();
        }
        this.buf.append(this.tab).append("// access flags 0x").append(Integer.toHexString(n).toUpperCase()).append('\n');
        "".length();
        if (Textifier.lIIIllIIIIll(string3)) {
            this.buf.append(this.tab);
            "".length();
            this.appendDescriptor(4, string3);
            object = new TraceSignatureVisitor(0);
            SignatureReader signatureReader = new SignatureReader(string3);
            signatureReader.accept((SignatureVisitor)object);
            String string4 = ((TraceSignatureVisitor)object).getDeclaration();
            String string5 = ((TraceSignatureVisitor)object).getReturnType();
            String string6 = ((TraceSignatureVisitor)object).getExceptions();
            this.buf.append(this.tab).append("// declaration: ").append(string5).append(' ').append(string).append(string4);
            "".length();
            if (Textifier.lIIIllIIIIll(string6)) {
                this.buf.append(" throws ").append(string6);
                "".length();
            }
            this.buf.append('\n');
            "".length();
        }
        this.buf.append(this.tab);
        "".length();
        this.appendAccess(n & 0xFFFFFFBF);
        if (Textifier.lIIIlIllllll(n & 0x100)) {
            this.buf.append("native ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x80)) {
            this.buf.append("varargs ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x40)) {
            this.buf.append("bridge ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(this.access & 0x200) && Textifier.lIIIllIIIIIl(n & 0x400) && Textifier.lIIIllIIIIIl(n & 8)) {
            this.buf.append("default ");
            "".length();
        }
        this.buf.append(string);
        "".length();
        this.appendDescriptor(3, string2);
        if (Textifier.lIIIllIIIIll(stringArray) && Textifier.lIIIllIIIlII(stringArray.length)) {
            this.buf.append(" throws ");
            "".length();
            int n2 = 0;
            while (Textifier.lIIIllIIIlIl(n2, stringArray.length)) {
                this.appendDescriptor(0, stringArray[n2]);
                this.buf.append(' ');
                "".length();
                ++n2;
                "".length();
                if (-" ".length() == -" ".length()) continue;
                return null;
            }
        }
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        object = this.createTextifier();
        this.text.add(((Printer)object).getText());
        "".length();
        return object;
    }

    public void visitClassEnd() {
        this.text.add("}\n");
        "".length();
    }

    public void visit(String string, Object object) {
        this.buf.setLength(0);
        this.appendComa(this.valueNumber++);
        if (Textifier.lIIIllIIIIll(string)) {
            this.buf.append(string).append('=');
            "".length();
        }
        if (Textifier.lIIIlIllllll(object instanceof String)) {
            this.visitString((String)object);
            "".length();
            if ((0x80 ^ 0x84) == 0) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Type)) {
            this.visitType((Type)object);
            "".length();
            if (((6 ^ 0x1F) & ~(0x69 ^ 0x70)) != 0) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Byte)) {
            this.visitByte((Byte)object);
            "".length();
            if (null != null) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Boolean)) {
            this.visitBoolean((Boolean)object);
            "".length();
            if (-"   ".length() > 0) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Short)) {
            this.visitShort((Short)object);
            "".length();
            if (-" ".length() > "   ".length()) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Character)) {
            this.visitChar(((Character)object).charValue());
            "".length();
            if ((0xAC ^ 0xA9) == 0) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Integer)) {
            this.visitInt((Integer)object);
            "".length();
            if ("   ".length() > "   ".length()) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Float)) {
            this.visitFloat(((Float)object).floatValue());
            "".length();
            if (null != null) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Long)) {
            this.visitLong((Long)object);
            "".length();
            if (((0xEE ^ 0xB2) & ~(0xFA ^ 0xA6)) != 0) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Double)) {
            this.visitDouble((Double)object);
            "".length();
            if ((0xA1 ^ 0x93 ^ (5 ^ 0x33)) < "  ".length()) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object.getClass().isArray() ? 1 : 0)) {
            this.buf.append('{');
            "".length();
            if (Textifier.lIIIlIllllll(object instanceof byte[])) {
                byte[] byArray = (byte[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, byArray.length)) {
                    this.appendComa(n);
                    this.visitByte(byArray[n]);
                    ++n;
                    "".length();
                    if (((0xC6 ^ 0xC1) & ~(0xC3 ^ 0xC4)) == 0) continue;
                    return;
                }
                "".length();
                if (" ".length() > (0x30 ^ 0x34)) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof boolean[])) {
                boolean[] blArray = (boolean[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, blArray.length)) {
                    this.appendComa(n);
                    this.visitBoolean(blArray[n]);
                    ++n;
                    "".length();
                    if (-" ".length() >= -" ".length()) continue;
                    return;
                }
                "".length();
                if (" ".length() != " ".length()) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof short[])) {
                short[] sArray = (short[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, sArray.length)) {
                    this.appendComa(n);
                    this.visitShort(sArray[n]);
                    ++n;
                    "".length();
                    if (-" ".length() < 0) continue;
                    return;
                }
                "".length();
                if ("   ".length() == 0) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof char[])) {
                char[] cArray = (char[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, cArray.length)) {
                    this.appendComa(n);
                    this.visitChar(cArray[n]);
                    ++n;
                    "".length();
                    if (((0xD0 ^ 0x81) & ~(0x60 ^ 0x31)) <= 0) continue;
                    return;
                }
                "".length();
                if ("   ".length() < "  ".length()) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof int[])) {
                int[] nArray = (int[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, nArray.length)) {
                    this.appendComa(n);
                    this.visitInt(nArray[n]);
                    ++n;
                    "".length();
                    if ((0x8C ^ 0x88) == (0x3F ^ 0x3B)) continue;
                    return;
                }
                "".length();
                if (-(119 + 76 - 90 + 55 ^ 108 + 59 - 31 + 29) >= 0) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof long[])) {
                long[] lArray = (long[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, lArray.length)) {
                    this.appendComa(n);
                    this.visitLong(lArray[n]);
                    ++n;
                    "".length();
                    if (((0x6A ^ 0x35) & ~(0x7E ^ 0x21)) != -" ".length()) continue;
                    return;
                }
                "".length();
                if (null != null) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof float[])) {
                float[] fArray = (float[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, fArray.length)) {
                    this.appendComa(n);
                    this.visitFloat(fArray[n]);
                    ++n;
                    "".length();
                    if (" ".length() >= 0) continue;
                    return;
                }
                "".length();
                if (null != null) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(object instanceof double[])) {
                double[] dArray = (double[])object;
                int n = 0;
                while (Textifier.lIIIllIIIlIl(n, dArray.length)) {
                    this.appendComa(n);
                    this.visitDouble(dArray[n]);
                    ++n;
                    "".length();
                    if (((213 + 189 - 376 + 195 ^ 128 + 112 - 234 + 131) & (0xF0 ^ 0xB3 ^ (0x80 ^ 0x97) ^ -" ".length())) == ((135 + 167 - 276 + 162 ^ 127 + 55 - 164 + 124) & (79 + 110 - 112 + 78 ^ 3 + 68 - -17 + 81 ^ -" ".length()))) continue;
                    return;
                }
            }
            this.buf.append('}');
            "".length();
        }
        this.text.add(this.buf.toString());
        "".length();
    }

    private void visitInt(int n) {
        this.buf.append(n);
        "".length();
    }

    private void visitLong(long l) {
        this.buf.append(l).append('L');
        "".length();
    }

    private void visitFloat(float f) {
        this.buf.append(f).append('F');
        "".length();
    }

    private void visitDouble(double d) {
        this.buf.append(d).append('D');
        "".length();
    }

    private void visitChar(char c) {
        this.buf.append("(char)").append((int)c);
        "".length();
    }

    private void visitShort(short s) {
        this.buf.append("(short)").append(s);
        "".length();
    }

    private void visitByte(byte by) {
        this.buf.append("(byte)").append(by);
        "".length();
    }

    private void visitBoolean(boolean bl) {
        this.buf.append(bl);
        "".length();
    }

    private void visitString(String string) {
        Textifier.appendString(this.buf, string);
    }

    private void visitType(Type type) {
        this.buf.append(type.getClassName()).append(".class");
        "".length();
    }

    public void visitEnum(String string, String string2, String string3) {
        this.buf.setLength(0);
        this.appendComa(this.valueNumber++);
        if (Textifier.lIIIllIIIIll(string)) {
            this.buf.append(string).append('=');
            "".length();
        }
        this.appendDescriptor(1, string2);
        this.buf.append('.').append(string3);
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Textifier visitAnnotation(String string, String string2) {
        this.buf.setLength(0);
        this.appendComa(this.valueNumber++);
        if (Textifier.lIIIllIIIIll(string)) {
            this.buf.append(string).append('=');
            "".length();
        }
        this.buf.append('@');
        "".length();
        this.appendDescriptor(1, string2);
        this.buf.append('(');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        this.text.add(")");
        "".length();
        return textifier;
    }

    public Textifier visitArray(String string) {
        this.buf.setLength(0);
        this.appendComa(this.valueNumber++);
        if (Textifier.lIIIllIIIIll(string)) {
            this.buf.append(string).append('=');
            "".length();
        }
        this.buf.append('{');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        this.text.add("}");
        "".length();
        return textifier;
    }

    public void visitAnnotationEnd() {
    }

    public Textifier visitFieldAnnotation(String string, boolean bl) {
        return this.visitAnnotation(string, bl);
    }

    public Printer visitFieldTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public void visitFieldAttribute(Attribute attribute) {
        this.visitAttribute(attribute);
    }

    public void visitFieldEnd() {
    }

    public void visitParameter(String string, int n) {
        String string2;
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("// parameter ");
        "".length();
        this.appendAccess(n);
        StringBuffer stringBuffer = this.buf.append(' ');
        if (Textifier.lIIIllIIIllI(string)) {
            string2 = "<no name>";
            "".length();
            if (null != null) {
                return;
            }
        } else {
            string2 = string;
        }
        stringBuffer.append(string2).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Textifier visitAnnotationDefault() {
        this.text.add(String.valueOf(new StringBuilder().append(this.tab2).append("default=")));
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        this.text.add("\n");
        "".length();
        return textifier;
    }

    public Textifier visitMethodAnnotation(String string, boolean bl) {
        return this.visitAnnotation(string, bl);
    }

    public Printer visitMethodTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public Textifier visitParameterAnnotation(int n, String string, boolean bl) {
        String string2;
        this.buf.setLength(0);
        this.buf.append(this.tab2).append('@');
        "".length();
        this.appendDescriptor(1, string);
        this.buf.append('(');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        if (Textifier.lIIIlIllllll(bl ? 1 : 0)) {
            string2 = ") // parameter ";
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string2 = ") // invisible, parameter ";
        }
        this.text.add(string2);
        "".length();
        this.text.add(n);
        "".length();
        this.text.add("\n");
        "".length();
        return textifier;
    }

    public void visitMethodAttribute(Attribute attribute) {
        this.buf.setLength(0);
        this.buf.append(this.tab).append("ATTRIBUTE ");
        "".length();
        this.appendDescriptor(-1, attribute.type);
        if (Textifier.lIIIlIllllll(attribute instanceof Textifiable)) {
            ((Textifiable)((Object)attribute)).textify(this.buf, this.labelNames);
            "".length();
            if (null != null) {
                return;
            }
        } else {
            this.buf.append(" : unknown\n");
            "".length();
        }
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitCode() {
    }

    public void visitFrame(int n, int n2, Object[] objectArray, int n3, Object[] objectArray2) {
        this.buf.setLength(0);
        this.buf.append(this.ltab);
        "".length();
        this.buf.append("FRAME ");
        "".length();
        switch (n) {
            case -1: 
            case 0: {
                this.buf.append("FULL [");
                "".length();
                this.appendFrameTypes(n2, objectArray);
                this.buf.append("] [");
                "".length();
                this.appendFrameTypes(n3, objectArray2);
                this.buf.append(']');
                "".length();
                "".length();
                if (" ".length() == " ".length()) break;
                return;
            }
            case 1: {
                this.buf.append("APPEND [");
                "".length();
                this.appendFrameTypes(n2, objectArray);
                this.buf.append(']');
                "".length();
                "".length();
                if ((0xB6 ^ 0xB2) != 0) break;
                return;
            }
            case 2: {
                this.buf.append("CHOP ").append(n2);
                "".length();
                "".length();
                if ((0x99 ^ 0x9C ^ " ".length()) == (0xDF ^ 0xB2 ^ (0x5B ^ 0x32))) break;
                return;
            }
            case 3: {
                this.buf.append("SAME");
                "".length();
                "".length();
                if (" ".length() > -" ".length()) break;
                return;
            }
            case 4: {
                this.buf.append("SAME1 ");
                "".length();
                this.appendFrameTypes(1, objectArray2);
            }
        }
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitInsn(int n) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append(OPCODES[n]).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitIntInsn(int n, int n2) {
        String string;
        this.buf.setLength(0);
        StringBuffer stringBuffer = this.buf.append(this.tab2).append(OPCODES[n]).append(' ');
        if (Textifier.lIIIllIIIlll(n, 188)) {
            string = TYPES[n2];
            "".length();
            if (-"  ".length() > 0) {
                return;
            }
        } else {
            string = Integer.toString(n2);
        }
        stringBuffer.append(string).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitVarInsn(int n, int n2) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append(OPCODES[n]).append(' ').append(n2).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitTypeInsn(int n, String string) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append(OPCODES[n]).append(' ');
        "".length();
        this.appendDescriptor(0, string);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitFieldInsn(int n, String string, String string2, String string3) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append(OPCODES[n]).append(' ');
        "".length();
        this.appendDescriptor(0, string);
        this.buf.append('.').append(string2).append(" : ");
        "".length();
        this.appendDescriptor(1, string3);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    @Deprecated
    public void visitMethodInsn(int n, String string, String string2, String string3) {
        boolean bl;
        if (Textifier.lIIIlIllllIl(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3);
            return;
        }
        if (Textifier.lIIIllIIIlll(n, 185)) {
            bl = true;
            "".length();
            if (-" ".length() > 0) {
                return;
            }
        } else {
            bl = false;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        if (Textifier.lIIIllIIIlIl(this.api, 327680)) {
            super.visitMethodInsn(n, string, string2, string3, bl);
            return;
        }
        this.doVisitMethodInsn(n, string, string2, string3, bl);
    }

    private void doVisitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append(OPCODES[n]).append(' ');
        "".length();
        this.appendDescriptor(0, string);
        this.buf.append('.').append(string2).append(' ');
        "".length();
        this.appendDescriptor(3, string3);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("INVOKEDYNAMIC").append(' ');
        "".length();
        this.buf.append(string);
        "".length();
        this.appendDescriptor(3, string2);
        this.buf.append(" [");
        "".length();
        this.buf.append('\n');
        "".length();
        this.buf.append(this.tab3);
        "".length();
        this.appendHandle(handle);
        this.buf.append('\n');
        "".length();
        this.buf.append(this.tab3).append("// arguments:");
        "".length();
        if (Textifier.lIIIllIIIIIl(objectArray.length)) {
            this.buf.append(" none");
            "".length();
            "".length();
            if (-(0x3B ^ 0x3F) >= 0) {
                return;
            }
        } else {
            this.buf.append('\n');
            "".length();
            int n = 0;
            while (Textifier.lIIIllIIIlIl(n, objectArray.length)) {
                this.buf.append(this.tab3);
                "".length();
                Object object = objectArray[n];
                if (Textifier.lIIIlIllllll(object instanceof String)) {
                    Printer.appendString(this.buf, (String)object);
                    "".length();
                    if ((0x68 ^ 0x76 ^ (0xB1 ^ 0xAB)) <= 0) {
                        return;
                    }
                } else if (Textifier.lIIIlIllllll(object instanceof Type)) {
                    Type type = (Type)object;
                    if (Textifier.lIIIllIIIlll(type.getSort(), 11)) {
                        this.appendDescriptor(3, type.getDescriptor());
                        "".length();
                        if ("   ".length() <= 0) {
                            return;
                        }
                    } else {
                        this.buf.append(type.getDescriptor()).append(".class");
                        "".length();
                    }
                    "".length();
                    if (((0x6D ^ 0x25) & ~(0x89 ^ 0xC1)) != 0) {
                        return;
                    }
                } else if (Textifier.lIIIlIllllll(object instanceof Handle)) {
                    this.appendHandle((Handle)object);
                    "".length();
                    if (null != null) {
                        return;
                    }
                } else {
                    this.buf.append(object);
                    "".length();
                }
                this.buf.append(", \n");
                "".length();
                ++n;
                "".length();
                if (((0x75 ^ 0x63 ^ (0xFD ^ 0xAD)) & (0xD8 ^ 0xB5 ^ (0xA ^ 0x21) ^ -" ".length())) < "   ".length()) continue;
                return;
            }
            this.buf.setLength(this.buf.length() - 3);
        }
        this.buf.append('\n');
        "".length();
        this.buf.append(this.tab2).append("]\n");
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitJumpInsn(int n, Label label) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append(OPCODES[n]).append(' ');
        "".length();
        this.appendLabel(label);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitLabel(Label label) {
        this.buf.setLength(0);
        this.buf.append(this.ltab);
        "".length();
        this.appendLabel(label);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitLdcInsn(Object object) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("LDC ");
        "".length();
        if (Textifier.lIIIlIllllll(object instanceof String)) {
            Printer.appendString(this.buf, (String)object);
            "".length();
            if (null != null) {
                return;
            }
        } else if (Textifier.lIIIlIllllll(object instanceof Type)) {
            this.buf.append(((Type)object).getDescriptor()).append(".class");
            "".length();
            "".length();
            if ("  ".length() <= 0) {
                return;
            }
        } else {
            this.buf.append(object);
            "".length();
        }
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitIincInsn(int n, int n2) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("IINC ").append(n).append(' ').append(n2).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitTableSwitchInsn(int n, int n2, Label label, Label ... labelArray) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("TABLESWITCH\n");
        "".length();
        int n3 = 0;
        while (Textifier.lIIIllIIIlIl(n3, labelArray.length)) {
            this.buf.append(this.tab3).append(n + n3).append(": ");
            "".length();
            this.appendLabel(labelArray[n3]);
            this.buf.append('\n');
            "".length();
            ++n3;
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
        this.buf.append(this.tab3).append("default: ");
        "".length();
        this.appendLabel(label);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitLookupSwitchInsn(Label label, int[] nArray, Label[] labelArray) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("LOOKUPSWITCH\n");
        "".length();
        int n = 0;
        while (Textifier.lIIIllIIIlIl(n, labelArray.length)) {
            this.buf.append(this.tab3).append(nArray[n]).append(": ");
            "".length();
            this.appendLabel(labelArray[n]);
            this.buf.append('\n');
            "".length();
            ++n;
            "".length();
            if ((5 + 9 - -82 + 57 ^ 56 + 85 - 39 + 55) >= 0) continue;
            return;
        }
        this.buf.append(this.tab3).append("default: ");
        "".length();
        this.appendLabel(label);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitMultiANewArrayInsn(String string, int n) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("MULTIANEWARRAY ");
        "".length();
        this.appendDescriptor(1, string);
        this.buf.append(' ').append(n).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Printer visitInsnAnnotation(int n, TypePath typePath, String string, boolean bl) {
        return this.visitTypeAnnotation(n, typePath, string, bl);
    }

    public void visitTryCatchBlock(Label label, Label label2, Label label3, String string) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("TRYCATCHBLOCK ");
        "".length();
        this.appendLabel(label);
        this.buf.append(' ');
        "".length();
        this.appendLabel(label2);
        this.buf.append(' ');
        "".length();
        this.appendLabel(label3);
        this.buf.append(' ');
        "".length();
        this.appendDescriptor(0, string);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public Printer visitTryCatchAnnotation(int n, TypePath typePath, String string, boolean bl) {
        String string2;
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("TRYCATCHBLOCK @");
        "".length();
        this.appendDescriptor(1, string);
        this.buf.append('(');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        this.buf.setLength(0);
        this.buf.append(") : ");
        "".length();
        this.appendTypeReference(n);
        this.buf.append(", ").append(typePath);
        "".length();
        if (Textifier.lIIIlIllllll(bl ? 1 : 0)) {
            string2 = "\n";
            "".length();
            if (-(0x72 ^ 0x76) >= 0) {
                return null;
            }
        } else {
            string2 = " // invisible\n";
        }
        this.buf.append(string2);
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        return textifier;
    }

    public void visitLocalVariable(String string, String string2, String string3, Label label, Label label2, int n) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("LOCALVARIABLE ").append(string).append(' ');
        "".length();
        this.appendDescriptor(1, string2);
        this.buf.append(' ');
        "".length();
        this.appendLabel(label);
        this.buf.append(' ');
        "".length();
        this.appendLabel(label2);
        this.buf.append(' ').append(n).append('\n');
        "".length();
        if (Textifier.lIIIllIIIIll(string3)) {
            this.buf.append(this.tab2);
            "".length();
            this.appendDescriptor(2, string3);
            TraceSignatureVisitor traceSignatureVisitor = new TraceSignatureVisitor(0);
            SignatureReader signatureReader = new SignatureReader(string3);
            signatureReader.acceptType(traceSignatureVisitor);
            this.buf.append(this.tab2).append("// declaration: ").append(traceSignatureVisitor.getDeclaration()).append('\n');
            "".length();
        }
        this.text.add(this.buf.toString());
        "".length();
    }

    public Printer visitLocalVariableAnnotation(int n, TypePath typePath, Label[] labelArray, Label[] labelArray2, int[] nArray, String string, boolean bl) {
        String string2;
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("LOCALVARIABLE @");
        "".length();
        this.appendDescriptor(1, string);
        this.buf.append('(');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        this.buf.setLength(0);
        this.buf.append(") : ");
        "".length();
        this.appendTypeReference(n);
        this.buf.append(", ").append(typePath);
        "".length();
        int n2 = 0;
        while (Textifier.lIIIllIIIlIl(n2, labelArray.length)) {
            this.buf.append(" [ ");
            "".length();
            this.appendLabel(labelArray[n2]);
            this.buf.append(" - ");
            "".length();
            this.appendLabel(labelArray2[n2]);
            this.buf.append(" - ").append(nArray[n2]).append(" ]");
            "".length();
            ++n2;
            "".length();
            if (" ".length() != 0) continue;
            return null;
        }
        if (Textifier.lIIIlIllllll(bl ? 1 : 0)) {
            string2 = "\n";
            "".length();
            if (-" ".length() > 0) {
                return null;
            }
        } else {
            string2 = " // invisible\n";
        }
        this.buf.append(string2);
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        return textifier;
    }

    public void visitLineNumber(int n, Label label) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("LINENUMBER ").append(n).append(' ');
        "".length();
        this.appendLabel(label);
        this.buf.append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitMaxs(int n, int n2) {
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("MAXSTACK = ").append(n).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        this.buf.setLength(0);
        this.buf.append(this.tab2).append("MAXLOCALS = ").append(n2).append('\n');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
    }

    public void visitMethodEnd() {
    }

    public Textifier visitAnnotation(String string, boolean bl) {
        String string2;
        this.buf.setLength(0);
        this.buf.append(this.tab).append('@');
        "".length();
        this.appendDescriptor(1, string);
        this.buf.append('(');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        if (Textifier.lIIIlIllllll(bl ? 1 : 0)) {
            string2 = ")\n";
            "".length();
            if (((0x22 ^ 0x47 ^ (0xE6 ^ 0x8E)) & (55 + 70 - 72 + 114 ^ 81 + 11 - 31 + 109 ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            string2 = ") // invisible\n";
        }
        this.text.add(string2);
        "".length();
        return textifier;
    }

    public Textifier visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        String string2;
        this.buf.setLength(0);
        this.buf.append(this.tab).append('@');
        "".length();
        this.appendDescriptor(1, string);
        this.buf.append('(');
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        Textifier textifier = this.createTextifier();
        this.text.add(textifier.getText());
        "".length();
        this.buf.setLength(0);
        this.buf.append(") : ");
        "".length();
        this.appendTypeReference(n);
        this.buf.append(", ").append(typePath);
        "".length();
        if (Textifier.lIIIlIllllll(bl ? 1 : 0)) {
            string2 = "\n";
            "".length();
            if (((0x5D ^ 4) & ~(0xF ^ 0x56)) != 0) {
                return null;
            }
        } else {
            string2 = " // invisible\n";
        }
        this.buf.append(string2);
        "".length();
        this.text.add(this.buf.toString());
        "".length();
        return textifier;
    }

    public void visitAttribute(Attribute attribute) {
        this.buf.setLength(0);
        this.buf.append(this.tab).append("ATTRIBUTE ");
        "".length();
        this.appendDescriptor(-1, attribute.type);
        if (Textifier.lIIIlIllllll(attribute instanceof Textifiable)) {
            ((Textifiable)((Object)attribute)).textify(this.buf, null);
            "".length();
            if (null != null) {
                return;
            }
        } else {
            this.buf.append(" : unknown\n");
            "".length();
        }
        this.text.add(this.buf.toString());
        "".length();
    }

    protected Textifier createTextifier() {
        return new Textifier();
    }

    protected void appendDescriptor(int n, String string) {
        if (!Textifier.lIIIllIIIIII(n, 5) || !Textifier.lIIIllIIIIII(n, 2) || Textifier.lIIIllIIIlll(n, 4)) {
            if (Textifier.lIIIllIIIIll(string)) {
                this.buf.append("// signature ").append(string).append('\n');
                "".length();
                "".length();
                if (-(0x35 ^ 0x31) >= 0) {
                    return;
                }
            }
        } else {
            this.buf.append(string);
            "".length();
        }
    }

    protected void appendLabel(Label label) {
        String string;
        if (Textifier.lIIIllIIIllI(this.labelNames)) {
            this.labelNames = new HashMap<Label, String>();
        }
        if (Textifier.lIIIllIIIllI(string = this.labelNames.get(label))) {
            string = String.valueOf(new StringBuilder().append("L").append(this.labelNames.size()));
            this.labelNames.put(label, string);
            "".length();
        }
        this.buf.append(string);
        "".length();
    }

    protected void appendHandle(Handle handle) {
        int n = handle.getTag();
        this.buf.append("// handle kind 0x").append(Integer.toHexString(n)).append(" : ");
        "".length();
        int n2 = 0;
        switch (n) {
            case 1: {
                this.buf.append("GETFIELD");
                "".length();
                "".length();
                if ("   ".length() >= "   ".length()) break;
                return;
            }
            case 2: {
                this.buf.append("GETSTATIC");
                "".length();
                "".length();
                if (((0x76 ^ 0x37) & ~(0x4D ^ 0xC)) >= 0) break;
                return;
            }
            case 3: {
                this.buf.append("PUTFIELD");
                "".length();
                "".length();
                if ("  ".length() != 0) break;
                return;
            }
            case 4: {
                this.buf.append("PUTSTATIC");
                "".length();
                "".length();
                if ("  ".length() >= " ".length()) break;
                return;
            }
            case 9: {
                this.buf.append("INVOKEINTERFACE");
                "".length();
                n2 = 1;
                "".length();
                if ("   ".length() > 0) break;
                return;
            }
            case 7: {
                this.buf.append("INVOKESPECIAL");
                "".length();
                n2 = 1;
                "".length();
                if (" ".length() >= " ".length()) break;
                return;
            }
            case 6: {
                this.buf.append("INVOKESTATIC");
                "".length();
                n2 = 1;
                "".length();
                if ("  ".length() != ((0xCF ^ 0x8E ^ (0xE9 ^ 0x8C)) & (92 + 160 - 244 + 172 ^ 139 + 87 - 115 + 33 ^ -" ".length()))) break;
                return;
            }
            case 5: {
                this.buf.append("INVOKEVIRTUAL");
                "".length();
                n2 = 1;
                "".length();
                if (-" ".length() < 0) break;
                return;
            }
            case 8: {
                this.buf.append("NEWINVOKESPECIAL");
                "".length();
                n2 = 1;
            }
        }
        this.buf.append('\n');
        "".length();
        this.buf.append(this.tab3);
        "".length();
        this.appendDescriptor(0, handle.getOwner());
        this.buf.append('.');
        "".length();
        this.buf.append(handle.getName());
        "".length();
        if (Textifier.lIIIllIIIIIl(n2)) {
            this.buf.append('(');
            "".length();
        }
        this.appendDescriptor(9, handle.getDesc());
        if (Textifier.lIIIllIIIIIl(n2)) {
            this.buf.append(')');
            "".length();
        }
    }

    private void appendAccess(int n) {
        if (Textifier.lIIIlIllllll(n & 1)) {
            this.buf.append("public ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 2)) {
            this.buf.append("private ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 4)) {
            this.buf.append("protected ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x10)) {
            this.buf.append("final ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 8)) {
            this.buf.append("static ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x20)) {
            this.buf.append("synchronized ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x40)) {
            this.buf.append("volatile ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x80)) {
            this.buf.append("transient ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x400)) {
            this.buf.append("abstract ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x800)) {
            this.buf.append("strictfp ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x1000)) {
            this.buf.append("synthetic ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x8000)) {
            this.buf.append("mandated ");
            "".length();
        }
        if (Textifier.lIIIlIllllll(n & 0x4000)) {
            this.buf.append("enum ");
            "".length();
        }
    }

    private void appendComa(int n) {
        if (Textifier.lIIIlIllllll(n)) {
            this.buf.append(", ");
            "".length();
        }
    }

    private void appendTypeReference(int n) {
        TypeReference typeReference = new TypeReference(n);
        switch (typeReference.getSort()) {
            case 0: {
                this.buf.append("CLASS_TYPE_PARAMETER ").append(typeReference.getTypeParameterIndex());
                "".length();
                "".length();
                if (-" ".length() != "  ".length()) break;
                return;
            }
            case 1: {
                this.buf.append("METHOD_TYPE_PARAMETER ").append(typeReference.getTypeParameterIndex());
                "".length();
                "".length();
                if (-" ".length() <= "   ".length()) break;
                return;
            }
            case 16: {
                this.buf.append("CLASS_EXTENDS ").append(typeReference.getSuperTypeIndex());
                "".length();
                "".length();
                if ("  ".length() != 0) break;
                return;
            }
            case 17: {
                this.buf.append("CLASS_TYPE_PARAMETER_BOUND ").append(typeReference.getTypeParameterIndex()).append(", ").append(typeReference.getTypeParameterBoundIndex());
                "".length();
                "".length();
                if ((0x41 ^ 0x45) >= 0) break;
                return;
            }
            case 18: {
                this.buf.append("METHOD_TYPE_PARAMETER_BOUND ").append(typeReference.getTypeParameterIndex()).append(", ").append(typeReference.getTypeParameterBoundIndex());
                "".length();
                "".length();
                if ("   ".length() > -" ".length()) break;
                return;
            }
            case 19: {
                this.buf.append("FIELD");
                "".length();
                "".length();
                if (((0xC1 ^ 0x9C) & ~(0x2C ^ 0x71)) == 0) break;
                return;
            }
            case 20: {
                this.buf.append("METHOD_RETURN");
                "".length();
                "".length();
                if (-" ".length() <= -" ".length()) break;
                return;
            }
            case 21: {
                this.buf.append("METHOD_RECEIVER");
                "".length();
                "".length();
                if (" ".length() <= "   ".length()) break;
                return;
            }
            case 22: {
                this.buf.append("METHOD_FORMAL_PARAMETER ").append(typeReference.getFormalParameterIndex());
                "".length();
                "".length();
                if (-" ".length() <= "   ".length()) break;
                return;
            }
            case 23: {
                this.buf.append("THROWS ").append(typeReference.getExceptionIndex());
                "".length();
                "".length();
                if (((0x7D ^ 0x65) & ~(0x68 ^ 0x70) & ~((0xD2 ^ 0x93) & ~(0xFD ^ 0xBC))) == 0) break;
                return;
            }
            case 64: {
                this.buf.append("LOCAL_VARIABLE");
                "".length();
                "".length();
                if ("   ".length() <= (0x3F ^ 0x3B)) break;
                return;
            }
            case 65: {
                this.buf.append("RESOURCE_VARIABLE");
                "".length();
                "".length();
                if ((0xF ^ 0x19 ^ (0xA0 ^ 0xB2)) >= " ".length()) break;
                return;
            }
            case 66: {
                this.buf.append("EXCEPTION_PARAMETER ").append(typeReference.getTryCatchBlockIndex());
                "".length();
                "".length();
                if (null == null) break;
                return;
            }
            case 67: {
                this.buf.append("INSTANCEOF");
                "".length();
                "".length();
                if (-"  ".length() <= 0) break;
                return;
            }
            case 68: {
                this.buf.append("NEW");
                "".length();
                "".length();
                if (" ".length() != (0xB2 ^ 0xB9 ^ (0x2B ^ 0x24))) break;
                return;
            }
            case 69: {
                this.buf.append("CONSTRUCTOR_REFERENCE");
                "".length();
                "".length();
                if (null == null) break;
                return;
            }
            case 70: {
                this.buf.append("METHOD_REFERENCE");
                "".length();
                "".length();
                if ("  ".length() == "  ".length()) break;
                return;
            }
            case 71: {
                this.buf.append("CAST ").append(typeReference.getTypeArgumentIndex());
                "".length();
                "".length();
                if (" ".length() >= ((0xA8 ^ 0x9B) & ~(0x2E ^ 0x1D))) break;
                return;
            }
            case 72: {
                this.buf.append("CONSTRUCTOR_INVOCATION_TYPE_ARGUMENT ").append(typeReference.getTypeArgumentIndex());
                "".length();
                "".length();
                if (-"   ".length() <= 0) break;
                return;
            }
            case 73: {
                this.buf.append("METHOD_INVOCATION_TYPE_ARGUMENT ").append(typeReference.getTypeArgumentIndex());
                "".length();
                "".length();
                if ("   ".length() != 0) break;
                return;
            }
            case 74: {
                this.buf.append("CONSTRUCTOR_REFERENCE_TYPE_ARGUMENT ").append(typeReference.getTypeArgumentIndex());
                "".length();
                "".length();
                if ((0xB6 ^ 0xB2) == (1 ^ 5)) break;
                return;
            }
            case 75: {
                this.buf.append("METHOD_REFERENCE_TYPE_ARGUMENT ").append(typeReference.getTypeArgumentIndex());
                "".length();
            }
        }
    }

    private void appendFrameTypes(int n, Object[] objectArray) {
        int n2 = 0;
        while (Textifier.lIIIllIIIlIl(n2, n)) {
            if (Textifier.lIIIllIIIlII(n2)) {
                this.buf.append(' ');
                "".length();
            }
            if (Textifier.lIIIlIllllll(objectArray[n2] instanceof String)) {
                String string = (String)objectArray[n2];
                if (Textifier.lIIIlIllllll(string.startsWith("[") ? 1 : 0)) {
                    this.appendDescriptor(1, string);
                    "".length();
                    if (null != null) {
                        return;
                    }
                } else {
                    this.appendDescriptor(0, string);
                }
                "".length();
                if (-"  ".length() >= 0) {
                    return;
                }
            } else if (Textifier.lIIIlIllllll(objectArray[n2] instanceof Integer)) {
                switch ((Integer)objectArray[n2]) {
                    case 0: {
                        this.appendDescriptor(1, "T");
                        "".length();
                        if (((0xF7 ^ 0xBB) & ~(0x35 ^ 0x79)) >= ((0x90 ^ 0xC3) & ~(0x18 ^ 0x4B))) break;
                        return;
                    }
                    case 1: {
                        this.appendDescriptor(1, "I");
                        "".length();
                        if (null == null) break;
                        return;
                    }
                    case 2: {
                        this.appendDescriptor(1, "F");
                        "".length();
                        if (((0x30 ^ 0x17) & ~(0xB3 ^ 0x94)) < "   ".length()) break;
                        return;
                    }
                    case 3: {
                        this.appendDescriptor(1, "D");
                        "".length();
                        if (-" ".length() == -" ".length()) break;
                        return;
                    }
                    case 4: {
                        this.appendDescriptor(1, "J");
                        "".length();
                        if ((0x21 ^ 0x25) >= "   ".length()) break;
                        return;
                    }
                    case 5: {
                        this.appendDescriptor(1, "N");
                        "".length();
                        if (" ".length() == " ".length()) break;
                        return;
                    }
                    case 6: {
                        this.appendDescriptor(1, "U");
                    }
                }
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                this.appendLabel((Label)objectArray[n2]);
            }
            ++n2;
            "".length();
            if (-" ".length() >= -" ".length()) continue;
            return;
        }
    }

    static {
        METHOD_DESCRIPTOR = 3;
        PARAMETERS_DECLARATION = 8;
        HANDLE_DESCRIPTOR = 9;
        METHOD_SIGNATURE = 4;
        CLASS_DECLARATION = 7;
        FIELD_SIGNATURE = 2;
        FIELD_DESCRIPTOR = 1;
        TYPE_DECLARATION = 6;
        INTERNAL_NAME = 0;
        CLASS_SIGNATURE = 5;
    }

    private static boolean lIIIllIIIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIllllIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIllIIIlIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIllIIIIlI(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIlIlllllI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlIllllII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIllIIIIll(Object object) {
        return object != null;
    }

    private static boolean lIIIllIIIllI(Object object) {
        return object == null;
    }

    private static boolean lIIIlIllllll(int n) {
        return n != 0;
    }

    private static boolean lIIIllIIIIIl(int n) {
        return n == 0;
    }

    private static boolean lIIIllIIIlII(int n) {
        return n > 0;
    }

    private static boolean lIIIllIIIIII(int n, int n2) {
        return n != n2;
    }
}

