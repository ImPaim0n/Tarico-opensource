/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.util.Printer;

public final class TraceAnnotationVisitor
extends AnnotationVisitor {
    private final Printer p;

    public TraceAnnotationVisitor(Printer printer) {
        this(null, printer);
    }

    public TraceAnnotationVisitor(AnnotationVisitor annotationVisitor, Printer printer) {
        super(327680, annotationVisitor);
        this.p = printer;
    }

    public void visit(String string, Object object) {
        this.p.visit(string, object);
        super.visit(string, object);
    }

    public void visitEnum(String string, String string2, String string3) {
        this.p.visitEnum(string, string2, string3);
        super.visitEnum(string, string2, string3);
    }

    public AnnotationVisitor visitAnnotation(String string, String string2) {
        AnnotationVisitor annotationVisitor;
        Printer printer = this.p.visitAnnotation(string, string2);
        if (TraceAnnotationVisitor.llIlIIllIII(this.av)) {
            annotationVisitor = null;
            "".length();
            if ((0xBC ^ 0xB8) < 0) {
                return null;
            }
        } else {
            annotationVisitor = this.av.visitAnnotation(string, string2);
        }
        AnnotationVisitor annotationVisitor2 = annotationVisitor;
        return new TraceAnnotationVisitor(annotationVisitor2, printer);
    }

    public AnnotationVisitor visitArray(String string) {
        AnnotationVisitor annotationVisitor;
        Printer printer = this.p.visitArray(string);
        if (TraceAnnotationVisitor.llIlIIllIII(this.av)) {
            annotationVisitor = null;
            "".length();
            if ((0x27 ^ 0x23) > (0x82 ^ 0x86)) {
                return null;
            }
        } else {
            annotationVisitor = this.av.visitArray(string);
        }
        AnnotationVisitor annotationVisitor2 = annotationVisitor;
        return new TraceAnnotationVisitor(annotationVisitor2, printer);
    }

    public void visitEnd() {
        this.p.visitAnnotationEnd();
        super.visitEnd();
    }

    private static boolean llIlIIllIII(Object object) {
        return object == null;
    }
}

