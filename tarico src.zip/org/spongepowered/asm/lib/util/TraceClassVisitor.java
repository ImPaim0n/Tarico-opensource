/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import java.io.PrintWriter;
import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.util.Printer;
import org.spongepowered.asm.lib.util.Textifier;
import org.spongepowered.asm.lib.util.TraceAnnotationVisitor;
import org.spongepowered.asm.lib.util.TraceFieldVisitor;
import org.spongepowered.asm.lib.util.TraceMethodVisitor;

public final class TraceClassVisitor
extends ClassVisitor {
    private final PrintWriter pw;
    public final Printer p;

    public TraceClassVisitor(PrintWriter printWriter) {
        this(null, printWriter);
    }

    public TraceClassVisitor(ClassVisitor classVisitor, PrintWriter printWriter) {
        this(classVisitor, new Textifier(), printWriter);
    }

    public TraceClassVisitor(ClassVisitor classVisitor, Printer printer, PrintWriter printWriter) {
        super(327680, classVisitor);
        this.pw = printWriter;
        this.p = printer;
    }

    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        this.p.visit(n, n2, string, string2, string3, stringArray);
        super.visit(n, n2, string, string2, string3, stringArray);
    }

    public void visitSource(String string, String string2) {
        this.p.visitSource(string, string2);
        super.visitSource(string, string2);
    }

    public void visitOuterClass(String string, String string2, String string3) {
        this.p.visitOuterClass(string, string2, string3);
        super.visitOuterClass(string, string2, string3);
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        Printer printer = this.p.visitClassAnnotation(string, bl);
        if (TraceClassVisitor.lIlllIIIll(this.cv)) {
            annotationVisitor = null;
            "".length();
            if ((0x11 ^ 0x14) <= 0) {
                return null;
            }
        } else {
            annotationVisitor = this.cv.visitAnnotation(string, bl);
        }
        AnnotationVisitor annotationVisitor2 = annotationVisitor;
        return new TraceAnnotationVisitor(annotationVisitor2, printer);
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        Printer printer = this.p.visitClassTypeAnnotation(n, typePath, string, bl);
        if (TraceClassVisitor.lIlllIIIll(this.cv)) {
            annotationVisitor = null;
            "".length();
            if (((0x7A ^ 0x4B ^ (0x79 ^ 0xA)) & (0xCE ^ 0xAC ^ (8 ^ 0x28) ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            annotationVisitor = this.cv.visitTypeAnnotation(n, typePath, string, bl);
        }
        AnnotationVisitor annotationVisitor2 = annotationVisitor;
        return new TraceAnnotationVisitor(annotationVisitor2, printer);
    }

    public void visitAttribute(Attribute attribute) {
        this.p.visitClassAttribute(attribute);
        super.visitAttribute(attribute);
    }

    public void visitInnerClass(String string, String string2, String string3, int n) {
        this.p.visitInnerClass(string, string2, string3, n);
        super.visitInnerClass(string, string2, string3, n);
    }

    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        FieldVisitor fieldVisitor;
        Printer printer = this.p.visitField(n, string, string2, string3, object);
        if (TraceClassVisitor.lIlllIIIll(this.cv)) {
            fieldVisitor = null;
            "".length();
            if ((0x98 ^ 0x9C) < -" ".length()) {
                return null;
            }
        } else {
            fieldVisitor = this.cv.visitField(n, string, string2, string3, object);
        }
        FieldVisitor fieldVisitor2 = fieldVisitor;
        return new TraceFieldVisitor(fieldVisitor2, printer);
    }

    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MethodVisitor methodVisitor;
        Printer printer = this.p.visitMethod(n, string, string2, string3, stringArray);
        if (TraceClassVisitor.lIlllIIIll(this.cv)) {
            methodVisitor = null;
            "".length();
            if ("   ".length() >= (0x4B ^ 0x4F)) {
                return null;
            }
        } else {
            methodVisitor = this.cv.visitMethod(n, string, string2, string3, stringArray);
        }
        MethodVisitor methodVisitor2 = methodVisitor;
        return new TraceMethodVisitor(methodVisitor2, printer);
    }

    public void visitEnd() {
        this.p.visitClassEnd();
        if (TraceClassVisitor.lIlllIIlII(this.pw)) {
            this.p.print(this.pw);
            this.pw.flush();
        }
        super.visitEnd();
    }

    private static boolean lIlllIIlII(Object object) {
        return object != null;
    }

    private static boolean lIlllIIIll(Object object) {
        return object == null;
    }
}

