/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.Attribute;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.TypePath;
import org.spongepowered.asm.lib.util.Printer;
import org.spongepowered.asm.lib.util.TraceAnnotationVisitor;

public final class TraceFieldVisitor
extends FieldVisitor {
    public final Printer p;

    public TraceFieldVisitor(Printer printer) {
        this(null, printer);
    }

    public TraceFieldVisitor(FieldVisitor fieldVisitor, Printer printer) {
        super(327680, fieldVisitor);
        this.p = printer;
    }

    public AnnotationVisitor visitAnnotation(String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        Printer printer = this.p.visitFieldAnnotation(string, bl);
        if (TraceFieldVisitor.lIIIllIIlllI(this.fv)) {
            annotationVisitor = null;
            "".length();
            if ((0x6B ^ 0x6F) <= -" ".length()) {
                return null;
            }
        } else {
            annotationVisitor = this.fv.visitAnnotation(string, bl);
        }
        AnnotationVisitor annotationVisitor2 = annotationVisitor;
        return new TraceAnnotationVisitor(annotationVisitor2, printer);
    }

    public AnnotationVisitor visitTypeAnnotation(int n, TypePath typePath, String string, boolean bl) {
        AnnotationVisitor annotationVisitor;
        Printer printer = this.p.visitFieldTypeAnnotation(n, typePath, string, bl);
        if (TraceFieldVisitor.lIIIllIIlllI(this.fv)) {
            annotationVisitor = null;
            "".length();
            if (" ".length() < 0) {
                return null;
            }
        } else {
            annotationVisitor = this.fv.visitTypeAnnotation(n, typePath, string, bl);
        }
        AnnotationVisitor annotationVisitor2 = annotationVisitor;
        return new TraceAnnotationVisitor(annotationVisitor2, printer);
    }

    public void visitAttribute(Attribute attribute) {
        this.p.visitFieldAttribute(attribute);
        super.visitAttribute(attribute);
    }

    public void visitEnd() {
        this.p.visitFieldEnd();
        super.visitEnd();
    }

    private static boolean lIIIllIIlllI(Object object) {
        return object == null;
    }
}

