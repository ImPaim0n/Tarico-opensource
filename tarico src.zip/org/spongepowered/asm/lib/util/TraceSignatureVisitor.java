/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.lib.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;

public final class TraceSignatureVisitor
extends SignatureVisitor {
    private final StringBuilder declaration;
    private boolean isInterface;
    private boolean seenFormalParameter;
    private boolean seenInterfaceBound;
    private boolean seenParameter;
    private boolean seenInterface;
    private StringBuilder returnType;
    private StringBuilder exceptions;
    private int argumentStack;
    private int arrayStack;
    private String separator = "";

    public TraceSignatureVisitor(int n) {
        super(327680);
        boolean bl;
        if (TraceSignatureVisitor.lIIIIllIIII(n & 0x200)) {
            bl = true;
            "".length();
            if (-"  ".length() > 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.isInterface = bl;
        this.declaration = new StringBuilder();
    }

    private TraceSignatureVisitor(StringBuilder stringBuilder) {
        super(327680);
        this.declaration = stringBuilder;
    }

    public void visitFormalTypeParameter(String string) {
        String string2;
        if (TraceSignatureVisitor.lIIIIllIIII(this.seenFormalParameter ? 1 : 0)) {
            string2 = ", ";
            "".length();
            if ("   ".length() >= (0x8E ^ 0x8A)) {
                return;
            }
        } else {
            string2 = "<";
        }
        this.declaration.append(string2).append(string);
        "".length();
        this.seenFormalParameter = true;
        this.seenInterfaceBound = false;
    }

    public SignatureVisitor visitClassBound() {
        this.separator = " extends ";
        this.startType();
        return this;
    }

    public SignatureVisitor visitInterfaceBound() {
        String string;
        if (TraceSignatureVisitor.lIIIIllIIII(this.seenInterfaceBound ? 1 : 0)) {
            string = ", ";
            "".length();
            if (((0x76 ^ 0x64) & ~(0x46 ^ 0x54)) != 0) {
                return null;
            }
        } else {
            string = " extends ";
        }
        this.separator = string;
        this.seenInterfaceBound = true;
        this.startType();
        return this;
    }

    public SignatureVisitor visitSuperclass() {
        this.endFormals();
        this.separator = " extends ";
        this.startType();
        return this;
    }

    public SignatureVisitor visitInterface() {
        String string;
        if (TraceSignatureVisitor.lIIIIllIIII(this.seenInterface ? 1 : 0)) {
            string = ", ";
            "".length();
            if (null != null) {
                return null;
            }
        } else if (TraceSignatureVisitor.lIIIIllIIII(this.isInterface ? 1 : 0)) {
            string = " extends ";
            "".length();
            if ("  ".length() < 0) {
                return null;
            }
        } else {
            string = " implements ";
        }
        this.separator = string;
        this.seenInterface = true;
        this.startType();
        return this;
    }

    public SignatureVisitor visitParameterType() {
        this.endFormals();
        if (TraceSignatureVisitor.lIIIIllIIII(this.seenParameter ? 1 : 0)) {
            this.declaration.append(", ");
            "".length();
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            this.seenParameter = true;
            this.declaration.append('(');
            "".length();
        }
        this.startType();
        return this;
    }

    public SignatureVisitor visitReturnType() {
        this.endFormals();
        if (TraceSignatureVisitor.lIIIIllIIII(this.seenParameter ? 1 : 0)) {
            this.seenParameter = false;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            this.declaration.append('(');
            "".length();
        }
        this.declaration.append(')');
        "".length();
        this.returnType = new StringBuilder();
        return new TraceSignatureVisitor(this.returnType);
    }

    public SignatureVisitor visitExceptionType() {
        if (TraceSignatureVisitor.lIIIIllIIIl(this.exceptions)) {
            this.exceptions = new StringBuilder();
            "".length();
            if (" ".length() == "   ".length()) {
                return null;
            }
        } else {
            this.exceptions.append(", ");
            "".length();
        }
        return new TraceSignatureVisitor(this.exceptions);
    }

    public void visitBaseType(char c) {
        switch (c) {
            case 'V': {
                this.declaration.append("void");
                "".length();
                "".length();
                if (-" ".length() < "  ".length()) break;
                return;
            }
            case 'B': {
                this.declaration.append("byte");
                "".length();
                "".length();
                if (-"  ".length() <= 0) break;
                return;
            }
            case 'J': {
                this.declaration.append("long");
                "".length();
                "".length();
                if (" ".length() < "   ".length()) break;
                return;
            }
            case 'Z': {
                this.declaration.append("boolean");
                "".length();
                "".length();
                if ("   ".length() != "  ".length()) break;
                return;
            }
            case 'I': {
                this.declaration.append("int");
                "".length();
                "".length();
                if (null == null) break;
                return;
            }
            case 'S': {
                this.declaration.append("short");
                "".length();
                "".length();
                if ("   ".length() != "  ".length()) break;
                return;
            }
            case 'C': {
                this.declaration.append("char");
                "".length();
                "".length();
                if (-" ".length() == -" ".length()) break;
                return;
            }
            case 'F': {
                this.declaration.append("float");
                "".length();
                "".length();
                if ("  ".length() >= 0) break;
                return;
            }
            default: {
                this.declaration.append("double");
                "".length();
            }
        }
        this.endType();
    }

    public void visitTypeVariable(String string) {
        this.declaration.append(string);
        "".length();
        this.endType();
    }

    public SignatureVisitor visitArrayType() {
        this.startType();
        this.arrayStack |= 1;
        return this;
    }

    public void visitClassType(String string) {
        if (TraceSignatureVisitor.lIIIIllIIII("java/lang/Object".equals(string) ? 1 : 0)) {
            int n;
            int n2;
            if (!TraceSignatureVisitor.lIIIIllIIlI(this.argumentStack % 2) || TraceSignatureVisitor.lIIIIllIIII(this.seenParameter ? 1 : 0)) {
                n2 = 1;
                "".length();
                if (((0x1C ^ 0x24) & ~(0x8C ^ 0xB4)) > 0) {
                    return;
                }
            } else {
                n2 = 0;
            }
            if (TraceSignatureVisitor.lIIIIllIIII(n = n2)) {
                this.declaration.append(this.separator).append(string.replace('/', '.'));
                "".length();
            }
            "".length();
            if (" ".length() <= ((7 ^ 0x74 ^ (0x4E ^ 1)) & (84 + 15 - 83 + 139 ^ 54 + 94 - 37 + 56 ^ -" ".length()))) {
                return;
            }
        } else {
            this.declaration.append(this.separator).append(string.replace('/', '.'));
            "".length();
        }
        this.separator = "";
        this.argumentStack *= 2;
    }

    public void visitInnerClassType(String string) {
        if (TraceSignatureVisitor.lIIIIllIIII(this.argumentStack % 2)) {
            this.declaration.append('>');
            "".length();
        }
        this.argumentStack /= 2;
        this.declaration.append('.');
        "".length();
        this.declaration.append(this.separator).append(string.replace('/', '.'));
        "".length();
        this.separator = "";
        this.argumentStack *= 2;
    }

    public void visitTypeArgument() {
        if (TraceSignatureVisitor.lIIIIllIIlI(this.argumentStack % 2)) {
            ++this.argumentStack;
            this.declaration.append('<');
            "".length();
            "".length();
            if ("   ".length() == 0) {
                return;
            }
        } else {
            this.declaration.append(", ");
            "".length();
        }
        this.declaration.append('?');
        "".length();
    }

    public SignatureVisitor visitTypeArgument(char c) {
        if (TraceSignatureVisitor.lIIIIllIIlI(this.argumentStack % 2)) {
            ++this.argumentStack;
            this.declaration.append('<');
            "".length();
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            this.declaration.append(", ");
            "".length();
        }
        if (TraceSignatureVisitor.lIIIIllIIll(c, 43)) {
            this.declaration.append("? extends ");
            "".length();
            "".length();
            if (((0x44 ^ 4 ^ (0xC9 ^ 0x96)) & (0xE ^ 0x10 ^ " ".length() ^ -" ".length())) < ((0x7F ^ 0x39 ^ (0x1A ^ 0x44)) & (0x92 ^ 0xC0 ^ (0x1A ^ 0x50) ^ -" ".length()))) {
                return null;
            }
        } else if (TraceSignatureVisitor.lIIIIllIIll(c, 45)) {
            this.declaration.append("? super ");
            "".length();
        }
        this.startType();
        return this;
    }

    public void visitEnd() {
        if (TraceSignatureVisitor.lIIIIllIIII(this.argumentStack % 2)) {
            this.declaration.append('>');
            "".length();
        }
        this.argumentStack /= 2;
        this.endType();
    }

    public String getDeclaration() {
        return String.valueOf(this.declaration);
    }

    public String getReturnType() {
        String string;
        if (TraceSignatureVisitor.lIIIIllIIIl(this.returnType)) {
            string = null;
            "".length();
            if ((143 + 103 - 158 + 60 ^ 13 + 16 - -110 + 5) < "   ".length()) {
                return null;
            }
        } else {
            string = String.valueOf(this.returnType);
        }
        return string;
    }

    public String getExceptions() {
        String string;
        if (TraceSignatureVisitor.lIIIIllIIIl(this.exceptions)) {
            string = null;
            "".length();
            if (((0x80 ^ 0xA3) & ~(0xE5 ^ 0xC6)) != 0) {
                return null;
            }
        } else {
            string = String.valueOf(this.exceptions);
        }
        return string;
    }

    private void endFormals() {
        if (TraceSignatureVisitor.lIIIIllIIII(this.seenFormalParameter ? 1 : 0)) {
            this.declaration.append('>');
            "".length();
            this.seenFormalParameter = false;
        }
    }

    private void startType() {
        this.arrayStack *= 2;
    }

    private void endType() {
        if (TraceSignatureVisitor.lIIIIllIIlI(this.arrayStack % 2)) {
            this.arrayStack /= 2;
            "".length();
            if (((180 + 5 - 123 + 192 ^ 3 + 70 - 25 + 148) & (51 + 149 - 165 + 145 ^ 29 + 97 - 98 + 114 ^ -" ".length())) != 0) {
                return;
            }
        } else {
            while (TraceSignatureVisitor.lIIIIllIIII(this.arrayStack % 2)) {
                this.arrayStack /= 2;
                this.declaration.append("[]");
                "".length();
                "".length();
                if (-" ".length() >= -" ".length()) continue;
                return;
            }
        }
    }

    private static boolean lIIIIllIIll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIllIIIl(Object object) {
        return object == null;
    }

    private static boolean lIIIIllIIII(int n) {
        return n != 0;
    }

    private static boolean lIIIIllIIlI(int n) {
        return n == 0;
    }
}

