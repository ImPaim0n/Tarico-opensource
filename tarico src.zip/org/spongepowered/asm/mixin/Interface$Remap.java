/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

public enum Interface$Remap {
    ALL,
    FORCE(true),
    ONLY_PREFIXED,
    NONE;

    private final boolean forceRemap;

    private Interface$Remap() {
        this(false);
    }

    private Interface$Remap(boolean bl) {
        this.forceRemap = bl;
    }

    public boolean forceRemap() {
        return this.forceRemap;
    }
}

