/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

class MixinEnvironment$1 {
}

