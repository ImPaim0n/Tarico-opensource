/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.util.JavaVersion;

final class MixinEnvironment$CompatibilityLevel$1
extends MixinEnvironment$CompatibilityLevel {
    MixinEnvironment$CompatibilityLevel$1(int n2, int n3, boolean bl) {
    }

    @Override
    boolean isSupported() {
        boolean bl;
        if (MixinEnvironment$CompatibilityLevel$1.lllIIlllIll(MixinEnvironment$CompatibilityLevel$1.lllIIlllIlI(JavaVersion.current(), 1.7))) {
            bl = true;
            "".length();
            if ("   ".length() == -" ".length()) {
                return ((3 ^ 0x47) & ~(0x2E ^ 0x6A)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean lllIIlllIll(int n) {
        return n >= 0;
    }

    private static int lllIIlllIlI(double d, double d2) {
        return d == d2 ? 0 : (d > d2 ? 1 : -1);
    }
}

