/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.util.JavaVersion;

final class MixinEnvironment$CompatibilityLevel$2
extends MixinEnvironment$CompatibilityLevel {
    MixinEnvironment$CompatibilityLevel$2(int n2, int n3, boolean bl) {
    }

    @Override
    boolean isSupported() {
        boolean bl;
        if (MixinEnvironment$CompatibilityLevel$2.lIIlI(MixinEnvironment$CompatibilityLevel$2.lIIIl(JavaVersion.current(), 1.8))) {
            bl = true;
            "".length();
            if ("  ".length() < 0) {
                return ((0xFE ^ 0xBC ^ (0xC5 ^ 0x93)) & ((0x63 ^ 0x41) & ~(0x7F ^ 0x5D) ^ (0x4A ^ 0x5E) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean lIIlI(int n) {
        return n >= 0;
    }

    private static int lIIIl(double d, double d2) {
        return d == d2 ? 0 : (d > d2 ? 1 : -1);
    }
}

