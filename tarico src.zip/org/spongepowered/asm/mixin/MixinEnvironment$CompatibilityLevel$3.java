/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;

final class MixinEnvironment$CompatibilityLevel$3
extends MixinEnvironment$CompatibilityLevel {
    MixinEnvironment$CompatibilityLevel$3(int n2, int n3, boolean bl) {
    }

    @Override
    boolean isSupported() {
        return false;
    }
}

