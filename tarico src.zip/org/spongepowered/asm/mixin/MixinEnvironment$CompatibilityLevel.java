/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$1;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel$1;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel$2;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel$3;

public class MixinEnvironment$CompatibilityLevel
extends Enum<MixinEnvironment$CompatibilityLevel> {
    public static final /* enum */ MixinEnvironment$CompatibilityLevel JAVA_6;
    public static final /* enum */ MixinEnvironment$CompatibilityLevel JAVA_7;
    public static final /* enum */ MixinEnvironment$CompatibilityLevel JAVA_8;
    public static final /* enum */ MixinEnvironment$CompatibilityLevel JAVA_9;
    private static final int CLASS_V1_9;
    private final int ver;
    private final int classVersion;
    private final boolean supportsMethodsInInterfaces;
    private MixinEnvironment$CompatibilityLevel maxCompatibleLevel;
    private static final /* synthetic */ MixinEnvironment$CompatibilityLevel[] $VALUES;

    public static MixinEnvironment$CompatibilityLevel[] values() {
        return (MixinEnvironment$CompatibilityLevel[])$VALUES.clone();
    }

    public static MixinEnvironment$CompatibilityLevel valueOf(String string) {
        return Enum.valueOf(MixinEnvironment$CompatibilityLevel.class, string);
    }

    private MixinEnvironment$CompatibilityLevel(int n2, int n3, boolean bl) {
        this.ver = n2;
        this.classVersion = n3;
        this.supportsMethodsInInterfaces = bl;
    }

    private void setMaxCompatibleLevel(MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel) {
        this.maxCompatibleLevel = mixinEnvironment$CompatibilityLevel;
    }

    boolean isSupported() {
        return true;
    }

    public int classVersion() {
        return this.classVersion;
    }

    public boolean supportsMethodsInInterfaces() {
        return this.supportsMethodsInInterfaces;
    }

    public boolean isAtLeast(MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel) {
        boolean bl;
        if (!MixinEnvironment$CompatibilityLevel.llllIIIIIl((Object)mixinEnvironment$CompatibilityLevel) || MixinEnvironment$CompatibilityLevel.llllIIIIlI(this.ver, mixinEnvironment$CompatibilityLevel.ver)) {
            bl = true;
            "".length();
            if ("  ".length() < ((0xA1 ^ 0xC1) & ~(0x39 ^ 0x59))) {
                return ((0x2C ^ 0x68) & ~(0xD0 ^ 0x94)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean canElevateTo(MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel) {
        boolean bl;
        if (!MixinEnvironment$CompatibilityLevel.llllIIIIIl((Object)mixinEnvironment$CompatibilityLevel) || MixinEnvironment$CompatibilityLevel.llllIIIIll((Object)this.maxCompatibleLevel)) {
            return true;
        }
        if (MixinEnvironment$CompatibilityLevel.llllIIIlII(mixinEnvironment$CompatibilityLevel.ver, this.maxCompatibleLevel.ver)) {
            bl = true;
            "".length();
            if (" ".length() > "  ".length()) {
                return ((0xB2 ^ 0x90) & ~(0x1A ^ 0x38)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean canSupport(MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel) {
        if (MixinEnvironment$CompatibilityLevel.llllIIIIll((Object)mixinEnvironment$CompatibilityLevel)) {
            return true;
        }
        return mixinEnvironment$CompatibilityLevel.canElevateTo(this);
    }

    /* synthetic */ MixinEnvironment$CompatibilityLevel(String string, int n, int n2, int n3, boolean bl, MixinEnvironment$1 mixinEnvironment$1) {
        this(n2, n3, bl);
    }

    static {
        CLASS_V1_9 = 53;
        JAVA_6 = new MixinEnvironment$CompatibilityLevel(6, 50, false);
        JAVA_7 = new MixinEnvironment$CompatibilityLevel$1(7, 51, false);
        JAVA_8 = new MixinEnvironment$CompatibilityLevel$2(8, 52, true);
        JAVA_9 = new MixinEnvironment$CompatibilityLevel$3(9, 53, true);
        $VALUES = new MixinEnvironment$CompatibilityLevel[]{JAVA_6, JAVA_7, JAVA_8, JAVA_9};
    }

    private static boolean llllIIIIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean llllIIIlII(int n, int n2) {
        return n <= n2;
    }

    private static boolean llllIIIIIl(Object object) {
        return object != null;
    }

    private static boolean llllIIIIll(Object object) {
        return object == null;
    }
}

