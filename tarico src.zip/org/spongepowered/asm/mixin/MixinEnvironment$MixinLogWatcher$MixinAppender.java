/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.core.LogEvent
 *  org.apache.logging.log4j.core.appender.AbstractAppender
 */
package org.spongepowered.asm.mixin;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$MixinLogWatcher;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;

class MixinEnvironment$MixinLogWatcher$MixinAppender
extends AbstractAppender {
    MixinEnvironment$MixinLogWatcher$MixinAppender() {
        super("MixinLogWatcherAppender", null, null);
    }

    public void append(LogEvent logEvent) {
        if (!MixinEnvironment$MixinLogWatcher$MixinAppender.lIllIIlIlII(logEvent.getLevel(), Level.DEBUG) || MixinEnvironment$MixinLogWatcher$MixinAppender.lIllIIlIlIl("Validating minecraft".equals(logEvent.getMessage().getFormattedMessage()) ? 1 : 0)) {
            return;
        }
        MixinEnvironment.gotoPhase(MixinEnvironment$Phase.INIT);
        if (MixinEnvironment$MixinLogWatcher$MixinAppender.lIllIIlIlII(MixinEnvironment$MixinLogWatcher.log.getLevel(), Level.ALL)) {
            MixinEnvironment$MixinLogWatcher.log.setLevel(MixinEnvironment$MixinLogWatcher.oldLevel);
        }
    }

    private static boolean lIllIIlIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIllIIlIlIl(int n) {
        return n == 0;
    }
}

