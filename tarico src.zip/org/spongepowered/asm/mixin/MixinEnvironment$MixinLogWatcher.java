/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.apache.logging.log4j.core.Appender
 *  org.apache.logging.log4j.core.Logger
 */
package org.spongepowered.asm.mixin;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Appender;
import org.spongepowered.asm.mixin.MixinEnvironment$MixinLogWatcher$MixinAppender;

class MixinEnvironment$MixinLogWatcher {
    static MixinEnvironment$MixinLogWatcher$MixinAppender appender = new MixinEnvironment$MixinLogWatcher$MixinAppender();
    static org.apache.logging.log4j.core.Logger log;
    static Level oldLevel;

    MixinEnvironment$MixinLogWatcher() {
    }

    static void begin() {
        Logger logger = LogManager.getLogger((String)"FML");
        if (MixinEnvironment$MixinLogWatcher.lllIllllllI(logger instanceof org.apache.logging.log4j.core.Logger)) {
            return;
        }
        log = (org.apache.logging.log4j.core.Logger)logger;
        oldLevel = log.getLevel();
        appender.start();
        log.addAppender((Appender)appender);
        log.setLevel(Level.ALL);
    }

    static void end() {
        if (MixinEnvironment$MixinLogWatcher.lllIlllllll(log)) {
            log.removeAppender((Appender)appender);
        }
    }

    static {
        oldLevel = null;
    }

    private static boolean lllIlllllll(Object object) {
        return object != null;
    }

    private static boolean lllIllllllI(int n) {
        return n == 0;
    }
}

