/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

enum MixinEnvironment$Option$Inherit {
    INHERIT,
    ALLOW_OVERRIDE,
    INDEPENDENT,
    ALWAYS_FALSE;

}

