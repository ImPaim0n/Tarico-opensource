/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$Option$Inherit;

public final class MixinEnvironment$Option
extends Enum<MixinEnvironment$Option> {
    public static final /* enum */ MixinEnvironment$Option DEBUG_ALL;
    public static final /* enum */ MixinEnvironment$Option DEBUG_EXPORT;
    public static final /* enum */ MixinEnvironment$Option DEBUG_EXPORT_FILTER;
    public static final /* enum */ MixinEnvironment$Option DEBUG_EXPORT_DECOMPILE;
    public static final /* enum */ MixinEnvironment$Option DEBUG_EXPORT_DECOMPILE_THREADED;
    public static final /* enum */ MixinEnvironment$Option DEBUG_VERIFY;
    public static final /* enum */ MixinEnvironment$Option DEBUG_VERBOSE;
    public static final /* enum */ MixinEnvironment$Option DEBUG_INJECTORS;
    public static final /* enum */ MixinEnvironment$Option DEBUG_STRICT;
    public static final /* enum */ MixinEnvironment$Option DEBUG_UNIQUE;
    public static final /* enum */ MixinEnvironment$Option DEBUG_TARGETS;
    public static final /* enum */ MixinEnvironment$Option DEBUG_PROFILER;
    public static final /* enum */ MixinEnvironment$Option DUMP_TARGET_ON_FAILURE;
    public static final /* enum */ MixinEnvironment$Option CHECK_ALL;
    public static final /* enum */ MixinEnvironment$Option CHECK_IMPLEMENTS;
    public static final /* enum */ MixinEnvironment$Option CHECK_IMPLEMENTS_STRICT;
    public static final /* enum */ MixinEnvironment$Option IGNORE_CONSTRAINTS;
    public static final /* enum */ MixinEnvironment$Option HOT_SWAP;
    public static final /* enum */ MixinEnvironment$Option ENVIRONMENT;
    public static final /* enum */ MixinEnvironment$Option OBFUSCATION_TYPE;
    public static final /* enum */ MixinEnvironment$Option DISABLE_REFMAP;
    public static final /* enum */ MixinEnvironment$Option REFMAP_REMAP;
    public static final /* enum */ MixinEnvironment$Option REFMAP_REMAP_RESOURCE;
    public static final /* enum */ MixinEnvironment$Option REFMAP_REMAP_SOURCE_ENV;
    public static final /* enum */ MixinEnvironment$Option IGNORE_REQUIRED;
    public static final /* enum */ MixinEnvironment$Option DEFAULT_COMPATIBILITY_LEVEL;
    public static final /* enum */ MixinEnvironment$Option SHIFT_BY_VIOLATION_BEHAVIOUR;
    public static final /* enum */ MixinEnvironment$Option INITIALISER_INJECTION_MODE;
    private static final String PREFIX;
    final MixinEnvironment$Option parent;
    final MixinEnvironment$Option$Inherit inheritance;
    final String property;
    final String defaultValue;
    final boolean isFlag;
    final int depth;
    private static final /* synthetic */ MixinEnvironment$Option[] $VALUES;

    public static MixinEnvironment$Option[] values() {
        return (MixinEnvironment$Option[])$VALUES.clone();
    }

    public static MixinEnvironment$Option valueOf(String string) {
        return Enum.valueOf(MixinEnvironment$Option.class, string);
    }

    private MixinEnvironment$Option(String string2) {
        this(null, string2, true);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option$Inherit inherit, String string2) {
        this(null, inherit, string2, true);
    }

    private MixinEnvironment$Option(String string2, boolean bl) {
        this(null, string2, bl);
    }

    private MixinEnvironment$Option(String string2, String string3) {
        this(null, MixinEnvironment$Option$Inherit.INDEPENDENT, string2, false, string3);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, String string2) {
        this(mixinEnvironment$Option, MixinEnvironment$Option$Inherit.INHERIT, string2, true);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, MixinEnvironment$Option$Inherit mixinEnvironment$Option$Inherit, String string2) {
        this(mixinEnvironment$Option, mixinEnvironment$Option$Inherit, string2, true);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, String string2, boolean bl) {
        this(mixinEnvironment$Option, MixinEnvironment$Option$Inherit.INHERIT, string2, bl, null);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, MixinEnvironment$Option$Inherit mixinEnvironment$Option$Inherit, String string2, boolean bl) {
        this(mixinEnvironment$Option, mixinEnvironment$Option$Inherit, string2, bl, null);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, String string2, String string3) {
        this(mixinEnvironment$Option, MixinEnvironment$Option$Inherit.INHERIT, string2, false, string3);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, MixinEnvironment$Option$Inherit mixinEnvironment$Option$Inherit, String string2, String string3) {
        this(mixinEnvironment$Option, mixinEnvironment$Option$Inherit, string2, false, string3);
    }

    private MixinEnvironment$Option(MixinEnvironment$Option mixinEnvironment$Option, MixinEnvironment$Option$Inherit mixinEnvironment$Option$Inherit, String string2, boolean bl, String string3) {
        String string4;
        this.parent = mixinEnvironment$Option;
        this.inheritance = mixinEnvironment$Option$Inherit;
        StringBuilder stringBuilder = new StringBuilder();
        if (MixinEnvironment$Option.llIlllIIl((Object)mixinEnvironment$Option)) {
            string4 = mixinEnvironment$Option.property;
            "".length();
            if (" ".length() >= (90 + 40 - 63 + 66 ^ 60 + 111 - 51 + 9)) {
                throw null;
            }
        } else {
            string4 = "mixin";
        }
        this.property = String.valueOf(stringBuilder.append(string4).append(".").append(string2));
        this.defaultValue = string3;
        this.isFlag = bl;
        int n2 = 0;
        while (MixinEnvironment$Option.llIlllIIl((Object)mixinEnvironment$Option)) {
            mixinEnvironment$Option = mixinEnvironment$Option.parent;
            ++n2;
            "".length();
            if (((94 + 7 - -46 + 3 ^ 145 + 126 - 223 + 104) & (99 + 61 - 32 + 3 ^ 132 + 79 - 183 + 113 ^ -" ".length())) <= 0) continue;
            throw null;
        }
        this.depth = n2;
    }

    MixinEnvironment$Option getParent() {
        return this.parent;
    }

    String getProperty() {
        return this.property;
    }

    public String toString() {
        String string;
        if (MixinEnvironment$Option.llIlllIlI(this.isFlag ? 1 : 0)) {
            string = String.valueOf(this.getBooleanValue());
            "".length();
            if ((0x40 ^ 0x2C ^ (0xF1 ^ 0x99)) <= ((43 + 94 - 79 + 78 ^ 34 + 110 - -8 + 7) & (0x3C ^ 0xA ^ (0x40 ^ 0x61) ^ -" ".length()))) {
                return null;
            }
        } else {
            string = this.getStringValue();
        }
        return string;
    }

    private boolean getLocalBooleanValue(boolean bl) {
        return Boolean.parseBoolean(System.getProperty(this.property, Boolean.toString(bl)));
    }

    private boolean getInheritedBooleanValue() {
        boolean bl;
        if (MixinEnvironment$Option.llIlllIIl((Object)this.parent) && MixinEnvironment$Option.llIlllIlI(this.parent.getBooleanValue() ? 1 : 0)) {
            bl = true;
            "".length();
            if ("   ".length() == " ".length()) {
                return ((0x14 ^ 0x1C) & ~(0x2E ^ 0x26)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    final boolean getBooleanValue() {
        boolean bl;
        boolean bl2;
        boolean bl3;
        if (MixinEnvironment$Option.llIlllIll((Object)this.inheritance, (Object)MixinEnvironment$Option$Inherit.ALWAYS_FALSE)) {
            return false;
        }
        int n = this.getLocalBooleanValue(false);
        if (MixinEnvironment$Option.llIlllIll((Object)this.inheritance, (Object)MixinEnvironment$Option$Inherit.INDEPENDENT)) {
            return n != 0;
        }
        if (!MixinEnvironment$Option.llIllllII(n) || MixinEnvironment$Option.llIlllIlI(this.getInheritedBooleanValue() ? 1 : 0)) {
            bl3 = true;
            "".length();
            if (" ".length() != " ".length()) {
                return ((0xD0 ^ 0x8F ^ (0xDC ^ 0x93)) & (0x74 ^ 0x52 ^ (0x12 ^ 0x24) ^ -" ".length())) != 0;
            }
        } else {
            bl3 = bl2 = false;
        }
        if (MixinEnvironment$Option.llIlllIll((Object)this.inheritance, (Object)MixinEnvironment$Option$Inherit.INHERIT)) {
            bl = bl2;
            "".length();
            if (" ".length() < 0) {
                return ((0x3C ^ 0x67) & ~(0x4E ^ 0x15)) != 0;
            }
        } else {
            bl = this.getLocalBooleanValue(bl2);
        }
        return bl;
    }

    final String getStringValue() {
        String string;
        if (!MixinEnvironment$Option.llIllllIl((Object)this.inheritance, (Object)MixinEnvironment$Option$Inherit.INDEPENDENT) || !MixinEnvironment$Option.llIlllIIl((Object)this.parent) || MixinEnvironment$Option.llIlllIlI(this.parent.getBooleanValue() ? 1 : 0)) {
            string = System.getProperty(this.property, this.defaultValue);
            "".length();
            if ((0x12 ^ 0x16) <= "  ".length()) {
                return null;
            }
        } else {
            string = this.defaultValue;
        }
        return string;
    }

    <E extends Enum<E>> E getEnumValue(E e) {
        String string = System.getProperty(this.property, e.name());
        try {
            return (E)Enum.valueOf(e.getClass(), string.toUpperCase());
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return e;
        }
    }

    static {
        PREFIX = "mixin";
        DEBUG_ALL = new MixinEnvironment$Option("debug");
        DEBUG_EXPORT = new MixinEnvironment$Option(DEBUG_ALL, "export");
        DEBUG_EXPORT_FILTER = new MixinEnvironment$Option(DEBUG_EXPORT, "filter", false);
        DEBUG_EXPORT_DECOMPILE = new MixinEnvironment$Option(DEBUG_EXPORT, MixinEnvironment$Option$Inherit.ALLOW_OVERRIDE, "decompile");
        DEBUG_EXPORT_DECOMPILE_THREADED = new MixinEnvironment$Option(DEBUG_EXPORT_DECOMPILE, MixinEnvironment$Option$Inherit.ALLOW_OVERRIDE, "async");
        DEBUG_VERIFY = new MixinEnvironment$Option(DEBUG_ALL, "verify");
        DEBUG_VERBOSE = new MixinEnvironment$Option(DEBUG_ALL, "verbose");
        DEBUG_INJECTORS = new MixinEnvironment$Option(DEBUG_ALL, "countInjections");
        DEBUG_STRICT = new MixinEnvironment$Option(DEBUG_ALL, MixinEnvironment$Option$Inherit.INDEPENDENT, "strict");
        DEBUG_UNIQUE = new MixinEnvironment$Option(DEBUG_STRICT, "unique");
        DEBUG_TARGETS = new MixinEnvironment$Option(DEBUG_STRICT, "targets");
        DEBUG_PROFILER = new MixinEnvironment$Option(DEBUG_ALL, MixinEnvironment$Option$Inherit.ALLOW_OVERRIDE, "profiler");
        DUMP_TARGET_ON_FAILURE = new MixinEnvironment$Option("dumpTargetOnFailure");
        CHECK_ALL = new MixinEnvironment$Option("checks");
        CHECK_IMPLEMENTS = new MixinEnvironment$Option(CHECK_ALL, "interfaces");
        CHECK_IMPLEMENTS_STRICT = new MixinEnvironment$Option(CHECK_IMPLEMENTS, MixinEnvironment$Option$Inherit.ALLOW_OVERRIDE, "strict");
        IGNORE_CONSTRAINTS = new MixinEnvironment$Option("ignoreConstraints");
        HOT_SWAP = new MixinEnvironment$Option("hotSwap");
        ENVIRONMENT = new MixinEnvironment$Option(MixinEnvironment$Option$Inherit.ALWAYS_FALSE, "env");
        OBFUSCATION_TYPE = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.ALWAYS_FALSE, "obf");
        DISABLE_REFMAP = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "disableRefMap");
        REFMAP_REMAP = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "remapRefMap");
        REFMAP_REMAP_RESOURCE = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "refMapRemappingFile", "");
        REFMAP_REMAP_SOURCE_ENV = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "refMapRemappingEnv", "searge");
        IGNORE_REQUIRED = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "ignoreRequired");
        DEFAULT_COMPATIBILITY_LEVEL = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "compatLevel");
        SHIFT_BY_VIOLATION_BEHAVIOUR = new MixinEnvironment$Option(ENVIRONMENT, MixinEnvironment$Option$Inherit.INDEPENDENT, "shiftByViolation", "warn");
        INITIALISER_INJECTION_MODE = new MixinEnvironment$Option("initialiserInjectionMode", "default");
        $VALUES = new MixinEnvironment$Option[]{DEBUG_ALL, DEBUG_EXPORT, DEBUG_EXPORT_FILTER, DEBUG_EXPORT_DECOMPILE, DEBUG_EXPORT_DECOMPILE_THREADED, DEBUG_VERIFY, DEBUG_VERBOSE, DEBUG_INJECTORS, DEBUG_STRICT, DEBUG_UNIQUE, DEBUG_TARGETS, DEBUG_PROFILER, DUMP_TARGET_ON_FAILURE, CHECK_ALL, CHECK_IMPLEMENTS, CHECK_IMPLEMENTS_STRICT, IGNORE_CONSTRAINTS, HOT_SWAP, ENVIRONMENT, OBFUSCATION_TYPE, DISABLE_REFMAP, REFMAP_REMAP, REFMAP_REMAP_RESOURCE, REFMAP_REMAP_SOURCE_ENV, IGNORE_REQUIRED, DEFAULT_COMPATIBILITY_LEVEL, SHIFT_BY_VIOLATION_BEHAVIOUR, INITIALISER_INJECTION_MODE};
    }

    private static boolean llIllllIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlllIIl(Object object) {
        return object != null;
    }

    private static boolean llIlllIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIlllIlI(int n) {
        return n != 0;
    }

    private static boolean llIllllII(int n) {
        return n == 0;
    }
}

