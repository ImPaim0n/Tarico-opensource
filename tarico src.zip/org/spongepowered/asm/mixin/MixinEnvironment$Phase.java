/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package org.spongepowered.asm.mixin;

import com.google.common.collect.ImmutableList;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.mixin.MixinEnvironment;

public final class MixinEnvironment$Phase {
    static final MixinEnvironment$Phase NOT_INITIALISED = new MixinEnvironment$Phase(-1, "NOT_INITIALISED");
    public static final MixinEnvironment$Phase PREINIT = new MixinEnvironment$Phase(0, "PREINIT");
    public static final MixinEnvironment$Phase INIT = new MixinEnvironment$Phase(1, "INIT");
    public static final MixinEnvironment$Phase DEFAULT = new MixinEnvironment$Phase(2, "DEFAULT");
    static final List<MixinEnvironment$Phase> phases = ImmutableList.of((Object)PREINIT, (Object)INIT, (Object)DEFAULT);
    final int ordinal;
    final String name;
    private MixinEnvironment environment;

    private MixinEnvironment$Phase(int n, String string) {
        this.ordinal = n;
        this.name = string;
    }

    public String toString() {
        return this.name;
    }

    public static MixinEnvironment$Phase forName(String string) {
        Iterator<MixinEnvironment$Phase> iterator = phases.iterator();
        while (MixinEnvironment$Phase.llIlllIl(iterator.hasNext() ? 1 : 0)) {
            MixinEnvironment$Phase mixinEnvironment$Phase = iterator.next();
            if (MixinEnvironment$Phase.llIlllIl(mixinEnvironment$Phase.name.equals(string) ? 1 : 0)) {
                return mixinEnvironment$Phase;
            }
            "".length();
            if ("   ".length() > " ".length()) continue;
            return null;
        }
        return null;
    }

    MixinEnvironment getEnvironment() {
        if (MixinEnvironment$Phase.llIllllI(this.ordinal)) {
            throw new IllegalArgumentException("Cannot access the NOT_INITIALISED environment");
        }
        if (MixinEnvironment$Phase.llIlllll(this.environment)) {
            this.environment = new MixinEnvironment(this);
        }
        return this.environment;
    }

    private static boolean llIlllll(Object object) {
        return object == null;
    }

    private static boolean llIlllIl(int n) {
        return n != 0;
    }

    private static boolean llIllllI(int n) {
        return n < 0;
    }
}

