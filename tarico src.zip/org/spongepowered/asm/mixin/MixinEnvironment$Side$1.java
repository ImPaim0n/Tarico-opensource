/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$Side;

final class MixinEnvironment$Side$1
extends MixinEnvironment$Side {
    @Override
    protected boolean detect() {
        return false;
    }
}

