/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$Side;
import org.spongepowered.asm.service.MixinService;

final class MixinEnvironment$Side$2
extends MixinEnvironment$Side {
    @Override
    protected boolean detect() {
        String string = MixinService.getService().getSideName();
        return "CLIENT".equals(string);
    }
}

