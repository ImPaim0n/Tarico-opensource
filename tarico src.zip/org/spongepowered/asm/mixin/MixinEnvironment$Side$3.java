/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$Side;
import org.spongepowered.asm.service.MixinService;

final class MixinEnvironment$Side$3
extends MixinEnvironment$Side {
    @Override
    protected boolean detect() {
        boolean bl;
        String string = MixinService.getService().getSideName();
        if (!MixinEnvironment$Side$3.lIIIlIIlllI("SERVER".equals(string) ? 1 : 0) || MixinEnvironment$Side$3.lIIIlIIllll("DEDICATEDSERVER".equals(string) ? 1 : 0)) {
            bl = true;
            "".length();
            if ("   ".length() < 0) {
                return ((0x23 ^ 0x13 ^ (0x6D ^ 0x1C)) & (0xF3 ^ 0xA3 ^ (1 ^ 0x10) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean lIIIlIIllll(int n) {
        return n != 0;
    }

    private static boolean lIIIlIIlllI(int n) {
        return n == 0;
    }
}

