/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment$1;
import org.spongepowered.asm.mixin.MixinEnvironment$Side$1;
import org.spongepowered.asm.mixin.MixinEnvironment$Side$2;
import org.spongepowered.asm.mixin.MixinEnvironment$Side$3;

public abstract class MixinEnvironment$Side
extends Enum<MixinEnvironment$Side> {
    public static final /* enum */ MixinEnvironment$Side UNKNOWN = new MixinEnvironment$Side$1();
    public static final /* enum */ MixinEnvironment$Side CLIENT = new MixinEnvironment$Side$2();
    public static final /* enum */ MixinEnvironment$Side SERVER = new MixinEnvironment$Side$3();
    private static final /* synthetic */ MixinEnvironment$Side[] $VALUES;

    public static MixinEnvironment$Side[] values() {
        return (MixinEnvironment$Side[])$VALUES.clone();
    }

    public static MixinEnvironment$Side valueOf(String string) {
        return Enum.valueOf(MixinEnvironment$Side.class, string);
    }

    private MixinEnvironment$Side() {
    }

    protected abstract boolean detect();

    /* synthetic */ MixinEnvironment$Side(String string, int n, MixinEnvironment$1 mixinEnvironment$1) {
        this();
    }

    static {
        $VALUES = new MixinEnvironment$Side[]{UNKNOWN, CLIENT, SERVER};
    }
}

