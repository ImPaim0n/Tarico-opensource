/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin;

import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.extensibility.IEnvironmentTokenProvider;

class MixinEnvironment$TokenProviderWrapper
implements Comparable<MixinEnvironment$TokenProviderWrapper> {
    private static int nextOrder = 0;
    private final int priority;
    private final int order;
    private final IEnvironmentTokenProvider provider;
    private final MixinEnvironment environment;

    public MixinEnvironment$TokenProviderWrapper(IEnvironmentTokenProvider iEnvironmentTokenProvider, MixinEnvironment mixinEnvironment) {
        this.provider = iEnvironmentTokenProvider;
        this.environment = mixinEnvironment;
        this.order = nextOrder++;
        this.priority = iEnvironmentTokenProvider.getPriority();
    }

    @Override
    public int compareTo(MixinEnvironment$TokenProviderWrapper mixinEnvironment$TokenProviderWrapper) {
        if (MixinEnvironment$TokenProviderWrapper.llIIIIIIl(mixinEnvironment$TokenProviderWrapper)) {
            return 0;
        }
        if (MixinEnvironment$TokenProviderWrapper.llIIIIIlI(mixinEnvironment$TokenProviderWrapper.priority, this.priority)) {
            return mixinEnvironment$TokenProviderWrapper.order - this.order;
        }
        return mixinEnvironment$TokenProviderWrapper.priority - this.priority;
    }

    public IEnvironmentTokenProvider getProvider() {
        return this.provider;
    }

    Integer getToken(String string) {
        return this.provider.getToken(string, this.environment);
    }

    private static boolean llIIIIIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean llIIIIIIl(Object object) {
        return object == null;
    }
}

