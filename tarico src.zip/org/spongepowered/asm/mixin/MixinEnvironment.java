/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin;

import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.GlobalProperties;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.mixin.MixinEnvironment$MixinLogWatcher;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.MixinEnvironment$Side;
import org.spongepowered.asm.mixin.MixinEnvironment$TokenProviderWrapper;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.mixin.extensibility.IEnvironmentTokenProvider;
import org.spongepowered.asm.mixin.throwables.MixinException;
import org.spongepowered.asm.mixin.transformer.MixinTransformer;
import org.spongepowered.asm.obfuscation.RemapperChain;
import org.spongepowered.asm.service.ILegacyClassTransformer;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.ITransformer;
import org.spongepowered.asm.service.MixinService;
import org.spongepowered.asm.util.ITokenProvider;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.perf.Profiler;

public final class MixinEnvironment
implements ITokenProvider {
    private static final Set<String> excludeTransformers = Sets.newHashSet((Object[])new String[]{"net.minecraftforge.fml.common.asm.transformers.EventSubscriptionTransformer", "cpw.mods.fml.common.asm.transformers.EventSubscriptionTransformer", "net.minecraftforge.fml.common.asm.transformers.TerminalTransformer", "cpw.mods.fml.common.asm.transformers.TerminalTransformer"});
    private static MixinEnvironment currentEnvironment;
    private static MixinEnvironment$Phase currentPhase;
    private static MixinEnvironment$CompatibilityLevel compatibility;
    private static boolean showHeader;
    private static final Logger logger;
    private static final Profiler profiler;
    private final IMixinService service;
    private final MixinEnvironment$Phase phase;
    private final String configsKey;
    private final boolean[] options;
    private final Set<String> tokenProviderClasses = new HashSet<String>();
    private final List<MixinEnvironment$TokenProviderWrapper> tokenProviders = new ArrayList<MixinEnvironment$TokenProviderWrapper>();
    private final Map<String, Integer> internalTokens = new HashMap<String, Integer>();
    private final RemapperChain remappers = new RemapperChain();
    private MixinEnvironment$Side side;
    private List<ILegacyClassTransformer> transformers;
    private String obfuscationContext = null;

    MixinEnvironment(MixinEnvironment$Phase mixinEnvironment$Phase) {
        this.service = MixinService.getService();
        this.phase = mixinEnvironment$Phase;
        this.configsKey = String.valueOf(new StringBuilder().append("mixin.configs.").append(this.phase.name.toLowerCase()));
        String string = this.getVersion();
        if (!MixinEnvironment.lllIIllIIIl(string) || MixinEnvironment.lllIIllIIlI("0.7.10".equals(string) ? 1 : 0)) {
            throw new MixinException("Environment conflict, mismatched versions or you didn't call MixinBootstrap.init()");
        }
        this.service.checkEnv(this);
        this.options = new boolean[MixinEnvironment$Option.values().length];
        MixinEnvironment$Option[] mixinEnvironment$OptionArray = MixinEnvironment$Option.values();
        int n = mixinEnvironment$OptionArray.length;
        int n2 = 0;
        while (MixinEnvironment.lllIIllIIll(n2, n)) {
            MixinEnvironment$Option mixinEnvironment$Option = mixinEnvironment$OptionArray[n2];
            this.options[mixinEnvironment$Option.ordinal()] = mixinEnvironment$Option.getBooleanValue();
            ++n2;
            "".length();
            if ("  ".length() == "  ".length()) continue;
            throw null;
        }
        if (MixinEnvironment.lllIIllIlII(showHeader ? 1 : 0)) {
            showHeader = false;
            this.printHeader(string);
        }
    }

    private void printHeader(Object object) {
        String string = this.getCodeSource();
        String string2 = this.service.getName();
        MixinEnvironment$Side mixinEnvironment$Side = this.getSide();
        logger.info("SpongePowered MIXIN Subsystem Version={} Source={} Service={} Env={}", new Object[]{object, string, string2, mixinEnvironment$Side});
        int n = this.getOption(MixinEnvironment$Option.DEBUG_VERBOSE);
        if (!MixinEnvironment.lllIIllIIlI(n) || !MixinEnvironment.lllIIllIIlI(this.getOption(MixinEnvironment$Option.DEBUG_EXPORT) ? 1 : 0) || MixinEnvironment.lllIIllIlII(this.getOption(MixinEnvironment$Option.DEBUG_PROFILER) ? 1 : 0)) {
            String string3;
            PrettyPrinter prettyPrinter = new PrettyPrinter(32);
            Object[] objectArray = new Object[1];
            if (MixinEnvironment.lllIIllIlII(n)) {
                string3 = " (Verbose debugging enabled)";
                "".length();
                if (((10 + 102 - -99 + 24 ^ 86 + 105 - 72 + 59) & (108 + 71 - 37 + 11 ^ 113 + 50 - 123 + 152 ^ -" ".length())) == " ".length()) {
                    return;
                }
            } else {
                string3 = "";
            }
            objectArray[0] = string3;
            prettyPrinter.add("SpongePowered MIXIN%s", objectArray).centre().hr();
            "".length();
            prettyPrinter.kv("Code source", string);
            "".length();
            prettyPrinter.kv("Internal Version", object);
            "".length();
            prettyPrinter.kv("Java 8 Supported", MixinEnvironment$CompatibilityLevel.JAVA_8.isSupported()).hr();
            "".length();
            prettyPrinter.kv("Service Name", string2);
            "".length();
            prettyPrinter.kv("Service Class", this.service.getClass().getName()).hr();
            "".length();
            MixinEnvironment$Option[] mixinEnvironment$OptionArray = MixinEnvironment$Option.values();
            int n2 = mixinEnvironment$OptionArray.length;
            int n3 = 0;
            while (MixinEnvironment.lllIIllIIll(n3, n2)) {
                MixinEnvironment$Option mixinEnvironment$Option = mixinEnvironment$OptionArray[n3];
                StringBuilder stringBuilder = new StringBuilder();
                int n4 = 0;
                while (MixinEnvironment.lllIIllIIll(n4, mixinEnvironment$Option.depth)) {
                    stringBuilder.append("- ");
                    "".length();
                    ++n4;
                    "".length();
                    if (" ".length() >= 0) continue;
                    return;
                }
                prettyPrinter.kv(mixinEnvironment$Option.property, "%s<%s>", new Object[]{stringBuilder, mixinEnvironment$Option});
                "".length();
                ++n3;
                "".length();
                if (-"  ".length() <= 0) continue;
                return;
            }
            prettyPrinter.hr().kv("Detected Side", (Object)mixinEnvironment$Side);
            "".length();
            prettyPrinter.print(System.err);
            "".length();
        }
    }

    private String getCodeSource() {
        try {
            return this.getClass().getProtectionDomain().getCodeSource().getLocation().toString();
        }
        catch (Throwable throwable) {
            return "Unknown";
        }
    }

    public MixinEnvironment$Phase getPhase() {
        return this.phase;
    }

    @Deprecated
    public List<String> getMixinConfigs() {
        ArrayList arrayList = (ArrayList)GlobalProperties.get(this.configsKey);
        if (MixinEnvironment.lllIIllIlIl(arrayList)) {
            arrayList = new ArrayList();
            GlobalProperties.put(this.configsKey, arrayList);
        }
        return arrayList;
    }

    @Deprecated
    public MixinEnvironment addConfiguration(String string) {
        logger.warn("MixinEnvironment::addConfiguration is deprecated and will be removed. Use Mixins::addConfiguration instead!");
        Mixins.addConfiguration(string, this);
        return this;
    }

    void registerConfig(String string) {
        List<String> list = this.getMixinConfigs();
        if (MixinEnvironment.lllIIllIIlI(list.contains(string) ? 1 : 0)) {
            list.add(string);
            "".length();
        }
    }

    @Deprecated
    public MixinEnvironment registerErrorHandlerClass(String string) {
        Mixins.registerErrorHandlerClass(string);
        return this;
    }

    public MixinEnvironment registerTokenProviderClass(String string) {
        if (MixinEnvironment.lllIIllIIlI(this.tokenProviderClasses.contains(string) ? 1 : 0)) {
            try {
                Class<?> clazz = this.service.getClassProvider().findClass(string, true);
                IEnvironmentTokenProvider iEnvironmentTokenProvider = (IEnvironmentTokenProvider)clazz.newInstance();
                this.registerTokenProvider(iEnvironmentTokenProvider);
                "".length();
                "".length();
            }
            catch (Throwable throwable) {
                logger.error(String.valueOf(new StringBuilder().append("Error instantiating ").append(string)), throwable);
            }
            if (null != null) {
                return null;
            }
        }
        return this;
    }

    public MixinEnvironment registerTokenProvider(IEnvironmentTokenProvider iEnvironmentTokenProvider) {
        if (MixinEnvironment.lllIIllIIIl(iEnvironmentTokenProvider) && MixinEnvironment.lllIIllIIlI(this.tokenProviderClasses.contains(iEnvironmentTokenProvider.getClass().getName()) ? 1 : 0)) {
            String string = iEnvironmentTokenProvider.getClass().getName();
            MixinEnvironment$TokenProviderWrapper mixinEnvironment$TokenProviderWrapper = new MixinEnvironment$TokenProviderWrapper(iEnvironmentTokenProvider, this);
            logger.info("Adding new token provider {} to {}", new Object[]{string, this});
            this.tokenProviders.add(mixinEnvironment$TokenProviderWrapper);
            "".length();
            this.tokenProviderClasses.add(string);
            "".length();
            Collections.sort(this.tokenProviders);
        }
        return this;
    }

    @Override
    public Integer getToken(String string) {
        string = string.toUpperCase();
        Iterator<MixinEnvironment$TokenProviderWrapper> iterator = this.tokenProviders.iterator();
        while (MixinEnvironment.lllIIllIlII(iterator.hasNext() ? 1 : 0)) {
            MixinEnvironment$TokenProviderWrapper mixinEnvironment$TokenProviderWrapper = iterator.next();
            Integer n = mixinEnvironment$TokenProviderWrapper.getToken(string);
            if (MixinEnvironment.lllIIllIIIl(n)) {
                return n;
            }
            "".length();
            if (-"   ".length() <= 0) continue;
            return null;
        }
        return this.internalTokens.get(string);
    }

    @Deprecated
    public Set<String> getErrorHandlerClasses() {
        return Mixins.getErrorHandlerClasses();
    }

    public Object getActiveTransformer() {
        return GlobalProperties.get("mixin.transformer");
    }

    public void setActiveTransformer(ITransformer iTransformer) {
        if (MixinEnvironment.lllIIllIIIl(iTransformer)) {
            GlobalProperties.put("mixin.transformer", iTransformer);
        }
    }

    public MixinEnvironment setSide(MixinEnvironment$Side mixinEnvironment$Side) {
        if (MixinEnvironment.lllIIllIIIl((Object)mixinEnvironment$Side) && MixinEnvironment.lllIIllIllI((Object)this.getSide(), (Object)MixinEnvironment$Side.UNKNOWN) && MixinEnvironment.lllIIllIlll((Object)mixinEnvironment$Side, (Object)MixinEnvironment$Side.UNKNOWN)) {
            this.side = mixinEnvironment$Side;
        }
        return this;
    }

    public MixinEnvironment$Side getSide() {
        MixinEnvironment$Side mixinEnvironment$Side;
        if (MixinEnvironment.lllIIllIlIl((Object)this.side)) {
            MixinEnvironment$Side[] mixinEnvironment$SideArray = MixinEnvironment$Side.values();
            int n = mixinEnvironment$SideArray.length;
            int n2 = 0;
            while (MixinEnvironment.lllIIllIIll(n2, n)) {
                MixinEnvironment$Side mixinEnvironment$Side2 = mixinEnvironment$SideArray[n2];
                if (MixinEnvironment.lllIIllIlII(mixinEnvironment$Side2.detect() ? 1 : 0)) {
                    this.side = mixinEnvironment$Side2;
                    "".length();
                    if (" ".length() > ((8 ^ 0x37 ^ (0xCE ^ 0xBB)) & (8 ^ 0x25 ^ (0x28 ^ 0x4F) ^ -" ".length()))) break;
                    return null;
                }
                ++n2;
                "".length();
                if (null == null) continue;
                return null;
            }
        }
        if (MixinEnvironment.lllIIllIIIl((Object)this.side)) {
            mixinEnvironment$Side = this.side;
            "".length();
            if ("  ".length() < 0) {
                return null;
            }
        } else {
            mixinEnvironment$Side = MixinEnvironment$Side.UNKNOWN;
        }
        return mixinEnvironment$Side;
    }

    public String getVersion() {
        return (String)GlobalProperties.get("mixin.initialised");
    }

    public boolean getOption(MixinEnvironment$Option mixinEnvironment$Option) {
        return this.options[mixinEnvironment$Option.ordinal()];
    }

    public void setOption(MixinEnvironment$Option mixinEnvironment$Option, boolean bl) {
        this.options[mixinEnvironment$Option.ordinal()] = bl;
    }

    public String getOptionValue(MixinEnvironment$Option mixinEnvironment$Option) {
        return mixinEnvironment$Option.getStringValue();
    }

    public <E extends Enum<E>> E getOption(MixinEnvironment$Option mixinEnvironment$Option, E e) {
        return mixinEnvironment$Option.getEnumValue(e);
    }

    public void setObfuscationContext(String string) {
        this.obfuscationContext = string;
    }

    public String getObfuscationContext() {
        return this.obfuscationContext;
    }

    public String getRefmapObfuscationContext() {
        String string = MixinEnvironment$Option.OBFUSCATION_TYPE.getStringValue();
        if (MixinEnvironment.lllIIllIIIl(string)) {
            return string;
        }
        return this.obfuscationContext;
    }

    public RemapperChain getRemappers() {
        return this.remappers;
    }

    public void audit() {
        Object object = this.getActiveTransformer();
        if (MixinEnvironment.lllIIllIlII(object instanceof MixinTransformer)) {
            MixinTransformer mixinTransformer = (MixinTransformer)object;
            mixinTransformer.audit(this);
        }
    }

    public List<ILegacyClassTransformer> getTransformers() {
        if (MixinEnvironment.lllIIllIlIl(this.transformers)) {
            this.buildTransformerDelegationList();
        }
        return Collections.unmodifiableList(this.transformers);
    }

    public void addTransformerExclusion(String string) {
        excludeTransformers.add(string);
        "".length();
        this.transformers = null;
    }

    private void buildTransformerDelegationList() {
        logger.debug("Rebuilding transformer delegation list:");
        this.transformers = new ArrayList<ILegacyClassTransformer>();
        Iterator<ITransformer> iterator = this.service.getTransformers().iterator();
        while (MixinEnvironment.lllIIllIlII(iterator.hasNext() ? 1 : 0)) {
            ITransformer iTransformer = iterator.next();
            if (MixinEnvironment.lllIIllIIlI(iTransformer instanceof ILegacyClassTransformer)) {
                "".length();
                if (((14 + 115 - 67 + 83 ^ 29 + 50 - 26 + 112) & (128 + 157 - 269 + 155 ^ 91 + 142 - 138 + 64 ^ -" ".length())) == 0) continue;
                return;
            }
            ILegacyClassTransformer iLegacyClassTransformer = (ILegacyClassTransformer)iTransformer;
            String string = iLegacyClassTransformer.getName();
            int n = 1;
            Iterator<String> iterator2 = excludeTransformers.iterator();
            while (MixinEnvironment.lllIIllIlII(iterator2.hasNext() ? 1 : 0)) {
                String string2 = iterator2.next();
                if (MixinEnvironment.lllIIllIlII(string.contains(string2) ? 1 : 0)) {
                    n = 0;
                    "".length();
                    if (-"   ".length() <= 0) break;
                    return;
                }
                "".length();
                if ((0x31 ^ 0x34) > 0) continue;
                return;
            }
            if (MixinEnvironment.lllIIllIlII(n) && MixinEnvironment.lllIIllIIlI(iLegacyClassTransformer.isDelegationExcluded() ? 1 : 0)) {
                logger.debug("  Adding:    {}", new Object[]{string});
                this.transformers.add(iLegacyClassTransformer);
                "".length();
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                logger.debug("  Excluding: {}", new Object[]{string});
            }
            "".length();
            if (null == null) continue;
            return;
        }
        logger.debug("Transformer delegation list created with {} entries", new Object[]{this.transformers.size()});
    }

    public String toString() {
        return String.format("%s[%s]", this.getClass().getSimpleName(), this.phase);
    }

    private static MixinEnvironment$Phase getCurrentPhase() {
        if (MixinEnvironment.lllIIllIllI(currentPhase, MixinEnvironment$Phase.NOT_INITIALISED)) {
            MixinEnvironment.init(MixinEnvironment$Phase.PREINIT);
        }
        return currentPhase;
    }

    public static void init(MixinEnvironment$Phase mixinEnvironment$Phase) {
        if (MixinEnvironment.lllIIllIllI(currentPhase, MixinEnvironment$Phase.NOT_INITIALISED)) {
            currentPhase = mixinEnvironment$Phase;
            MixinEnvironment mixinEnvironment = MixinEnvironment.getEnvironment(mixinEnvironment$Phase);
            MixinEnvironment.getProfiler().setActive(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_PROFILER));
            MixinEnvironment$MixinLogWatcher.begin();
        }
    }

    public static MixinEnvironment getEnvironment(MixinEnvironment$Phase mixinEnvironment$Phase) {
        if (MixinEnvironment.lllIIllIlIl(mixinEnvironment$Phase)) {
            return MixinEnvironment$Phase.DEFAULT.getEnvironment();
        }
        return mixinEnvironment$Phase.getEnvironment();
    }

    public static MixinEnvironment getDefaultEnvironment() {
        return MixinEnvironment.getEnvironment(MixinEnvironment$Phase.DEFAULT);
    }

    public static MixinEnvironment getCurrentEnvironment() {
        if (MixinEnvironment.lllIIllIlIl(currentEnvironment)) {
            currentEnvironment = MixinEnvironment.getEnvironment(MixinEnvironment.getCurrentPhase());
        }
        return currentEnvironment;
    }

    public static MixinEnvironment$CompatibilityLevel getCompatibilityLevel() {
        return compatibility;
    }

    @Deprecated
    public static void setCompatibilityLevel(MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel) {
        StackTraceElement[] stackTraceElementArray = Thread.currentThread().getStackTrace();
        if (MixinEnvironment.lllIIllIIlI("org.spongepowered.asm.mixin.transformer.MixinConfig".equals(stackTraceElementArray[2].getClassName()) ? 1 : 0)) {
            logger.warn("MixinEnvironment::setCompatibilityLevel is deprecated and will be removed. Set level via config instead!");
        }
        if (MixinEnvironment.lllIIllIlll((Object)mixinEnvironment$CompatibilityLevel, (Object)compatibility) && MixinEnvironment.lllIIllIlII(mixinEnvironment$CompatibilityLevel.isAtLeast(compatibility) ? 1 : 0)) {
            if (MixinEnvironment.lllIIllIIlI(mixinEnvironment$CompatibilityLevel.isSupported() ? 1 : 0)) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("The requested compatibility level ").append((Object)mixinEnvironment$CompatibilityLevel).append(" could not be set. Level is not supported")));
            }
            compatibility = mixinEnvironment$CompatibilityLevel;
            logger.info("Compatibility level set to {}", new Object[]{mixinEnvironment$CompatibilityLevel});
        }
    }

    public static Profiler getProfiler() {
        return profiler;
    }

    static void gotoPhase(MixinEnvironment$Phase mixinEnvironment$Phase) {
        if (!MixinEnvironment.lllIIllIIIl(mixinEnvironment$Phase) || MixinEnvironment.lllIIlllIII(mixinEnvironment$Phase.ordinal)) {
            throw new IllegalArgumentException("Cannot go to the specified phase, phase is null or invalid");
        }
        if (MixinEnvironment.lllIIlllIIl(mixinEnvironment$Phase.ordinal, MixinEnvironment.getCurrentPhase().ordinal)) {
            MixinService.getService().beginPhase();
        }
        if (MixinEnvironment.lllIIllIllI(mixinEnvironment$Phase, MixinEnvironment$Phase.DEFAULT)) {
            MixinEnvironment$MixinLogWatcher.end();
        }
        currentPhase = mixinEnvironment$Phase;
        currentEnvironment = MixinEnvironment.getEnvironment(MixinEnvironment.getCurrentPhase());
    }

    static {
        currentPhase = MixinEnvironment$Phase.NOT_INITIALISED;
        compatibility = MixinEnvironment$Option.DEFAULT_COMPATIBILITY_LEVEL.getEnumValue(MixinEnvironment$CompatibilityLevel.JAVA_6);
        showHeader = true;
        logger = LogManager.getLogger((String)"mixin");
        profiler = new Profiler();
    }

    private static boolean lllIIllIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIIlllIIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIIllIlll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lllIIllIIIl(Object object) {
        return object != null;
    }

    private static boolean lllIIllIllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIIllIlIl(Object object) {
        return object == null;
    }

    private static boolean lllIIllIlII(int n) {
        return n != 0;
    }

    private static boolean lllIIllIIlI(int n) {
        return n == 0;
    }

    private static boolean lllIIlllIII(int n) {
        return n < 0;
    }
}

