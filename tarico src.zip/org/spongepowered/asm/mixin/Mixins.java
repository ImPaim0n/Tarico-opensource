/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.GlobalProperties;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.transformer.Config;

public final class Mixins {
    private static final Logger logger;
    private static final String CONFIGS_KEY;
    private static final Set<String> errorHandlers;

    private Mixins() {
    }

    public static void addConfigurations(String ... stringArray) {
        MixinEnvironment mixinEnvironment = MixinEnvironment.getDefaultEnvironment();
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        int n2 = 0;
        while (Mixins.lllIIlIIlI(n2, n)) {
            String string = stringArray2[n2];
            Mixins.createConfiguration(string, mixinEnvironment);
            ++n2;
            "".length();
            if (null == null) continue;
            return;
        }
    }

    public static void addConfiguration(String string) {
        Mixins.createConfiguration(string, MixinEnvironment.getDefaultEnvironment());
    }

    @Deprecated
    static void addConfiguration(String string, MixinEnvironment mixinEnvironment) {
        Mixins.createConfiguration(string, mixinEnvironment);
    }

    private static void createConfiguration(String string, MixinEnvironment mixinEnvironment) {
        Config config = null;
        try {
            config = Config.create(string, mixinEnvironment);
            "".length();
        }
        catch (Exception exception) {
            logger.error(String.valueOf(new StringBuilder().append("Error encountered reading mixin config ").append(string).append(": ").append(exception.getClass().getName()).append(" ").append(exception.getMessage())), (Throwable)exception);
        }
        if (null != null) {
            return;
        }
        Mixins.registerConfiguration(config);
    }

    private static void registerConfiguration(Config config) {
        if (Mixins.lllIIlIIll(config)) {
            return;
        }
        MixinEnvironment mixinEnvironment = config.getEnvironment();
        if (Mixins.lllIIlIlII(mixinEnvironment)) {
            mixinEnvironment.registerConfig(config.getName());
        }
        Mixins.getConfigs().add(config);
        "".length();
    }

    public static int getUnvisitedCount() {
        int n = 0;
        Iterator<Config> iterator = Mixins.getConfigs().iterator();
        while (Mixins.lllIIlIlIl(iterator.hasNext() ? 1 : 0)) {
            Config config = iterator.next();
            if (Mixins.lllIIlIllI(config.isVisited() ? 1 : 0)) {
                ++n;
            }
            "".length();
            if (((0x19 ^ 0x34) & ~(0x9F ^ 0xB2)) == ((0xE0 ^ 0xB4) & ~(0xDB ^ 0x8F))) continue;
            return (0xD2 ^ 0x97) & ~(4 ^ 0x41);
        }
        return n;
    }

    public static Set<Config> getConfigs() {
        LinkedHashSet linkedHashSet = (LinkedHashSet)GlobalProperties.get("mixin.configs.queue");
        if (Mixins.lllIIlIIll(linkedHashSet)) {
            linkedHashSet = new LinkedHashSet();
            GlobalProperties.put("mixin.configs.queue", linkedHashSet);
        }
        return linkedHashSet;
    }

    public static void registerErrorHandlerClass(String string) {
        if (Mixins.lllIIlIlII(string)) {
            errorHandlers.add(string);
            "".length();
        }
    }

    public static Set<String> getErrorHandlerClasses() {
        return Collections.unmodifiableSet(errorHandlers);
    }

    static {
        CONFIGS_KEY = "mixin.configs.queue";
        logger = LogManager.getLogger((String)"mixin");
        errorHandlers = new LinkedHashSet<String>();
    }

    private static boolean lllIIlIIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIIlIlII(Object object) {
        return object != null;
    }

    private static boolean lllIIlIIll(Object object) {
        return object == null;
    }

    private static boolean lllIIlIlIl(int n) {
        return n != 0;
    }

    private static boolean lllIIlIllI(int n) {
        return n == 0;
    }
}

