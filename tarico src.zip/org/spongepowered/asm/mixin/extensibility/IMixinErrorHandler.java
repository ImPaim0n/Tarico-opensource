/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.extensibility;

import org.spongepowered.asm.mixin.extensibility.IMixinConfig;
import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler$ErrorAction;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public interface IMixinErrorHandler {
    public ErrorAction onPrepareError(IMixinConfig var1, Throwable var2, IMixinInfo var3, ErrorAction var4);

    public ErrorAction onApplyError(String var1, Throwable var2, IMixinInfo var3, ErrorAction var4);
}

