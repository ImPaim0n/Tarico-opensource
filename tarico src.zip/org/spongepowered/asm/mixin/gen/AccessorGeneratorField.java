/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.gen;

import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.mixin.gen.AccessorGenerator;
import org.spongepowered.asm.mixin.gen.AccessorInfo;

public abstract class AccessorGeneratorField
extends AccessorGenerator {
    protected final FieldNode targetField;
    protected final Type targetType;
    protected final boolean isInstanceField;

    public AccessorGeneratorField(AccessorInfo accessorInfo) {
        super(accessorInfo);
        boolean bl;
        this.targetField = accessorInfo.getTargetField();
        this.targetType = accessorInfo.getTargetFieldType();
        if (AccessorGeneratorField.lIIlIlllll(this.targetField.access & 8)) {
            bl = true;
            "".length();
            if ("  ".length() <= 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.isInstanceField = bl;
    }

    private static boolean lIIlIlllll(int n) {
        return n == 0;
    }
}

