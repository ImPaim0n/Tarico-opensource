/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.gen;

import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.gen.AccessorGeneratorField;
import org.spongepowered.asm.mixin.gen.AccessorInfo;

public class AccessorGeneratorFieldSetter
extends AccessorGeneratorField {
    public AccessorGeneratorFieldSetter(AccessorInfo accessorInfo) {
        super(accessorInfo);
    }

    @Override
    public MethodNode generate() {
        int n;
        int n2;
        if (AccessorGeneratorFieldSetter.llIIllIIllI(this.isInstanceField ? 1 : 0)) {
            n2 = 1;
            "".length();
            if ((0x69 ^ 0x48 ^ (0xE6 ^ 0xC3)) <= ((0x50 ^ 0x7E ^ (0xFB ^ 0x9C)) & (0xD2 ^ 0xB1 ^ (0x19 ^ 0x33) ^ -" ".length()))) {
                return null;
            }
        } else {
            n2 = 0;
        }
        int n3 = n2;
        int n4 = n3 + this.targetType.getSize();
        int n5 = n3 + this.targetType.getSize();
        MethodNode methodNode = this.createMethod(n4, n5);
        if (AccessorGeneratorFieldSetter.llIIllIIllI(this.isInstanceField ? 1 : 0)) {
            methodNode.instructions.add(new VarInsnNode(25, 0));
        }
        methodNode.instructions.add(new VarInsnNode(this.targetType.getOpcode(21), n3));
        if (AccessorGeneratorFieldSetter.llIIllIIllI(this.isInstanceField ? 1 : 0)) {
            n = 181;
            "".length();
            if ((0x99 ^ 0x9D) < 0) {
                return null;
            }
        } else {
            n = 179;
        }
        int n6 = n;
        methodNode.instructions.add(new FieldInsnNode(n6, this.info.getClassNode().name, this.targetField.name, this.targetField.desc));
        methodNode.instructions.add(new InsnNode(177));
        return methodNode;
    }

    private static boolean llIIllIIllI(int n) {
        return n != 0;
    }
}

