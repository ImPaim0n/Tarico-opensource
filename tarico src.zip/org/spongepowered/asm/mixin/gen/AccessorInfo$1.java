/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.gen;

import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType;

class AccessorInfo$1 {
    static final /* synthetic */ int[] $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType;

    static {
        block6: {
            block5: {
                $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType = new int[AccessorInfo$AccessorType.values().length];
                try {
                    AccessorInfo$1.$SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[AccessorInfo$AccessorType.FIELD_GETTER.ordinal()] = 1;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if ("  ".length() >= -" ".length()) break block5;
                break block6;
            }
            try {
                AccessorInfo$1.$SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[AccessorInfo$AccessorType.FIELD_SETTER.ordinal()] = 2;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if (null != null) {
                // empty if block
            }
        }
    }
}

