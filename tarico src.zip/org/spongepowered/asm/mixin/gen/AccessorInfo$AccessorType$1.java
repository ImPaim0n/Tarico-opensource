/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.gen;

import java.util.Set;
import org.spongepowered.asm.mixin.gen.AccessorGenerator;
import org.spongepowered.asm.mixin.gen.AccessorGeneratorFieldGetter;
import org.spongepowered.asm.mixin.gen.AccessorInfo;
import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType;

final class AccessorInfo$AccessorType$1
extends AccessorInfo$AccessorType {
    AccessorInfo$AccessorType$1(Set set) {
    }

    @Override
    AccessorGenerator getGenerator(AccessorInfo accessorInfo) {
        return new AccessorGeneratorFieldGetter(accessorInfo);
    }
}

