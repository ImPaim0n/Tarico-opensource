/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 */
package org.spongepowered.asm.mixin.gen;

import com.google.common.collect.ImmutableSet;
import java.util.Set;
import org.spongepowered.asm.mixin.gen.AccessorGenerator;
import org.spongepowered.asm.mixin.gen.AccessorInfo;
import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType$1;
import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType$2;
import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType$3;

public abstract class AccessorInfo$AccessorType
extends Enum<AccessorInfo$AccessorType> {
    public static final /* enum */ AccessorInfo$AccessorType FIELD_GETTER = new AccessorInfo$AccessorType$1((Set)ImmutableSet.of((Object)"get", (Object)"is"));
    public static final /* enum */ AccessorInfo$AccessorType FIELD_SETTER = new AccessorInfo$AccessorType$2((Set)ImmutableSet.of((Object)"set"));
    public static final /* enum */ AccessorInfo$AccessorType METHOD_PROXY = new AccessorInfo$AccessorType$3((Set)ImmutableSet.of((Object)"call", (Object)"invoke"));
    private final Set<String> expectedPrefixes;
    private static final /* synthetic */ AccessorInfo$AccessorType[] $VALUES;

    public static AccessorInfo$AccessorType[] values() {
        return (AccessorInfo$AccessorType[])$VALUES.clone();
    }

    public static AccessorInfo$AccessorType valueOf(String string) {
        return Enum.valueOf(AccessorInfo$AccessorType.class, string);
    }

    private AccessorInfo$AccessorType(Set<String> set) {
        this.expectedPrefixes = set;
    }

    public boolean isExpectedPrefix(String string) {
        return this.expectedPrefixes.contains(string);
    }

    public String getExpectedPrefixes() {
        return this.expectedPrefixes.toString();
    }

    abstract AccessorGenerator getGenerator(AccessorInfo var1);

    static {
        $VALUES = new AccessorInfo$AccessorType[]{FIELD_GETTER, FIELD_SETTER, METHOD_PROXY};
    }
}

