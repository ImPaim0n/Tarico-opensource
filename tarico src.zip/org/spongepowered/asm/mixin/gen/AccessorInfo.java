/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  org.apache.logging.log4j.LogManager
 */
package org.spongepowered.asm.mixin.gen;

import com.google.common.base.Strings;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.AccessorInfo$1;
import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.gen.InvokerInfo;
import org.spongepowered.asm.mixin.gen.throwables.InvalidAccessorException;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.struct.SpecialMethodInfo;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

public class AccessorInfo
extends SpecialMethodInfo {
    protected static final Pattern PATTERN_ACCESSOR = Pattern.compile("^(get|set|is|invoke|call)(([A-Z])(.*?))(_\\$md.*)?$");
    protected final Type[] argTypes;
    protected final Type returnType;
    protected final AccessorInfo$AccessorType type;
    private final Type targetFieldType;
    protected final MemberInfo target;
    protected FieldNode targetField;
    protected MethodNode targetMethod;

    public AccessorInfo(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        this(mixinTargetContext, methodNode, Accessor.class);
    }

    protected AccessorInfo(MixinTargetContext mixinTargetContext, MethodNode methodNode, Class<? extends Annotation> clazz) {
        super(mixinTargetContext, methodNode, Annotations.getVisible(methodNode, clazz));
        this.argTypes = Type.getArgumentTypes(methodNode.desc);
        this.returnType = Type.getReturnType(methodNode.desc);
        this.type = this.initType();
        this.targetFieldType = this.initTargetFieldType();
        this.target = this.initTarget();
    }

    protected AccessorInfo$AccessorType initType() {
        if (AccessorInfo.lllIlllIlIl(this.returnType.equals(Type.VOID_TYPE) ? 1 : 0)) {
            return AccessorInfo$AccessorType.FIELD_SETTER;
        }
        return AccessorInfo$AccessorType.FIELD_GETTER;
    }

    protected Type initTargetFieldType() {
        switch (AccessorInfo$1.$SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[this.type.ordinal()]) {
            case 1: {
                if (AccessorInfo.lllIlllIllI(this.argTypes.length)) {
                    throw new InvalidAccessorException((IMixinContext)this.mixin, String.valueOf(new StringBuilder().append(this).append(" must take exactly 0 arguments, found ").append(this.argTypes.length)));
                }
                return this.returnType;
            }
            case 2: {
                if (AccessorInfo.lllIlllIlll(this.argTypes.length, 1)) {
                    throw new InvalidAccessorException((IMixinContext)this.mixin, String.valueOf(new StringBuilder().append(this).append(" must take exactly 1 argument, found ").append(this.argTypes.length)));
                }
                return this.argTypes[0];
            }
        }
        throw new InvalidAccessorException((IMixinContext)this.mixin, String.valueOf(new StringBuilder().append("Computed unsupported accessor type ").append((Object)this.type).append(" for ").append(this)));
    }

    protected MemberInfo initTarget() {
        MemberInfo memberInfo = new MemberInfo(this.getTargetName(), null, this.targetFieldType.getDescriptor());
        this.annotation.visit("target", memberInfo.toString());
        return memberInfo;
    }

    protected String getTargetName() {
        String string = (String)Annotations.getValue(this.annotation);
        if (AccessorInfo.lllIlllIlIl(Strings.isNullOrEmpty((String)string) ? 1 : 0)) {
            String string2 = this.inflectTarget();
            if (AccessorInfo.lllIllllIII(string2)) {
                throw new InvalidAccessorException((IMixinContext)this.mixin, String.valueOf(new StringBuilder().append("Failed to inflect target name for ").append(this).append(", supported prefixes: [get, set, is]")));
            }
            return string2;
        }
        return MemberInfo.parse((String)string, (IMixinContext)this.mixin).name;
    }

    protected String inflectTarget() {
        return AccessorInfo.inflectTarget(this.method.name, this.type, this.toString(), this.mixin, this.mixin.getEnvironment().getOption(MixinEnvironment$Option.DEBUG_VERBOSE));
    }

    public static String inflectTarget(String string, AccessorInfo$AccessorType accessorInfo$AccessorType, String string2, IMixinContext iMixinContext, boolean bl) {
        Matcher matcher = PATTERN_ACCESSOR.matcher(string);
        if (AccessorInfo.lllIlllIlIl(matcher.matches() ? 1 : 0)) {
            boolean bl2;
            String string3 = matcher.group(1);
            String string4 = matcher.group(3);
            String string5 = matcher.group(4);
            Object[] objectArray = new Object[2];
            if (AccessorInfo.lllIllllIIl(AccessorInfo.isUpperCase(string5) ? 1 : 0)) {
                bl2 = true;
                "".length();
                if ("  ".length() != "  ".length()) {
                    return null;
                }
            } else {
                bl2 = false;
            }
            objectArray[0] = AccessorInfo.toLowerCase(string4, bl2);
            objectArray[1] = string5;
            String string6 = String.format("%s%s", objectArray);
            if (AccessorInfo.lllIllllIIl(accessorInfo$AccessorType.isExpectedPrefix(string3) ? 1 : 0) && AccessorInfo.lllIlllIlIl(bl ? 1 : 0)) {
                LogManager.getLogger((String)"mixin").warn("Unexpected prefix for {}, found [{}] expecting {}", new Object[]{string2, string3, accessorInfo$AccessorType.getExpectedPrefixes()});
            }
            return MemberInfo.parse((String)string6, (IMixinContext)iMixinContext).name;
        }
        return null;
    }

    public final MemberInfo getTarget() {
        return this.target;
    }

    public final Type getTargetFieldType() {
        return this.targetFieldType;
    }

    public final FieldNode getTargetField() {
        return this.targetField;
    }

    public final MethodNode getTargetMethod() {
        return this.targetMethod;
    }

    public final Type getReturnType() {
        return this.returnType;
    }

    public final Type[] getArgTypes() {
        return this.argTypes;
    }

    public String toString() {
        return String.format("%s->@%s[%s]::%s%s", this.mixin.toString(), Bytecode.getSimpleName(this.annotation), this.type.toString(), this.method.name, this.method.desc);
    }

    public void locate() {
        this.targetField = this.findTargetField();
    }

    public MethodNode generate() {
        MethodNode methodNode = this.type.getGenerator(this).generate();
        Bytecode.mergeAnnotations(this.method, methodNode);
        return methodNode;
    }

    private FieldNode findTargetField() {
        return this.findTarget(this.classNode.fields);
    }

    protected <TNode> TNode findTarget(List<TNode> list) {
        String string;
        TNode TNode = null;
        ArrayList<TNode> arrayList = new ArrayList<TNode>();
        Object object = list.iterator();
        while (AccessorInfo.lllIlllIlIl(object.hasNext() ? 1 : 0)) {
            TNode TNode2 = object.next();
            String string2 = AccessorInfo.getNodeDesc(TNode2);
            if (!AccessorInfo.lllIllllIlI(string2)) continue;
            if (AccessorInfo.lllIllllIIl(string2.equals(this.target.desc) ? 1 : 0)) {
                "".length();
                if (null == null) continue;
                return null;
            }
            String string3 = AccessorInfo.getNodeName(TNode2);
            if (AccessorInfo.lllIllllIlI(string3)) {
                if (AccessorInfo.lllIlllIlIl(string3.equals(this.target.name) ? 1 : 0)) {
                    TNode = TNode2;
                }
                if (AccessorInfo.lllIlllIlIl(string3.equalsIgnoreCase(this.target.name) ? 1 : 0)) {
                    arrayList.add(TNode2);
                    "".length();
                }
            }
            "".length();
            if ("   ".length() >= 0) continue;
            return null;
        }
        if (AccessorInfo.lllIllllIlI(TNode)) {
            if (AccessorInfo.lllIllllIll(arrayList.size(), 1)) {
                LogManager.getLogger((String)"mixin").debug("{} found an exact match for {} but other candidates were found!", new Object[]{this, this.target});
            }
            return TNode;
        }
        if (AccessorInfo.lllIlllllII(arrayList.size(), 1)) {
            return (TNode)arrayList.get(0);
        }
        if (AccessorInfo.lllIllllIIl(arrayList.size())) {
            string = "No";
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string = "Multiple";
        }
        object = string;
        throw new InvalidAccessorException(this, String.valueOf(new StringBuilder().append((String)object).append(" candidates were found matching ").append(this.target).append(" in ").append(this.classNode.name).append(" for ").append(this)));
    }

    private static <TNode> String getNodeDesc(TNode TNode) {
        String string;
        if (AccessorInfo.lllIlllIlIl(TNode instanceof MethodNode)) {
            string = ((MethodNode)TNode).desc;
            "".length();
            if ("  ".length() == -" ".length()) {
                return null;
            }
        } else if (AccessorInfo.lllIlllIlIl(TNode instanceof FieldNode)) {
            string = ((FieldNode)TNode).desc;
            "".length();
            if (((11 + 115 - -88 + 16 ^ 11 + 126 - 97 + 154) & (0xC2 ^ 0x9B ^ (0xC5 ^ 0xB8) ^ -" ".length())) < -" ".length()) {
                return null;
            }
        } else {
            string = null;
        }
        return string;
    }

    private static <TNode> String getNodeName(TNode TNode) {
        String string;
        if (AccessorInfo.lllIlllIlIl(TNode instanceof MethodNode)) {
            string = ((MethodNode)TNode).name;
            "".length();
            if ((47 + 156 - 120 + 79 ^ 22 + 101 - 69 + 112) <= "   ".length()) {
                return null;
            }
        } else if (AccessorInfo.lllIlllIlIl(TNode instanceof FieldNode)) {
            string = ((FieldNode)TNode).name;
            "".length();
            if ("  ".length() == 0) {
                return null;
            }
        } else {
            string = null;
        }
        return string;
    }

    public static AccessorInfo of(MixinTargetContext mixinTargetContext, MethodNode methodNode, Class<? extends Annotation> clazz) {
        if (AccessorInfo.lllIlllllIl(clazz, Accessor.class)) {
            return new AccessorInfo(mixinTargetContext, methodNode);
        }
        if (AccessorInfo.lllIlllllIl(clazz, Invoker.class)) {
            return new InvokerInfo(mixinTargetContext, methodNode);
        }
        throw new InvalidAccessorException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("Could not parse accessor for unknown type ").append(clazz.getName())));
    }

    private static String toLowerCase(String string, boolean bl) {
        String string2;
        if (AccessorInfo.lllIlllIlIl(bl ? 1 : 0)) {
            string2 = string.toLowerCase();
            "".length();
            if ("  ".length() < ((0x91 ^ 0xC6) & ~(0x6F ^ 0x38))) {
                return null;
            }
        } else {
            string2 = string;
        }
        return string2;
    }

    private static boolean isUpperCase(String string) {
        return string.toUpperCase().equals(string);
    }

    private static boolean lllIlllllII(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIllllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIllllIlI(Object object) {
        return object != null;
    }

    private static boolean lllIlllllIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIllllIII(Object object) {
        return object == null;
    }

    private static boolean lllIlllIlIl(int n) {
        return n != 0;
    }

    private static boolean lllIllllIIl(int n) {
        return n == 0;
    }

    private static boolean lllIlllIllI(int n) {
        return n > 0;
    }

    private static boolean lllIlllIlll(int n, int n2) {
        return n != n2;
    }
}

