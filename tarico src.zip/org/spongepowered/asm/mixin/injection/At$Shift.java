/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection;

public enum At$Shift {
    NONE,
    BEFORE,
    AFTER,
    BY;

}

