/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Joiner
 */
package org.spongepowered.asm.mixin.injection;

import com.google.common.base.Joiner;
import org.spongepowered.asm.mixin.injection.InjectionPoint;

abstract class InjectionPoint$CompositeInjectionPoint
extends InjectionPoint {
    protected final InjectionPoint[] components;

    protected InjectionPoint$CompositeInjectionPoint(InjectionPoint ... injectionPointArray) {
        if (!InjectionPoint$CompositeInjectionPoint.lIlIIIIlIl(injectionPointArray) || InjectionPoint$CompositeInjectionPoint.lIlIIIIllI(injectionPointArray.length, 2)) {
            throw new IllegalArgumentException("Must supply two or more component injection points for composite point!");
        }
        this.components = injectionPointArray;
    }

    @Override
    public String toString() {
        return String.valueOf(new StringBuilder().append("CompositeInjectionPoint(").append(this.getClass().getSimpleName()).append(")[").append(Joiner.on((char)',').join((Object[])this.components)).append("]"));
    }

    private static boolean lIlIIIIllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIIIlIl(Object object) {
        return object != null;
    }
}

