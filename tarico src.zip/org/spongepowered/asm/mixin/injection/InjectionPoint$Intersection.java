/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$CompositeInjectionPoint;

final class InjectionPoint$Intersection
extends InjectionPoint$CompositeInjectionPoint {
    public InjectionPoint$Intersection(InjectionPoint ... injectionPointArray) {
        super(injectionPointArray);
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        boolean bl = false;
        ArrayList[] arrayListArray = (ArrayList[])Array.newInstance(ArrayList.class, this.components.length);
        int n = 0;
        while (InjectionPoint$Intersection.lIlIIlIl(n, this.components.length)) {
            arrayListArray[n] = new ArrayList();
            this.components[n].find(string, insnList, arrayListArray[n]);
            "".length();
            ++n;
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return ((0xD8 ^ 0xC5) & ~(0x83 ^ 0x9E)) != 0;
        }
        ArrayList arrayList = arrayListArray[0];
        int n2 = 0;
        while (InjectionPoint$Intersection.lIlIIlIl(n2, arrayList.size())) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)arrayList.get(n2);
            int n3 = 1;
            int n4 = 1;
            while (InjectionPoint$Intersection.lIlIIlIl(n4, arrayListArray.length)) {
                if (InjectionPoint$Intersection.lIlIIllI(arrayListArray[n4].contains(abstractInsnNode) ? 1 : 0)) {
                    "".length();
                    if (" ".length() != (50 + 103 - 65 + 67 ^ 62 + 104 - 105 + 98)) break;
                    return ((86 + 29 - 35 + 100 ^ 32 + 63 - 89 + 125) & (69 + 43 - 63 + 82 ^ 64 + 42 - 65 + 139 ^ -" ".length())) != 0;
                }
                ++n4;
                "".length();
                if (" ".length() <= " ".length()) continue;
                return ((0x73 ^ 0x7B) & ~(0x43 ^ 0x4B)) != 0;
            }
            if (InjectionPoint$Intersection.lIlIIllI(n3)) {
                "".length();
                if ("  ".length() == "   ".length()) {
                    return ((63 + 114 - 126 + 118 ^ 99 + 109 - 204 + 148) & (0x6F ^ 0x17 ^ (0x1C ^ 0x55) ^ -" ".length())) != 0;
                }
            } else {
                collection.add(abstractInsnNode);
                "".length();
                bl = true;
            }
            ++n2;
            "".length();
            if ((0x23 ^ 0x27) == (0xAC ^ 0xA8)) continue;
            return ((0xBC ^ 0x85) & ~(0x93 ^ 0xAA)) != 0;
        }
        return bl;
    }

    private static boolean lIlIIlIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIllI(int n) {
        return n == 0;
    }
}

