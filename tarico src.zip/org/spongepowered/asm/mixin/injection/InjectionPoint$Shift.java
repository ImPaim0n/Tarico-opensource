/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.mixin.injection.InjectionPoint;

final class InjectionPoint$Shift
extends InjectionPoint {
    private final InjectionPoint input;
    private final int shift;

    public InjectionPoint$Shift(InjectionPoint injectionPoint, int n) {
        if (InjectionPoint$Shift.lIlIllllIlI(injectionPoint)) {
            throw new IllegalArgumentException("Must supply an input injection point for SHIFT");
        }
        this.input = injectionPoint;
        this.shift = n;
    }

    @Override
    public String toString() {
        return String.valueOf(new StringBuilder().append("InjectionPoint(").append(this.getClass().getSimpleName()).append(")[").append(this.input).append("]"));
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        boolean bl;
        List list;
        if (InjectionPoint$Shift.lIlIllllIll(collection instanceof List)) {
            list = (List)collection;
            "".length();
            if (-" ".length() > -" ".length()) {
                return ((0x81 ^ 0xC2) & ~(0xE5 ^ 0xA6)) != 0;
            }
        } else {
            list = new ArrayList<AbstractInsnNode>(collection);
        }
        List list2 = list;
        this.input.find(string, insnList, collection);
        "".length();
        int n = 0;
        while (InjectionPoint$Shift.lIlIlllllII(n, list2.size())) {
            list2.set(n, insnList.get(insnList.indexOf((AbstractInsnNode)list2.get(n)) + this.shift));
            "".length();
            ++n;
            "".length();
            if ((0xB6 ^ 0x8E ^ (0x83 ^ 0xBF)) != 0) continue;
            return ((0x3E ^ 0x6E ^ (0x70 ^ 0xA)) & (0xFF ^ 0xAF ^ (0xFE ^ 0x84) ^ -" ".length())) != 0;
        }
        if (InjectionPoint$Shift.lIlIlllllIl(collection, list2)) {
            collection.clear();
            collection.addAll(list2);
            "".length();
        }
        if (InjectionPoint$Shift.lIlIllllllI(collection.size())) {
            bl = true;
            "".length();
            if ("  ".length() == (107 + 141 - 171 + 98 ^ 158 + 91 - 136 + 58)) {
                return ((0x24 ^ 0x66 ^ (0xC8 ^ 0xA9)) & (48 + 13 - -27 + 81 ^ 0 + 104 - 18 + 52 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean lIlIlllllII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIlllllIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIlIllllIlI(Object object) {
        return object == null;
    }

    private static boolean lIlIllllIll(int n) {
        return n != 0;
    }

    private static boolean lIlIllllllI(int n) {
        return n > 0;
    }
}

