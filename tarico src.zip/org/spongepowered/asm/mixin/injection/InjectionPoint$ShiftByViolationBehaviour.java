/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection;

enum InjectionPoint$ShiftByViolationBehaviour {
    IGNORE,
    WARN,
    ERROR;

}

