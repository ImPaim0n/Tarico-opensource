/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection;

import java.util.Collection;
import java.util.LinkedHashSet;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$CompositeInjectionPoint;

final class InjectionPoint$Union
extends InjectionPoint$CompositeInjectionPoint {
    public InjectionPoint$Union(InjectionPoint ... injectionPointArray) {
        super(injectionPointArray);
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        boolean bl;
        LinkedHashSet<AbstractInsnNode> linkedHashSet = new LinkedHashSet<AbstractInsnNode>();
        int n = 0;
        while (InjectionPoint$Union.lIIlllllllI(n, this.components.length)) {
            this.components[n].find(string, insnList, linkedHashSet);
            "".length();
            ++n;
            "".length();
            if (null == null) continue;
            return ((0x37 ^ 0xF) & ~(0x6D ^ 0x55)) != 0;
        }
        collection.addAll(linkedHashSet);
        "".length();
        if (InjectionPoint$Union.lIIllllllll(linkedHashSet.size())) {
            bl = true;
            "".length();
            if ("  ".length() < 0) {
                return ((0xE0 ^ 0xB1) & ~(0x53 ^ 2)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean lIIlllllllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIllllllll(int n) {
        return n > 0;
    }
}

