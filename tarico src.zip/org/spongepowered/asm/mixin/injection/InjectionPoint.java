/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 *  org.apache.logging.log4j.LogManager
 */
package org.spongepowered.asm.mixin.injection;

import com.google.common.collect.ImmutableList;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At$Shift;
import org.spongepowered.asm.mixin.injection.IInjectionPointContext;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.InjectionPoint$Intersection;
import org.spongepowered.asm.mixin.injection.InjectionPoint$Selector;
import org.spongepowered.asm.mixin.injection.InjectionPoint$Shift;
import org.spongepowered.asm.mixin.injection.InjectionPoint$ShiftByViolationBehaviour;
import org.spongepowered.asm.mixin.injection.InjectionPoint$Union;
import org.spongepowered.asm.mixin.injection.modify.AfterStoreLocal;
import org.spongepowered.asm.mixin.injection.modify.BeforeLoadLocal;
import org.spongepowered.asm.mixin.injection.points.AfterInvoke;
import org.spongepowered.asm.mixin.injection.points.BeforeConstant;
import org.spongepowered.asm.mixin.injection.points.BeforeFieldAccess;
import org.spongepowered.asm.mixin.injection.points.BeforeFinalReturn;
import org.spongepowered.asm.mixin.injection.points.BeforeInvoke;
import org.spongepowered.asm.mixin.injection.points.BeforeNew;
import org.spongepowered.asm.mixin.injection.points.BeforeReturn;
import org.spongepowered.asm.mixin.injection.points.BeforeStringInvoke;
import org.spongepowered.asm.mixin.injection.points.JumpInsnPoint;
import org.spongepowered.asm.mixin.injection.points.MethodHead;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

public abstract class InjectionPoint {
    public static final int DEFAULT_ALLOWED_SHIFT_BY;
    public static final int MAX_ALLOWED_SHIFT_BY;
    private static Map<String, Class<? extends InjectionPoint>> types;
    private final String slice;
    private final InjectionPoint$Selector selector;
    private final String id;

    protected InjectionPoint() {
        this("", InjectionPoint$Selector.DEFAULT, null);
    }

    protected InjectionPoint(InjectionPointData injectionPointData) {
        this(injectionPointData.getSlice(), injectionPointData.getSelector(), injectionPointData.getId());
    }

    public InjectionPoint(String string, InjectionPoint$Selector injectionPoint$Selector, String string2) {
        this.slice = string;
        this.selector = injectionPoint$Selector;
        this.id = string2;
    }

    public String getSlice() {
        return this.slice;
    }

    public InjectionPoint$Selector getSelector() {
        return this.selector;
    }

    public String getId() {
        return this.id;
    }

    public boolean checkPriority(int n, int n2) {
        boolean bl;
        if (InjectionPoint.lIlIIlIlIlI(n, n2)) {
            bl = true;
            "".length();
            if (-" ".length() > 0) {
                return ((0xA6 ^ 0x8B) & ~(0x6E ^ 0x43)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public abstract boolean find(String var1, InsnList var2, Collection<AbstractInsnNode> var3);

    public String toString() {
        return String.format("@At(\"%s\")", this.getAtCode());
    }

    protected static AbstractInsnNode nextNode(InsnList insnList, AbstractInsnNode abstractInsnNode) {
        int n = insnList.indexOf(abstractInsnNode) + 1;
        if (InjectionPoint.lIlIIlIlIll(n) && InjectionPoint.lIlIIlIlIlI(n, insnList.size())) {
            return insnList.get(n);
        }
        return abstractInsnNode;
    }

    public static InjectionPoint and(InjectionPoint ... injectionPointArray) {
        return new InjectionPoint$Intersection(injectionPointArray);
    }

    public static InjectionPoint or(InjectionPoint ... injectionPointArray) {
        return new InjectionPoint$Union(injectionPointArray);
    }

    public static InjectionPoint after(InjectionPoint injectionPoint) {
        return new InjectionPoint$Shift(injectionPoint, 1);
    }

    public static InjectionPoint before(InjectionPoint injectionPoint) {
        return new InjectionPoint$Shift(injectionPoint, -1);
    }

    public static InjectionPoint shift(InjectionPoint injectionPoint, int n) {
        return new InjectionPoint$Shift(injectionPoint, n);
    }

    public static List<InjectionPoint> parse(IInjectionPointContext iInjectionPointContext, List<AnnotationNode> list) {
        return InjectionPoint.parse(iInjectionPointContext.getContext(), iInjectionPointContext.getMethod(), iInjectionPointContext.getAnnotation(), list);
    }

    public static List<InjectionPoint> parse(IMixinContext iMixinContext, MethodNode methodNode, AnnotationNode annotationNode, List<AnnotationNode> list) {
        ImmutableList.Builder builder = ImmutableList.builder();
        Iterator<AnnotationNode> iterator = list.iterator();
        while (InjectionPoint.lIlIIlIllII(iterator.hasNext() ? 1 : 0)) {
            AnnotationNode annotationNode2 = iterator.next();
            InjectionPoint injectionPoint = InjectionPoint.parse(iMixinContext, methodNode, annotationNode, annotationNode2);
            if (InjectionPoint.lIlIIlIllIl(injectionPoint)) {
                builder.add((Object)injectionPoint);
                "".length();
            }
            "".length();
            if (((0x81 ^ 0xA1) & ~(0x1E ^ 0x3E)) == 0) continue;
            return null;
        }
        return builder.build();
    }

    public static InjectionPoint parse(IInjectionPointContext iInjectionPointContext, At at) {
        return InjectionPoint.parse(iInjectionPointContext.getContext(), iInjectionPointContext.getMethod(), iInjectionPointContext.getAnnotation(), at.value(), at.shift(), at.by(), Arrays.asList(at.args()), at.target(), at.slice(), at.ordinal(), at.opcode(), at.id());
    }

    public static InjectionPoint parse(IMixinContext iMixinContext, MethodNode methodNode, AnnotationNode annotationNode, At at) {
        return InjectionPoint.parse(iMixinContext, methodNode, annotationNode, at.value(), at.shift(), at.by(), Arrays.asList(at.args()), at.target(), at.slice(), at.ordinal(), at.opcode(), at.id());
    }

    public static InjectionPoint parse(IInjectionPointContext iInjectionPointContext, AnnotationNode annotationNode) {
        return InjectionPoint.parse(iInjectionPointContext.getContext(), iInjectionPointContext.getMethod(), iInjectionPointContext.getAnnotation(), annotationNode);
    }

    public static InjectionPoint parse(IMixinContext iMixinContext, MethodNode methodNode, AnnotationNode annotationNode, AnnotationNode annotationNode2) {
        String string = (String)Annotations.getValue(annotationNode2, "value");
        List list = (List)Annotations.getValue(annotationNode2, "args");
        String string2 = Annotations.getValue(annotationNode2, "target", "");
        String string3 = Annotations.getValue(annotationNode2, "slice", "");
        At$Shift at$Shift = Annotations.getValue(annotationNode2, "shift", At$Shift.class, At$Shift.NONE);
        int n = Annotations.getValue(annotationNode2, "by", 0);
        int n2 = Annotations.getValue(annotationNode2, "ordinal", -1);
        int n3 = Annotations.getValue(annotationNode2, "opcode", 0);
        String string4 = (String)Annotations.getValue(annotationNode2, "id");
        if (InjectionPoint.lIlIIlIlllI(list)) {
            list = ImmutableList.of();
        }
        return InjectionPoint.parse(iMixinContext, methodNode, annotationNode, string, at$Shift, n, list, string2, string3, n2, n3, string4);
    }

    public static InjectionPoint parse(IMixinContext iMixinContext, MethodNode methodNode, AnnotationNode annotationNode, String string, At$Shift at$Shift, int n, List<String> list, String string2, String string3, int n2, int n3, String string4) {
        InjectionPointData injectionPointData = new InjectionPointData(iMixinContext, methodNode, annotationNode, string, list, string2, string3, n2, n3, string4);
        Class<? extends InjectionPoint> clazz = InjectionPoint.findClass(iMixinContext, injectionPointData);
        InjectionPoint injectionPoint = InjectionPoint.create(iMixinContext, injectionPointData, clazz);
        return InjectionPoint.shift(iMixinContext, methodNode, annotationNode, injectionPoint, at$Shift, n);
    }

    private static Class<? extends InjectionPoint> findClass(IMixinContext iMixinContext, InjectionPointData injectionPointData) {
        Class<InjectionPoint> clazz;
        block3: {
            block4: {
                String string = injectionPointData.getType();
                clazz = types.get(string);
                if (!InjectionPoint.lIlIIlIlllI(clazz)) break block3;
                if (!InjectionPoint.lIlIIlIllII(string.matches("^([A-Za-z_][A-Za-z0-9_]*\\.)+[A-Za-z_][A-Za-z0-9_]*$") ? 1 : 0)) break block4;
                try {
                    clazz = Class.forName(string);
                    types.put(string, clazz);
                    "".length();
                    "".length();
                }
                catch (Exception exception) {
                    throw new InvalidInjectionException(iMixinContext, String.valueOf(new StringBuilder().append(injectionPointData).append(" could not be loaded or is not a valid InjectionPoint")), (Throwable)exception);
                }
                if ((0xF ^ 0xB) <= 0) {
                    return null;
                }
                break block3;
            }
            throw new InvalidInjectionException(iMixinContext, String.valueOf(new StringBuilder().append(injectionPointData).append(" is not a valid injection point specifier")));
        }
        return clazz;
    }

    private static InjectionPoint create(IMixinContext iMixinContext, InjectionPointData injectionPointData, Class<? extends InjectionPoint> clazz) {
        Constructor<? extends InjectionPoint> constructor = null;
        try {
            constructor = clazz.getDeclaredConstructor(InjectionPointData.class);
            constructor.setAccessible(true);
            "".length();
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new InvalidInjectionException(iMixinContext, String.valueOf(new StringBuilder().append(clazz.getName()).append(" must contain a constructor which accepts an InjectionPointData")), (Throwable)noSuchMethodException);
        }
        if (" ".length() != " ".length()) {
            return null;
        }
        InjectionPoint injectionPoint = null;
        try {
            injectionPoint = constructor.newInstance(injectionPointData);
            "".length();
        }
        catch (Exception exception) {
            throw new InvalidInjectionException(iMixinContext, String.valueOf(new StringBuilder().append("Error whilst instancing injection point ").append(clazz.getName()).append(" for ").append(injectionPointData.getAt())), (Throwable)exception);
        }
        if ((0x82 ^ 0x87) <= 0) {
            return null;
        }
        return injectionPoint;
    }

    private static InjectionPoint shift(IMixinContext iMixinContext, MethodNode methodNode, AnnotationNode annotationNode, InjectionPoint injectionPoint, At$Shift at$Shift, int n) {
        if (InjectionPoint.lIlIIlIllIl(injectionPoint)) {
            if (InjectionPoint.lIlIIlIllll((Object)at$Shift, (Object)At$Shift.BEFORE)) {
                return InjectionPoint.before(injectionPoint);
            }
            if (InjectionPoint.lIlIIlIllll((Object)at$Shift, (Object)At$Shift.AFTER)) {
                return InjectionPoint.after(injectionPoint);
            }
            if (InjectionPoint.lIlIIlIllll((Object)at$Shift, (Object)At$Shift.BY)) {
                InjectionPoint.validateByValue(iMixinContext, methodNode, annotationNode, injectionPoint, n);
                return InjectionPoint.shift(injectionPoint, n);
            }
        }
        return injectionPoint;
    }

    private static void validateByValue(IMixinContext iMixinContext, MethodNode methodNode, AnnotationNode annotationNode, InjectionPoint injectionPoint, int n) {
        MixinEnvironment mixinEnvironment = iMixinContext.getMixin().getConfig().getEnvironment();
        InjectionPoint$ShiftByViolationBehaviour injectionPoint$ShiftByViolationBehaviour = mixinEnvironment.getOption(MixinEnvironment$Option.SHIFT_BY_VIOLATION_BEHAVIOUR, InjectionPoint$ShiftByViolationBehaviour.WARN);
        if (InjectionPoint.lIlIIlIllll((Object)injectionPoint$ShiftByViolationBehaviour, (Object)InjectionPoint$ShiftByViolationBehaviour.IGNORE)) {
            return;
        }
        int n2 = 0;
        if (InjectionPoint.lIlIIlIllII(iMixinContext instanceof MixinTargetContext)) {
            n2 = ((MixinTargetContext)iMixinContext).getMaxShiftByValue();
        }
        if (InjectionPoint.lIlIIllIIII(n, n2)) {
            return;
        }
        String string = String.format("@%s(%s) Shift.BY=%d on %s::%s exceeds the maximum allowed value %d.", Bytecode.getSimpleName(annotationNode), injectionPoint, n, iMixinContext, methodNode.name, n2);
        if (InjectionPoint.lIlIIlIllll((Object)injectionPoint$ShiftByViolationBehaviour, (Object)InjectionPoint$ShiftByViolationBehaviour.WARN)) {
            LogManager.getLogger((String)"mixin").warn("{} Increase the value of maxShiftBy to suppress this warning.", new Object[]{string});
            return;
        }
        throw new InvalidInjectionException(iMixinContext, string);
    }

    protected String getAtCode() {
        String string;
        InjectionPoint$AtCode injectionPoint$AtCode = this.getClass().getAnnotation(InjectionPoint$AtCode.class);
        if (InjectionPoint.lIlIIlIlllI(injectionPoint$AtCode)) {
            string = this.getClass().getName();
            "".length();
            if (-" ".length() >= "   ".length()) {
                return null;
            }
        } else {
            string = injectionPoint$AtCode.value();
        }
        return string;
    }

    public static void register(Class<? extends InjectionPoint> clazz) {
        InjectionPoint$AtCode injectionPoint$AtCode = clazz.getAnnotation(InjectionPoint$AtCode.class);
        if (InjectionPoint.lIlIIlIlllI(injectionPoint$AtCode)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Injection point class ").append(clazz).append(" is not annotated with @AtCode")));
        }
        Class<? extends InjectionPoint> clazz2 = types.get(injectionPoint$AtCode.value());
        if (InjectionPoint.lIlIIlIllIl(clazz2) && InjectionPoint.lIlIIllIIIl(clazz2.equals(clazz) ? 1 : 0)) {
            LogManager.getLogger((String)"mixin").debug("Overriding InjectionPoint {} with {} (previously {})", new Object[]{injectionPoint$AtCode.value(), clazz.getName(), clazz2.getName()});
        }
        types.put(injectionPoint$AtCode.value(), clazz);
        "".length();
    }

    static {
        MAX_ALLOWED_SHIFT_BY = 0;
        DEFAULT_ALLOWED_SHIFT_BY = 0;
        types = new HashMap<String, Class<? extends InjectionPoint>>();
        InjectionPoint.register(BeforeFieldAccess.class);
        InjectionPoint.register(BeforeInvoke.class);
        InjectionPoint.register(BeforeNew.class);
        InjectionPoint.register(BeforeReturn.class);
        InjectionPoint.register(BeforeStringInvoke.class);
        InjectionPoint.register(JumpInsnPoint.class);
        InjectionPoint.register(MethodHead.class);
        InjectionPoint.register(AfterInvoke.class);
        InjectionPoint.register(BeforeLoadLocal.class);
        InjectionPoint.register(AfterStoreLocal.class);
        InjectionPoint.register(BeforeFinalReturn.class);
        InjectionPoint.register(BeforeConstant.class);
    }

    private static boolean lIlIIlIlIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIllIIII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIlIIlIllIl(Object object) {
        return object != null;
    }

    private static boolean lIlIIlIllll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIlIIlIlllI(Object object) {
        return object == null;
    }

    private static boolean lIlIIlIllII(int n) {
        return n != 0;
    }

    private static boolean lIlIIllIIIl(int n) {
        return n == 0;
    }

    private static boolean lIlIIlIlIll(int n) {
        return n > 0;
    }
}

