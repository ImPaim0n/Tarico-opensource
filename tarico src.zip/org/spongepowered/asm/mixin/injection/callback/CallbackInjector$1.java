/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.callback;

import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

class CallbackInjector$1 {
    static final /* synthetic */ int[] $SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture;

    static {
        block6: {
            block5: {
                $SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture = new int[LocalCapture.values().length];
                try {
                    CallbackInjector$1.$SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture[LocalCapture.CAPTURE_FAILEXCEPTION.ordinal()] = 1;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if ("  ".length() <= "  ".length()) break block5;
                break block6;
            }
            try {
                CallbackInjector$1.$SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture[LocalCapture.CAPTURE_FAILSOFT.ordinal()] = 2;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if (" ".length() < 0) {
                // empty if block
            }
        }
    }
}

