/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.callback;

import java.util.ArrayList;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInjector;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

class CallbackInjector$Callback
extends InsnList {
    private final MethodNode handler;
    private final AbstractInsnNode head;
    final Target target;
    final InjectionNodes$InjectionNode node;
    final LocalVariableNode[] locals;
    final Type[] localTypes;
    final int frameSize;
    final int extraArgs;
    final boolean canCaptureLocals;
    final boolean isAtReturn;
    final String desc;
    final String descl;
    final String[] argNames;
    int ctor;
    int invoke;
    private int marshalVar = -1;
    private boolean captureArgs = true;
    final /* synthetic */ CallbackInjector this$0;

    CallbackInjector$Callback(CallbackInjector callbackInjector, MethodNode methodNode, Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode, LocalVariableNode[] localVariableNodeArray, boolean bl) {
        int n;
        boolean bl2;
        boolean bl3;
        String[] stringArray;
        boolean bl4;
        Type[] typeArray;
        this.this$0 = callbackInjector;
        this.handler = methodNode;
        this.target = target;
        this.head = target.insns.getFirst();
        this.node = injectionNodes$InjectionNode;
        this.locals = localVariableNodeArray;
        if (CallbackInjector$Callback.lIIIlIIIIl(localVariableNodeArray)) {
            typeArray = new Type[localVariableNodeArray.length];
            "".length();
            if (null != null) {
                throw null;
            }
        } else {
            typeArray = null;
        }
        this.localTypes = typeArray;
        Type[] typeArray2 = target.arguments;
        if (CallbackInjector$Callback.lIIIlIIIlI(callbackInjector.isStatic() ? 1 : 0)) {
            bl4 = true;
            "".length();
            if ("  ".length() <= 0) {
                throw null;
            }
        } else {
            bl4 = false;
        }
        this.frameSize = Bytecode.getFirstNonArgLocalIndex(typeArray2, bl4);
        ArrayList<String> arrayList = null;
        if (CallbackInjector$Callback.lIIIlIIIIl(localVariableNodeArray)) {
            int n2;
            if (CallbackInjector$Callback.lIIIlIIIll(callbackInjector.isStatic() ? 1 : 0)) {
                n2 = 0;
                "".length();
                if (((0xAA ^ 0xBB) & ~(0xAC ^ 0xBD)) != 0) {
                    throw null;
                }
            } else {
                n2 = 1;
            }
            int n3 = n2;
            arrayList = new ArrayList<String>();
            int n4 = 0;
            while (CallbackInjector$Callback.lIIIlIIlII(n4, localVariableNodeArray.length)) {
                if (CallbackInjector$Callback.lIIIlIIlIl(n4, this.frameSize)) {
                    String string;
                    if (CallbackInjector$Callback.lIIIlIIllI(target.returnType, Type.VOID_TYPE)) {
                        string = "ci";
                        "".length();
                        if (((0x9F ^ 0x86) & ~(0x65 ^ 0x7C)) != 0) {
                            throw null;
                        }
                    } else {
                        string = "cir";
                    }
                    arrayList.add(string);
                    "".length();
                }
                if (CallbackInjector$Callback.lIIIlIIlll(n4, localVariableNodeArray.length) && CallbackInjector$Callback.lIIIlIIIIl(localVariableNodeArray[n4])) {
                    this.localTypes[n4] = Type.getType(localVariableNodeArray[n4].desc);
                    if (CallbackInjector$Callback.lIIIlIlIII(n4, n3)) {
                        arrayList.add(CallbackInjector.meltSnowman(n4, localVariableNodeArray[n4].name));
                        "".length();
                    }
                }
                ++n4;
                "".length();
                if (((0xB2 ^ 0x81) & ~(0x9F ^ 0xAC)) == 0) continue;
                throw null;
            }
        }
        this.extraArgs = Math.max(0, Bytecode.getFirstNonArgLocalIndex(this.handler) - (this.frameSize + 1));
        if (CallbackInjector$Callback.lIIIlIIIIl(arrayList)) {
            stringArray = arrayList.toArray(new String[arrayList.size()]);
            "".length();
            if (-(0x63 ^ 0x7C ^ (0x7B ^ 0x61)) >= 0) {
                throw null;
            }
        } else {
            stringArray = this.argNames = null;
        }
        if (CallbackInjector$Callback.lIIIlIIIll(bl ? 1 : 0) && CallbackInjector$Callback.lIIIlIIIIl(localVariableNodeArray) && CallbackInjector$Callback.lIIIlIlIIl(localVariableNodeArray.length, this.frameSize)) {
            bl3 = true;
            "".length();
            if (" ".length() >= "   ".length()) {
                throw null;
            }
        } else {
            bl3 = this.canCaptureLocals = false;
        }
        if (CallbackInjector$Callback.lIIIlIIIll(this.node.getCurrentTarget() instanceof InsnNode) && CallbackInjector$Callback.lIIIlIIIll(this.isValueReturnOpcode(this.node.getCurrentTarget().getOpcode()) ? 1 : 0)) {
            bl2 = true;
            "".length();
            if (null != null) {
                throw null;
            }
        } else {
            bl2 = false;
        }
        this.isAtReturn = bl2;
        this.desc = target.getCallbackDescriptor(this.localTypes, target.arguments);
        this.descl = target.getCallbackDescriptor(true, this.localTypes, target.arguments, this.frameSize, this.extraArgs);
        int n5 = target.arguments.length;
        if (CallbackInjector$Callback.lIIIlIIIll(this.canCaptureLocals ? 1 : 0)) {
            n = this.localTypes.length - this.frameSize;
            "".length();
            if (null != null) {
                throw null;
            }
        } else {
            n = 0;
        }
        this.invoke = n5 + n;
    }

    private boolean isValueReturnOpcode(int n) {
        boolean bl;
        if (CallbackInjector$Callback.lIIIlIlIII(n, 172) && CallbackInjector$Callback.lIIIlIIlll(n, 177)) {
            bl = true;
            "".length();
            if (-" ".length() >= "   ".length()) {
                return ((0x38 ^ 0x37) & ~(0x37 ^ 0x38)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    String getDescriptor() {
        String string;
        if (CallbackInjector$Callback.lIIIlIIIll(this.canCaptureLocals ? 1 : 0)) {
            string = this.descl;
            "".length();
            if ("  ".length() == "   ".length()) {
                return null;
            }
        } else {
            string = this.desc;
        }
        return string;
    }

    String getDescriptorWithAllLocals() {
        return this.target.getCallbackDescriptor(true, this.localTypes, this.target.arguments, this.frameSize, Short.MAX_VALUE);
    }

    String getCallbackInfoConstructorDescriptor() {
        String string;
        if (CallbackInjector$Callback.lIIIlIIIll(this.isAtReturn ? 1 : 0)) {
            string = CallbackInfo.getConstructorDescriptor(this.target.returnType);
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string = CallbackInfo.getConstructorDescriptor();
        }
        return string;
    }

    void add(AbstractInsnNode abstractInsnNode, boolean bl, boolean bl2) {
        this.add(abstractInsnNode, bl, bl2, false);
    }

    void add(AbstractInsnNode abstractInsnNode, boolean bl, boolean bl2, boolean bl3) {
        int n;
        int n2;
        if (CallbackInjector$Callback.lIIIlIIIll(bl3 ? 1 : 0)) {
            this.target.insns.insertBefore(this.head, abstractInsnNode);
            "".length();
            if (-(0xFC ^ 0x84 ^ (0x5D ^ 0x21)) > 0) {
                return;
            }
        } else {
            this.add(abstractInsnNode);
        }
        if (CallbackInjector$Callback.lIIIlIIIll(bl ? 1 : 0)) {
            n2 = 1;
            "".length();
            if (-(0xB ^ 0xF) >= 0) {
                return;
            }
        } else {
            n2 = 0;
        }
        this.ctor += n2;
        if (CallbackInjector$Callback.lIIIlIIIll(bl2 ? 1 : 0)) {
            n = 1;
            "".length();
            if ("   ".length() == "  ".length()) {
                return;
            }
        } else {
            n = 0;
        }
        this.invoke += n;
    }

    void inject() {
        this.target.insertBefore(this.node, (InsnList)this);
        this.target.addToStack(Math.max(this.invoke, this.ctor));
    }

    boolean checkDescriptor(String string) {
        Type[] typeArray;
        if (CallbackInjector$Callback.lIIIlIIIll(this.getDescriptor().equals(string) ? 1 : 0)) {
            return true;
        }
        if (CallbackInjector$Callback.lIIIlIIIll(this.target.getSimpleCallbackDescriptor().equals(string) ? 1 : 0) && CallbackInjector$Callback.lIIIlIIIlI(this.canCaptureLocals ? 1 : 0)) {
            this.captureArgs = false;
            return true;
        }
        Type[] typeArray2 = Type.getArgumentTypes(string);
        if (CallbackInjector$Callback.lIIIlIlIlI(typeArray2.length, (typeArray = Type.getArgumentTypes(this.descl)).length)) {
            return false;
        }
        int n = 0;
        while (CallbackInjector$Callback.lIIIlIIlll(n, typeArray.length)) {
            Type type = typeArray2[n];
            if (CallbackInjector$Callback.lIIIlIIIll(type.equals(typeArray[n]) ? 1 : 0)) {
                "".length();
                if (" ".length() == "   ".length()) {
                    return ((0x4B ^ 0x5C) & ~(0x48 ^ 0x5F)) != 0;
                }
            } else {
                if (CallbackInjector$Callback.lIIIlIIlIl(type.getSort(), 9)) {
                    return false;
                }
                if (CallbackInjector$Callback.lIIIlIlIll(Annotations.getInvisibleParameter(this.handler, Coerce.class, n))) {
                    return false;
                }
                if (CallbackInjector$Callback.lIIIlIIIlI(Injector.canCoerce(typeArray2[n], typeArray[n]) ? 1 : 0)) {
                    return false;
                }
            }
            ++n;
            "".length();
            if ("   ".length() >= 0) continue;
            return ((0xB3 ^ 0x81 ^ (0x88 ^ 0xB4)) & (41 + 154 - 146 + 115 ^ 18 + 42 - 45 + 155 ^ -" ".length())) != 0;
        }
        return true;
    }

    boolean captureArgs() {
        return this.captureArgs;
    }

    int marshalVar() {
        if (CallbackInjector$Callback.lIIIlIllII(this.marshalVar)) {
            this.marshalVar = this.target.allocateLocal();
        }
        return this.marshalVar;
    }

    private static boolean lIIIlIIlIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIlIII(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIlIIlll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIIlII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIlIlIIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlIIIIl(Object object) {
        return object != null;
    }

    private static boolean lIIIlIIllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIlIlIll(Object object) {
        return object == null;
    }

    private static boolean lIIIlIIIll(int n) {
        return n != 0;
    }

    private static boolean lIIIlIIIlI(int n) {
        return n == 0;
    }

    private static boolean lIIIlIllII(int n) {
        return n < 0;
    }

    private static boolean lIIIlIlIlI(int n, int n2) {
        return n != n2;
    }
}

