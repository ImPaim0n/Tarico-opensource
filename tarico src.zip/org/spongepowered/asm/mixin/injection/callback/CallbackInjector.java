/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.mixin.injection.callback;

import com.google.common.base.Strings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.LdcInsnNode;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.Surrogate;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInjector$1;
import org.spongepowered.asm.mixin.injection.callback.CallbackInjector$Callback;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.points.BeforeReturn;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InjectionError;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.Locals;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.SignaturePrinter;

public class CallbackInjector
extends Injector {
    private final boolean cancellable;
    private final LocalCapture localCapture;
    private final String identifier;
    private final Map<Integer, String> ids = new HashMap<Integer, String>();
    private int totalInjections = 0;
    private int callbackInfoVar = -1;
    private String lastId;
    private String lastDesc;
    private Target lastTarget;
    private String callbackInfoClass;

    public CallbackInjector(InjectionInfo injectionInfo, boolean bl, LocalCapture localCapture, String string) {
        super(injectionInfo);
        this.cancellable = bl;
        this.localCapture = localCapture;
        this.identifier = string;
    }

    @Override
    protected void sanityCheck(Target target, List<InjectionPoint> list) {
        super.sanityCheck(target, list);
        if (CallbackInjector.lIlll(target.isStatic ? 1 : 0, this.isStatic ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("'static' modifier of callback method does not match target in ").append(this)));
        }
        if (CallbackInjector.llIII("<init>".equals(target.method.name) ? 1 : 0)) {
            Iterator<InjectionPoint> iterator = list.iterator();
            while (CallbackInjector.llIII(iterator.hasNext() ? 1 : 0)) {
                InjectionPoint injectionPoint = iterator.next();
                if (CallbackInjector.llIIl(injectionPoint.getClass().equals(BeforeReturn.class) ? 1 : 0)) {
                    throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Found injection point type ").append(injectionPoint.getClass().getSimpleName()).append(" targetting a ctor in ").append(this).append(". Only RETURN allowed for a ctor target")));
                }
                "".length();
                if (null == null) continue;
                return;
            }
        }
    }

    @Override
    protected void addTargetNode(Target target, List<InjectionNodes$InjectionNode> list, AbstractInsnNode abstractInsnNode, Set<InjectionPoint> set) {
        InjectionNodes$InjectionNode injectionNodes$InjectionNode = target.addInjectionNode(abstractInsnNode);
        Iterator<InjectionPoint> iterator = set.iterator();
        while (CallbackInjector.llIII(iterator.hasNext() ? 1 : 0)) {
            InjectionPoint injectionPoint = iterator.next();
            String string = injectionPoint.getId();
            if (CallbackInjector.llIII(Strings.isNullOrEmpty((String)string) ? 1 : 0)) {
                "".length();
                if (-(0x9A ^ 0x9E) <= 0) continue;
                return;
            }
            String string2 = this.ids.get(injectionNodes$InjectionNode.getId());
            if (CallbackInjector.llIlI(string2) && CallbackInjector.llIIl(string2.equals(string) ? 1 : 0)) {
                Injector.logger.warn("Conflicting id for {} insn in {}, found id {} on {}, previously defined as {}", new Object[]{Bytecode.getOpcodeName(abstractInsnNode), target.toString(), string, this.info, string2});
                "".length();
                if (null == null) break;
                return;
            }
            this.ids.put(injectionNodes$InjectionNode.getId(), string);
            "".length();
            "".length();
            if (((0x42 ^ 0x44 ^ (0x4E ^ 0x57)) & (0x56 ^ 0x14 ^ (0x13 ^ 0x4E) ^ -" ".length())) < "   ".length()) continue;
            return;
        }
        list.add(injectionNodes$InjectionNode);
        "".length();
        ++this.totalInjections;
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        LocalVariableNode[] localVariableNodeArray = null;
        if (!CallbackInjector.llIIl(this.localCapture.isCaptureLocals() ? 1 : 0) || CallbackInjector.llIII(this.localCapture.isPrintLocals() ? 1 : 0)) {
            localVariableNodeArray = Locals.getLocalsAt(this.classNode, target.method, injectionNodes$InjectionNode.getCurrentTarget());
        }
        this.inject(new CallbackInjector$Callback(this, this.methodNode, target, injectionNodes$InjectionNode, localVariableNodeArray, this.localCapture.isCaptureLocals()));
    }

    private void inject(CallbackInjector$Callback callbackInjector$Callback) {
        if (CallbackInjector.llIII(this.localCapture.isPrintLocals() ? 1 : 0)) {
            this.printLocals(callbackInjector$Callback);
            this.info.addCallbackInvocation(this.methodNode);
            return;
        }
        MethodNode methodNode = this.methodNode;
        if (CallbackInjector.llIIl(callbackInjector$Callback.checkDescriptor(this.methodNode.desc) ? 1 : 0)) {
            if (CallbackInjector.llIll(this.info.getTargets().size(), 1)) {
                return;
            }
            if (CallbackInjector.llIII(callbackInjector$Callback.canCaptureLocals ? 1 : 0)) {
                MethodNode methodNode2 = Bytecode.findMethod(this.classNode, this.methodNode.name, callbackInjector$Callback.getDescriptor());
                if (CallbackInjector.llIlI(methodNode2) && CallbackInjector.llIlI(Annotations.getVisible(methodNode2, Surrogate.class))) {
                    methodNode = methodNode2;
                    "".length();
                    if ("   ".length() != "   ".length()) {
                        return;
                    }
                } else {
                    String string = this.generateBadLVTMessage(callbackInjector$Callback);
                    switch (CallbackInjector$1.$SwitchMap$org$spongepowered$asm$mixin$injection$callback$LocalCapture[this.localCapture.ordinal()]) {
                        case 1: {
                            Injector.logger.error("Injection error: {}", new Object[]{string});
                            methodNode = this.generateErrorMethod(callbackInjector$Callback, "org/spongepowered/asm/mixin/injection/throwables/InjectionError", string);
                            "".length();
                            if ((0x68 ^ 0x65 ^ (0x6D ^ 0x64)) >= -" ".length()) break;
                            return;
                        }
                        case 2: {
                            Injector.logger.warn("Injection warning: {}", new Object[]{string});
                            return;
                        }
                        default: {
                            Injector.logger.error("Critical injection failure: {}", new Object[]{string});
                            throw new InjectionError(string);
                        }
                    }
                }
                "".length();
                if ("   ".length() < 0) {
                    return;
                }
            } else {
                String string = this.methodNode.desc.replace("Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;", "Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;");
                if (CallbackInjector.llIII(callbackInjector$Callback.checkDescriptor(string) ? 1 : 0)) {
                    throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Invalid descriptor on ").append(this.info).append("! CallbackInfoReturnable is required!")));
                }
                MethodNode methodNode3 = Bytecode.findMethod(this.classNode, this.methodNode.name, callbackInjector$Callback.getDescriptor());
                if (CallbackInjector.llIlI(methodNode3) && CallbackInjector.llIlI(Annotations.getVisible(methodNode3, Surrogate.class))) {
                    methodNode = methodNode3;
                    "".length();
                    if ("  ".length() < -" ".length()) {
                        return;
                    }
                } else {
                    throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Invalid descriptor on ").append(this.info).append("! Expected ").append(callbackInjector$Callback.getDescriptor()).append(" but found ").append(this.methodNode.desc)));
                }
            }
        }
        this.dupReturnValue(callbackInjector$Callback);
        if (!CallbackInjector.llIIl(this.cancellable ? 1 : 0) || CallbackInjector.llIll(this.totalInjections, 1)) {
            this.createCallbackInfo(callbackInjector$Callback, true);
        }
        this.invokeCallback(callbackInjector$Callback, methodNode);
        this.injectCancellationCode(callbackInjector$Callback);
        callbackInjector$Callback.inject();
        this.info.notifyInjected(callbackInjector$Callback.target);
    }

    private String generateBadLVTMessage(CallbackInjector$Callback callbackInjector$Callback) {
        int n = callbackInjector$Callback.target.indexOf(callbackInjector$Callback.node);
        List<String> list = CallbackInjector.summariseLocals(this.methodNode.desc, callbackInjector$Callback.target.arguments.length + 1);
        List<String> list2 = CallbackInjector.summariseLocals(callbackInjector$Callback.getDescriptorWithAllLocals(), callbackInjector$Callback.frameSize);
        return String.format("LVT in %s has incompatible changes at opcode %d in callback %s.\nExpected: %s\n   Found: %s", callbackInjector$Callback.target, n, this, list, list2);
    }

    private MethodNode generateErrorMethod(CallbackInjector$Callback callbackInjector$Callback, String string, String string2) {
        boolean bl;
        MethodNode methodNode = this.info.addMethod(this.methodNode.access, String.valueOf(new StringBuilder().append(this.methodNode.name).append("$missing")), callbackInjector$Callback.getDescriptor());
        Type[] typeArray = Type.getArgumentTypes(callbackInjector$Callback.getDescriptor());
        if (CallbackInjector.llIIl(this.isStatic ? 1 : 0)) {
            bl = true;
            "".length();
            if (" ".length() != " ".length()) {
                return null;
            }
        } else {
            bl = false;
        }
        methodNode.maxLocals = Bytecode.getFirstNonArgLocalIndex(typeArray, bl);
        methodNode.maxStack = 3;
        InsnList insnList = methodNode.instructions;
        insnList.add(new TypeInsnNode(187, string));
        insnList.add(new InsnNode(89));
        insnList.add(new LdcInsnNode(string2));
        insnList.add(new MethodInsnNode(183, string, "<init>", "(Ljava/lang/String;)V", false));
        insnList.add(new InsnNode(191));
        return methodNode;
    }

    private void printLocals(CallbackInjector$Callback callbackInjector$Callback) {
        Type[] typeArray = Type.getArgumentTypes(callbackInjector$Callback.getDescriptorWithAllLocals());
        SignaturePrinter signaturePrinter = new SignaturePrinter(callbackInjector$Callback.target.method, callbackInjector$Callback.argNames);
        SignaturePrinter signaturePrinter2 = new SignaturePrinter(this.methodNode.name, callbackInjector$Callback.target.returnType, typeArray, callbackInjector$Callback.argNames);
        signaturePrinter2.setModifiers(this.methodNode);
        PrettyPrinter prettyPrinter = new PrettyPrinter();
        prettyPrinter.kv("Target Class", this.classNode.name.replace('/', '.'));
        "".length();
        prettyPrinter.kv("Target Method", signaturePrinter);
        "".length();
        prettyPrinter.kv("Target Max LOCALS", callbackInjector$Callback.target.getMaxLocals());
        "".length();
        prettyPrinter.kv("Initial Frame Size", callbackInjector$Callback.frameSize);
        "".length();
        prettyPrinter.kv("Callback Name", this.methodNode.name);
        "".length();
        prettyPrinter.kv("Instruction", "%s %s", callbackInjector$Callback.node.getClass().getSimpleName(), Bytecode.getOpcodeName(callbackInjector$Callback.node.getCurrentTarget().getOpcode()));
        "".length();
        prettyPrinter.hr();
        "".length();
        if (CallbackInjector.llIll(callbackInjector$Callback.locals.length, callbackInjector$Callback.frameSize)) {
            prettyPrinter.add("  %s  %20s  %s", "LOCAL", "TYPE", "NAME");
            "".length();
            int n = 0;
            while (CallbackInjector.lllII(n, callbackInjector$Callback.locals.length)) {
                String string;
                String string2;
                if (CallbackInjector.lllIl(n, callbackInjector$Callback.frameSize)) {
                    string2 = ">";
                    "".length();
                    if (null != null) {
                        return;
                    }
                } else {
                    string2 = string = " ";
                }
                if (CallbackInjector.llIlI(callbackInjector$Callback.locals[n])) {
                    String string3;
                    Object[] objectArray = new Object[5];
                    objectArray[0] = string;
                    objectArray[1] = n;
                    objectArray[2] = SignaturePrinter.getTypeName(callbackInjector$Callback.localTypes[n], false);
                    objectArray[3] = CallbackInjector.meltSnowman(n, callbackInjector$Callback.locals[n].name);
                    if (CallbackInjector.llllI(n, callbackInjector$Callback.frameSize)) {
                        string3 = "<capture>";
                        "".length();
                        if ((0xCC ^ 0xAD ^ (0xF ^ 0x6A)) == 0) {
                            return;
                        }
                    } else {
                        string3 = "";
                    }
                    objectArray[4] = string3;
                    prettyPrinter.add("%s [%3d]  %20s  %-50s %s", objectArray);
                    "".length();
                    "".length();
                    if ("  ".length() < 0) {
                        return;
                    }
                } else {
                    String string4;
                    int n2;
                    if (CallbackInjector.lllll(n) && CallbackInjector.llIlI(callbackInjector$Callback.localTypes[n - 1]) && CallbackInjector.llIll(callbackInjector$Callback.localTypes[n - 1].getSize(), 1)) {
                        n2 = 1;
                        "".length();
                        if (-" ".length() > 0) {
                            return;
                        }
                    } else {
                        n2 = 0;
                    }
                    int n3 = n2;
                    Object[] objectArray = new Object[3];
                    objectArray[0] = string;
                    objectArray[1] = n;
                    if (CallbackInjector.llIII(n3)) {
                        string4 = "<top>";
                        "".length();
                        if (" ".length() > "   ".length()) {
                            return;
                        }
                    } else {
                        string4 = "-";
                    }
                    objectArray[2] = string4;
                    prettyPrinter.add("%s [%3d]  %20s", objectArray);
                    "".length();
                }
                ++n;
                "".length();
                if (null == null) continue;
                return;
            }
            prettyPrinter.hr();
            "".length();
        }
        prettyPrinter.add().add("/**").add(" * Expected callback signature").add(" * /");
        "".length();
        prettyPrinter.add("%s {", signaturePrinter2);
        "".length();
        prettyPrinter.add("    // Method body").add("}").add().print(System.err);
        "".length();
    }

    private void createCallbackInfo(CallbackInjector$Callback callbackInjector$Callback, boolean bl) {
        if (CallbackInjector.lIIIII(callbackInjector$Callback.target, this.lastTarget)) {
            this.lastId = null;
            this.lastDesc = null;
        }
        this.lastTarget = callbackInjector$Callback.target;
        String string = this.getIdentifier(callbackInjector$Callback);
        String string2 = callbackInjector$Callback.getCallbackInfoConstructorDescriptor();
        if (CallbackInjector.llIII(string.equals(this.lastId) ? 1 : 0) && CallbackInjector.llIII(string2.equals(this.lastDesc) ? 1 : 0) && CallbackInjector.llIIl(callbackInjector$Callback.isAtReturn ? 1 : 0) && CallbackInjector.llIIl(this.cancellable ? 1 : 0)) {
            return;
        }
        this.instanceCallbackInfo(callbackInjector$Callback, string, string2, bl);
    }

    private void loadOrCreateCallbackInfo(CallbackInjector$Callback callbackInjector$Callback) {
        if (!CallbackInjector.llIIl(this.cancellable ? 1 : 0) || CallbackInjector.llIll(this.totalInjections, 1)) {
            callbackInjector$Callback.add(new VarInsnNode(25, this.callbackInfoVar), false, true);
            "".length();
            if (-(0xAF ^ 0xAA) >= 0) {
                return;
            }
        } else {
            this.createCallbackInfo(callbackInjector$Callback, false);
        }
    }

    private void dupReturnValue(CallbackInjector$Callback callbackInjector$Callback) {
        if (CallbackInjector.llIIl(callbackInjector$Callback.isAtReturn ? 1 : 0)) {
            return;
        }
        callbackInjector$Callback.add(new InsnNode(89));
        callbackInjector$Callback.add(new VarInsnNode(callbackInjector$Callback.target.returnType.getOpcode(54), callbackInjector$Callback.marshalVar()));
    }

    protected void instanceCallbackInfo(CallbackInjector$Callback callbackInjector$Callback, String string, String string2, boolean bl) {
        boolean bl2;
        int n;
        boolean bl3;
        boolean bl4;
        boolean bl5;
        this.lastId = string;
        this.lastDesc = string2;
        this.callbackInfoVar = callbackInjector$Callback.marshalVar();
        this.callbackInfoClass = callbackInjector$Callback.target.getCallbackInfoClass();
        if (CallbackInjector.llIII(bl ? 1 : 0) && CallbackInjector.llIll(this.totalInjections, 1) && CallbackInjector.llIIl(callbackInjector$Callback.isAtReturn ? 1 : 0) && CallbackInjector.llIIl(this.cancellable ? 1 : 0)) {
            bl5 = true;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            bl5 = false;
        }
        boolean bl6 = bl5;
        TypeInsnNode typeInsnNode = new TypeInsnNode(187, this.callbackInfoClass);
        if (CallbackInjector.llIIl(bl ? 1 : 0)) {
            bl4 = true;
            "".length();
            if ((0x76 ^ 0x72) < -" ".length()) {
                return;
            }
        } else {
            bl4 = false;
        }
        callbackInjector$Callback.add(typeInsnNode, true, bl4, bl6);
        callbackInjector$Callback.add(new InsnNode(89), true, true, bl6);
        LdcInsnNode ldcInsnNode = new LdcInsnNode(string);
        if (CallbackInjector.llIIl(bl ? 1 : 0)) {
            bl3 = true;
            "".length();
            if ((0xF ^ 0xB) == " ".length()) {
                return;
            }
        } else {
            bl3 = false;
        }
        callbackInjector$Callback.add(ldcInsnNode, true, bl3, bl6);
        if (CallbackInjector.llIII(this.cancellable ? 1 : 0)) {
            n = 4;
            "".length();
            if ("   ".length() == " ".length()) {
                return;
            }
        } else {
            n = 3;
        }
        InsnNode insnNode = new InsnNode(n);
        if (CallbackInjector.llIIl(bl ? 1 : 0)) {
            bl2 = true;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            bl2 = false;
        }
        callbackInjector$Callback.add(insnNode, true, bl2, bl6);
        if (CallbackInjector.llIII(callbackInjector$Callback.isAtReturn ? 1 : 0)) {
            boolean bl7;
            VarInsnNode varInsnNode = new VarInsnNode(callbackInjector$Callback.target.returnType.getOpcode(21), callbackInjector$Callback.marshalVar());
            if (CallbackInjector.llIIl(bl ? 1 : 0)) {
                bl7 = true;
                "".length();
                if (" ".length() != " ".length()) {
                    return;
                }
            } else {
                bl7 = false;
            }
            callbackInjector$Callback.add(varInsnNode, true, bl7);
            callbackInjector$Callback.add(new MethodInsnNode(183, this.callbackInfoClass, "<init>", string2, false));
            "".length();
            if ((0x54 ^ 0x50) <= 0) {
                return;
            }
        } else {
            callbackInjector$Callback.add(new MethodInsnNode(183, this.callbackInfoClass, "<init>", string2, false), false, false, bl6);
        }
        if (CallbackInjector.llIII(bl ? 1 : 0)) {
            callbackInjector$Callback.target.addLocalVariable(this.callbackInfoVar, String.valueOf(new StringBuilder().append("callbackInfo").append(this.callbackInfoVar)), String.valueOf(new StringBuilder().append("L").append(this.callbackInfoClass).append(";")));
            callbackInjector$Callback.add(new VarInsnNode(58, this.callbackInfoVar), false, false, bl6);
        }
    }

    private void invokeCallback(CallbackInjector$Callback callbackInjector$Callback, MethodNode methodNode) {
        if (CallbackInjector.llIIl(this.isStatic ? 1 : 0)) {
            callbackInjector$Callback.add(new VarInsnNode(25, 0), false, true);
        }
        if (CallbackInjector.llIII(callbackInjector$Callback.captureArgs() ? 1 : 0)) {
            int n;
            Type[] typeArray = callbackInjector$Callback.target.arguments;
            if (CallbackInjector.llIII(this.isStatic ? 1 : 0)) {
                n = 0;
                "".length();
                if (((0x90 ^ 0x9F) & ~(0xA9 ^ 0xA6)) > "   ".length()) {
                    return;
                }
            } else {
                n = 1;
            }
            Bytecode.loadArgs(typeArray, callbackInjector$Callback, n, -1);
        }
        this.loadOrCreateCallbackInfo(callbackInjector$Callback);
        if (CallbackInjector.llIII(callbackInjector$Callback.canCaptureLocals ? 1 : 0)) {
            Locals.loadLocals(callbackInjector$Callback.localTypes, callbackInjector$Callback, callbackInjector$Callback.frameSize, callbackInjector$Callback.extraArgs);
        }
        this.invokeHandler(callbackInjector$Callback, methodNode);
        "".length();
    }

    private String getIdentifier(CallbackInjector$Callback callbackInjector$Callback) {
        String string;
        String string2;
        if (CallbackInjector.llIII(Strings.isNullOrEmpty((String)this.identifier) ? 1 : 0)) {
            string2 = callbackInjector$Callback.target.method.name;
            "".length();
            if (-" ".length() > ((0x2E ^ 0x60) & ~(0x6B ^ 0x25))) {
                return null;
            }
        } else {
            string2 = this.identifier;
        }
        String string3 = string2;
        String string4 = this.ids.get(callbackInjector$Callback.node.getId());
        StringBuilder stringBuilder = new StringBuilder().append(string3);
        if (CallbackInjector.llIII(Strings.isNullOrEmpty((String)string4) ? 1 : 0)) {
            string = "";
            "".length();
            if (-" ".length() >= (0x2B ^ 0x2F)) {
                return null;
            }
        } else {
            string = String.valueOf(new StringBuilder().append(":").append(string4));
        }
        return String.valueOf(stringBuilder.append(string));
    }

    protected void injectCancellationCode(CallbackInjector$Callback callbackInjector$Callback) {
        if (CallbackInjector.llIIl(this.cancellable ? 1 : 0)) {
            return;
        }
        callbackInjector$Callback.add(new VarInsnNode(25, this.callbackInfoVar));
        callbackInjector$Callback.add(new MethodInsnNode(182, this.callbackInfoClass, CallbackInfo.getIsCancelledMethodName(), CallbackInfo.getIsCancelledMethodSig(), false));
        LabelNode labelNode = new LabelNode();
        callbackInjector$Callback.add(new JumpInsnNode(153, labelNode));
        this.injectReturnCode(callbackInjector$Callback);
        callbackInjector$Callback.add(labelNode);
    }

    protected void injectReturnCode(CallbackInjector$Callback callbackInjector$Callback) {
        if (CallbackInjector.llIII(callbackInjector$Callback.target.returnType.equals(Type.VOID_TYPE) ? 1 : 0)) {
            callbackInjector$Callback.add(new InsnNode(177));
            "".length();
            if (null != null) {
                return;
            }
        } else {
            callbackInjector$Callback.add(new VarInsnNode(25, callbackInjector$Callback.marshalVar()));
            String string = CallbackInfoReturnable.getReturnAccessor(callbackInjector$Callback.target.returnType);
            String string2 = CallbackInfoReturnable.getReturnDescriptor(callbackInjector$Callback.target.returnType);
            callbackInjector$Callback.add(new MethodInsnNode(182, this.callbackInfoClass, string, string2, false));
            if (CallbackInjector.lllIl(callbackInjector$Callback.target.returnType.getSort(), 10)) {
                callbackInjector$Callback.add(new TypeInsnNode(192, callbackInjector$Callback.target.returnType.getInternalName()));
            }
            callbackInjector$Callback.add(new InsnNode(callbackInjector$Callback.target.returnType.getOpcode(172)));
        }
    }

    protected boolean isStatic() {
        return this.isStatic;
    }

    private static List<String> summariseLocals(String string, int n) {
        return CallbackInjector.summariseLocals(Type.getArgumentTypes(string), n);
    }

    private static List<String> summariseLocals(Type[] typeArray, int n) {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (CallbackInjector.llIlI(typeArray)) {
            while (CallbackInjector.lllII(n, typeArray.length)) {
                if (CallbackInjector.llIlI(typeArray[n])) {
                    arrayList.add(typeArray[n].toString());
                    "".length();
                }
                ++n;
                "".length();
                if (null == null) continue;
                return null;
            }
        }
        return arrayList;
    }

    static String meltSnowman(int n, String string) {
        String string2;
        if (CallbackInjector.llIlI(string) && CallbackInjector.lllIl(9731, string.charAt(0))) {
            string2 = String.valueOf(new StringBuilder().append("var").append(n));
            "".length();
            if (-(0x17 ^ 0x12) >= 0) {
                return null;
            }
        } else {
            string2 = string;
        }
        return string2;
    }

    private static boolean lllIl(int n, int n2) {
        return n == n2;
    }

    private static boolean llllI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lllII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlI(Object object) {
        return object != null;
    }

    private static boolean llIII(int n) {
        return n != 0;
    }

    private static boolean llIIl(int n) {
        return n == 0;
    }

    private static boolean lllll(int n) {
        return n > 0;
    }

    private static boolean lIlll(int n, int n2) {
        return n != n2;
    }
}

