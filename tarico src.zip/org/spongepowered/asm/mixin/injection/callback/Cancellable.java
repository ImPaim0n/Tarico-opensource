/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.callback;

public interface Cancellable {
    public boolean isCancellable();

    public boolean isCancelled();

    public void cancel();
}

