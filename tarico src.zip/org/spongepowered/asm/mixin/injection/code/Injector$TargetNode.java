/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.code;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;

public final class Injector$TargetNode {
    final AbstractInsnNode insn;
    final Set<InjectionPoint> nominators = new HashSet<InjectionPoint>();

    Injector$TargetNode(AbstractInsnNode abstractInsnNode) {
        this.insn = abstractInsnNode;
    }

    public AbstractInsnNode getNode() {
        return this.insn;
    }

    public Set<InjectionPoint> getNominators() {
        return Collections.unmodifiableSet(this.nominators);
    }

    public boolean equals(Object object) {
        boolean bl;
        if (!Injector$TargetNode.llllIlIl(object) || Injector$TargetNode.llllIllI(object.getClass(), Injector$TargetNode.class)) {
            return false;
        }
        if (Injector$TargetNode.llllIlll(((Injector$TargetNode)object).insn, this.insn)) {
            bl = true;
            "".length();
            if (-" ".length() == (0x5A ^ 0x5E)) {
                return ((0xA4 ^ 0x96) & ~(0xAD ^ 0x9F)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.insn.hashCode();
    }

    private static boolean llllIllI(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llllIlIl(Object object) {
        return object != null;
    }

    private static boolean llllIlll(Object object, Object object2) {
        return object == object2;
    }
}

