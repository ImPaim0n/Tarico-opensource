/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.injection.code;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.LdcInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.code.Injector$TargetNode;
import org.spongepowered.asm.mixin.injection.code.InjectorTarget;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.util.Bytecode;

public abstract class Injector {
    protected static final Logger logger = LogManager.getLogger((String)"mixin");
    protected InjectionInfo info;
    protected final ClassNode classNode;
    protected final MethodNode methodNode;
    protected final Type[] methodArgs;
    protected final Type returnType;
    protected final boolean isStatic;

    public Injector(InjectionInfo injectionInfo) {
        this(injectionInfo.getClassNode(), injectionInfo.getMethod());
        this.info = injectionInfo;
    }

    private Injector(ClassNode classNode, MethodNode methodNode) {
        this.classNode = classNode;
        this.methodNode = methodNode;
        this.methodArgs = Type.getArgumentTypes(this.methodNode.desc);
        this.returnType = Type.getReturnType(this.methodNode.desc);
        this.isStatic = Bytecode.methodIsStatic(this.methodNode);
    }

    public String toString() {
        return String.format("%s::%s", this.classNode.name, this.methodNode.name);
    }

    public final List<InjectionNodes$InjectionNode> find(InjectorTarget injectorTarget, List<InjectionPoint> list) {
        this.sanityCheck(injectorTarget.getTarget(), list);
        ArrayList<InjectionNodes$InjectionNode> arrayList = new ArrayList<InjectionNodes$InjectionNode>();
        Iterator<Injector$TargetNode> iterator = this.findTargetNodes(injectorTarget, list).iterator();
        while (Injector.llllIllIlI(iterator.hasNext() ? 1 : 0)) {
            Injector$TargetNode injector$TargetNode = iterator.next();
            this.addTargetNode(injectorTarget.getTarget(), arrayList, injector$TargetNode.insn, injector$TargetNode.nominators);
            "".length();
            if ("   ".length() >= 0) continue;
            return null;
        }
        return arrayList;
    }

    protected void addTargetNode(Target target, List<InjectionNodes$InjectionNode> list, AbstractInsnNode abstractInsnNode, Set<InjectionPoint> set) {
        list.add(target.addInjectionNode(abstractInsnNode));
        "".length();
    }

    public final void inject(Target target, List<InjectionNodes$InjectionNode> list) {
        InjectionNodes$InjectionNode injectionNodes$InjectionNode;
        Iterator<InjectionNodes$InjectionNode> iterator = list.iterator();
        while (Injector.llllIllIlI(iterator.hasNext() ? 1 : 0)) {
            injectionNodes$InjectionNode = iterator.next();
            if (Injector.llllIllIlI(injectionNodes$InjectionNode.isRemoved() ? 1 : 0)) {
                if (!Injector.llllIllIlI(this.info.getContext().getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) continue;
                logger.warn("Target node for {} was removed by a previous injector in {}", new Object[]{this.info, target});
                "".length();
                if ("  ".length() != 0) continue;
                return;
            }
            this.inject(target, injectionNodes$InjectionNode);
            "".length();
            if (null == null) continue;
            return;
        }
        iterator = list.iterator();
        while (Injector.llllIllIlI(iterator.hasNext() ? 1 : 0)) {
            injectionNodes$InjectionNode = iterator.next();
            this.postInject(target, injectionNodes$InjectionNode);
            "".length();
            if ((0xB7 ^ 0x91 ^ (0xAE ^ 0x8C)) == (100 + 75 - 160 + 115 ^ 108 + 18 - 64 + 72)) continue;
            return;
        }
    }

    private Collection<Injector$TargetNode> findTargetNodes(InjectorTarget injectorTarget, List<InjectionPoint> list) {
        IMixinContext iMixinContext = this.info.getContext();
        MethodNode methodNode = injectorTarget.getMethod();
        TreeMap<Integer, Injector$TargetNode> treeMap = new TreeMap<Integer, Injector$TargetNode>();
        ArrayList<AbstractInsnNode> arrayList = new ArrayList<AbstractInsnNode>(32);
        Iterator<InjectionPoint> iterator = list.iterator();
        while (Injector.llllIllIlI(iterator.hasNext() ? 1 : 0)) {
            InjectionPoint injectionPoint = iterator.next();
            arrayList.clear();
            if (Injector.llllIllIlI(injectorTarget.isMerged() ? 1 : 0) && Injector.llllIllIll(iMixinContext.getClassName().equals(injectorTarget.getMergedBy()) ? 1 : 0) && Injector.llllIllIll(injectionPoint.checkPriority(injectorTarget.getMergedPriority(), iMixinContext.getPriority()) ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.format("%s on %s with priority %d cannot inject into %s merged by %s with priority %d", injectionPoint, this, iMixinContext.getPriority(), injectorTarget, injectorTarget.getMergedBy(), injectorTarget.getMergedPriority()));
            }
            if (Injector.llllIllIlI(this.findTargetNodes(methodNode, injectionPoint, injectorTarget.getSlice(injectionPoint), arrayList) ? 1 : 0)) {
                Iterator iterator2 = arrayList.iterator();
                while (Injector.llllIllIlI(iterator2.hasNext() ? 1 : 0)) {
                    AbstractInsnNode abstractInsnNode = (AbstractInsnNode)iterator2.next();
                    Integer n = methodNode.instructions.indexOf(abstractInsnNode);
                    Injector$TargetNode injector$TargetNode = (Injector$TargetNode)treeMap.get(n);
                    if (Injector.llllIlllII(injector$TargetNode)) {
                        injector$TargetNode = new Injector$TargetNode(abstractInsnNode);
                        treeMap.put(n, injector$TargetNode);
                        "".length();
                    }
                    injector$TargetNode.nominators.add(injectionPoint);
                    "".length();
                    "".length();
                    if ("   ".length() < (0x31 ^ 0x13 ^ (0x96 ^ 0xB0))) continue;
                    return null;
                }
            }
            "".length();
            if (" ".length() <= (105 + 24 - 64 + 114 ^ 15 + 0 - -70 + 98)) continue;
            return null;
        }
        return treeMap.values();
    }

    protected boolean findTargetNodes(MethodNode methodNode, InjectionPoint injectionPoint, InsnList insnList, Collection<AbstractInsnNode> collection) {
        return injectionPoint.find(methodNode.desc, insnList, collection);
    }

    protected void sanityCheck(Target target, List<InjectionPoint> list) {
        if (Injector.llllIlllIl(target.classNode, this.classNode)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Target class does not match injector class in ").append(this)));
        }
    }

    protected abstract void inject(Target var1, InjectionNodes$InjectionNode var2);

    protected void postInject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
    }

    protected AbstractInsnNode invokeHandler(InsnList insnList) {
        return this.invokeHandler(insnList, this.methodNode);
    }

    protected AbstractInsnNode invokeHandler(InsnList insnList, MethodNode methodNode) {
        int n;
        int n2;
        int n3;
        if (Injector.llllIllIlI(methodNode.access & 2)) {
            n3 = 1;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            n3 = n2 = 0;
        }
        if (Injector.llllIllIlI(this.isStatic ? 1 : 0)) {
            n = 184;
            "".length();
            if (-" ".length() > " ".length()) {
                return null;
            }
        } else if (Injector.llllIllIlI(n2)) {
            n = 183;
            "".length();
            if (((0x75 ^ 6 ^ (0xA6 ^ 0x91)) & (53 + 73 - 108 + 227 ^ 1 + 110 - 13 + 79 ^ -" ".length())) == "  ".length()) {
                return null;
            }
        } else {
            n = 182;
        }
        int n4 = n;
        MethodInsnNode methodInsnNode = new MethodInsnNode(n4, this.classNode.name, methodNode.name, methodNode.desc, false);
        insnList.add(methodInsnNode);
        this.info.addCallbackInvocation(methodNode);
        return methodInsnNode;
    }

    protected void throwException(InsnList insnList, String string, String string2) {
        insnList.add(new TypeInsnNode(187, string));
        insnList.add(new InsnNode(89));
        insnList.add(new LdcInsnNode(string2));
        insnList.add(new MethodInsnNode(183, string, "<init>", "(Ljava/lang/String;)V", false));
        insnList.add(new InsnNode(191));
    }

    public static boolean canCoerce(Type type, Type type2) {
        if (Injector.llllIllllI(type.getSort(), 10) && Injector.llllIllllI(type2.getSort(), 10)) {
            return Injector.canCoerce(ClassInfo.forType(type), ClassInfo.forType(type2));
        }
        return Injector.canCoerce(type.getDescriptor(), type2.getDescriptor());
    }

    public static boolean canCoerce(String string, String string2) {
        if (!Injector.llllIlllll(string.length(), 1) || Injector.lllllIIIII(string2.length(), 1)) {
            return false;
        }
        return Injector.canCoerce(string.charAt(0), string2.charAt(0));
    }

    public static boolean canCoerce(char c, char c2) {
        boolean bl;
        if (Injector.llllIllllI(c2, 73) && Injector.lllllIIIII("IBSCZ".indexOf(c), -1)) {
            bl = true;
            "".length();
            if (((0x7D ^ 0x48) & ~(0x69 ^ 0x5C)) < -" ".length()) {
                return ((0x2E ^ 5) & ~(0x16 ^ 0x3D)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean canCoerce(ClassInfo classInfo, ClassInfo classInfo2) {
        boolean bl;
        if (Injector.lllllIIIIl(classInfo) && Injector.lllllIIIIl(classInfo2) && (!Injector.llllIlllIl(classInfo2, classInfo) || Injector.llllIllIlI(classInfo2.hasSuperClass(classInfo) ? 1 : 0))) {
            bl = true;
            "".length();
            if ((0x55 ^ 0x51) != (0xC3 ^ 0xC7)) {
                return ((0x5E ^ 0x3E) & ~(0x36 ^ 0x56)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean llllIllllI(int n, int n2) {
        return n == n2;
    }

    private static boolean llllIlllll(int n, int n2) {
        return n <= n2;
    }

    private static boolean lllllIIIII(int n, int n2) {
        return n > n2;
    }

    private static boolean llllIlllIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lllllIIIIl(Object object) {
        return object != null;
    }

    private static boolean llllIlllII(Object object) {
        return object == null;
    }

    private static boolean llllIllIlI(int n) {
        return n != 0;
    }

    private static boolean llllIllIll(int n) {
        return n == 0;
    }
}

