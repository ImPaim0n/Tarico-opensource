/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.code;

import java.util.ListIterator;
import java.util.NoSuchElementException;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;

class MethodSlice$InsnListSlice$SliceIterator
implements ListIterator<AbstractInsnNode> {
    private final ListIterator<AbstractInsnNode> iter;
    private int start;
    private int end;
    private int index;

    public MethodSlice$InsnListSlice$SliceIterator(ListIterator<AbstractInsnNode> listIterator, int n, int n2, int n3) {
        this.iter = listIterator;
        this.start = n;
        this.end = n2;
        this.index = n3;
    }

    @Override
    public boolean hasNext() {
        boolean bl;
        if (MethodSlice$InsnListSlice$SliceIterator.lIlllIIIl(this.index, this.end) && MethodSlice$InsnListSlice$SliceIterator.lIlllIIlI(this.iter.hasNext() ? 1 : 0)) {
            bl = true;
            "".length();
            if ((" ".length() & (" ".length() ^ -" ".length())) != 0) {
                return ((0xAB ^ 0xA2 ^ (0x15 ^ 0x2A)) & (0x74 ^ 0x20 ^ (0xF3 ^ 0x91) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public AbstractInsnNode next() {
        if (MethodSlice$InsnListSlice$SliceIterator.lIlllIIll(this.index, this.end)) {
            throw new NoSuchElementException();
        }
        ++this.index;
        return this.iter.next();
    }

    @Override
    public boolean hasPrevious() {
        boolean bl;
        if (MethodSlice$InsnListSlice$SliceIterator.lIlllIIll(this.index, this.start)) {
            bl = true;
            "".length();
            if (-" ".length() >= "  ".length()) {
                return ((0x6D ^ 0x5B ^ (0xD6 ^ 0xB9)) & (27 + 249 - 96 + 71 ^ 35 + 20 - 52 + 159 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public AbstractInsnNode previous() {
        if (MethodSlice$InsnListSlice$SliceIterator.lIlllIIIl(this.index, this.start)) {
            throw new NoSuchElementException();
        }
        --this.index;
        return this.iter.previous();
    }

    @Override
    public int nextIndex() {
        return this.index - this.start;
    }

    @Override
    public int previousIndex() {
        return this.index - this.start - 1;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Cannot remove insn from slice");
    }

    @Override
    public void set(AbstractInsnNode abstractInsnNode) {
        throw new UnsupportedOperationException("Cannot set insn using slice");
    }

    @Override
    public void add(AbstractInsnNode abstractInsnNode) {
        throw new UnsupportedOperationException("Cannot add insn using slice");
    }

    private static boolean lIlllIIIl(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIlllIIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIlllIIlI(int n) {
        return n != 0;
    }
}

