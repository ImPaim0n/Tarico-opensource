/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.code;

import java.util.ListIterator;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.mixin.injection.code.MethodSlice$InsnListSlice$SliceIterator;
import org.spongepowered.asm.mixin.injection.code.ReadOnlyInsnList;

final class MethodSlice$InsnListSlice
extends ReadOnlyInsnList {
    private final int start;
    private final int end;

    protected MethodSlice$InsnListSlice(InsnList insnList, int n, int n2) {
        super(insnList);
        this.start = n;
        this.end = n2;
    }

    @Override
    public ListIterator<AbstractInsnNode> iterator() {
        return this.iterator(0);
    }

    @Override
    public ListIterator<AbstractInsnNode> iterator(int n) {
        return new MethodSlice$InsnListSlice$SliceIterator(super.iterator(this.start + n), this.start, this.end, this.start + n);
    }

    @Override
    public AbstractInsnNode[] toArray() {
        AbstractInsnNode[] abstractInsnNodeArray = super.toArray();
        AbstractInsnNode[] abstractInsnNodeArray2 = new AbstractInsnNode[this.size()];
        System.arraycopy(abstractInsnNodeArray, this.start, abstractInsnNodeArray2, 0, abstractInsnNodeArray2.length);
        return abstractInsnNodeArray2;
    }

    @Override
    public int size() {
        return this.end - this.start + 1;
    }

    @Override
    public AbstractInsnNode getFirst() {
        return super.get(this.start);
    }

    @Override
    public AbstractInsnNode getLast() {
        return super.get(this.end);
    }

    @Override
    public AbstractInsnNode get(int n) {
        return super.get(this.start + n);
    }

    @Override
    public boolean contains(AbstractInsnNode abstractInsnNode) {
        AbstractInsnNode[] abstractInsnNodeArray = this.toArray();
        int n = abstractInsnNodeArray.length;
        int n2 = 0;
        while (MethodSlice$InsnListSlice.lIIllIl(n2, n)) {
            AbstractInsnNode abstractInsnNode2 = abstractInsnNodeArray[n2];
            if (MethodSlice$InsnListSlice.lIIlllI(abstractInsnNode2, abstractInsnNode)) {
                return true;
            }
            ++n2;
            "".length();
            if ((77 + 14 - 0 + 53 ^ 45 + 18 - 23 + 108) >= "   ".length()) continue;
            return ((0x85 ^ 0xC0 ^ (0x28 ^ 0x56)) & (0x15 ^ 0x6C ^ (0x2F ^ 0x6D) ^ -" ".length())) != 0;
        }
        return false;
    }

    @Override
    public int indexOf(AbstractInsnNode abstractInsnNode) {
        int n;
        int n2 = super.indexOf(abstractInsnNode);
        if (MethodSlice$InsnListSlice.lIIllll(n2, this.start) && MethodSlice$InsnListSlice.lIlIIII(n2, this.end)) {
            n = n2 - this.start;
            "".length();
            if ((0x51 ^ 0x4E ^ (0x56 ^ 0x4D)) == ((4 + 101 - 7 + 47 ^ 30 + 81 - -3 + 42) & (26 + 146 - -25 + 9 ^ 105 + 87 - 166 + 169 ^ -" ".length()))) {
                return (0x26 ^ 0x47 ^ (0x7C ^ 0x14)) & (0x45 ^ 0x2C ^ (0xA0 ^ 0xC0) ^ -" ".length());
            }
        } else {
            n = -1;
        }
        return n;
    }

    public int realIndexOf(AbstractInsnNode abstractInsnNode) {
        return super.indexOf(abstractInsnNode);
    }

    private static boolean lIIllll(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIllIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIlllI(Object object, Object object2) {
        return object == object2;
    }
}

