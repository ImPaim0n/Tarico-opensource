/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.injection.code;

import com.google.common.base.Strings;
import java.util.LinkedList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.IInjectionPointContext;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$Selector;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.code.ISliceContext;
import org.spongepowered.asm.mixin.injection.code.MethodSlice$InsnListSlice;
import org.spongepowered.asm.mixin.injection.code.ReadOnlyInsnList;
import org.spongepowered.asm.mixin.injection.throwables.InjectionError;
import org.spongepowered.asm.mixin.injection.throwables.InvalidSliceException;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

public final class MethodSlice {
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private final ISliceContext owner;
    private final String id;
    private final InjectionPoint from;
    private final InjectionPoint to;
    private final String name;

    private MethodSlice(ISliceContext iSliceContext, String string, InjectionPoint injectionPoint, InjectionPoint injectionPoint2) {
        if (MethodSlice.lllIlIIIIll(injectionPoint) && MethodSlice.lllIlIIIIll(injectionPoint2)) {
            throw new InvalidSliceException(iSliceContext, String.format("%s is redundant. No 'from' or 'to' value specified", this));
        }
        this.owner = iSliceContext;
        this.id = Strings.nullToEmpty((String)string);
        this.from = injectionPoint;
        this.to = injectionPoint2;
        this.name = MethodSlice.getSliceName(string);
    }

    public String getId() {
        return this.id;
    }

    public ReadOnlyInsnList getSlice(MethodNode methodNode) {
        int n;
        int n2 = methodNode.instructions.size() - 1;
        int n3 = this.find(methodNode, this.from, 0, 0, String.valueOf(new StringBuilder().append(this.name).append("(from)")));
        if (MethodSlice.lllIlIIIlIl(n3, n = this.find(methodNode, this.to, n2, n3, String.valueOf(new StringBuilder().append(this.name).append("(to)"))))) {
            throw new InvalidSliceException(this.owner, String.format("%s is negative size. Range(%d -> %d)", this.describe(), n3, n));
        }
        if (!MethodSlice.lllIlIIIllI(n3) || !MethodSlice.lllIlIIIllI(n) || !MethodSlice.lllIlIIIlll(n3, n2) || MethodSlice.lllIlIIIlIl(n, n2)) {
            throw new InjectionError(String.valueOf(new StringBuilder().append("Unexpected critical error in ").append(this).append(": out of bounds start=").append(n3).append(" end=").append(n).append(" lim=").append(n2)));
        }
        if (MethodSlice.lllIlIIlIII(n3) && MethodSlice.lllIlIIlIIl(n, n2)) {
            return new ReadOnlyInsnList(methodNode.instructions);
        }
        return new MethodSlice$InsnListSlice(methodNode.instructions, n3, n);
    }

    private int find(MethodNode methodNode, InjectionPoint injectionPoint, int n, int n2, String string) {
        AbstractInsnNode abstractInsnNode;
        if (MethodSlice.lllIlIIIIll(injectionPoint)) {
            return n;
        }
        LinkedList<AbstractInsnNode> linkedList = new LinkedList<AbstractInsnNode>();
        ReadOnlyInsnList readOnlyInsnList = new ReadOnlyInsnList(methodNode.instructions);
        int n3 = injectionPoint.find(methodNode.desc, readOnlyInsnList, linkedList);
        InjectionPoint$Selector injectionPoint$Selector = injectionPoint.getSelector();
        if (MethodSlice.lllIlIIlIlI(linkedList.size(), 1) && MethodSlice.lllIlIIlIll((Object)injectionPoint$Selector, (Object)InjectionPoint$Selector.ONE)) {
            throw new InvalidSliceException(this.owner, String.format("%s requires 1 result but found %d", this.describe(string), linkedList.size()));
        }
        if (MethodSlice.lllIlIIlIII(n3)) {
            if (MethodSlice.lllIlIIllII(this.owner.getContext().getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
                logger.warn("{} did not match any instructions", new Object[]{this.describe(string)});
            }
            return n2;
        }
        InsnList insnList = methodNode.instructions;
        if (MethodSlice.lllIlIIlIll((Object)injectionPoint$Selector, (Object)InjectionPoint$Selector.FIRST)) {
            abstractInsnNode = (AbstractInsnNode)linkedList.getFirst();
            "".length();
            if (((0x6B ^ 0x6D) & ~(0xAC ^ 0xAA)) != 0) {
                return (0x16 ^ 9) & ~(0x50 ^ 0x4F);
            }
        } else {
            abstractInsnNode = (AbstractInsnNode)linkedList.getLast();
        }
        return insnList.indexOf(abstractInsnNode);
    }

    public String toString() {
        return this.describe();
    }

    private String describe() {
        return this.describe(this.name);
    }

    private String describe(String string) {
        return MethodSlice.describeSlice(string, this.owner);
    }

    private static String describeSlice(String string, ISliceContext iSliceContext) {
        String string2 = Bytecode.getSimpleName(iSliceContext.getAnnotation());
        MethodNode methodNode = iSliceContext.getMethod();
        return String.format("%s->%s(%s)::%s%s", iSliceContext.getContext(), string2, string, methodNode.name, methodNode.desc);
    }

    private static String getSliceName(String string) {
        return String.format("@Slice[%s]", Strings.nullToEmpty((String)string));
    }

    public static MethodSlice parse(ISliceContext iSliceContext, Slice slice) {
        InjectionPoint injectionPoint;
        InjectionPoint injectionPoint2;
        InjectionPoint injectionPoint3;
        String string = slice.id();
        At at = slice.from();
        At at2 = slice.to();
        if (MethodSlice.lllIlIIlllI(at)) {
            injectionPoint3 = InjectionPoint.parse((IInjectionPointContext)iSliceContext, at);
            "".length();
            if (((0x25 ^ 3) & ~(0xE4 ^ 0xC2)) != 0) {
                return null;
            }
        } else {
            injectionPoint3 = injectionPoint2 = null;
        }
        if (MethodSlice.lllIlIIlllI(at2)) {
            injectionPoint = InjectionPoint.parse((IInjectionPointContext)iSliceContext, at2);
            "".length();
            if ("   ".length() <= 0) {
                return null;
            }
        } else {
            injectionPoint = null;
        }
        InjectionPoint injectionPoint4 = injectionPoint;
        return new MethodSlice(iSliceContext, string, injectionPoint2, injectionPoint4);
    }

    public static MethodSlice parse(ISliceContext iSliceContext, AnnotationNode annotationNode) {
        InjectionPoint injectionPoint;
        InjectionPoint injectionPoint2;
        InjectionPoint injectionPoint3;
        String string = (String)Annotations.getValue(annotationNode, "id");
        AnnotationNode annotationNode2 = (AnnotationNode)Annotations.getValue(annotationNode, "from");
        AnnotationNode annotationNode3 = (AnnotationNode)Annotations.getValue(annotationNode, "to");
        if (MethodSlice.lllIlIIlllI(annotationNode2)) {
            injectionPoint3 = InjectionPoint.parse((IInjectionPointContext)iSliceContext, annotationNode2);
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            injectionPoint3 = injectionPoint2 = null;
        }
        if (MethodSlice.lllIlIIlllI(annotationNode3)) {
            injectionPoint = InjectionPoint.parse((IInjectionPointContext)iSliceContext, annotationNode3);
            "".length();
            if (((47 + 141 - 94 + 65 ^ 133 + 24 - 20 + 11) & (0x20 ^ 0x27 ^ (0x6D ^ 0x61) ^ -" ".length())) >= "   ".length()) {
                return null;
            }
        } else {
            injectionPoint = null;
        }
        InjectionPoint injectionPoint4 = injectionPoint;
        return new MethodSlice(iSliceContext, string, injectionPoint2, injectionPoint4);
    }

    private static boolean lllIlIIlIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIlIIIlll(int n, int n2) {
        return n <= n2;
    }

    private static boolean lllIlIIIlIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIlIIlIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIlIIlllI(Object object) {
        return object != null;
    }

    private static boolean lllIlIIIIll(Object object) {
        return object == null;
    }

    private static boolean lllIlIIllII(int n) {
        return n != 0;
    }

    private static boolean lllIlIIlIII(int n) {
        return n == 0;
    }

    private static boolean lllIlIIIllI(int n) {
        return n >= 0;
    }

    private static boolean lllIlIIlIlI(int n, int n2) {
        return n != n2;
    }
}

