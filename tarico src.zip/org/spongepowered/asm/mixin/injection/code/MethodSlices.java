/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.code;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.mixin.injection.code.ISliceContext;
import org.spongepowered.asm.mixin.injection.code.MethodSlice;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.throwables.InvalidSliceException;
import org.spongepowered.asm.util.Annotations;

public final class MethodSlices {
    private final InjectionInfo info;
    private final Map<String, MethodSlice> slices = new HashMap<String, MethodSlice>(4);

    private MethodSlices(InjectionInfo injectionInfo) {
        this.info = injectionInfo;
    }

    private void add(MethodSlice methodSlice) {
        String string = this.info.getSliceId(methodSlice.getId());
        if (MethodSlices.lIlIIIlllll(this.slices.containsKey(string) ? 1 : 0)) {
            throw new InvalidSliceException((ISliceContext)this.info, String.valueOf(new StringBuilder().append(methodSlice).append(" has a duplicate id, '").append(string).append("' was already defined")));
        }
        this.slices.put(string, methodSlice);
        "".length();
    }

    public MethodSlice get(String string) {
        return this.slices.get(string);
    }

    public String toString() {
        return String.format("MethodSlices%s", this.slices.keySet());
    }

    public static MethodSlices parse(InjectionInfo injectionInfo) {
        MethodSlices methodSlices = new MethodSlices(injectionInfo);
        AnnotationNode annotationNode = injectionInfo.getAnnotation();
        if (MethodSlices.lIlIIlIIIlI(annotationNode)) {
            Iterator iterator = Annotations.getValue(annotationNode, "slice", true).iterator();
            while (MethodSlices.lIlIIIlllll(iterator.hasNext() ? 1 : 0)) {
                AnnotationNode annotationNode2 = (AnnotationNode)iterator.next();
                MethodSlice methodSlice = MethodSlice.parse((ISliceContext)injectionInfo, annotationNode2);
                methodSlices.add(methodSlice);
                "".length();
                if (null == null) continue;
                return null;
            }
        }
        return methodSlices;
    }

    private static boolean lIlIIlIIIlI(Object object) {
        return object != null;
    }

    private static boolean lIlIIIlllll(int n) {
        return n != 0;
    }
}

