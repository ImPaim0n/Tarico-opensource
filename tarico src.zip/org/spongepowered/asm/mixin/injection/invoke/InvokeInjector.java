/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke;

import java.util.List;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;

public abstract class InvokeInjector
extends Injector {
    protected final String annotationType;

    public InvokeInjector(InjectionInfo injectionInfo, String string) {
        super(injectionInfo);
        this.annotationType = string;
    }

    @Override
    protected void sanityCheck(Target target, List<InjectionPoint> list) {
        super.sanityCheck(target, list);
        this.checkTarget(target);
    }

    protected void checkTarget(Target target) {
        this.checkTargetModifiers(target, true);
    }

    protected final void checkTargetModifiers(Target target, boolean bl) {
        if (InvokeInjector.lllIIIllllI(bl ? 1 : 0) && InvokeInjector.lllIIIlllll(target.isStatic ? 1 : 0, this.isStatic ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("'static' modifier of handler method does not match target in ").append(this)));
        }
        if (InvokeInjector.lllIIlIIIII(bl ? 1 : 0) && InvokeInjector.lllIIlIIIII(this.isStatic ? 1 : 0) && InvokeInjector.lllIIIllllI(target.isStatic ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("non-static callback method ").append(this).append(" targets a static method which is not supported")));
        }
    }

    protected void checkTargetForNode(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        if (InvokeInjector.lllIIIllllI(target.isCtor ? 1 : 0)) {
            MethodInsnNode methodInsnNode = target.findSuperInitNode();
            int n = target.indexOf(methodInsnNode);
            int n2 = target.indexOf(injectionNodes$InjectionNode.getCurrentTarget());
            if (InvokeInjector.lllIIlIIIIl(n2, n)) {
                if (InvokeInjector.lllIIlIIIII(this.isStatic ? 1 : 0)) {
                    throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Pre-super ").append(this.annotationType).append(" invocation must be static in ").append(this)));
                }
                return;
            }
        }
        this.checkTargetModifiers(target, true);
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        if (InvokeInjector.lllIIlIIIII(injectionNodes$InjectionNode.getCurrentTarget() instanceof MethodInsnNode)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append(this.annotationType).append(" annotation on is targetting a non-method insn in ").append(target).append(" in ").append(this)));
        }
        this.injectAtInvoke(target, injectionNodes$InjectionNode);
    }

    protected abstract void injectAtInvoke(Target var1, InjectionNodes$InjectionNode var2);

    protected AbstractInsnNode invokeHandlerWithArgs(Type[] typeArray, InsnList insnList, int[] nArray) {
        return this.invokeHandlerWithArgs(typeArray, insnList, nArray, 0, typeArray.length);
    }

    protected AbstractInsnNode invokeHandlerWithArgs(Type[] typeArray, InsnList insnList, int[] nArray, int n, int n2) {
        if (InvokeInjector.lllIIlIIIII(this.isStatic ? 1 : 0)) {
            insnList.add(new VarInsnNode(25, 0));
        }
        this.pushArgs(typeArray, insnList, nArray, n, n2);
        return this.invokeHandler(insnList);
    }

    protected int[] storeArgs(Target target, Type[] typeArray, InsnList insnList, int n) {
        int[] nArray = target.generateArgMap(typeArray, n);
        this.storeArgs(typeArray, insnList, nArray, n, typeArray.length);
        return nArray;
    }

    protected void storeArgs(Type[] typeArray, InsnList insnList, int[] nArray, int n, int n2) {
        int n3 = n2 - 1;
        while (InvokeInjector.lllIIlIIIlI(n3, n)) {
            insnList.add(new VarInsnNode(typeArray[n3].getOpcode(54), nArray[n3]));
            --n3;
            "".length();
            if (-" ".length() < "  ".length()) continue;
            return;
        }
    }

    protected void pushArgs(Type[] typeArray, InsnList insnList, int[] nArray, int n, int n2) {
        int n3 = n;
        while (InvokeInjector.lllIIlIIIll(n3, n2)) {
            insnList.add(new VarInsnNode(typeArray[n3].getOpcode(21), nArray[n3]));
            ++n3;
            "".length();
            if ("  ".length() != 0) continue;
            return;
        }
    }

    private static boolean lllIIlIIIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lllIIlIIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIIlIIIIl(int n, int n2) {
        return n <= n2;
    }

    private static boolean lllIIIllllI(int n) {
        return n != 0;
    }

    private static boolean lllIIlIIIII(int n) {
        return n == 0;
    }

    private static boolean lllIIIlllll(int n, int n2) {
        return n != n2;
    }
}

