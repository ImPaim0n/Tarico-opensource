/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke;

import java.util.Arrays;
import java.util.List;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.invoke.InvokeInjector;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.util.Bytecode;

public class ModifyArgInjector
extends InvokeInjector {
    private final int index;
    private final boolean singleArgMode;

    public ModifyArgInjector(InjectionInfo injectionInfo, int n) {
        super(injectionInfo, "@ModifyArg");
        boolean bl;
        this.index = n;
        if (ModifyArgInjector.lIllIIIlIIl(this.methodArgs.length, 1)) {
            bl = true;
            "".length();
            if (-"  ".length() > 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.singleArgMode = bl;
    }

    @Override
    protected void sanityCheck(Target target, List<InjectionPoint> list) {
        super.sanityCheck(target, list);
        if (ModifyArgInjector.lIllIIIlIlI(this.singleArgMode ? 1 : 0) && ModifyArgInjector.lIllIIIlIll(this.methodArgs[0].equals(this.returnType) ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("@ModifyArg return type on ").append(this).append(" must match the parameter type. ARG=").append(this.methodArgs[0]).append(" RETURN=").append(this.returnType)));
        }
    }

    @Override
    protected void checkTarget(Target target) {
        if (ModifyArgInjector.lIllIIIlIll(this.isStatic ? 1 : 0) && ModifyArgInjector.lIllIIIlIlI(target.isStatic ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("non-static callback method ").append(this).append(" targets a static method which is not supported")));
        }
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        this.checkTargetForNode(target, injectionNodes$InjectionNode);
        super.inject(target, injectionNodes$InjectionNode);
    }

    @Override
    protected void injectAtInvoke(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        MethodInsnNode methodInsnNode = (MethodInsnNode)injectionNodes$InjectionNode.getCurrentTarget();
        Type[] typeArray = Type.getArgumentTypes(methodInsnNode.desc);
        int n = this.findArgIndex(target, typeArray);
        InsnList insnList = new InsnList();
        int n2 = 0;
        if (ModifyArgInjector.lIllIIIlIlI(this.singleArgMode ? 1 : 0)) {
            n2 = this.injectSingleArgHandler(target, typeArray, n, insnList);
            "".length();
            if (-" ".length() >= "   ".length()) {
                return;
            }
        } else {
            n2 = this.injectMultiArgHandler(target, typeArray, n, insnList);
        }
        target.insns.insertBefore((AbstractInsnNode)methodInsnNode, insnList);
        target.addToLocals(n2);
        target.addToStack(2 - (n2 - 1));
    }

    private int injectSingleArgHandler(Target target, Type[] typeArray, int n, InsnList insnList) {
        int[] nArray = this.storeArgs(target, typeArray, insnList, n);
        this.invokeHandlerWithArgs(typeArray, insnList, nArray, n, n + 1);
        "".length();
        this.pushArgs(typeArray, insnList, nArray, n + 1, typeArray.length);
        return nArray[nArray.length - 1] - target.getMaxLocals() + typeArray[typeArray.length - 1].getSize();
    }

    private int injectMultiArgHandler(Target target, Type[] typeArray, int n, InsnList insnList) {
        if (ModifyArgInjector.lIllIIIlIll(Arrays.equals(typeArray, this.methodArgs) ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("@ModifyArg method ").append(this).append(" targets a method with an invalid signature ").append(Bytecode.getDescriptor(typeArray)).append(", expected ").append(Bytecode.getDescriptor(this.methodArgs))));
        }
        int[] nArray = this.storeArgs(target, typeArray, insnList, 0);
        this.pushArgs(typeArray, insnList, nArray, 0, n);
        this.invokeHandlerWithArgs(typeArray, insnList, nArray, 0, typeArray.length);
        "".length();
        this.pushArgs(typeArray, insnList, nArray, n + 1, typeArray.length);
        return nArray[nArray.length - 1] - target.getMaxLocals() + typeArray[typeArray.length - 1].getSize();
    }

    protected int findArgIndex(Target target, Type[] typeArray) {
        if (ModifyArgInjector.lIllIIIllII(this.index, -1)) {
            if (!ModifyArgInjector.lIllIIIllIl(this.index, typeArray.length) || ModifyArgInjector.lIllIIIlIll(typeArray[this.index].equals(this.returnType) ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Specified index ").append(this.index).append(" for @ModifyArg is invalid for args ").append(Bytecode.getDescriptor(typeArray)).append(", expected ").append(this.returnType).append(" on ").append(this)));
            }
            return this.index;
        }
        int n = -1;
        int n2 = 0;
        while (ModifyArgInjector.lIllIIIllIl(n2, typeArray.length)) {
            if (ModifyArgInjector.lIllIIIlIll(typeArray[n2].equals(this.returnType) ? 1 : 0)) {
                "".length();
                if (((0x10 ^ 0x1A) & ~(0xA8 ^ 0xA2)) >= (0x82 ^ 0x86)) {
                    return (0x5D ^ 0x59) & ~(0x55 ^ 0x51);
                }
            } else {
                if (ModifyArgInjector.lIllIIIlllI(n, -1)) {
                    throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Found duplicate args with index [").append(n).append(", ").append(n2).append("] matching type ").append(this.returnType).append(" for @ModifyArg target ").append(target).append(" in ").append(this).append(". Please specify index of desired arg.")));
                }
                n = n2;
            }
            ++n2;
            "".length();
            if ("  ".length() <= "  ".length()) continue;
            return (0x61 ^ 0x25) & ~(3 ^ 0x47);
        }
        if (ModifyArgInjector.lIllIIIlIIl(n, -1)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Could not find arg matching type ").append(this.returnType).append(" for @ModifyArg target ").append(target).append(" in ").append(this)));
        }
        return n;
    }

    private static boolean lIllIIIlIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIllIIIllIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllIIIllII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllIIIlIlI(int n) {
        return n != 0;
    }

    private static boolean lIllIIIlIll(int n) {
        return n == 0;
    }

    private static boolean lIllIIIlllI(int n, int n2) {
        return n != n2;
    }
}

