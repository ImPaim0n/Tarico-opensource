/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke;

import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.injection.invoke.InvokeInjector;
import org.spongepowered.asm.mixin.injection.invoke.arg.ArgsClassGenerator;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.util.Bytecode;

public class ModifyArgsInjector
extends InvokeInjector {
    private final ArgsClassGenerator argsClassGenerator;

    public ModifyArgsInjector(InjectionInfo injectionInfo) {
        super(injectionInfo, "@ModifyArgs");
        this.argsClassGenerator = (ArgsClassGenerator)injectionInfo.getContext().getExtensions().getGenerator(ArgsClassGenerator.class);
    }

    @Override
    protected void checkTarget(Target target) {
        this.checkTargetModifiers(target, false);
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        this.checkTargetForNode(target, injectionNodes$InjectionNode);
        super.inject(target, injectionNodes$InjectionNode);
    }

    @Override
    protected void injectAtInvoke(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        MethodInsnNode methodInsnNode = (MethodInsnNode)injectionNodes$InjectionNode.getCurrentTarget();
        Type[] typeArray = Type.getArgumentTypes(methodInsnNode.desc);
        if (ModifyArgsInjector.lIIIlIlIIIII(typeArray.length)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("@ModifyArgs injector ").append(this).append(" targets a method invocation ").append(methodInsnNode.name).append(methodInsnNode.desc).append(" with no arguments!")));
        }
        String string = this.argsClassGenerator.getClassRef(methodInsnNode.desc);
        int n = this.verifyTarget(target);
        InsnList insnList = new InsnList();
        target.addToStack(1);
        this.packArgs(insnList, string, methodInsnNode);
        if (ModifyArgsInjector.lIIIlIlIIIIl(n)) {
            int n2;
            target.addToStack(Bytecode.getArgsSize(target.arguments));
            Type[] typeArray2 = target.arguments;
            if (ModifyArgsInjector.lIIIlIlIIIIl(target.isStatic ? 1 : 0)) {
                n2 = 0;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n2 = 1;
            }
            Bytecode.loadArgs(typeArray2, insnList, n2);
        }
        this.invokeHandler(insnList);
        "".length();
        this.unpackArgs(insnList, string, typeArray);
        target.insns.insertBefore((AbstractInsnNode)methodInsnNode, insnList);
    }

    private boolean verifyTarget(Target target) {
        String string = String.format("(L%s;)V", ArgsClassGenerator.ARGS_REF);
        if (ModifyArgsInjector.lIIIlIlIIIII(this.methodNode.desc.equals(string) ? 1 : 0)) {
            String string2 = Bytecode.changeDescriptorReturnType(target.method.desc, "V");
            String string3 = String.format("(L%s;%s", ArgsClassGenerator.ARGS_REF, string2.substring(1));
            if (ModifyArgsInjector.lIIIlIlIIIIl(this.methodNode.desc.equals(string3) ? 1 : 0)) {
                return true;
            }
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("@ModifyArgs injector ").append(this).append(" has an invalid signature ").append(this.methodNode.desc).append(", expected ").append(string).append(" or ").append(string3)));
        }
        return false;
    }

    private void packArgs(InsnList insnList, String string, MethodInsnNode methodInsnNode) {
        String string2 = Bytecode.changeDescriptorReturnType(methodInsnNode.desc, String.valueOf(new StringBuilder().append("L").append(string).append(";")));
        insnList.add(new MethodInsnNode(184, string, "of", string2, false));
        insnList.add(new InsnNode(89));
        if (ModifyArgsInjector.lIIIlIlIIIII(this.isStatic ? 1 : 0)) {
            insnList.add(new VarInsnNode(25, 0));
            insnList.add(new InsnNode(95));
        }
    }

    private void unpackArgs(InsnList insnList, String string, Type[] typeArray) {
        int n = 0;
        while (ModifyArgsInjector.lIIIlIlIIIlI(n, typeArray.length)) {
            if (ModifyArgsInjector.lIIIlIlIIIlI(n, typeArray.length - 1)) {
                insnList.add(new InsnNode(89));
            }
            insnList.add(new MethodInsnNode(182, string, String.valueOf(new StringBuilder().append("$").append(n)), String.valueOf(new StringBuilder().append("()").append(typeArray[n].getDescriptor())), false));
            if (ModifyArgsInjector.lIIIlIlIIIlI(n, typeArray.length - 1)) {
                if (ModifyArgsInjector.lIIIlIlIIIll(typeArray[n].getSize(), 1)) {
                    insnList.add(new InsnNode(95));
                    "".length();
                    if ((0x80 ^ 0x84) < ((0x74 ^ 0x41) & ~(0x11 ^ 0x24))) {
                        return;
                    }
                } else {
                    insnList.add(new InsnNode(93));
                    insnList.add(new InsnNode(88));
                }
            }
            ++n;
            "".length();
            if (-"  ".length() <= 0) continue;
            return;
        }
    }

    private static boolean lIIIlIlIIIll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIlIIIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIlIIIIl(int n) {
        return n != 0;
    }

    private static boolean lIIIlIlIIIII(int n) {
        return n == 0;
    }
}

