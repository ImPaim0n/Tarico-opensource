/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.Level
 */
package org.spongepowered.asm.mixin.injection.invoke;

import org.apache.logging.log4j.Level;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.invoke.RedirectInjector;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.Locals;
import org.spongepowered.asm.util.SignaturePrinter;

public class ModifyConstantInjector
extends RedirectInjector {
    private static final int OPCODE_OFFSET = 6;

    public ModifyConstantInjector(InjectionInfo injectionInfo) {
        super(injectionInfo, "@ModifyConstant");
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        if (ModifyConstantInjector.lIllIllIII(this.preInject(injectionNodes$InjectionNode) ? 1 : 0)) {
            return;
        }
        if (ModifyConstantInjector.lIllIllIIl(injectionNodes$InjectionNode.isReplaced() ? 1 : 0)) {
            throw new UnsupportedOperationException(String.valueOf(new StringBuilder().append("Target failure for ").append(this.info)));
        }
        AbstractInsnNode abstractInsnNode = injectionNodes$InjectionNode.getCurrentTarget();
        if (ModifyConstantInjector.lIllIllIIl(abstractInsnNode instanceof JumpInsnNode)) {
            this.checkTargetModifiers(target, false);
            this.injectExpandedConstantModifier(target, (JumpInsnNode)abstractInsnNode);
            return;
        }
        if (ModifyConstantInjector.lIllIllIIl(Bytecode.isConstant(abstractInsnNode) ? 1 : 0)) {
            this.checkTargetModifiers(target, false);
            this.injectConstantModifier(target, abstractInsnNode);
            return;
        }
        throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append(this.annotationType).append(" annotation is targetting an invalid insn in ").append(target).append(" in ").append(this)));
    }

    private void injectExpandedConstantModifier(Target target, JumpInsnNode jumpInsnNode) {
        int n = jumpInsnNode.getOpcode();
        if (!ModifyConstantInjector.lIllIllIlI(n, 155) || ModifyConstantInjector.lIllIllIll(n, 158)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append(this.annotationType).append(" annotation selected an invalid opcode ").append(Bytecode.getOpcodeName(n)).append(" in ").append(target).append(" in ").append(this)));
        }
        InsnList insnList = new InsnList();
        insnList.add(new InsnNode(3));
        AbstractInsnNode abstractInsnNode = this.invokeConstantHandler(Type.getType("I"), target, insnList, insnList);
        insnList.add(new JumpInsnNode(n + 6, jumpInsnNode.label));
        target.replaceNode(jumpInsnNode, abstractInsnNode, insnList);
        target.addToStack(1);
    }

    private void injectConstantModifier(Target target, AbstractInsnNode abstractInsnNode) {
        Type type = Bytecode.getConstantType(abstractInsnNode);
        if (ModifyConstantInjector.lIllIlllII(type.getSort(), 5) && ModifyConstantInjector.lIllIllIIl(this.info.getContext().getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
            this.checkNarrowing(target, abstractInsnNode, type);
        }
        InsnList insnList = new InsnList();
        InsnList insnList2 = new InsnList();
        AbstractInsnNode abstractInsnNode2 = this.invokeConstantHandler(type, target, insnList, insnList2);
        target.wrapNode(abstractInsnNode, abstractInsnNode2, insnList, insnList2);
    }

    private AbstractInsnNode invokeConstantHandler(Type type, Target target, InsnList insnList, InsnList insnList2) {
        String string = Bytecode.generateDescriptor(type, type);
        int n = this.checkDescriptor(string, target, "getter");
        if (ModifyConstantInjector.lIllIllIII(this.isStatic ? 1 : 0)) {
            insnList.insert(new VarInsnNode(25, 0));
            target.addToStack(1);
        }
        if (ModifyConstantInjector.lIllIllIIl(n)) {
            this.pushArgs(target.arguments, insnList2, target.getArgIndices(), 0, target.arguments.length);
            target.addToStack(Bytecode.getArgsSize(target.arguments));
        }
        return this.invokeHandler(insnList2);
    }

    private void checkNarrowing(Target target, AbstractInsnNode abstractInsnNode, Type type) {
        int n;
        LocalVariableNode localVariableNode;
        AbstractInsnNode abstractInsnNode2 = new InsnFinder().findPopInsn(target, abstractInsnNode);
        if (ModifyConstantInjector.lIllIlllIl(abstractInsnNode2)) {
            return;
        }
        if (ModifyConstantInjector.lIllIllIIl(abstractInsnNode2 instanceof FieldInsnNode)) {
            FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode2;
            Type type2 = Type.getType(fieldInsnNode.desc);
            this.checkNarrowing(target, abstractInsnNode, type, type2, target.indexOf(abstractInsnNode2), String.format("%s %s %s.%s", Bytecode.getOpcodeName(abstractInsnNode2), SignaturePrinter.getTypeName(type2, false), fieldInsnNode.owner.replace('/', '.'), fieldInsnNode.name));
            "".length();
            if (-"  ".length() > 0) {
                return;
            }
        } else if (ModifyConstantInjector.lIllIllllI(abstractInsnNode2.getOpcode(), 172)) {
            this.checkNarrowing(target, abstractInsnNode, type, target.returnType, target.indexOf(abstractInsnNode2), String.valueOf(new StringBuilder().append("RETURN ").append(SignaturePrinter.getTypeName(target.returnType, false))));
            "".length();
            if ("   ".length() != "   ".length()) {
                return;
            }
        } else if (ModifyConstantInjector.lIllIllllI(abstractInsnNode2.getOpcode(), 54) && ModifyConstantInjector.lIllIlllll(localVariableNode = Locals.getLocalVariableAt(target.classNode, target.method, abstractInsnNode2, n = ((VarInsnNode)abstractInsnNode2).var)) && ModifyConstantInjector.lIllIlllll(localVariableNode.desc)) {
            String string;
            if (ModifyConstantInjector.lIllIlllll(localVariableNode.name)) {
                string = localVariableNode.name;
                "".length();
                if (((0x5A ^ 0xF) & ~(0x3B ^ 0x6E)) != ((0x34 ^ 4) & ~(0xF2 ^ 0xC2))) {
                    return;
                }
            } else {
                string = "unnamed";
            }
            String string2 = string;
            Type type3 = Type.getType(localVariableNode.desc);
            this.checkNarrowing(target, abstractInsnNode, type, type3, target.indexOf(abstractInsnNode2), String.format("ISTORE[var=%d] %s %s", n, SignaturePrinter.getTypeName(type3, false), string2));
        }
    }

    private void checkNarrowing(Target target, AbstractInsnNode abstractInsnNode, Type type, Type type2, int n, String string) {
        int n2 = type.getSort();
        int n3 = type2.getSort();
        if (ModifyConstantInjector.lIlllIIIII(n3, n2)) {
            Level level;
            String string2;
            String string3;
            String string4 = SignaturePrinter.getTypeName(type, false);
            String string5 = SignaturePrinter.getTypeName(type2, false);
            if (ModifyConstantInjector.lIllIllllI(n3, 1)) {
                string3 = ". Implicit conversion to <boolean> can cause nondeterministic (JVM-specific) behaviour!";
                "".length();
                if (-"   ".length() >= 0) {
                    return;
                }
            } else {
                string3 = string2 = "";
            }
            if (ModifyConstantInjector.lIllIllllI(n3, 1)) {
                level = Level.ERROR;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                level = Level.WARN;
            }
            Level level2 = level;
            Injector.logger.log(level2, "Narrowing conversion of <{}> to <{}> in {} target {} at opcode {} ({}){}", new Object[]{string4, string5, this.info, target, n, string, string2});
        }
    }

    private static boolean lIllIllllI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIllIllIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIlllIIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllIlllII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIllIllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllIlllll(Object object) {
        return object != null;
    }

    private static boolean lIllIlllIl(Object object) {
        return object == null;
    }

    private static boolean lIllIllIIl(int n) {
        return n != 0;
    }

    private static boolean lIllIllIII(int n) {
        return n == 0;
    }
}

