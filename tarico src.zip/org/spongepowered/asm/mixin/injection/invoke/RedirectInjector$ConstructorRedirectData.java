/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke;

class RedirectInjector$ConstructorRedirectData {
    public static final String KEY = "ctor";
    public boolean wildcard = false;
    public int injected = 0;

    RedirectInjector$ConstructorRedirectData() {
    }
}

