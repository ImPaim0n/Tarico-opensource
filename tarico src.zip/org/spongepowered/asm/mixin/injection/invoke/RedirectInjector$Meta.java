/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke;

import org.spongepowered.asm.mixin.injection.invoke.RedirectInjector;

class RedirectInjector$Meta {
    public static final String KEY = "redirector";
    final int priority;
    final boolean isFinal;
    final String name;
    final String desc;
    final /* synthetic */ RedirectInjector this$0;

    public RedirectInjector$Meta(RedirectInjector redirectInjector, int n, boolean bl, String string, String string2) {
        this.this$0 = redirectInjector;
        this.priority = n;
        this.isFinal = bl;
        this.name = string;
        this.desc = string2;
    }

    RedirectInjector getOwner() {
        return this.this$0;
    }
}

