/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ObjectArrays
 */
package org.spongepowered.asm.mixin.injection.invoke;

import com.google.common.collect.ObjectArrays;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.mixin.injection.struct.Target;

class RedirectInjector$RedirectedInvoke {
    final Target target;
    final MethodInsnNode node;
    final Type returnType;
    final Type[] args;
    final Type[] locals;
    boolean captureTargetArgs = false;

    RedirectInjector$RedirectedInvoke(Target target, MethodInsnNode methodInsnNode) {
        Type[] typeArray;
        this.target = target;
        this.node = methodInsnNode;
        this.returnType = Type.getReturnType(methodInsnNode.desc);
        this.args = Type.getArgumentTypes(methodInsnNode.desc);
        if (RedirectInjector$RedirectedInvoke.lIllIlIIlll(methodInsnNode.getOpcode(), 184)) {
            typeArray = this.args;
            "".length();
            if (((0x31 ^ 0x44 ^ (0x4D ^ 0x15)) & (0x6C ^ 0x75 ^ (0x18 ^ 0x2C) ^ -" ".length())) > "   ".length()) {
                throw null;
            }
        } else {
            typeArray = (Type[])ObjectArrays.concat((Object)Type.getType(String.valueOf(new StringBuilder().append("L").append(methodInsnNode.owner).append(";"))), (Object[])this.args);
        }
        this.locals = typeArray;
    }

    private static boolean lIllIlIIlll(int n, int n2) {
        return n == n2;
    }
}

