/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Joiner
 *  com.google.common.primitives.Ints
 */
package org.spongepowered.asm.mixin.injection.invoke;

import com.google.common.base.Joiner;
import com.google.common.primitives.Ints;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.invoke.InvokeInjector;
import org.spongepowered.asm.mixin.injection.invoke.RedirectInjector$ConstructorRedirectData;
import org.spongepowered.asm.mixin.injection.invoke.RedirectInjector$Meta;
import org.spongepowered.asm.mixin.injection.invoke.RedirectInjector$RedirectedInvoke;
import org.spongepowered.asm.mixin.injection.points.BeforeFieldAccess;
import org.spongepowered.asm.mixin.injection.points.BeforeNew;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

public class RedirectInjector
extends InvokeInjector {
    private static final String KEY_NOMINATORS = "nominators";
    private static final String KEY_FUZZ = "fuzz";
    private static final String KEY_OPCODE = "opcode";
    protected RedirectInjector$Meta meta;
    private Map<BeforeNew, RedirectInjector$ConstructorRedirectData> ctorRedirectors = new HashMap<BeforeNew, RedirectInjector$ConstructorRedirectData>();

    public RedirectInjector(InjectionInfo injectionInfo) {
        this(injectionInfo, "@Redirect");
    }

    protected RedirectInjector(InjectionInfo injectionInfo, String string) {
        super(injectionInfo, string);
        boolean bl;
        int n = injectionInfo.getContext().getPriority();
        if (RedirectInjector.llIIIIIIIl(Annotations.getVisible(this.methodNode, Final.class))) {
            bl = true;
            "".length();
            if (((0xB2 ^ 0x8B) & ~(0x3D ^ 4)) != 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        this.meta = new RedirectInjector$Meta(this, n, bl2, this.info.toString(), this.methodNode.desc);
    }

    @Override
    protected void checkTarget(Target target) {
    }

    @Override
    protected void addTargetNode(Target target, List<InjectionNodes$InjectionNode> list, AbstractInsnNode abstractInsnNode, Set<InjectionPoint> set) {
        Object object;
        InjectionNodes$InjectionNode injectionNodes$InjectionNode = target.getInjectionNode(abstractInsnNode);
        RedirectInjector$ConstructorRedirectData redirectInjector$ConstructorRedirectData = null;
        int n = 8;
        int n2 = 0;
        if (RedirectInjector.llIIIIIIIl(injectionNodes$InjectionNode) && RedirectInjector.llIIIIIIIl(object = (RedirectInjector$Meta)injectionNodes$InjectionNode.getDecoration("redirector")) && RedirectInjector.llIIIIIIlI(((RedirectInjector$Meta)object).getOwner(), this)) {
            if (RedirectInjector.llIIIIIIll(((RedirectInjector$Meta)object).priority, this.meta.priority)) {
                Injector.logger.warn("{} conflict. Skipping {} with priority {}, already redirected by {} with priority {}", new Object[]{this.annotationType, this.info, this.meta.priority, ((RedirectInjector$Meta)object).name, ((RedirectInjector$Meta)object).priority});
                return;
            }
            if (RedirectInjector.llIIIIIlII(((RedirectInjector$Meta)object).isFinal ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.format("%s conflict: %s failed because target was already remapped by %s", this.annotationType, this, ((RedirectInjector$Meta)object).name));
            }
        }
        object = set.iterator();
        while (RedirectInjector.llIIIIIlII(object.hasNext() ? 1 : 0)) {
            InjectionPoint injectionPoint = (InjectionPoint)object.next();
            if (RedirectInjector.llIIIIIlII(injectionPoint instanceof BeforeNew)) {
                boolean bl;
                redirectInjector$ConstructorRedirectData = this.getCtorRedirect((BeforeNew)injectionPoint);
                if (RedirectInjector.llIIIIIlIl(((BeforeNew)injectionPoint).hasDescriptor() ? 1 : 0)) {
                    bl = true;
                    "".length();
                    if ("   ".length() < "  ".length()) {
                        return;
                    }
                } else {
                    bl = false;
                }
                redirectInjector$ConstructorRedirectData.wildcard = bl;
                "".length();
                if (((0x33 ^ 0x22 ^ (0x4F ^ 0x13)) & (168 + 181 - 323 + 216 ^ 179 + 182 - 358 + 188 ^ -" ".length())) > 0) {
                    return;
                }
            } else if (RedirectInjector.llIIIIIlII(injectionPoint instanceof BeforeFieldAccess)) {
                BeforeFieldAccess beforeFieldAccess = (BeforeFieldAccess)injectionPoint;
                n = beforeFieldAccess.getFuzzFactor();
                n2 = beforeFieldAccess.getArrayOpcode();
            }
            "".length();
            if (-"  ".length() <= 0) continue;
            return;
        }
        object = target.addInjectionNode(abstractInsnNode);
        ((InjectionNodes$InjectionNode)object).decorate("redirector", this.meta);
        "".length();
        ((InjectionNodes$InjectionNode)object).decorate("nominators", set);
        "".length();
        if (RedirectInjector.llIIIIIlII(abstractInsnNode instanceof TypeInsnNode) && RedirectInjector.llIIIIIllI(abstractInsnNode.getOpcode(), 187)) {
            ((InjectionNodes$InjectionNode)object).decorate("ctor", redirectInjector$ConstructorRedirectData);
            "".length();
            "".length();
            if (((0xD4 ^ 0x9A) & ~(0x11 ^ 0x5F)) != 0) {
                return;
            }
        } else {
            ((InjectionNodes$InjectionNode)object).decorate("fuzz", n);
            "".length();
            ((InjectionNodes$InjectionNode)object).decorate("opcode", n2);
            "".length();
        }
        list.add((InjectionNodes$InjectionNode)object);
        "".length();
    }

    private RedirectInjector$ConstructorRedirectData getCtorRedirect(BeforeNew beforeNew) {
        RedirectInjector$ConstructorRedirectData redirectInjector$ConstructorRedirectData = this.ctorRedirectors.get(beforeNew);
        if (RedirectInjector.llIIIIIlll(redirectInjector$ConstructorRedirectData)) {
            redirectInjector$ConstructorRedirectData = new RedirectInjector$ConstructorRedirectData();
            this.ctorRedirectors.put(beforeNew, redirectInjector$ConstructorRedirectData);
            "".length();
        }
        return redirectInjector$ConstructorRedirectData;
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        if (RedirectInjector.llIIIIIlIl(this.preInject(injectionNodes$InjectionNode) ? 1 : 0)) {
            return;
        }
        if (RedirectInjector.llIIIIIlII(injectionNodes$InjectionNode.isReplaced() ? 1 : 0)) {
            throw new UnsupportedOperationException(String.valueOf(new StringBuilder().append("Redirector target failure for ").append(this.info)));
        }
        if (RedirectInjector.llIIIIIlII(injectionNodes$InjectionNode.getCurrentTarget() instanceof MethodInsnNode)) {
            this.checkTargetForNode(target, injectionNodes$InjectionNode);
            this.injectAtInvoke(target, injectionNodes$InjectionNode);
            return;
        }
        if (RedirectInjector.llIIIIIlII(injectionNodes$InjectionNode.getCurrentTarget() instanceof FieldInsnNode)) {
            this.checkTargetForNode(target, injectionNodes$InjectionNode);
            this.injectAtFieldAccess(target, injectionNodes$InjectionNode);
            return;
        }
        if (RedirectInjector.llIIIIIlII(injectionNodes$InjectionNode.getCurrentTarget() instanceof TypeInsnNode) && RedirectInjector.llIIIIIllI(injectionNodes$InjectionNode.getCurrentTarget().getOpcode(), 187)) {
            if (RedirectInjector.llIIIIIlIl(this.isStatic ? 1 : 0) && RedirectInjector.llIIIIIlII(target.isStatic ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.format("non-static callback method %s has a static target which is not supported", this));
            }
            this.injectAtConstructor(target, injectionNodes$InjectionNode);
            return;
        }
        throw new InvalidInjectionException(this.info, String.format("%s annotation on is targetting an invalid insn in %s in %s", this.annotationType, target, this));
    }

    protected boolean preInject(InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        RedirectInjector$Meta redirectInjector$Meta = (RedirectInjector$Meta)injectionNodes$InjectionNode.getDecoration("redirector");
        if (RedirectInjector.llIIIIIIlI(redirectInjector$Meta.getOwner(), this)) {
            Injector.logger.warn("{} conflict. Skipping {} with priority {}, already redirected by {} with priority {}", new Object[]{this.annotationType, this.info, this.meta.priority, redirectInjector$Meta.name, redirectInjector$Meta.priority});
            return false;
        }
        return true;
    }

    @Override
    protected void postInject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        super.postInject(target, injectionNodes$InjectionNode);
        if (RedirectInjector.llIIIIIlII(injectionNodes$InjectionNode.getOriginalTarget() instanceof TypeInsnNode) && RedirectInjector.llIIIIIllI(injectionNodes$InjectionNode.getOriginalTarget().getOpcode(), 187)) {
            RedirectInjector$ConstructorRedirectData redirectInjector$ConstructorRedirectData = (RedirectInjector$ConstructorRedirectData)injectionNodes$InjectionNode.getDecoration("ctor");
            if (RedirectInjector.llIIIIIlII(redirectInjector$ConstructorRedirectData.wildcard ? 1 : 0) && RedirectInjector.llIIIIIlIl(redirectInjector$ConstructorRedirectData.injected)) {
                throw new InvalidInjectionException(this.info, String.format("%s ctor invocation was not found in %s", this.annotationType, target));
            }
        }
    }

    @Override
    protected void injectAtInvoke(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        RedirectInjector$RedirectedInvoke redirectInjector$RedirectedInvoke = new RedirectInjector$RedirectedInvoke(target, (MethodInsnNode)injectionNodes$InjectionNode.getCurrentTarget());
        this.validateParams(redirectInjector$RedirectedInvoke);
        InsnList insnList = new InsnList();
        int n = Bytecode.getArgsSize(redirectInjector$RedirectedInvoke.locals) + 1;
        int n2 = 1;
        int[] nArray = this.storeArgs(target, redirectInjector$RedirectedInvoke.locals, insnList, 0);
        if (RedirectInjector.llIIIIIlII(redirectInjector$RedirectedInvoke.captureTargetArgs ? 1 : 0)) {
            int n3 = Bytecode.getArgsSize(target.arguments);
            n += n3;
            n2 += n3;
            nArray = Ints.concat((int[][])new int[][]{nArray, target.getArgIndices()});
        }
        AbstractInsnNode abstractInsnNode = this.invokeHandlerWithArgs(this.methodArgs, insnList, nArray);
        target.replaceNode(redirectInjector$RedirectedInvoke.node, abstractInsnNode, insnList);
        target.addToLocals(n);
        target.addToStack(n2);
    }

    protected void validateParams(RedirectInjector$RedirectedInvoke redirectInjector$RedirectedInvoke) {
        int n = this.methodArgs.length;
        String string = String.format("%s handler method %s", this.annotationType, this);
        if (RedirectInjector.llIIIIIlIl(redirectInjector$RedirectedInvoke.returnType.equals(this.returnType) ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.format("%s has an invalid signature. Expected return type %s found %s", string, this.returnType, redirectInjector$RedirectedInvoke.returnType));
        }
        int n2 = 0;
        while (RedirectInjector.llIIIIlIII(n2, n)) {
            Type type = null;
            if (RedirectInjector.llIIIIIIll(n2, this.methodArgs.length)) {
                throw new InvalidInjectionException(this.info, String.format("%s has an invalid signature. Not enough arguments found for capture of target method args, expected %d but found %d", string, n, this.methodArgs.length));
            }
            Type type2 = this.methodArgs[n2];
            if (RedirectInjector.llIIIIlIII(n2, redirectInjector$RedirectedInvoke.locals.length)) {
                type = redirectInjector$RedirectedInvoke.locals[n2];
                "".length();
                if (" ".length() <= 0) {
                    return;
                }
            } else {
                redirectInjector$RedirectedInvoke.captureTargetArgs = true;
                n = Math.max(n, redirectInjector$RedirectedInvoke.locals.length + redirectInjector$RedirectedInvoke.target.arguments.length);
                int n3 = n2 - redirectInjector$RedirectedInvoke.locals.length;
                if (RedirectInjector.llIIIIIIll(n3, redirectInjector$RedirectedInvoke.target.arguments.length)) {
                    throw new InvalidInjectionException(this.info, String.format("%s has an invalid signature. Found unexpected additional target argument with type %s at index %d", string, type2, n2));
                }
                type = redirectInjector$RedirectedInvoke.target.arguments[n3];
            }
            AnnotationNode annotationNode = Annotations.getInvisibleParameter(this.methodNode, Coerce.class, n2);
            if (RedirectInjector.llIIIIIlII(type2.equals(type) ? 1 : 0)) {
                if (RedirectInjector.llIIIIIIIl(annotationNode) && RedirectInjector.llIIIIIlII(this.info.getContext().getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
                    Injector.logger.warn("Redundant @Coerce on {} argument {}, {} is identical to {}", new Object[]{string, n2, type, type2});
                    "".length();
                    if (((0xC0 ^ 0x83 ^ (0x21 ^ 0x74)) & (0x2C ^ 9 ^ (0xA1 ^ 0x92) ^ -" ".length())) != 0) {
                        return;
                    }
                }
            } else {
                int n4 = Injector.canCoerce(type2, type);
                if (RedirectInjector.llIIIIIlll(annotationNode)) {
                    throw new InvalidInjectionException(this.info, String.format("%s has an invalid signature. Found unexpected argument type %s at index %d, expected %s", string, type2, n2, type));
                }
                if (RedirectInjector.llIIIIIlIl(n4)) {
                    throw new InvalidInjectionException(this.info, String.format("%s has an invalid signature. Cannot @Coerce argument type %s at index %d to %s", string, type, n2, type2));
                }
            }
            ++n2;
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
    }

    private void injectAtFieldAccess(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        int n;
        int n2;
        int n3;
        int n4;
        FieldInsnNode fieldInsnNode = (FieldInsnNode)injectionNodes$InjectionNode.getCurrentTarget();
        int n5 = fieldInsnNode.getOpcode();
        Type type = Type.getType(String.valueOf(new StringBuilder().append("L").append(fieldInsnNode.owner).append(";")));
        Type type2 = Type.getType(fieldInsnNode.desc);
        if (RedirectInjector.llIIIIIllI(type2.getSort(), 9)) {
            n4 = type2.getDimensions();
            "".length();
            if (-"   ".length() >= 0) {
                return;
            }
        } else {
            n4 = n3 = 0;
        }
        if (RedirectInjector.llIIIIIllI(this.returnType.getSort(), 9)) {
            n2 = this.returnType.getDimensions();
            "".length();
            if (null != null) {
                return;
            }
        } else {
            n2 = 0;
        }
        if (RedirectInjector.llIIIIlIIl(n = n2, n3)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Dimensionality of handler method is greater than target array on ").append(this)));
        }
        if (RedirectInjector.llIIIIIlIl(n) && RedirectInjector.llIIIIlIlI(n3)) {
            int n6 = (Integer)injectionNodes$InjectionNode.getDecoration("fuzz");
            int n7 = (Integer)injectionNodes$InjectionNode.getDecoration("opcode");
            this.injectAtArrayField(target, fieldInsnNode, n5, type, type2, n6, n7);
            "".length();
            if (" ".length() == 0) {
                return;
            }
        } else {
            this.injectAtScalarField(target, fieldInsnNode, n5, type, type2);
        }
    }

    private void injectAtArrayField(Target target, FieldInsnNode fieldInsnNode, int n, Type type, Type type2, int n2, int n3) {
        Type type3 = type2.getElementType();
        if (RedirectInjector.llIIIIlIll(n, 178) && RedirectInjector.llIIIIlIll(n, 180)) {
            throw new InvalidInjectionException(this.info, String.format("Unspported opcode %s for array access %s", Bytecode.getOpcodeName(n), this.info));
        }
        if (RedirectInjector.llIIIIIlII(this.returnType.getSort())) {
            if (RedirectInjector.llIIIIlIll(n3, 190)) {
                n3 = type3.getOpcode(46);
            }
            AbstractInsnNode abstractInsnNode = BeforeFieldAccess.findArrayNode(target.insns, fieldInsnNode, n3, n2);
            this.injectAtGetArray(target, fieldInsnNode, abstractInsnNode, type, type2);
            "".length();
            if (null != null) {
                return;
            }
        } else {
            AbstractInsnNode abstractInsnNode = BeforeFieldAccess.findArrayNode(target.insns, fieldInsnNode, type3.getOpcode(79), n2);
            this.injectAtSetArray(target, fieldInsnNode, abstractInsnNode, type, type2);
        }
    }

    private void injectAtGetArray(Target target, FieldInsnNode fieldInsnNode, AbstractInsnNode abstractInsnNode, Type type, Type type2) {
        String string = RedirectInjector.getGetArrayHandlerDescriptor(abstractInsnNode, this.returnType, type2);
        boolean bl = this.checkDescriptor(string, target, "array getter");
        this.injectArrayRedirect(target, fieldInsnNode, abstractInsnNode, bl, "array getter");
    }

    private void injectAtSetArray(Target target, FieldInsnNode fieldInsnNode, AbstractInsnNode abstractInsnNode, Type type, Type type2) {
        String string = Bytecode.generateDescriptor(null, RedirectInjector.getArrayArgs(type2, 1, type2.getElementType()));
        boolean bl = this.checkDescriptor(string, target, "array setter");
        this.injectArrayRedirect(target, fieldInsnNode, abstractInsnNode, bl, "array setter");
    }

    public void injectArrayRedirect(Target target, FieldInsnNode fieldInsnNode, AbstractInsnNode abstractInsnNode, boolean bl, String string) {
        if (RedirectInjector.llIIIIIlll(abstractInsnNode)) {
            String string2 = "";
            throw new InvalidInjectionException(this.info, String.format("Array element %s on %s could not locate a matching %s instruction in %s. %s", this.annotationType, this, string, target, string2));
        }
        if (RedirectInjector.llIIIIIlIl(this.isStatic ? 1 : 0)) {
            target.insns.insertBefore((AbstractInsnNode)fieldInsnNode, new VarInsnNode(25, 0));
            target.addToStack(1);
        }
        InsnList insnList = new InsnList();
        if (RedirectInjector.llIIIIIlII(bl ? 1 : 0)) {
            this.pushArgs(target.arguments, insnList, target.getArgIndices(), 0, target.arguments.length);
            target.addToStack(Bytecode.getArgsSize(target.arguments));
        }
        target.replaceNode(abstractInsnNode, this.invokeHandler(insnList), insnList);
    }

    public void injectAtScalarField(Target target, FieldInsnNode fieldInsnNode, int n, Type type, Type type2) {
        AbstractInsnNode abstractInsnNode = null;
        InsnList insnList = new InsnList();
        if (!RedirectInjector.llIIIIlIll(n, 178) || RedirectInjector.llIIIIIllI(n, 180)) {
            boolean bl;
            if (RedirectInjector.llIIIIIllI(n, 178)) {
                bl = true;
                "".length();
                if ("   ".length() == 0) {
                    return;
                }
            } else {
                bl = false;
            }
            abstractInsnNode = this.injectAtGetField(insnList, target, fieldInsnNode, bl, type, type2);
            "".length();
            if ("   ".length() <= "  ".length()) {
                return;
            }
        } else if (!RedirectInjector.llIIIIlIll(n, 179) || RedirectInjector.llIIIIIllI(n, 181)) {
            boolean bl;
            if (RedirectInjector.llIIIIIllI(n, 179)) {
                bl = true;
                "".length();
                if ((0x61 ^ 0x65) <= -" ".length()) {
                    return;
                }
            } else {
                bl = false;
            }
            abstractInsnNode = this.injectAtPutField(insnList, target, fieldInsnNode, bl, type, type2);
            "".length();
            if (((0x85 ^ 0xC6) & ~(0xC ^ 0x4F)) > 0) {
                return;
            }
        } else {
            throw new InvalidInjectionException(this.info, String.format("Unspported opcode %s for %s", Bytecode.getOpcodeName(n), this.info));
        }
        target.replaceNode(fieldInsnNode, abstractInsnNode, insnList);
    }

    private AbstractInsnNode injectAtGetField(InsnList insnList, Target target, FieldInsnNode fieldInsnNode, boolean bl, Type type, Type type2) {
        int n;
        String string;
        if (RedirectInjector.llIIIIIlII(bl ? 1 : 0)) {
            string = Bytecode.generateDescriptor(type2, new Object[0]);
            "".length();
            if ("  ".length() == (0xA7 ^ 0x94 ^ (0x60 ^ 0x57))) {
                return null;
            }
        } else {
            string = Bytecode.generateDescriptor(type2, type);
        }
        String string2 = string;
        int n2 = this.checkDescriptor(string2, target, "getter");
        if (RedirectInjector.llIIIIIlIl(this.isStatic ? 1 : 0)) {
            insnList.add(new VarInsnNode(25, 0));
            if (RedirectInjector.llIIIIIlIl(bl ? 1 : 0)) {
                insnList.add(new InsnNode(95));
            }
        }
        if (RedirectInjector.llIIIIIlII(n2)) {
            this.pushArgs(target.arguments, insnList, target.getArgIndices(), 0, target.arguments.length);
            target.addToStack(Bytecode.getArgsSize(target.arguments));
        }
        if (RedirectInjector.llIIIIIlII(this.isStatic ? 1 : 0)) {
            n = 0;
            "".length();
            if (((116 + 35 - 87 + 100 ^ 108 + 53 - 63 + 38) & (0x52 ^ 0x4D ^ (0x11 ^ 0x22) ^ -" ".length())) > "  ".length()) {
                return null;
            }
        } else {
            n = 1;
        }
        target.addToStack(n);
        return this.invokeHandler(insnList);
    }

    private AbstractInsnNode injectAtPutField(InsnList insnList, Target target, FieldInsnNode fieldInsnNode, boolean bl, Type type, Type type2) {
        int n;
        String string;
        if (RedirectInjector.llIIIIIlII(bl ? 1 : 0)) {
            string = Bytecode.generateDescriptor(null, type2);
            "".length();
            if (-" ".length() >= "  ".length()) {
                return null;
            }
        } else {
            string = Bytecode.generateDescriptor(null, type, type2);
        }
        String string2 = string;
        int n2 = this.checkDescriptor(string2, target, "setter");
        if (RedirectInjector.llIIIIIlIl(this.isStatic ? 1 : 0)) {
            if (RedirectInjector.llIIIIIlII(bl ? 1 : 0)) {
                insnList.add(new VarInsnNode(25, 0));
                insnList.add(new InsnNode(95));
                "".length();
                if ((0x82 ^ 0x86) < -" ".length()) {
                    return null;
                }
            } else {
                int n3 = target.allocateLocals(type2.getSize());
                insnList.add(new VarInsnNode(type2.getOpcode(54), n3));
                insnList.add(new VarInsnNode(25, 0));
                insnList.add(new InsnNode(95));
                insnList.add(new VarInsnNode(type2.getOpcode(21), n3));
            }
        }
        if (RedirectInjector.llIIIIIlII(n2)) {
            this.pushArgs(target.arguments, insnList, target.getArgIndices(), 0, target.arguments.length);
            target.addToStack(Bytecode.getArgsSize(target.arguments));
        }
        if (RedirectInjector.llIIIIIlIl(this.isStatic ? 1 : 0) && RedirectInjector.llIIIIIlIl(bl ? 1 : 0)) {
            n = 1;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            n = 0;
        }
        target.addToStack(n);
        return this.invokeHandler(insnList);
    }

    protected boolean checkDescriptor(String string, Target target, String string2) {
        if (RedirectInjector.llIIIIIlII(this.methodNode.desc.equals(string) ? 1 : 0)) {
            return false;
        }
        int n = string.indexOf(41);
        String string3 = String.format("%s%s%s", string.substring(0, n), Joiner.on((String)"").join((Object[])target.arguments), string.substring(n));
        if (RedirectInjector.llIIIIIlII(this.methodNode.desc.equals(string3) ? 1 : 0)) {
            return true;
        }
        throw new InvalidInjectionException(this.info, String.format("%s method %s %s has an invalid signature. Expected %s but found %s", this.annotationType, string2, this, string, this.methodNode.desc));
    }

    protected void injectAtConstructor(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        int n;
        RedirectInjector$ConstructorRedirectData redirectInjector$ConstructorRedirectData = (RedirectInjector$ConstructorRedirectData)injectionNodes$InjectionNode.getDecoration("ctor");
        if (RedirectInjector.llIIIIIlll(redirectInjector$ConstructorRedirectData)) {
            throw new InvalidInjectionException(this.info, String.format("%s ctor redirector has no metadata, the injector failed a preprocessing phase", this.annotationType));
        }
        TypeInsnNode typeInsnNode = (TypeInsnNode)injectionNodes$InjectionNode.getCurrentTarget();
        AbstractInsnNode abstractInsnNode = target.get(target.indexOf(typeInsnNode) + 1);
        MethodInsnNode methodInsnNode = target.findInitNodeFor(typeInsnNode);
        if (RedirectInjector.llIIIIIlll(methodInsnNode)) {
            if (RedirectInjector.llIIIIIlIl(redirectInjector$ConstructorRedirectData.wildcard ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.format("%s ctor invocation was not found in %s", this.annotationType, target));
            }
            return;
        }
        if (RedirectInjector.llIIIIIllI(abstractInsnNode.getOpcode(), 89)) {
            n = 1;
            "".length();
            if (-"   ".length() > 0) {
                return;
            }
        } else {
            n = 0;
        }
        int n2 = n;
        String string = methodInsnNode.desc.replace(")V", String.valueOf(new StringBuilder().append(")L").append(typeInsnNode.desc).append(";")));
        int n3 = 0;
        try {
            n3 = this.checkDescriptor(string, target, "constructor");
        }
        catch (InvalidInjectionException invalidInjectionException) {
            if (RedirectInjector.llIIIIIlIl(redirectInjector$ConstructorRedirectData.wildcard ? 1 : 0)) {
                throw invalidInjectionException;
            }
            return;
        }
        "".length();
        if (" ".length() <= 0) {
            return;
        }
        if (RedirectInjector.llIIIIIlII(n2)) {
            target.removeNode(abstractInsnNode);
        }
        if (RedirectInjector.llIIIIIlII(this.isStatic ? 1 : 0)) {
            target.removeNode(typeInsnNode);
            "".length();
            if (((0xA3 ^ 0xAC ^ (0x9E ^ 0xA0)) & (0xE1 ^ 0xC1 ^ (0x54 ^ 0x45) ^ -" ".length())) > 0) {
                return;
            }
        } else {
            target.replaceNode((AbstractInsnNode)typeInsnNode, new VarInsnNode(25, 0));
        }
        InsnList insnList = new InsnList();
        if (RedirectInjector.llIIIIIlII(n3)) {
            this.pushArgs(target.arguments, insnList, target.getArgIndices(), 0, target.arguments.length);
            target.addToStack(Bytecode.getArgsSize(target.arguments));
        }
        this.invokeHandler(insnList);
        "".length();
        if (RedirectInjector.llIIIIIlII(n2)) {
            LabelNode labelNode = new LabelNode();
            insnList.add(new InsnNode(89));
            insnList.add(new JumpInsnNode(199, labelNode));
            this.throwException(insnList, "java/lang/NullPointerException", String.format("%s constructor handler %s returned null for %s", this.annotationType, this, typeInsnNode.desc.replace('/', '.')));
            insnList.add(labelNode);
            target.addToStack(1);
            "".length();
            if ("  ".length() < "  ".length()) {
                return;
            }
        } else {
            insnList.add(new InsnNode(87));
        }
        target.replaceNode((AbstractInsnNode)methodInsnNode, insnList);
        ++redirectInjector$ConstructorRedirectData.injected;
    }

    private static String getGetArrayHandlerDescriptor(AbstractInsnNode abstractInsnNode, Type type, Type type2) {
        if (RedirectInjector.llIIIIIIIl(abstractInsnNode) && RedirectInjector.llIIIIIllI(abstractInsnNode.getOpcode(), 190)) {
            return Bytecode.generateDescriptor(Type.INT_TYPE, RedirectInjector.getArrayArgs(type2, 0, new Type[0]));
        }
        return Bytecode.generateDescriptor(type, RedirectInjector.getArrayArgs(type2, 1, new Type[0]));
    }

    private static Type[] getArrayArgs(Type type, int n, Type ... typeArray) {
        int n2 = type.getDimensions() + n;
        Type[] typeArray2 = new Type[n2 + typeArray.length];
        int n3 = 0;
        while (RedirectInjector.llIIIIlIII(n3, typeArray2.length)) {
            Type type2;
            if (RedirectInjector.llIIIIIlIl(n3)) {
                type2 = type;
                "".length();
                if (((0x65 ^ 0x6E) & ~(3 ^ 8)) != 0) {
                    return null;
                }
            } else if (RedirectInjector.llIIIIlIII(n3, n2)) {
                type2 = Type.INT_TYPE;
                "".length();
                if (" ".length() != " ".length()) {
                    return null;
                }
            } else {
                type2 = typeArray[n2 - n3];
            }
            typeArray2[n3] = type2;
            ++n3;
            "".length();
            if ("  ".length() <= "  ".length()) continue;
            return null;
        }
        return typeArray2;
    }

    private static boolean llIIIIIllI(int n, int n2) {
        return n == n2;
    }

    private static boolean llIIIIIIll(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIIIIlIII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIIIIlIIl(int n, int n2) {
        return n > n2;
    }

    private static boolean llIIIIIIlI(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIIIIIIIl(Object object) {
        return object != null;
    }

    private static boolean llIIIIIlll(Object object) {
        return object == null;
    }

    private static boolean llIIIIIlII(int n) {
        return n != 0;
    }

    private static boolean llIIIIIlIl(int n) {
        return n == 0;
    }

    private static boolean llIIIIlIlI(int n) {
        return n > 0;
    }

    private static boolean llIIIIlIll(int n, int n2) {
        return n != n2;
    }
}

