/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.BiMap
 *  com.google.common.collect.HashBiMap
 */
package org.spongepowered.asm.mixin.injection.invoke.arg;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import java.util.HashMap;
import java.util.Map;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.util.CheckClassAdapter;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import org.spongepowered.asm.mixin.transformer.ext.IClassGenerator;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.SignaturePrinter;
import org.spongepowered.asm.util.asm.MethodVisitorEx;

public final class ArgsClassGenerator
implements IClassGenerator {
    public static final String ARGS_NAME;
    public static final String ARGS_REF;
    public static final String GETTER_PREFIX;
    private static final String CLASS_NAME_BASE;
    private static final String OBJECT;
    private static final String OBJECT_ARRAY;
    private static final String VALUES_FIELD;
    private static final String CTOR_DESC;
    private static final String SET;
    private static final String SET_DESC;
    private static final String SETALL;
    private static final String SETALL_DESC;
    private static final String NPE;
    private static final String NPE_CTOR_DESC;
    private static final String AIOOBE;
    private static final String AIOOBE_CTOR_DESC;
    private static final String ACE;
    private static final String ACE_CTOR_DESC;
    private int nextIndex = 1;
    private final BiMap<String, String> classNames = HashBiMap.create();
    private final Map<String, byte[]> classBytes = new HashMap<String, byte[]>();

    public String getClassName(String string) {
        String string2 = Bytecode.changeDescriptorReturnType(string, "V");
        String string3 = (String)this.classNames.get((Object)string2);
        if (ArgsClassGenerator.lllIIlIIlII(string3)) {
            string3 = String.format("%s%d", "org.spongepowered.asm.synthetic.args.Args$", this.nextIndex++);
            this.classNames.put((Object)string2, (Object)string3);
            "".length();
        }
        return string3;
    }

    public String getClassRef(String string) {
        return this.getClassName(string).replace('.', '/');
    }

    @Override
    public byte[] generate(String string) {
        return this.getBytes(string);
    }

    public byte[] getBytes(String string) {
        byte[] byArray = this.classBytes.get(string);
        if (ArgsClassGenerator.lllIIlIIlII(byArray)) {
            String string2 = (String)this.classNames.inverse().get((Object)string);
            if (ArgsClassGenerator.lllIIlIIlII(string2)) {
                return null;
            }
            byArray = this.generateClass(string, string2);
            this.classBytes.put(string, byArray);
            "".length();
        }
        return byArray;
    }

    private byte[] generateClass(String string, String string2) {
        String string3 = string.replace('.', '/');
        Type[] typeArray = Type.getArgumentTypes(string2);
        ClassWriter classWriter = new ClassWriter(2);
        ClassVisitor classVisitor = classWriter;
        if (ArgsClassGenerator.lllIIlIIlIl(MixinEnvironment.getCurrentEnvironment().getOption(MixinEnvironment$Option.DEBUG_VERIFY) ? 1 : 0)) {
            classVisitor = new CheckClassAdapter(classWriter);
        }
        classVisitor.visit(50, 4129, string3, null, ARGS_REF, null);
        classVisitor.visitSource(String.valueOf(new StringBuilder().append(string.substring(string.lastIndexOf(46) + 1)).append(".java")), null);
        this.generateCtor(string3, string2, typeArray, classVisitor);
        this.generateToString(string3, string2, typeArray, classVisitor);
        this.generateFactory(string3, string2, typeArray, classVisitor);
        this.generateSetters(string3, string2, typeArray, classVisitor);
        this.generateGetters(string3, string2, typeArray, classVisitor);
        classVisitor.visitEnd();
        return classWriter.toByteArray();
    }

    private void generateCtor(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        MethodVisitor methodVisitor = classVisitor.visitMethod(2, "<init>", "([Ljava/lang/Object;)V", null, null);
        methodVisitor.visitCode();
        methodVisitor.visitVarInsn(25, 0);
        methodVisitor.visitVarInsn(25, 1);
        methodVisitor.visitMethodInsn(183, ARGS_REF, "<init>", "([Ljava/lang/Object;)V", false);
        methodVisitor.visitInsn(177);
        methodVisitor.visitMaxs(2, 2);
        methodVisitor.visitEnd();
    }

    private void generateToString(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        MethodVisitor methodVisitor = classVisitor.visitMethod(1, "toString", "()Ljava/lang/String;", null, null);
        methodVisitor.visitCode();
        methodVisitor.visitLdcInsn(String.valueOf(new StringBuilder().append("Args").append(ArgsClassGenerator.getSignature(typeArray))));
        methodVisitor.visitInsn(176);
        methodVisitor.visitMaxs(1, 1);
        methodVisitor.visitEnd();
    }

    private void generateFactory(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        String string3 = Bytecode.changeDescriptorReturnType(string2, String.valueOf(new StringBuilder().append("L").append(string).append(";")));
        MethodVisitorEx methodVisitorEx = new MethodVisitorEx(classVisitor.visitMethod(9, "of", string3, null, null));
        methodVisitorEx.visitCode();
        methodVisitorEx.visitTypeInsn(187, string);
        methodVisitorEx.visitInsn(89);
        methodVisitorEx.visitConstant((byte)typeArray.length);
        methodVisitorEx.visitTypeInsn(189, "java/lang/Object");
        byte by = 0;
        Type[] typeArray2 = typeArray;
        int n = typeArray2.length;
        int n2 = 0;
        while (ArgsClassGenerator.lllIIlIIllI(n2, n)) {
            Type type = typeArray2[n2];
            methodVisitorEx.visitInsn(89);
            methodVisitorEx.visitConstant(by);
            methodVisitorEx.visitVarInsn(type.getOpcode(21), by);
            ArgsClassGenerator.box(methodVisitorEx, type);
            methodVisitorEx.visitInsn(83);
            by = (byte)(by + type.getSize());
            ++n2;
            "".length();
            if (null == null) continue;
            return;
        }
        methodVisitorEx.visitMethodInsn(183, string, "<init>", "([Ljava/lang/Object;)V", false);
        methodVisitorEx.visitInsn(176);
        methodVisitorEx.visitMaxs(6, Bytecode.getArgsSize(typeArray));
        methodVisitorEx.visitEnd();
    }

    private void generateGetters(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        byte by = 0;
        Type[] typeArray2 = typeArray;
        int n = typeArray2.length;
        int n2 = 0;
        while (ArgsClassGenerator.lllIIlIIllI(n2, n)) {
            Type type = typeArray2[n2];
            String string3 = String.valueOf(new StringBuilder().append("$").append(by));
            String string4 = String.valueOf(new StringBuilder().append("()").append(type.getDescriptor()));
            MethodVisitorEx methodVisitorEx = new MethodVisitorEx(classVisitor.visitMethod(1, string3, string4, null, null));
            methodVisitorEx.visitCode();
            methodVisitorEx.visitVarInsn(25, 0);
            methodVisitorEx.visitFieldInsn(180, string, "values", "[Ljava/lang/Object;");
            methodVisitorEx.visitConstant(by);
            methodVisitorEx.visitInsn(50);
            ArgsClassGenerator.unbox(methodVisitorEx, type);
            methodVisitorEx.visitInsn(type.getOpcode(172));
            methodVisitorEx.visitMaxs(2, 1);
            methodVisitorEx.visitEnd();
            by = (byte)(by + 1);
            ++n2;
            "".length();
            if (((9 + 99 - 0 + 20 ^ 34 + 117 - 104 + 98) & (0x6C ^ 3 ^ (0x71 ^ 0xF) ^ -" ".length())) <= "  ".length()) continue;
            return;
        }
    }

    private void generateSetters(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        this.generateIndexedSetter(string, string2, typeArray, classVisitor);
        this.generateMultiSetter(string, string2, typeArray, classVisitor);
    }

    private void generateIndexedSetter(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        MethodVisitorEx methodVisitorEx = new MethodVisitorEx(classVisitor.visitMethod(1, "set", "(ILjava/lang/Object;)V", null, null));
        methodVisitorEx.visitCode();
        Label label = new Label();
        Label label2 = new Label();
        Label[] labelArray = new Label[typeArray.length];
        int n = 0;
        while (ArgsClassGenerator.lllIIlIIllI(n, labelArray.length)) {
            labelArray[n] = new Label();
            ++n;
            "".length();
            if (-" ".length() < (0x69 ^ 0x6D)) continue;
            return;
        }
        methodVisitorEx.visitVarInsn(25, 0);
        methodVisitorEx.visitFieldInsn(180, string, "values", "[Ljava/lang/Object;");
        n = 0;
        while (ArgsClassGenerator.lllIIlIIllI(n, typeArray.length)) {
            methodVisitorEx.visitVarInsn(21, 1);
            methodVisitorEx.visitConstant((byte)n);
            methodVisitorEx.visitJumpInsn(159, labelArray[n]);
            n = (byte)(n + 1);
            "".length();
            if (null == null) continue;
            return;
        }
        ArgsClassGenerator.throwAIOOBE(methodVisitorEx, 1);
        n = 0;
        while (ArgsClassGenerator.lllIIlIIllI(n, typeArray.length)) {
            Label label3;
            String string3;
            String string4 = Bytecode.getBoxingType(typeArray[n]);
            methodVisitorEx.visitLabel(labelArray[n]);
            methodVisitorEx.visitVarInsn(21, 1);
            methodVisitorEx.visitVarInsn(25, 2);
            if (ArgsClassGenerator.lllIIlIIlll(string4)) {
                string3 = string4;
                "".length();
                if ("   ".length() != "   ".length()) {
                    return;
                }
            } else {
                string3 = typeArray[n].getInternalName();
            }
            methodVisitorEx.visitTypeInsn(192, string3);
            if (ArgsClassGenerator.lllIIlIIlll(string4)) {
                label3 = label2;
                "".length();
                if ("   ".length() <= ((166 + 191 - 171 + 55 ^ 2 + 157 - 113 + 118) & (83 + 75 - 28 + 17 ^ 188 + 102 - 219 + 127 ^ -" ".length()))) {
                    return;
                }
            } else {
                label3 = label;
            }
            methodVisitorEx.visitJumpInsn(167, label3);
            ++n;
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
        methodVisitorEx.visitLabel(label2);
        methodVisitorEx.visitInsn(89);
        methodVisitorEx.visitJumpInsn(199, label);
        ArgsClassGenerator.throwNPE(methodVisitorEx, "Argument with primitive type cannot be set to NULL");
        methodVisitorEx.visitLabel(label);
        methodVisitorEx.visitInsn(83);
        methodVisitorEx.visitInsn(177);
        methodVisitorEx.visitMaxs(6, 3);
        methodVisitorEx.visitEnd();
    }

    private void generateMultiSetter(String string, String string2, Type[] typeArray, ClassVisitor classVisitor) {
        MethodVisitorEx methodVisitorEx = new MethodVisitorEx(classVisitor.visitMethod(1, "setAll", "([Ljava/lang/Object;)V", null, null));
        methodVisitorEx.visitCode();
        Label label = new Label();
        Label label2 = new Label();
        int n = 6;
        methodVisitorEx.visitVarInsn(25, 1);
        methodVisitorEx.visitInsn(190);
        methodVisitorEx.visitInsn(89);
        methodVisitorEx.visitConstant((byte)typeArray.length);
        methodVisitorEx.visitJumpInsn(159, label);
        methodVisitorEx.visitTypeInsn(187, "org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentCountException");
        methodVisitorEx.visitInsn(89);
        methodVisitorEx.visitInsn(93);
        methodVisitorEx.visitInsn(88);
        methodVisitorEx.visitConstant((byte)typeArray.length);
        methodVisitorEx.visitLdcInsn(ArgsClassGenerator.getSignature(typeArray));
        methodVisitorEx.visitMethodInsn(183, "org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentCountException", "<init>", "(IILjava/lang/String;)V", false);
        methodVisitorEx.visitInsn(191);
        methodVisitorEx.visitLabel(label);
        methodVisitorEx.visitInsn(87);
        methodVisitorEx.visitVarInsn(25, 0);
        methodVisitorEx.visitFieldInsn(180, string, "values", "[Ljava/lang/Object;");
        byte by = 0;
        while (ArgsClassGenerator.lllIIlIIllI(by, typeArray.length)) {
            String string3;
            methodVisitorEx.visitInsn(89);
            methodVisitorEx.visitConstant(by);
            methodVisitorEx.visitVarInsn(25, 1);
            methodVisitorEx.visitConstant(by);
            methodVisitorEx.visitInsn(50);
            String string4 = Bytecode.getBoxingType(typeArray[by]);
            if (ArgsClassGenerator.lllIIlIIlll(string4)) {
                string3 = string4;
                "".length();
                if ("   ".length() >= (6 ^ 2)) {
                    return;
                }
            } else {
                string3 = typeArray[by].getInternalName();
            }
            methodVisitorEx.visitTypeInsn(192, string3);
            if (ArgsClassGenerator.lllIIlIIlll(string4)) {
                methodVisitorEx.visitInsn(89);
                methodVisitorEx.visitJumpInsn(198, label2);
                n = 7;
            }
            methodVisitorEx.visitInsn(83);
            by = (byte)(by + 1);
            "".length();
            if ((0xAD ^ 0xA9) >= (0xC5 ^ 0xC1)) continue;
            return;
        }
        methodVisitorEx.visitInsn(177);
        methodVisitorEx.visitLabel(label2);
        ArgsClassGenerator.throwNPE(methodVisitorEx, "Argument with primitive type cannot be set to NULL");
        methodVisitorEx.visitInsn(177);
        methodVisitorEx.visitMaxs(n, 2);
        methodVisitorEx.visitEnd();
    }

    private static void throwNPE(MethodVisitorEx methodVisitorEx, String string) {
        methodVisitorEx.visitTypeInsn(187, "java/lang/NullPointerException");
        methodVisitorEx.visitInsn(89);
        methodVisitorEx.visitLdcInsn(string);
        methodVisitorEx.visitMethodInsn(183, "java/lang/NullPointerException", "<init>", "(Ljava/lang/String;)V", false);
        methodVisitorEx.visitInsn(191);
    }

    private static void throwAIOOBE(MethodVisitorEx methodVisitorEx, int n) {
        methodVisitorEx.visitTypeInsn(187, "org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentIndexOutOfBoundsException");
        methodVisitorEx.visitInsn(89);
        methodVisitorEx.visitVarInsn(21, n);
        methodVisitorEx.visitMethodInsn(183, "org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentIndexOutOfBoundsException", "<init>", "(I)V", false);
        methodVisitorEx.visitInsn(191);
    }

    private static void box(MethodVisitor methodVisitor, Type type) {
        String string = Bytecode.getBoxingType(type);
        if (ArgsClassGenerator.lllIIlIIlll(string)) {
            String string2 = String.format("(%s)L%s;", type.getDescriptor(), string);
            methodVisitor.visitMethodInsn(184, string, "valueOf", string2, false);
        }
    }

    private static void unbox(MethodVisitor methodVisitor, Type type) {
        String string = Bytecode.getBoxingType(type);
        if (ArgsClassGenerator.lllIIlIIlll(string)) {
            String string2 = Bytecode.getUnboxingMethod(type);
            String string3 = String.valueOf(new StringBuilder().append("()").append(type.getDescriptor()));
            methodVisitor.visitTypeInsn(192, string);
            methodVisitor.visitMethodInsn(182, string, string2, string3, false);
            "".length();
            if (-" ".length() > 0) {
                return;
            }
        } else {
            methodVisitor.visitTypeInsn(192, type.getInternalName());
        }
    }

    private static String getSignature(Type[] typeArray) {
        return new SignaturePrinter("", null, typeArray).setFullyQualified(true).getFormattedArgs();
    }

    static {
        CLASS_NAME_BASE = "org.spongepowered.asm.synthetic.args.Args$";
        GETTER_PREFIX = "$";
        ACE = "org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentCountException";
        CTOR_DESC = "([Ljava/lang/Object;)V";
        OBJECT = "java/lang/Object";
        VALUES_FIELD = "values";
        NPE_CTOR_DESC = "(Ljava/lang/String;)V";
        SETALL = "setAll";
        NPE = "java/lang/NullPointerException";
        ACE_CTOR_DESC = "(IILjava/lang/String;)V";
        SET = "set";
        AIOOBE_CTOR_DESC = "(I)V";
        OBJECT_ARRAY = "[Ljava/lang/Object;";
        SET_DESC = "(ILjava/lang/Object;)V";
        SETALL_DESC = "([Ljava/lang/Object;)V";
        AIOOBE = "org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentIndexOutOfBoundsException";
        ARGS_NAME = Args.class.getName();
        ARGS_REF = ARGS_NAME.replace('.', '/');
    }

    private static boolean lllIIlIIllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIIlIIlll(Object object) {
        return object != null;
    }

    private static boolean lllIIlIIlII(Object object) {
        return object == null;
    }

    private static boolean lllIIlIIlIl(int n) {
        return n != 0;
    }
}

