/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke.arg;

public class ArgumentCountException
extends IllegalArgumentException {
    private static final long serialVersionUID = 1L;

    public ArgumentCountException(int n, int n2, String string) {
        super(String.valueOf(new StringBuilder().append("Invalid number of arguments for setAll, received ").append(n).append(" but expected ").append(n2).append(": ").append(string)));
    }
}

