/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke.util;

enum InsnFinder$AnalyzerState {
    SEARCH,
    ANALYSE,
    COMPLETE;

}

