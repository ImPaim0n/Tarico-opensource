/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke.util;

import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;
import org.spongepowered.asm.lib.tree.analysis.Frame;
import org.spongepowered.asm.lib.tree.analysis.Interpreter;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder$AnalysisResultException;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder$AnalyzerState;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder$PopAnalyzer;

class InsnFinder$PopAnalyzer$PopFrame
extends Frame<BasicValue> {
    private AbstractInsnNode current;
    private InsnFinder$AnalyzerState state;
    private int depth;
    final /* synthetic */ InsnFinder$PopAnalyzer this$0;

    public InsnFinder$PopAnalyzer$PopFrame(InsnFinder$PopAnalyzer insnFinder$PopAnalyzer, int n, int n2) {
        this.this$0 = insnFinder$PopAnalyzer;
        super(n, n2);
        this.state = InsnFinder$AnalyzerState.SEARCH;
        this.depth = 0;
    }

    @Override
    public void execute(AbstractInsnNode abstractInsnNode, Interpreter<BasicValue> interpreter) {
        this.current = abstractInsnNode;
        super.execute(abstractInsnNode, interpreter);
    }

    @Override
    public void push(BasicValue basicValue) {
        if (InsnFinder$PopAnalyzer$PopFrame.lIllIlIIIll(this.current, this.this$0.node) && InsnFinder$PopAnalyzer$PopFrame.lIllIlIIIll((Object)this.state, (Object)InsnFinder$AnalyzerState.SEARCH)) {
            this.state = InsnFinder$AnalyzerState.ANALYSE;
            ++this.depth;
            "".length();
            if (((0x96 ^ 0x82 ^ (0x70 ^ 0x5C)) & (0x76 ^ 0xF ^ (0x10 ^ 0x51) ^ -" ".length())) != 0) {
                return;
            }
        } else if (InsnFinder$PopAnalyzer$PopFrame.lIllIlIIIll((Object)this.state, (Object)InsnFinder$AnalyzerState.ANALYSE)) {
            ++this.depth;
        }
        super.push(basicValue);
    }

    @Override
    public BasicValue pop() {
        if (InsnFinder$PopAnalyzer$PopFrame.lIllIlIIIll((Object)this.state, (Object)InsnFinder$AnalyzerState.ANALYSE) && InsnFinder$PopAnalyzer$PopFrame.lIllIlIIlII(--this.depth)) {
            this.state = InsnFinder$AnalyzerState.COMPLETE;
            throw new InsnFinder$AnalysisResultException(this.current);
        }
        return (BasicValue)super.pop();
    }

    private static boolean lIllIlIIIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIllIlIIlII(int n) {
        return n == 0;
    }
}

