/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.invoke.util;

import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.analysis.Analyzer;
import org.spongepowered.asm.lib.tree.analysis.BasicInterpreter;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;
import org.spongepowered.asm.lib.tree.analysis.Frame;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder$PopAnalyzer$PopFrame;

class InsnFinder$PopAnalyzer
extends Analyzer<BasicValue> {
    protected final AbstractInsnNode node;

    public InsnFinder$PopAnalyzer(AbstractInsnNode abstractInsnNode) {
        super(new BasicInterpreter());
        this.node = abstractInsnNode;
    }

    @Override
    protected Frame<BasicValue> newFrame(int n, int n2) {
        return new InsnFinder$PopAnalyzer$PopFrame(this, n, n2);
    }
}

