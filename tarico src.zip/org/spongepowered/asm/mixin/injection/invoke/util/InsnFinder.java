/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.injection.invoke.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.analysis.AnalyzerException;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder$AnalysisResultException;
import org.spongepowered.asm.mixin.injection.invoke.util.InsnFinder$PopAnalyzer;
import org.spongepowered.asm.mixin.injection.struct.Target;

public class InsnFinder {
    private static final Logger logger = LogManager.getLogger((String)"mixin");

    public AbstractInsnNode findPopInsn(Target target, AbstractInsnNode abstractInsnNode) {
        try {
            new InsnFinder$PopAnalyzer(abstractInsnNode).analyze(target.classNode.name, target.method);
            "".length();
            "".length();
        }
        catch (AnalyzerException analyzerException) {
            if (InsnFinder.llIIIlI(analyzerException.getCause() instanceof InsnFinder$AnalysisResultException)) {
                return ((InsnFinder$AnalysisResultException)analyzerException.getCause()).getResult();
            }
            logger.catching((Throwable)analyzerException);
        }
        if ((0x9E ^ 0x9A) <= 0) {
            return null;
        }
        return null;
    }

    private static boolean llIIIlI(int n) {
        return n != 0;
    }
}

