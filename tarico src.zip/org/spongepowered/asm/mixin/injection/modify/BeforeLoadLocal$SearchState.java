/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import java.util.Collection;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;

class BeforeLoadLocal$SearchState {
    private final boolean print;
    private final int targetOrdinal;
    private int ordinal = 0;
    private boolean pendingCheck = false;
    private boolean found = false;
    private VarInsnNode varNode;

    BeforeLoadLocal$SearchState(int n, boolean bl) {
        this.targetOrdinal = n;
        this.print = bl;
    }

    boolean success() {
        return this.found;
    }

    boolean isPendingCheck() {
        return this.pendingCheck;
    }

    void setPendingCheck() {
        this.pendingCheck = true;
    }

    void register(VarInsnNode varInsnNode) {
        this.varNode = varInsnNode;
    }

    void check(Collection<AbstractInsnNode> collection, AbstractInsnNode abstractInsnNode, int n) {
        this.pendingCheck = false;
        if (BeforeLoadLocal$SearchState.lIIIIIlllIIl(n, this.varNode.var) && (!BeforeLoadLocal$SearchState.lIIIIIlllIlI(n, -2) || BeforeLoadLocal$SearchState.lIIIIIlllIll(this.print ? 1 : 0))) {
            return;
        }
        if (!BeforeLoadLocal$SearchState.lIIIIIlllIIl(this.targetOrdinal, -1) || BeforeLoadLocal$SearchState.lIIIIIllllII(this.targetOrdinal, this.ordinal)) {
            collection.add(abstractInsnNode);
            "".length();
            this.found = true;
        }
        ++this.ordinal;
        this.varNode = null;
    }

    private static boolean lIIIIIllllII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIIlllIlI(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIIIlllIll(int n) {
        return n == 0;
    }

    private static boolean lIIIIIlllIIl(int n, int n2) {
        return n != n2;
    }
}

