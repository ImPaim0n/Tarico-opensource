/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import java.util.Collection;
import java.util.ListIterator;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.modify.BeforeLoadLocal$SearchState;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator;
import org.spongepowered.asm.mixin.injection.modify.ModifyVariableInjector$ContextualInjectionPoint;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.struct.Target;

@InjectionPoint.AtCode(value="LOAD")
public class BeforeLoadLocal
extends ModifyVariableInjector$ContextualInjectionPoint {
    private final Type returnType;
    private final LocalVariableDiscriminator discriminator;
    private final int opcode;
    private final int ordinal;
    private boolean opcodeAfter;

    protected BeforeLoadLocal(InjectionPointData injectionPointData) {
        this(injectionPointData, 21, false);
    }

    protected BeforeLoadLocal(InjectionPointData injectionPointData, int n, boolean bl) {
        super(injectionPointData.getContext());
        this.returnType = injectionPointData.getMethodReturnType();
        this.discriminator = injectionPointData.getLocalVariableDiscriminator();
        this.opcode = injectionPointData.getOpcode(this.returnType.getOpcode(n));
        this.ordinal = injectionPointData.getOrdinal();
        this.opcodeAfter = bl;
    }

    @Override
    boolean find(Target target, Collection<AbstractInsnNode> collection) {
        BeforeLoadLocal$SearchState beforeLoadLocal$SearchState = new BeforeLoadLocal$SearchState(this.ordinal, this.discriminator.printLVT());
        ListIterator<AbstractInsnNode> listIterator = target.method.instructions.iterator();
        while (BeforeLoadLocal.lIIIllI(listIterator.hasNext() ? 1 : 0)) {
            int n;
            AbstractInsnNode abstractInsnNode = listIterator.next();
            if (BeforeLoadLocal.lIIIllI(beforeLoadLocal$SearchState.isPendingCheck() ? 1 : 0)) {
                n = this.discriminator.findLocal(this.returnType, this.discriminator.isArgsOnly(), target, abstractInsnNode);
                beforeLoadLocal$SearchState.check(collection, abstractInsnNode, n);
                "".length();
                if (((0x80 ^ 0xBB) & ~(0xBD ^ 0x86)) != 0) {
                    return ((0x7C ^ 0x29) & ~(0x46 ^ 0x13)) != 0;
                }
            } else if (BeforeLoadLocal.lIIIllI(abstractInsnNode instanceof VarInsnNode) && BeforeLoadLocal.lIIIlll(abstractInsnNode.getOpcode(), this.opcode) && (!BeforeLoadLocal.lIIlIII(this.ordinal, -1) || BeforeLoadLocal.lIIlIIl(beforeLoadLocal$SearchState.success() ? 1 : 0))) {
                beforeLoadLocal$SearchState.register((VarInsnNode)abstractInsnNode);
                if (BeforeLoadLocal.lIIIllI(this.opcodeAfter ? 1 : 0)) {
                    beforeLoadLocal$SearchState.setPendingCheck();
                    "".length();
                    if ("  ".length() < 0) {
                        return ((0xE1 ^ 0xA7) & ~(0x5A ^ 0x1C)) != 0;
                    }
                } else {
                    n = this.discriminator.findLocal(this.returnType, this.discriminator.isArgsOnly(), target, abstractInsnNode);
                    beforeLoadLocal$SearchState.check(collection, abstractInsnNode, n);
                }
            }
            "".length();
            if (-"   ".length() < 0) continue;
            return ((44 + 28 - -47 + 43 ^ 135 + 7 - 73 + 123) & (0xBE ^ 0xA0 ^ (0x6F ^ 0x13) ^ -" ".length())) != 0;
        }
        return beforeLoadLocal$SearchState.success();
    }

    private static boolean lIIIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIllI(int n) {
        return n != 0;
    }

    private static boolean lIIlIIl(int n) {
        return n == 0;
    }

    private static boolean lIIlIII(int n, int n2) {
        return n != n2;
    }
}

