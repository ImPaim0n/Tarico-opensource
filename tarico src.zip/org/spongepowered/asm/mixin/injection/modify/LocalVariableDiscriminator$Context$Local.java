/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator$Context;

public class LocalVariableDiscriminator$Context$Local {
    int ord = 0;
    String name;
    Type type;
    final /* synthetic */ LocalVariableDiscriminator.Context this$0;

    public LocalVariableDiscriminator$Context$Local(LocalVariableDiscriminator.Context context, String string, Type type) {
        this.this$0 = context;
        this.name = string;
        this.type = type;
    }

    public String toString() {
        return String.format("Local[ordinal=%d, name=%s, type=%s]", this.ord, this.name, this.type);
    }
}

