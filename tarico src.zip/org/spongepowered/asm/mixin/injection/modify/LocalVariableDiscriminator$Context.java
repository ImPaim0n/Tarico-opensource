/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import java.util.HashMap;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator$Context$Local;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.Locals;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.PrettyPrinter$IPrettyPrintable;
import org.spongepowered.asm.util.SignaturePrinter;

public class LocalVariableDiscriminator$Context
implements PrettyPrinter$IPrettyPrintable {
    final Target target;
    final Type returnType;
    final AbstractInsnNode node;
    final int baseArgIndex;
    final LocalVariableDiscriminator$Context$Local[] locals;
    private final boolean isStatic;

    public LocalVariableDiscriminator$Context(Type type, boolean bl, Target target, AbstractInsnNode abstractInsnNode) {
        int n;
        this.isStatic = Bytecode.methodIsStatic(target.method);
        this.returnType = type;
        this.target = target;
        this.node = abstractInsnNode;
        if (LocalVariableDiscriminator$Context.lIllIIllIl(this.isStatic ? 1 : 0)) {
            n = 0;
            "".length();
            if (((0xA ^ 0x42) & ~(0xEE ^ 0xA6)) != 0) {
                throw null;
            }
        } else {
            n = 1;
        }
        this.baseArgIndex = n;
        this.locals = this.initLocals(target, bl, abstractInsnNode);
        this.initOrdinals();
    }

    private LocalVariableDiscriminator$Context$Local[] initLocals(Target target, boolean bl, AbstractInsnNode abstractInsnNode) {
        Object[] objectArray;
        if (LocalVariableDiscriminator$Context.lIllIIlllI(bl ? 1 : 0) && LocalVariableDiscriminator$Context.lIllIIllll(objectArray = Locals.getLocalsAt(target.classNode, target.method, abstractInsnNode))) {
            LocalVariableDiscriminator$Context$Local[] localVariableDiscriminator$Context$LocalArray = new LocalVariableDiscriminator$Context$Local[objectArray.length];
            int n = 0;
            while (LocalVariableDiscriminator$Context.lIllIlIIII(n, objectArray.length)) {
                if (LocalVariableDiscriminator$Context.lIllIIllll(objectArray[n])) {
                    localVariableDiscriminator$Context$LocalArray[n] = new LocalVariableDiscriminator$Context$Local(this, ((LocalVariableNode)objectArray[n]).name, Type.getType(((LocalVariableNode)objectArray[n]).desc));
                }
                ++n;
                "".length();
                if ((3 + 129 - 79 + 84 ^ 2 + 3 - -22 + 113) > 0) continue;
                return null;
            }
            return localVariableDiscriminator$Context$LocalArray;
        }
        objectArray = new LocalVariableDiscriminator$Context$Local[this.baseArgIndex + target.arguments.length];
        if (LocalVariableDiscriminator$Context.lIllIIlllI(this.isStatic ? 1 : 0)) {
            objectArray[0] = new LocalVariableDiscriminator$Context$Local(this, "this", Type.getType(target.classNode.name));
        }
        int n = this.baseArgIndex;
        while (LocalVariableDiscriminator$Context.lIllIlIIII(n, objectArray.length)) {
            Type type = target.arguments[n - this.baseArgIndex];
            objectArray[n] = new LocalVariableDiscriminator$Context$Local(this, String.valueOf(new StringBuilder().append("arg").append(n)), type);
            ++n;
            "".length();
            if (-(94 + 109 - 122 + 93 ^ 41 + 68 - 40 + 101) <= 0) continue;
            return null;
        }
        return objectArray;
    }

    private void initOrdinals() {
        HashMap<Type, Integer> hashMap = new HashMap<Type, Integer>();
        int n = 0;
        while (LocalVariableDiscriminator$Context.lIllIlIIII(n, this.locals.length)) {
            Integer n2 = 0;
            if (LocalVariableDiscriminator$Context.lIllIIllll(this.locals[n])) {
                int n3;
                n2 = (Integer)hashMap.get(this.locals[n].type);
                Type type = this.locals[n].type;
                if (LocalVariableDiscriminator$Context.lIllIlIIIl(n2)) {
                    n3 = 0;
                    "".length();
                    if ((0x1D ^ 0x18) <= 0) {
                        return;
                    }
                } else {
                    n3 = n2 + 1;
                }
                n2 = n3;
                hashMap.put(type, n2);
                "".length();
                this.locals[n].ord = n2;
            }
            ++n;
            "".length();
            if (" ".length() > -" ".length()) continue;
            return;
        }
    }

    @Override
    public void print(PrettyPrinter prettyPrinter) {
        prettyPrinter.add("%5s  %7s  %30s  %-50s  %s", "INDEX", "ORDINAL", "TYPE", "NAME", "CANDIDATE");
        "".length();
        int n = this.baseArgIndex;
        while (LocalVariableDiscriminator$Context.lIllIlIIII(n, this.locals.length)) {
            Object object;
            LocalVariableDiscriminator$Context$Local localVariableDiscriminator$Context$Local = this.locals[n];
            if (LocalVariableDiscriminator$Context.lIllIIllll(localVariableDiscriminator$Context$Local)) {
                String string;
                object = localVariableDiscriminator$Context$Local.type;
                String string2 = localVariableDiscriminator$Context$Local.name;
                int n2 = localVariableDiscriminator$Context$Local.ord;
                if (LocalVariableDiscriminator$Context.lIllIIllIl(this.returnType.equals(object) ? 1 : 0)) {
                    string = "YES";
                    "".length();
                    if ("   ".length() <= -" ".length()) {
                        return;
                    }
                } else {
                    string = "-";
                }
                String string3 = string;
                prettyPrinter.add("[%3d]    [%3d]  %30s  %-50s  %s", n, n2, SignaturePrinter.getTypeName((Type)object, false), string2, string3);
                "".length();
                "".length();
                if (-" ".length() != -" ".length()) {
                    return;
                }
            } else if (LocalVariableDiscriminator$Context.lIllIlIlIl(n)) {
                String string;
                int n3;
                object = this.locals[n - 1];
                if (LocalVariableDiscriminator$Context.lIllIIllll(object) && LocalVariableDiscriminator$Context.lIllIIllll(((LocalVariableDiscriminator$Context$Local)object).type) && LocalVariableDiscriminator$Context.lIllIlIllI(((LocalVariableDiscriminator$Context$Local)object).type.getSize(), 1)) {
                    n3 = 1;
                    "".length();
                    if ((0x15 ^ 0x11) == " ".length()) {
                        return;
                    }
                } else {
                    n3 = 0;
                }
                int n4 = n3;
                Object[] objectArray = new Object[2];
                objectArray[0] = n;
                if (LocalVariableDiscriminator$Context.lIllIIllIl(n4)) {
                    string = "<top>";
                    "".length();
                    if ("   ".length() < 0) {
                        return;
                    }
                } else {
                    string = "-";
                }
                objectArray[1] = string;
                prettyPrinter.add("[%3d]           %30s", objectArray);
                "".length();
            }
            ++n;
            "".length();
            if ((0x70 ^ 0x74) == (0xA8 ^ 0xAC)) continue;
            return;
        }
    }

    private static boolean lIllIlIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllIlIllI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllIIllll(Object object) {
        return object != null;
    }

    private static boolean lIllIlIIIl(Object object) {
        return object == null;
    }

    private static boolean lIllIIllIl(int n) {
        return n != 0;
    }

    private static boolean lIllIIlllI(int n) {
        return n == 0;
    }

    private static boolean lIllIlIlIl(int n) {
        return n > 0;
    }
}

