/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.mixin.injection.modify.InvalidImplicitDiscriminatorException;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator$Context;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator$Context$Local;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.util.Annotations;

public class LocalVariableDiscriminator {
    private final boolean argsOnly;
    private final int ordinal;
    private final int index;
    private final Set<String> names;
    private final boolean print;

    public LocalVariableDiscriminator(boolean bl, int n, int n2, Set<String> set, boolean bl2) {
        this.argsOnly = bl;
        this.ordinal = n;
        this.index = n2;
        this.names = Collections.unmodifiableSet(set);
        this.print = bl2;
    }

    public boolean isArgsOnly() {
        return this.argsOnly;
    }

    public int getOrdinal() {
        return this.ordinal;
    }

    public int getIndex() {
        return this.index;
    }

    public Set<String> getNames() {
        return this.names;
    }

    public boolean hasNames() {
        boolean bl;
        if (LocalVariableDiscriminator.llllllIIlIl(this.names.isEmpty() ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x59 ^ 0x47 ^ (0x50 ^ 0x43)) & (70 + 108 - 163 + 120 ^ 96 + 4 - 16 + 54 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean printLVT() {
        return this.print;
    }

    protected boolean isImplicit(LocalVariableDiscriminator$Context localVariableDiscriminator$Context) {
        boolean bl;
        if (LocalVariableDiscriminator.llllllIIllI(this.ordinal) && LocalVariableDiscriminator.llllllIIlll(this.index, localVariableDiscriminator$Context.baseArgIndex) && LocalVariableDiscriminator.llllllIlIII(this.names.isEmpty() ? 1 : 0)) {
            bl = true;
            "".length();
            if ((0x6E ^ 0x6B) <= 0) {
                return ((8 ^ 0x69) & ~(0x30 ^ 0x51)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int findLocal(Type type, boolean bl, Target target, AbstractInsnNode abstractInsnNode) {
        try {
            return this.findLocal(new LocalVariableDiscriminator$Context(type, bl, target, abstractInsnNode));
        }
        catch (InvalidImplicitDiscriminatorException invalidImplicitDiscriminatorException) {
            return -2;
        }
    }

    public int findLocal(LocalVariableDiscriminator$Context localVariableDiscriminator$Context) {
        if (LocalVariableDiscriminator.llllllIlIII(this.isImplicit(localVariableDiscriminator$Context) ? 1 : 0)) {
            return this.findImplicitLocal(localVariableDiscriminator$Context);
        }
        return this.findExplicitLocal(localVariableDiscriminator$Context);
    }

    private int findImplicitLocal(LocalVariableDiscriminator$Context localVariableDiscriminator$Context) {
        int n = 0;
        int n2 = 0;
        int n3 = localVariableDiscriminator$Context.baseArgIndex;
        while (LocalVariableDiscriminator.llllllIIlll(n3, localVariableDiscriminator$Context.locals.length)) {
            LocalVariableDiscriminator$Context$Local localVariableDiscriminator$Context$Local = localVariableDiscriminator$Context.locals[n3];
            if (LocalVariableDiscriminator.llllllIlIIl(localVariableDiscriminator$Context$Local)) {
                if (LocalVariableDiscriminator.llllllIIlIl(localVariableDiscriminator$Context$Local.type.equals(localVariableDiscriminator$Context.returnType) ? 1 : 0)) {
                    "".length();
                    if ("  ".length() == 0) {
                        return (0x4D ^ 0x18) & ~(0x92 ^ 0xC7);
                    }
                } else {
                    ++n2;
                    n = n3;
                }
            }
            ++n3;
            "".length();
            if (" ".length() > ((0x4A ^ 0x76) & ~(0x54 ^ 0x68))) continue;
            return (0x8D ^ 0x83) & ~(0x76 ^ 0x78);
        }
        if (LocalVariableDiscriminator.llllllIlIlI(n2, 1)) {
            return n;
        }
        throw new InvalidImplicitDiscriminatorException(String.valueOf(new StringBuilder().append("Found ").append(n2).append(" candidate variables but exactly 1 is required.")));
    }

    private int findExplicitLocal(LocalVariableDiscriminator$Context localVariableDiscriminator$Context) {
        int n = localVariableDiscriminator$Context.baseArgIndex;
        while (LocalVariableDiscriminator.llllllIIlll(n, localVariableDiscriminator$Context.locals.length)) {
            LocalVariableDiscriminator$Context$Local localVariableDiscriminator$Context$Local = localVariableDiscriminator$Context.locals[n];
            if (LocalVariableDiscriminator.llllllIlIIl(localVariableDiscriminator$Context$Local)) {
                if (LocalVariableDiscriminator.llllllIIlIl(localVariableDiscriminator$Context$Local.type.equals(localVariableDiscriminator$Context.returnType) ? 1 : 0)) {
                    "".length();
                    if (null != null) {
                        return (20 + 53 - 2 + 145 ^ 118 + 96 - 106 + 23) & (0xE8 ^ 0xBC ^ (0x5A ^ 0x55) ^ -" ".length());
                    }
                } else if (LocalVariableDiscriminator.llllllIlIll(this.ordinal, -1) ? LocalVariableDiscriminator.llllllIlIlI(this.ordinal, localVariableDiscriminator$Context$Local.ord) : (LocalVariableDiscriminator.llllllIllII(this.index, localVariableDiscriminator$Context.baseArgIndex) ? LocalVariableDiscriminator.llllllIlIlI(this.index, n) : LocalVariableDiscriminator.llllllIlIII(this.names.contains(localVariableDiscriminator$Context$Local.name) ? 1 : 0))) {
                    return n;
                }
            }
            ++n;
            "".length();
            if (" ".length() > 0) continue;
            return (0x65 ^ 0x25) & ~(0xD4 ^ 0x94);
        }
        return -1;
    }

    public static LocalVariableDiscriminator parse(AnnotationNode annotationNode) {
        boolean bl = Annotations.getValue(annotationNode, "argsOnly", Boolean.FALSE);
        int n = Annotations.getValue(annotationNode, "ordinal", -1);
        int n2 = Annotations.getValue(annotationNode, "index", -1);
        boolean bl2 = Annotations.getValue(annotationNode, "print", Boolean.FALSE);
        HashSet<String> hashSet = new HashSet<String>();
        List list = Annotations.getValue(annotationNode, "name", (List)null);
        if (LocalVariableDiscriminator.llllllIlIIl(list)) {
            hashSet.addAll(list);
            "".length();
        }
        return new LocalVariableDiscriminator(bl, n, n2, hashSet, bl2);
    }

    private static boolean llllllIlIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean llllllIllII(int n, int n2) {
        return n >= n2;
    }

    private static boolean llllllIIlll(int n, int n2) {
        return n < n2;
    }

    private static boolean llllllIlIll(int n, int n2) {
        return n > n2;
    }

    private static boolean llllllIlIIl(Object object) {
        return object != null;
    }

    private static boolean llllllIlIII(int n) {
        return n != 0;
    }

    private static boolean llllllIIlIl(int n) {
        return n == 0;
    }

    private static boolean llllllIIllI(int n) {
        return n < 0;
    }
}

