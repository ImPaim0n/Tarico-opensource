/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import java.util.Collection;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;

abstract class ModifyVariableInjector$ContextualInjectionPoint
extends InjectionPoint {
    protected final IMixinContext context;

    ModifyVariableInjector$ContextualInjectionPoint(IMixinContext iMixinContext) {
        this.context = iMixinContext;
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        throw new InvalidInjectionException(this.context, String.valueOf(new StringBuilder().append(this.getAtCode()).append(" injection point must be used in conjunction with @ModifyVariable")));
    }

    abstract boolean find(Target var1, Collection<AbstractInsnNode> var2);
}

