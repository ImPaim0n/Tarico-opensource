/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.modify;

import java.util.Collection;
import java.util.List;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.modify.InvalidImplicitDiscriminatorException;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator;
import org.spongepowered.asm.mixin.injection.modify.ModifyVariableInjector$Context;
import org.spongepowered.asm.mixin.injection.modify.ModifyVariableInjector$ContextualInjectionPoint;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.SignaturePrinter;

public class ModifyVariableInjector
extends Injector {
    private final LocalVariableDiscriminator discriminator;

    public ModifyVariableInjector(InjectionInfo injectionInfo, LocalVariableDiscriminator localVariableDiscriminator) {
        super(injectionInfo);
        this.discriminator = localVariableDiscriminator;
    }

    @Override
    protected boolean findTargetNodes(MethodNode methodNode, InjectionPoint injectionPoint, InsnList insnList, Collection<AbstractInsnNode> collection) {
        if (ModifyVariableInjector.lIIIlllIlll(injectionPoint instanceof ModifyVariableInjector$ContextualInjectionPoint)) {
            Target target = this.info.getContext().getTargetMethod(methodNode);
            return ((ModifyVariableInjector$ContextualInjectionPoint)injectionPoint).find(target, collection);
        }
        return injectionPoint.find(methodNode.desc, insnList, collection);
    }

    @Override
    protected void sanityCheck(Target target, List<InjectionPoint> list) {
        super.sanityCheck(target, list);
        if (ModifyVariableInjector.lIIIllllIII(target.isStatic ? 1 : 0, this.isStatic ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("'static' of variable modifier method does not match target in ").append(this)));
        }
        int n = this.discriminator.getOrdinal();
        if (ModifyVariableInjector.lIIIllllIIl(n, -1)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Invalid ordinal ").append(n).append(" specified in ").append(this)));
        }
        if (ModifyVariableInjector.lIIIllllIlI(this.discriminator.getIndex()) && ModifyVariableInjector.lIIIllllIlI(this.isStatic ? 1 : 0)) {
            throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Invalid index 0 specified in non-static variable modifier ").append(this)));
        }
    }

    @Override
    protected void inject(Target target, InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        int n;
        ModifyVariableInjector$Context modifyVariableInjector$Context;
        block10: {
            String string;
            if (ModifyVariableInjector.lIIIlllIlll(injectionNodes$InjectionNode.isReplaced() ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Variable modifier target for ").append(this).append(" was removed by another injector")));
            }
            modifyVariableInjector$Context = new ModifyVariableInjector$Context(this.returnType, this.discriminator.isArgsOnly(), target, injectionNodes$InjectionNode.getCurrentTarget());
            if (ModifyVariableInjector.lIIIlllIlll(this.discriminator.printLVT() ? 1 : 0)) {
                this.printLocals(modifyVariableInjector$Context);
            }
            if (ModifyVariableInjector.lIIIllllIlI((string = Bytecode.getDescriptor(new Type[]{this.returnType}, this.returnType)).equals(this.methodNode.desc) ? 1 : 0)) {
                throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Variable modifier ").append(this).append(" has an invalid signature, expected ").append(string).append(" but found ").append(this.methodNode.desc)));
            }
            try {
                int n2 = this.discriminator.findLocal(modifyVariableInjector$Context);
                if (!ModifyVariableInjector.lIIIllllIll(n2, -1)) break block10;
                this.inject(modifyVariableInjector$Context, n2);
            }
            catch (InvalidImplicitDiscriminatorException invalidImplicitDiscriminatorException) {
                if (ModifyVariableInjector.lIIIlllIlll(this.discriminator.printLVT() ? 1 : 0)) {
                    this.info.addCallbackInvocation(this.methodNode);
                    return;
                }
                throw new InvalidInjectionException(this.info, String.valueOf(new StringBuilder().append("Implicit variable modifier injection failed in ").append(this)), (Throwable)invalidImplicitDiscriminatorException);
            }
        }
        "".length();
        if (" ".length() == ((152 + 71 - 148 + 118 ^ 124 + 83 - 105 + 49) & (0x54 ^ 0x44 ^ (0xCF ^ 0x89) ^ -" ".length()))) {
            return;
        }
        target.insns.insertBefore(modifyVariableInjector$Context.node, modifyVariableInjector$Context.insns);
        if (ModifyVariableInjector.lIIIlllIlll(this.isStatic ? 1 : 0)) {
            n = 1;
            "".length();
            if ((0x34 ^ 0x6D ^ (0x98 ^ 0xC5)) < 0) {
                return;
            }
        } else {
            n = 2;
        }
        target.addToStack(n);
    }

    private void printLocals(ModifyVariableInjector$Context modifyVariableInjector$Context) {
        Object object;
        Object object2;
        Object object3;
        String string;
        SignaturePrinter signaturePrinter = new SignaturePrinter(this.methodNode.name, this.returnType, this.methodArgs, new String[]{"var"});
        signaturePrinter.setModifiers(this.methodNode);
        PrettyPrinter prettyPrinter = new PrettyPrinter().kvWidth(20).kv("Target Class", this.classNode.name.replace('/', '.')).kv("Target Method", modifyVariableInjector$Context.target.method.name).kv("Callback Name", this.methodNode.name).kv("Capture Type", SignaturePrinter.getTypeName(this.returnType, false)).kv("Instruction", "%s %s", modifyVariableInjector$Context.node.getClass().getSimpleName(), Bytecode.getOpcodeName(modifyVariableInjector$Context.node.getOpcode())).hr();
        if (ModifyVariableInjector.lIIIlllIlll(this.discriminator.isImplicit(modifyVariableInjector$Context) ? 1 : 0)) {
            string = "IMPLICIT (match single)";
            "".length();
            if (null != null) {
                return;
            }
        } else {
            string = "EXPLICIT (match by criteria)";
        }
        PrettyPrinter prettyPrinter2 = prettyPrinter.kv("Match mode", string);
        if (ModifyVariableInjector.lIIIlllllII(this.discriminator.getOrdinal())) {
            object3 = "any";
            "".length();
            if (null != null) {
                return;
            }
        } else {
            object3 = this.discriminator.getOrdinal();
        }
        PrettyPrinter prettyPrinter3 = prettyPrinter2.kv("Match ordinal", object3);
        if (ModifyVariableInjector.lIIIllllIIl(this.discriminator.getIndex(), modifyVariableInjector$Context.baseArgIndex)) {
            object2 = "any";
            "".length();
            if (" ".length() < " ".length()) {
                return;
            }
        } else {
            object2 = this.discriminator.getIndex();
        }
        PrettyPrinter prettyPrinter4 = prettyPrinter3.kv("Match index", object2);
        if (ModifyVariableInjector.lIIIlllIlll(this.discriminator.hasNames() ? 1 : 0)) {
            object = this.discriminator.getNames();
            "".length();
            if ("  ".length() <= " ".length()) {
                return;
            }
        } else {
            object = "any";
        }
        prettyPrinter4.kv("Match name(s)", object).kv("Args only", this.discriminator.isArgsOnly()).hr().add(modifyVariableInjector$Context).print(System.err);
        "".length();
    }

    private void inject(ModifyVariableInjector$Context modifyVariableInjector$Context, int n) {
        if (ModifyVariableInjector.lIIIllllIlI(this.isStatic ? 1 : 0)) {
            modifyVariableInjector$Context.insns.add(new VarInsnNode(25, 0));
        }
        modifyVariableInjector$Context.insns.add(new VarInsnNode(this.returnType.getOpcode(21), n));
        this.invokeHandler(modifyVariableInjector$Context.insns);
        "".length();
        modifyVariableInjector$Context.insns.add(new VarInsnNode(this.returnType.getOpcode(54), n));
    }

    private static boolean lIIIllllIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIllllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlllIlll(int n) {
        return n != 0;
    }

    private static boolean lIIIllllIlI(int n) {
        return n == 0;
    }

    private static boolean lIIIlllllII(int n) {
        return n < 0;
    }

    private static boolean lIIIllllIII(int n, int n2) {
        return n != n2;
    }
}

