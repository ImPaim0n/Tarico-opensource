/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.primitives.Doubles
 *  com.google.common.primitives.Floats
 *  com.google.common.primitives.Ints
 *  com.google.common.primitives.Longs
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.injection.points;

import com.google.common.primitives.Doubles;
import com.google.common.primitives.Floats;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FrameNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.mixin.injection.Constant$Condition;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.InjectionPoint$Selector;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

@InjectionPoint$AtCode(value="CONSTANT")
public class BeforeConstant
extends InjectionPoint {
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private final int ordinal;
    private final boolean nullValue;
    private final Integer intValue;
    private final Float floatValue;
    private final Long longValue;
    private final Double doubleValue;
    private final String stringValue;
    private final Type typeValue;
    private final int[] expandOpcodes;
    private final boolean expand;
    private final String matchByType;
    private final boolean log;

    public BeforeConstant(IMixinContext iMixinContext, AnnotationNode annotationNode, String string) {
        super(Annotations.getValue(annotationNode, "slice", ""), InjectionPoint$Selector.DEFAULT, null);
        boolean bl;
        boolean bl2;
        Boolean bl3 = Annotations.getValue(annotationNode, "nullValue", (Boolean)null);
        this.ordinal = Annotations.getValue(annotationNode, "ordinal", -1);
        if (BeforeConstant.lIIIIllI(bl3) && BeforeConstant.lIIIIlll(bl3.booleanValue() ? 1 : 0)) {
            bl2 = true;
            "".length();
            if (((0x50 ^ 0x4E ^ (0x64 ^ 0x4D)) & (0x44 ^ 0x7F ^ (0xA ^ 6) ^ -" ".length())) >= "  ".length()) {
                throw null;
            }
        } else {
            bl2 = false;
        }
        this.nullValue = bl2;
        this.intValue = Annotations.getValue(annotationNode, "intValue", (Integer)null);
        this.floatValue = Annotations.getValue(annotationNode, "floatValue", (Float)null);
        this.longValue = Annotations.getValue(annotationNode, "longValue", (Long)null);
        this.doubleValue = Annotations.getValue(annotationNode, "doubleValue", (Double)null);
        this.stringValue = Annotations.getValue(annotationNode, "stringValue", (String)null);
        this.typeValue = Annotations.getValue(annotationNode, "classValue", (Type)null);
        this.matchByType = this.validateDiscriminator(iMixinContext, string, bl3, "on @Constant annotation");
        this.expandOpcodes = this.parseExpandOpcodes(Annotations.getValue(annotationNode, "expandZeroConditions", true, Constant$Condition.class));
        if (BeforeConstant.lIIIlIII(this.expandOpcodes.length)) {
            bl = true;
            "".length();
            if ((0x91 ^ 0x9E ^ (0xB4 ^ 0xBE)) == 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.expand = bl;
        this.log = Annotations.getValue(annotationNode, "log", Boolean.FALSE);
    }

    public BeforeConstant(InjectionPointData injectionPointData) {
        super(injectionPointData);
        boolean bl;
        Type type;
        boolean bl2;
        Boolean bl3;
        String string = injectionPointData.get("nullValue", null);
        if (BeforeConstant.lIIIIllI(string)) {
            bl3 = Boolean.parseBoolean(string);
            "".length();
            if ("   ".length() < 0) {
                throw null;
            }
        } else {
            bl3 = null;
        }
        Boolean bl4 = bl3;
        this.ordinal = injectionPointData.getOrdinal();
        if (BeforeConstant.lIIIIllI(bl4) && BeforeConstant.lIIIIlll(bl4.booleanValue() ? 1 : 0)) {
            bl2 = true;
            "".length();
            if ((0x1F ^ 0x3B ^ (0x6E ^ 0x4E)) <= 0) {
                throw null;
            }
        } else {
            bl2 = false;
        }
        this.nullValue = bl2;
        this.intValue = Ints.tryParse((String)injectionPointData.get("intValue", ""));
        this.floatValue = Floats.tryParse((String)injectionPointData.get("floatValue", ""));
        this.longValue = Longs.tryParse((String)injectionPointData.get("longValue", ""));
        this.doubleValue = Doubles.tryParse((String)injectionPointData.get("doubleValue", ""));
        this.stringValue = injectionPointData.get("stringValue", null);
        String string2 = injectionPointData.get("classValue", null);
        if (BeforeConstant.lIIIIllI(string2)) {
            type = Type.getObjectType(string2.replace('.', '/'));
            "".length();
            if (null != null) {
                throw null;
            }
        } else {
            type = null;
        }
        this.typeValue = type;
        this.matchByType = this.validateDiscriminator(injectionPointData.getContext(), "V", bl4, "in @At(\"CONSTANT\") args");
        if (BeforeConstant.lIIIIlll("V".equals(this.matchByType) ? 1 : 0)) {
            throw new InvalidInjectionException(injectionPointData.getContext(), "No constant discriminator could be parsed in @At(\"CONSTANT\") args");
        }
        ArrayList<Constant$Condition> arrayList = new ArrayList<Constant$Condition>();
        String string3 = injectionPointData.get("expandZeroConditions", "").toLowerCase();
        Constant$Condition[] constant$ConditionArray = Constant$Condition.values();
        int n = constant$ConditionArray.length;
        int n2 = 0;
        while (BeforeConstant.lIIIlIIl(n2, n)) {
            Constant$Condition constant$Condition = constant$ConditionArray[n2];
            if (BeforeConstant.lIIIIlll(string3.contains(constant$Condition.name().toLowerCase()) ? 1 : 0)) {
                arrayList.add(constant$Condition);
                "".length();
            }
            ++n2;
            "".length();
            if ("  ".length() >= 0) continue;
            throw null;
        }
        this.expandOpcodes = this.parseExpandOpcodes(arrayList);
        if (BeforeConstant.lIIIlIII(this.expandOpcodes.length)) {
            bl = true;
            "".length();
            if (((1 ^ 0x50) & ~(0xCC ^ 0x9D)) < -" ".length()) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.expand = bl;
        this.log = injectionPointData.get("log", false);
    }

    private String validateDiscriminator(IMixinContext iMixinContext, String string, Boolean bl, String string2) {
        int n = BeforeConstant.count(bl, this.intValue, this.floatValue, this.longValue, this.doubleValue, this.stringValue, this.typeValue);
        if (BeforeConstant.lIIIlIlI(n, 1)) {
            string = null;
            "".length();
            if (((87 + 16 - 52 + 80 ^ 38 + 73 - 67 + 90) & (0x24 ^ 9 ^ (0x66 ^ 0x4E) ^ -" ".length())) >= "  ".length()) {
                return null;
            }
        } else if (BeforeConstant.lIIIlIll(n, 1)) {
            throw new InvalidInjectionException(iMixinContext, String.valueOf(new StringBuilder().append("Conflicting constant discriminators specified ").append(string2).append(" for ").append(iMixinContext)));
        }
        return string;
    }

    private int[] parseExpandOpcodes(List<Constant$Condition> list) {
        HashSet<Integer> hashSet = new HashSet<Integer>();
        Iterator<Constant$Condition> iterator = list.iterator();
        while (BeforeConstant.lIIIIlll(iterator.hasNext() ? 1 : 0)) {
            Constant$Condition constant$Condition = iterator.next();
            Constant$Condition constant$Condition2 = constant$Condition.getEquivalentCondition();
            int[] nArray = constant$Condition2.getOpcodes();
            int n = nArray.length;
            int n2 = 0;
            while (BeforeConstant.lIIIlIIl(n2, n)) {
                int n3 = nArray[n2];
                hashSet.add(n3);
                "".length();
                ++n2;
                "".length();
                if (((0x48 ^ 0x29) & ~(0x72 ^ 0x13)) <= " ".length()) continue;
                return null;
            }
            "".length();
            if (-(0x14 ^ 0x10) <= 0) continue;
            return null;
        }
        return Ints.toArray(hashSet);
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        boolean bl = false;
        this.log("BeforeConstant is searching for constants in method with descriptor {}", string);
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator();
        int n = 0;
        int n2 = 0;
        while (BeforeConstant.lIIIIlll(listIterator.hasNext() ? 1 : 0)) {
            int n3;
            int n4;
            AbstractInsnNode abstractInsnNode = listIterator.next();
            if (BeforeConstant.lIIIIlll(this.expand ? 1 : 0)) {
                n4 = this.matchesConditionalInsn(n2, abstractInsnNode);
                "".length();
                if (-" ".length() < -" ".length()) {
                    return ((0x40 ^ 0x5A ^ (0xF0 ^ 0xB1)) & (0xEE ^ 0xC3 ^ (2 ^ 0x74) ^ -" ".length())) != 0;
                }
            } else {
                n4 = this.matchesConstantInsn(abstractInsnNode);
            }
            if (BeforeConstant.lIIIIlll(n3 = n4)) {
                String string2;
                Object[] objectArray = new Object[2];
                if (BeforeConstant.lIIIIllI(this.matchByType)) {
                    string2 = " TYPE";
                    "".length();
                    if (null != null) {
                        return ((0x40 ^ 0x1F) & ~(0x99 ^ 0xC6)) != 0;
                    }
                } else {
                    string2 = " value";
                }
                objectArray[0] = string2;
                objectArray[1] = n;
                this.log("    BeforeConstant found a matching constant{} at ordinal {}", objectArray);
                if (!BeforeConstant.lIIIllII(this.ordinal, -1) || BeforeConstant.lIIIlIlI(this.ordinal, n)) {
                    this.log("      BeforeConstant found {}", Bytecode.describeNode(abstractInsnNode).trim());
                    collection.add(abstractInsnNode);
                    "".length();
                    bl = true;
                }
                ++n;
            }
            if (BeforeConstant.lIIIllIl(abstractInsnNode instanceof LabelNode) && BeforeConstant.lIIIllIl(abstractInsnNode instanceof FrameNode)) {
                n2 = abstractInsnNode.getOpcode();
            }
            "".length();
            if (-" ".length() <= 0) continue;
            return ((0x47 ^ 0x7D ^ (0x67 ^ 0x3D)) & (70 + 28 - -140 + 2 ^ 18 + 18 - -37 + 71 ^ -" ".length())) != 0;
        }
        return bl;
    }

    private boolean matchesConditionalInsn(int n, AbstractInsnNode abstractInsnNode) {
        Object object = this.expandOpcodes;
        int n2 = ((int[])object).length;
        int n3 = 0;
        while (BeforeConstant.lIIIlIIl(n3, n2)) {
            int n4 = object[n3];
            int n5 = abstractInsnNode.getOpcode();
            if (BeforeConstant.lIIIlIlI(n5, n4)) {
                if (!(BeforeConstant.lIIIllII(n, 148) && BeforeConstant.lIIIllII(n, 149) && BeforeConstant.lIIIllII(n, 150) && BeforeConstant.lIIIllII(n, 151) && !BeforeConstant.lIIIlIlI(n, 152))) {
                    this.log("  BeforeConstant is ignoring {} following {}", Bytecode.getOpcodeName(n5), Bytecode.getOpcodeName(n));
                    return false;
                }
                this.log("  BeforeConstant found {} instruction", Bytecode.getOpcodeName(n5));
                return true;
            }
            ++n3;
            "".length();
            if ("   ".length() < (0x90 ^ 0x94)) continue;
            return ((5 ^ 0x1F) & ~(0xDF ^ 0xC5)) != 0;
        }
        if (BeforeConstant.lIIIIllI(this.intValue) && BeforeConstant.lIIIllIl(this.intValue) && BeforeConstant.lIIIIlll(Bytecode.isConstant(abstractInsnNode) ? 1 : 0)) {
            boolean bl;
            object = Bytecode.getConstant(abstractInsnNode);
            this.log("  BeforeConstant found INTEGER constant: value = {}", object);
            if (BeforeConstant.lIIIIlll(object instanceof Integer) && BeforeConstant.lIIIllIl((Integer)object)) {
                bl = true;
                "".length();
                if ((143 + 75 - 179 + 110 ^ 90 + 77 - 146 + 124) <= -" ".length()) {
                    return ((0x35 ^ 0x51 ^ (0x24 ^ 0x60)) & (2 + 130 - 106 + 114 ^ 99 + 17 - 92 + 148 ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    private boolean matchesConstantInsn(AbstractInsnNode abstractInsnNode) {
        if (BeforeConstant.lIIIllIl(Bytecode.isConstant(abstractInsnNode) ? 1 : 0)) {
            return false;
        }
        Object object = Bytecode.getConstant(abstractInsnNode);
        if (BeforeConstant.lIIIlllI(object)) {
            boolean bl;
            this.log("  BeforeConstant found NULL constant: nullValue = {}", this.nullValue);
            if (!BeforeConstant.lIIIllIl(this.nullValue ? 1 : 0) || BeforeConstant.lIIIIlll("Ljava/lang/Object;".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if (((0x87 ^ 0x98) & ~(0x2A ^ 0x35)) > (0x2B ^ 0x2F)) {
                    return ((0x76 ^ 0x55) & ~(0x6B ^ 0x48)) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        if (BeforeConstant.lIIIIlll(object instanceof Integer)) {
            boolean bl;
            this.log("  BeforeConstant found INTEGER constant: value = {}, intValue = {}", object, this.intValue);
            if (!BeforeConstant.lIIIllIl(object.equals(this.intValue) ? 1 : 0) || BeforeConstant.lIIIIlll("I".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if (-"  ".length() >= 0) {
                    return ((6 ^ 0x13 ^ (0xDA ^ 0x99)) & (0x37 ^ 0xE ^ (0xD1 ^ 0xBE) ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        if (BeforeConstant.lIIIIlll(object instanceof Float)) {
            boolean bl;
            this.log("  BeforeConstant found FLOAT constant: value = {}, floatValue = {}", object, this.floatValue);
            if (!BeforeConstant.lIIIllIl(object.equals(this.floatValue) ? 1 : 0) || BeforeConstant.lIIIIlll("F".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if ((0x21 ^ 0x57 ^ (8 ^ 0x7B)) == 0) {
                    return ("  ".length() & ("  ".length() ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        if (BeforeConstant.lIIIIlll(object instanceof Long)) {
            boolean bl;
            this.log("  BeforeConstant found LONG constant: value = {}, longValue = {}", object, this.longValue);
            if (!BeforeConstant.lIIIllIl(object.equals(this.longValue) ? 1 : 0) || BeforeConstant.lIIIIlll("J".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if (-" ".length() > ((0x6B ^ 0x51 ^ (0xA3 ^ 0x84)) & (0xF ^ 5 ^ (0x11 ^ 6) ^ -" ".length()))) {
                    return ((118 + 77 - 83 + 23 ^ 48 + 121 - 70 + 57) & (19 + 50 - -26 + 75 ^ 146 + 90 - 183 + 124 ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        if (BeforeConstant.lIIIIlll(object instanceof Double)) {
            boolean bl;
            this.log("  BeforeConstant found DOUBLE constant: value = {}, doubleValue = {}", object, this.doubleValue);
            if (!BeforeConstant.lIIIllIl(object.equals(this.doubleValue) ? 1 : 0) || BeforeConstant.lIIIIlll("D".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if ((0xD2 ^ 0xBF ^ (0xEB ^ 0x82)) == "  ".length()) {
                    return ((40 + 50 - 41 + 140 ^ 97 + 131 - 171 + 92) & (0x22 ^ 0x18 ^ (0x1E ^ 0xC) ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        if (BeforeConstant.lIIIIlll(object instanceof String)) {
            boolean bl;
            this.log("  BeforeConstant found STRING constant: value = {}, stringValue = {}", object, this.stringValue);
            if (!BeforeConstant.lIIIllIl(object.equals(this.stringValue) ? 1 : 0) || BeforeConstant.lIIIIlll("Ljava/lang/String;".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if ("   ".length() < 0) {
                    return ((83 + 10 - -2 + 92 ^ 149 + 90 - 122 + 45) & (62 + 71 - 6 + 21 ^ 38 + 124 - 106 + 85 ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        if (BeforeConstant.lIIIIlll(object instanceof Type)) {
            boolean bl;
            this.log("  BeforeConstant found CLASS constant: value = {}, typeValue = {}", object, this.typeValue);
            if (!BeforeConstant.lIIIllIl(object.equals(this.typeValue) ? 1 : 0) || BeforeConstant.lIIIIlll("Ljava/lang/Class;".equals(this.matchByType) ? 1 : 0)) {
                bl = true;
                "".length();
                if (" ".length() <= ((0x71 ^ 0x43 ^ " ".length()) & (140 + 18 - 140 + 145 ^ 128 + 8 - -1 + 7 ^ -" ".length()))) {
                    return ((0xC ^ 0x34 ^ (0x82 ^ 0xAC)) & (0xD0 ^ 0xA2 ^ (0x25 ^ 0x41) ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    protected void log(String string, Object ... objectArray) {
        if (BeforeConstant.lIIIIlll(this.log ? 1 : 0)) {
            logger.info(string, objectArray);
        }
    }

    private static int count(Object ... objectArray) {
        int n = 0;
        Object[] objectArray2 = objectArray;
        int n2 = objectArray2.length;
        int n3 = 0;
        while (BeforeConstant.lIIIlIIl(n3, n2)) {
            Object object = objectArray2[n3];
            if (BeforeConstant.lIIIIllI(object)) {
                ++n;
            }
            ++n3;
            "".length();
            if ("   ".length() != -" ".length()) continue;
            return (0xDA ^ 0xBE ^ (0x2D ^ 0x50)) & (0xDA ^ 0x9E ^ (0x5B ^ 6) ^ -" ".length());
        }
        return n;
    }

    private static boolean lIIIlIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIIllI(Object object) {
        return object != null;
    }

    private static boolean lIIIlllI(Object object) {
        return object == null;
    }

    private static boolean lIIIIlll(int n) {
        return n != 0;
    }

    private static boolean lIIIllIl(int n) {
        return n == 0;
    }

    private static boolean lIIIlIII(int n) {
        return n > 0;
    }

    private static boolean lIIIllII(int n, int n2) {
        return n != n2;
    }
}

