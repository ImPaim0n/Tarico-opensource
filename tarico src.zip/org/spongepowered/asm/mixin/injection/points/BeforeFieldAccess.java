/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.points;

import java.util.Collection;
import java.util.ListIterator;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.points.BeforeInvoke;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.util.Bytecode;

@InjectionPoint$AtCode(value="FIELD")
public class BeforeFieldAccess
extends BeforeInvoke {
    private static final String ARRAY_GET = "get";
    private static final String ARRAY_SET;
    private static final String ARRAY_LENGTH;
    public static final int ARRAY_SEARCH_FUZZ_DEFAULT;
    private final int opcode;
    private final int arrOpcode;
    private final int fuzzFactor;

    public BeforeFieldAccess(InjectionPointData injectionPointData) {
        super(injectionPointData);
        int n;
        this.opcode = injectionPointData.getOpcode(-1, 180, 181, 178, 179, -1);
        String string = injectionPointData.get("array", "");
        if (BeforeFieldAccess.lIlIlIIIlII("get".equalsIgnoreCase(string) ? 1 : 0)) {
            n = 46;
            "".length();
            if ("  ".length() >= "   ".length()) {
                throw null;
            }
        } else if (BeforeFieldAccess.lIlIlIIIlII("set".equalsIgnoreCase(string) ? 1 : 0)) {
            n = 79;
            "".length();
            if (-" ".length() == "  ".length()) {
                throw null;
            }
        } else if (BeforeFieldAccess.lIlIlIIIlII("length".equalsIgnoreCase(string) ? 1 : 0)) {
            n = 190;
            "".length();
            if (-" ".length() >= 0) {
                throw null;
            }
        } else {
            n = 0;
        }
        this.arrOpcode = n;
        this.fuzzFactor = Math.min(Math.max(injectionPointData.get("fuzz", 8), 1), 32);
    }

    public int getFuzzFactor() {
        return this.fuzzFactor;
    }

    public int getArrayOpcode() {
        return this.arrOpcode;
    }

    private int getArrayOpcode(String string) {
        if (BeforeFieldAccess.lIlIllIIIII(this.arrOpcode, 190)) {
            return Type.getType(string).getElementType().getOpcode(this.arrOpcode);
        }
        return this.arrOpcode;
    }

    @Override
    protected boolean matchesInsn(AbstractInsnNode abstractInsnNode) {
        if (BeforeFieldAccess.lIlIlIIIlII(abstractInsnNode instanceof FieldInsnNode) && (!BeforeFieldAccess.lIlIllIIIII(((FieldInsnNode)abstractInsnNode).getOpcode(), this.opcode) || BeforeFieldAccess.lIlIllIIIIl(this.opcode, -1))) {
            boolean bl;
            if (BeforeFieldAccess.lIlIllIIIlI(this.arrOpcode)) {
                return true;
            }
            if (BeforeFieldAccess.lIlIllIIIII(abstractInsnNode.getOpcode(), 178) && BeforeFieldAccess.lIlIllIIIII(abstractInsnNode.getOpcode(), 180)) {
                return false;
            }
            if (BeforeFieldAccess.lIlIllIIIIl(Type.getType(((FieldInsnNode)abstractInsnNode).desc).getSort(), 9)) {
                bl = true;
                "".length();
                if ("  ".length() < 0) {
                    return ((29 + 190 - 45 + 61 ^ 131 + 8 - 47 + 97) & (59 + 71 - 67 + 162 ^ 100 + 179 - 157 + 61 ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    @Override
    protected boolean addInsn(InsnList insnList, Collection<AbstractInsnNode> collection, AbstractInsnNode abstractInsnNode) {
        if (BeforeFieldAccess.lIlIllIIIll(this.arrOpcode)) {
            FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
            int n = this.getArrayOpcode(fieldInsnNode.desc);
            this.log("{} > > > > searching for array access opcode {} fuzz={}", this.className, Bytecode.getOpcodeName(n), this.fuzzFactor);
            if (BeforeFieldAccess.lIlIllIIlII(BeforeFieldAccess.findArrayNode(insnList, fieldInsnNode, n, this.fuzzFactor))) {
                this.log("{} > > > > > failed to locate matching insn", this.className);
                return false;
            }
        }
        this.log("{} > > > > > adding matching insn", this.className);
        return super.addInsn(insnList, collection, abstractInsnNode);
    }

    public static AbstractInsnNode findArrayNode(InsnList insnList, FieldInsnNode fieldInsnNode, int n, int n2) {
        int n3 = 0;
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator(insnList.indexOf(fieldInsnNode) + 1);
        while (BeforeFieldAccess.lIlIlIIIlII(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (BeforeFieldAccess.lIlIllIIIIl(abstractInsnNode.getOpcode(), n)) {
                return abstractInsnNode;
            }
            if (BeforeFieldAccess.lIlIllIIIIl(abstractInsnNode.getOpcode(), 190) && BeforeFieldAccess.lIlIllIIIlI(n3)) {
                return null;
            }
            if (BeforeFieldAccess.lIlIlIIIlII(abstractInsnNode instanceof FieldInsnNode)) {
                FieldInsnNode fieldInsnNode2 = (FieldInsnNode)abstractInsnNode;
                if (BeforeFieldAccess.lIlIlIIIlII(fieldInsnNode2.desc.equals(fieldInsnNode.desc) ? 1 : 0) && BeforeFieldAccess.lIlIlIIIlII(fieldInsnNode2.name.equals(fieldInsnNode.name) ? 1 : 0) && BeforeFieldAccess.lIlIlIIIlII(fieldInsnNode2.owner.equals(fieldInsnNode.owner) ? 1 : 0)) {
                    return null;
                }
            }
            if (BeforeFieldAccess.lIlIllIIlIl(n3++, n2)) {
                return null;
            }
            "".length();
            if (-(0x2F ^ 0x2B) <= 0) continue;
            return null;
        }
        return null;
    }

    static {
        ARRAY_LENGTH = "length";
        ARRAY_SET = "set";
        ARRAY_SEARCH_FUZZ_DEFAULT = 8;
    }

    private static boolean lIlIllIIIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlIllIIlIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lIlIllIIlII(Object object) {
        return object == null;
    }

    private static boolean lIlIlIIIlII(int n) {
        return n != 0;
    }

    private static boolean lIlIllIIIlI(int n) {
        return n == 0;
    }

    private static boolean lIlIllIIIll(int n) {
        return n > 0;
    }

    private static boolean lIlIllIIIII(int n, int n2) {
        return n != n2;
    }
}

