/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.injection.points;

import java.util.Collection;
import java.util.ListIterator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;

@InjectionPoint$AtCode(value="INVOKE")
public class BeforeInvoke
extends InjectionPoint {
    protected final MemberInfo target;
    protected final MemberInfo permissiveTarget;
    protected final int ordinal;
    protected final String className;
    private boolean log = false;
    private final Logger logger = LogManager.getLogger((String)"mixin");

    public BeforeInvoke(InjectionPointData injectionPointData) {
        super(injectionPointData);
        MemberInfo memberInfo;
        this.target = injectionPointData.getTarget();
        this.ordinal = injectionPointData.getOrdinal();
        this.log = injectionPointData.get("log", false);
        this.className = this.getClassName();
        if (BeforeInvoke.lllllIIlIl(injectionPointData.getContext().getOption(MixinEnvironment$Option.REFMAP_REMAP) ? 1 : 0)) {
            memberInfo = this.target.transform(null);
            "".length();
            if ("  ".length() == -" ".length()) {
                throw null;
            }
        } else {
            memberInfo = null;
        }
        this.permissiveTarget = memberInfo;
    }

    private String getClassName() {
        String string;
        InjectionPoint$AtCode injectionPoint$AtCode = this.getClass().getAnnotation(InjectionPoint$AtCode.class);
        Object[] objectArray = new Object[1];
        if (BeforeInvoke.lllllIIllI(injectionPoint$AtCode)) {
            string = injectionPoint$AtCode.value();
            "".length();
            if ((0x65 ^ 0x6C ^ (0x74 ^ 0x79)) < (87 + 99 - 60 + 55 ^ 55 + 74 - -6 + 42)) {
                return null;
            }
        } else {
            string = this.getClass().getSimpleName().toUpperCase();
        }
        objectArray[0] = string;
        return String.format("@At(%s)", objectArray);
    }

    public BeforeInvoke setLogging(boolean bl) {
        this.log = bl;
        return this;
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        this.log("{} is searching for an injection point in method with descriptor {}", this.className, string);
        if (BeforeInvoke.lllllIIlll(this.find(string, insnList, collection, this.target) ? 1 : 0)) {
            return this.find(string, insnList, collection, this.permissiveTarget);
        }
        return true;
    }

    protected boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection, MemberInfo memberInfo) {
        if (BeforeInvoke.lllllIlIII(memberInfo)) {
            return false;
        }
        int n = 0;
        boolean bl = false;
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator();
        while (BeforeInvoke.lllllIIlIl(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = listIterator.next();
            if (BeforeInvoke.lllllIIlIl(this.matchesInsn(abstractInsnNode) ? 1 : 0)) {
                MemberInfo memberInfo2 = new MemberInfo(abstractInsnNode);
                this.log("{} is considering insn {}", this.className, memberInfo2);
                if (BeforeInvoke.lllllIIlIl(memberInfo.matches(memberInfo2.owner, memberInfo2.name, memberInfo2.desc) ? 1 : 0)) {
                    this.log("{} > found a matching insn, checking preconditions...", this.className);
                    if (BeforeInvoke.lllllIIlIl(this.matchesInsn(memberInfo2, n) ? 1 : 0)) {
                        this.log("{} > > > found a matching insn at ordinal {}", this.className, n);
                        bl |= this.addInsn(insnList, collection, abstractInsnNode);
                        if (BeforeInvoke.lllllIlIIl(this.ordinal, n)) {
                            "".length();
                            if (((0 ^ 0x29 ^ (0x26 ^ 0x6C)) & (80 + 181 - 105 + 51 ^ 1 + 13 - -96 + 62 ^ -" ".length())) >= ((37 + 194 - 200 + 173 ^ 53 + 129 - 150 + 111) & (0x4D ^ 0x5B ^ (0xE4 ^ 0xB1) ^ -" ".length()))) break;
                            return ((0x2E ^ 5 ^ (0xAB ^ 0x98)) & (0x76 ^ 0x67 ^ (0x3D ^ 0x34) ^ -" ".length())) != 0;
                        }
                    }
                    ++n;
                }
            }
            this.inspectInsn(string, insnList, abstractInsnNode);
            "".length();
            if (((0x95 ^ 0xAE) & ~(0x85 ^ 0xBE)) == 0) continue;
            return ((0x6E ^ 0x59) & ~(0x1C ^ 0x2B)) != 0;
        }
        return bl;
    }

    protected boolean addInsn(InsnList insnList, Collection<AbstractInsnNode> collection, AbstractInsnNode abstractInsnNode) {
        collection.add(abstractInsnNode);
        "".length();
        return true;
    }

    protected boolean matchesInsn(AbstractInsnNode abstractInsnNode) {
        return abstractInsnNode instanceof MethodInsnNode;
    }

    protected void inspectInsn(String string, InsnList insnList, AbstractInsnNode abstractInsnNode) {
    }

    protected boolean matchesInsn(MemberInfo memberInfo, int n) {
        boolean bl;
        this.log("{} > > comparing target ordinal {} with current ordinal {}", this.className, this.ordinal, n);
        if (!BeforeInvoke.lllllIlIlI(this.ordinal, -1) || BeforeInvoke.lllllIlIIl(this.ordinal, n)) {
            bl = true;
            "".length();
            if ("  ".length() <= 0) {
                return ((0x53 ^ 0x17) & ~(0xF7 ^ 0xB3)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    protected void log(String string, Object ... objectArray) {
        if (BeforeInvoke.lllllIIlIl(this.log ? 1 : 0)) {
            this.logger.info(string, objectArray);
        }
    }

    private static boolean lllllIlIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lllllIIllI(Object object) {
        return object != null;
    }

    private static boolean lllllIlIII(Object object) {
        return object == null;
    }

    private static boolean lllllIIlIl(int n) {
        return n != 0;
    }

    private static boolean lllllIIlll(int n) {
        return n == 0;
    }

    private static boolean lllllIlIlI(int n, int n2) {
        return n != n2;
    }
}

