/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.mixin.injection.points;

import com.google.common.base.Strings;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ListIterator;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;

@InjectionPoint$AtCode(value="NEW")
public class BeforeNew
extends InjectionPoint {
    private final String target;
    private final String desc;
    private final int ordinal;

    public BeforeNew(InjectionPointData injectionPointData) {
        super(injectionPointData);
        this.ordinal = injectionPointData.getOrdinal();
        String string = Strings.emptyToNull((String)injectionPointData.get("class", injectionPointData.get("target", "")).replace('.', '/'));
        MemberInfo memberInfo = MemberInfo.parseAndValidate(string, injectionPointData.getContext());
        this.target = memberInfo.toCtorType();
        this.desc = memberInfo.toCtorDesc();
    }

    public boolean hasDescriptor() {
        boolean bl;
        if (BeforeNew.llIIIIllII(this.desc)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((124 + 90 - 117 + 81 ^ 86 + 12 - 20 + 74) & (0x2E ^ 0x46 ^ (0xF5 ^ 0xB7) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        Object object;
        Collection<Object> collection2;
        boolean bl = false;
        int n = 0;
        ArrayList arrayList = new ArrayList();
        if (BeforeNew.llIIIIllII(this.desc)) {
            collection2 = arrayList;
            "".length();
            if ("  ".length() != "  ".length()) {
                return ((0x9D ^ 0xB8) & ~(0x6C ^ 0x49)) != 0;
            }
        } else {
            collection2 = collection;
        }
        Collection<Object> collection3 = collection2;
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator();
        while (BeforeNew.llIIIIllll(listIterator.hasNext() ? 1 : 0)) {
            object = listIterator.next();
            if (BeforeNew.llIIIIllll(object instanceof TypeInsnNode) && BeforeNew.llIIIlIIII(((AbstractInsnNode)object).getOpcode(), 187) && BeforeNew.llIIIIllll(this.matchesOwner((TypeInsnNode)object) ? 1 : 0)) {
                if (!BeforeNew.llIIIlIIIl(this.ordinal, -1) || BeforeNew.llIIIlIIII(this.ordinal, n)) {
                    boolean bl2;
                    collection3.add(object);
                    "".length();
                    if (BeforeNew.llIIIlIIlI(this.desc)) {
                        bl2 = true;
                        "".length();
                        if (((0x74 ^ 0x60 ^ (0xD6 ^ 0x8F)) & (24 + 72 - 18 + 137 ^ 132 + 2 - 42 + 62 ^ -" ".length())) > 0) {
                            return ((172 + 98 - 172 + 112 ^ 1 + 99 - -43 + 15) & (0x50 ^ 0x77 ^ (0x26 ^ 0x4D) ^ -" ".length())) != 0;
                        }
                    } else {
                        bl2 = false;
                    }
                    bl = bl2;
                }
                ++n;
            }
            "".length();
            if ("   ".length() >= 0) continue;
            return ((0xE1 ^ 0x81) & ~(0x6C ^ 0xC)) != 0;
        }
        if (BeforeNew.llIIIIllII(this.desc)) {
            object = arrayList.iterator();
            while (BeforeNew.llIIIIllll(object.hasNext() ? 1 : 0)) {
                TypeInsnNode typeInsnNode = (TypeInsnNode)object.next();
                if (BeforeNew.llIIIIllll(this.findCtor(insnList, typeInsnNode) ? 1 : 0)) {
                    collection.add(typeInsnNode);
                    "".length();
                    bl = true;
                }
                "".length();
                if ("  ".length() >= ((29 + 37 - -87 + 4 ^ 18 + 12 - 26 + 135) & (0x46 ^ 0xC ^ (0xE7 ^ 0xBB) ^ -" ".length()))) continue;
                return ((0xEA ^ 0x86 ^ (0xD9 ^ 0x80)) & (0x7F ^ 0x42 ^ (0x16 ^ 0x1E) ^ -" ".length())) != 0;
            }
        }
        return bl;
    }

    protected boolean findCtor(InsnList insnList, TypeInsnNode typeInsnNode) {
        int n = insnList.indexOf(typeInsnNode);
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator(n);
        while (BeforeNew.llIIIIllll(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (BeforeNew.llIIIIllll(abstractInsnNode instanceof MethodInsnNode) && BeforeNew.llIIIlIIII(abstractInsnNode.getOpcode(), 183)) {
                MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
                if (BeforeNew.llIIIIllll("<init>".equals(methodInsnNode.name) ? 1 : 0) && BeforeNew.llIIIIllll(methodInsnNode.owner.equals(typeInsnNode.desc) ? 1 : 0) && BeforeNew.llIIIIllll(methodInsnNode.desc.equals(this.desc) ? 1 : 0)) {
                    return true;
                }
            }
            "".length();
            if ("   ".length() != " ".length()) continue;
            return ((7 ^ 0x4B) & ~(0x2D ^ 0x61)) != 0;
        }
        return false;
    }

    private boolean matchesOwner(TypeInsnNode typeInsnNode) {
        boolean bl;
        if (!BeforeNew.llIIIIllII(this.target) || BeforeNew.llIIIIllll(this.target.equals(typeInsnNode.desc) ? 1 : 0)) {
            bl = true;
            "".length();
            if (((0x3F ^ 0x75) & ~(0x3D ^ 0x77)) != 0) {
                return ((0x7B ^ 0x4A) & ~(0x7D ^ 0x4C)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean llIIIlIIII(int n, int n2) {
        return n == n2;
    }

    private static boolean llIIIIllII(Object object) {
        return object != null;
    }

    private static boolean llIIIlIIlI(Object object) {
        return object == null;
    }

    private static boolean llIIIIllll(int n) {
        return n != 0;
    }

    private static boolean llIIIlIIIl(int n, int n2) {
        return n != n2;
    }
}

