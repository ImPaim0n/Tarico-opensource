/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.points;

import java.util.Collection;
import java.util.ListIterator;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;

@InjectionPoint$AtCode(value="RETURN")
public class BeforeReturn
extends InjectionPoint {
    private final int ordinal;

    public BeforeReturn(InjectionPointData injectionPointData) {
        super(injectionPointData);
        this.ordinal = injectionPointData.getOrdinal();
    }

    @Override
    public boolean checkPriority(int n, int n2) {
        return true;
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        boolean bl = false;
        int n = Type.getReturnType(string).getOpcode(172);
        int n2 = 0;
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator();
        while (BeforeReturn.lIIIIlllIlll(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = listIterator.next();
            if (BeforeReturn.lIIIIlllIlll(abstractInsnNode instanceof InsnNode) && BeforeReturn.lIIIIllllIII(abstractInsnNode.getOpcode(), n)) {
                if (!BeforeReturn.lIIIIllllIIl(this.ordinal, -1) || BeforeReturn.lIIIIllllIII(this.ordinal, n2)) {
                    collection.add(abstractInsnNode);
                    "".length();
                    bl = true;
                }
                ++n2;
            }
            "".length();
            if (-"   ".length() <= 0) continue;
            return ((9 ^ 0x6C ^ (0xEE ^ 0xC0)) & (0x56 ^ 0x5D ^ (0x15 ^ 0x55) ^ -" ".length())) != 0;
        }
        return bl;
    }

    private static boolean lIIIIllllIII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIlllIlll(int n) {
        return n != 0;
    }

    private static boolean lIIIIllllIIl(int n, int n2) {
        return n != n2;
    }
}

