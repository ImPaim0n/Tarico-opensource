/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.points;

import java.util.Collection;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.LdcInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.points.BeforeInvoke;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;

@InjectionPoint$AtCode(value="INVOKE_STRING")
public class BeforeStringInvoke
extends BeforeInvoke {
    private static final String STRING_VOID_SIG = "(Ljava/lang/String;)V";
    private final String ldcValue;
    private boolean foundLdc;

    public BeforeStringInvoke(InjectionPointData injectionPointData) {
        super(injectionPointData);
        this.ldcValue = injectionPointData.get("ldc", null);
        if (BeforeStringInvoke.lIlIIIIIIIl(this.ldcValue)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(this.getClass().getSimpleName()).append(" requires named argument \"ldc\" to specify the desired target")));
        }
        if (BeforeStringInvoke.lIlIIIIIIlI("(Ljava/lang/String;)V".equals(this.target.desc) ? 1 : 0)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(this.getClass().getSimpleName()).append(" requires target method with with signature ").append("(Ljava/lang/String;)V")));
        }
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        this.foundLdc = false;
        return super.find(string, insnList, collection);
    }

    @Override
    protected void inspectInsn(String string, InsnList insnList, AbstractInsnNode abstractInsnNode) {
        if (BeforeStringInvoke.lIlIIIIIIll(abstractInsnNode instanceof LdcInsnNode)) {
            LdcInsnNode ldcInsnNode = (LdcInsnNode)abstractInsnNode;
            if (BeforeStringInvoke.lIlIIIIIIll(ldcInsnNode.cst instanceof String) && BeforeStringInvoke.lIlIIIIIIll(this.ldcValue.equals(ldcInsnNode.cst) ? 1 : 0)) {
                this.log("{} > found a matching LDC with value {}", this.className, ldcInsnNode.cst);
                this.foundLdc = true;
                return;
            }
        }
        this.foundLdc = false;
    }

    @Override
    protected boolean matchesInsn(MemberInfo memberInfo, int n) {
        boolean bl;
        this.log("{} > > found LDC \"{}\" = {}", this.className, this.ldcValue, this.foundLdc);
        if (BeforeStringInvoke.lIlIIIIIIll(this.foundLdc ? 1 : 0) && BeforeStringInvoke.lIlIIIIIIll(super.matchesInsn(memberInfo, n) ? 1 : 0)) {
            bl = true;
            "".length();
            if (((0xF2 ^ 0xAD) & ~(0x99 ^ 0xC6)) != 0) {
                return ((0x9D ^ 0x8A) & ~(0x17 ^ 0)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static boolean lIlIIIIIIIl(Object object) {
        return object == null;
    }

    private static boolean lIlIIIIIIll(int n) {
        return n != 0;
    }

    private static boolean lIlIIIIIIlI(int n) {
        return n == 0;
    }
}

