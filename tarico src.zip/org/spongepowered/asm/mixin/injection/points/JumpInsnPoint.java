/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.points;

import java.util.Collection;
import java.util.ListIterator;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.InjectionPoint$AtCode;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;

@InjectionPoint$AtCode(value="JUMP")
public class JumpInsnPoint
extends InjectionPoint {
    private final int opCode;
    private final int ordinal;

    public JumpInsnPoint(InjectionPointData injectionPointData) {
        this.opCode = injectionPointData.getOpcode(-1, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 198, 199, -1);
        this.ordinal = injectionPointData.getOrdinal();
    }

    @Override
    public boolean find(String string, InsnList insnList, Collection<AbstractInsnNode> collection) {
        boolean bl = false;
        int n = 0;
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator();
        while (JumpInsnPoint.llIllIlIl(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = listIterator.next();
            if (JumpInsnPoint.llIllIlIl(abstractInsnNode instanceof JumpInsnNode) && (!JumpInsnPoint.llIllIllI(this.opCode, -1) || JumpInsnPoint.llIllIlll(abstractInsnNode.getOpcode(), this.opCode))) {
                if (!JumpInsnPoint.llIllIllI(this.ordinal, -1) || JumpInsnPoint.llIllIlll(this.ordinal, n)) {
                    collection.add(abstractInsnNode);
                    "".length();
                    bl = true;
                }
                ++n;
            }
            "".length();
            if ("  ".length() <= (0xAC ^ 0xA8)) continue;
            return ((0x21 ^ 0x3D) & ~(0x32 ^ 0x2E)) != 0;
        }
        return bl;
    }

    private static boolean llIllIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean llIllIlIl(int n) {
        return n != 0;
    }

    private static boolean llIllIllI(int n, int n2) {
        return n != n2;
    }
}

