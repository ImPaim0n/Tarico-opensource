/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.mixin.injection.struct;

import com.google.common.base.Strings;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.code.ISliceContext;
import org.spongepowered.asm.mixin.injection.code.Injector;
import org.spongepowered.asm.mixin.injection.code.InjectorTarget;
import org.spongepowered.asm.mixin.injection.code.MethodSlice;
import org.spongepowered.asm.mixin.injection.code.MethodSlices;
import org.spongepowered.asm.mixin.injection.struct.CallbackInjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;
import org.spongepowered.asm.mixin.injection.struct.InjectorGroupInfo;
import org.spongepowered.asm.mixin.injection.struct.InvalidMemberDescriptorException;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.mixin.injection.struct.ModifyArgInjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.ModifyArgsInjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.ModifyConstantInjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.ModifyVariableInjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.RedirectInjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.injection.throwables.InjectionError;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.struct.SpecialMethodInfo;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.meta.MixinMerged;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

public abstract class InjectionInfo
extends SpecialMethodInfo
implements ISliceContext {
    protected final boolean isStatic;
    protected final Deque<MethodNode> targets = new ArrayDeque<MethodNode>();
    protected final MethodSlices slices;
    protected final String atKey;
    protected final List<InjectionPoint> injectionPoints = new ArrayList<InjectionPoint>();
    protected final Map<Target, List<InjectionNodes$InjectionNode>> targetNodes = new LinkedHashMap<Target, List<InjectionNodes$InjectionNode>>();
    protected Injector injector;
    protected InjectorGroupInfo group;
    private final List<MethodNode> injectedMethods = new ArrayList<MethodNode>(0);
    private int expectedCallbackCount = 1;
    private int requiredCallbackCount = 0;
    private int maxCallbackCount = Integer.MAX_VALUE;
    private int injectedCallbackCount = 0;

    protected InjectionInfo(MixinTargetContext mixinTargetContext, MethodNode methodNode, AnnotationNode annotationNode) {
        this(mixinTargetContext, methodNode, annotationNode, "at");
    }

    protected InjectionInfo(MixinTargetContext mixinTargetContext, MethodNode methodNode, AnnotationNode annotationNode, String string) {
        super(mixinTargetContext, methodNode, annotationNode);
        this.isStatic = Bytecode.methodIsStatic(methodNode);
        this.slices = MethodSlices.parse(this);
        this.atKey = string;
        this.readAnnotation();
    }

    protected void readAnnotation() {
        if (InjectionInfo.lIlIlllI(this.annotation)) {
            return;
        }
        String string = String.valueOf(new StringBuilder().append("@").append(Bytecode.getSimpleName(this.annotation)));
        List<AnnotationNode> list = this.readInjectionPoints(string);
        this.findMethods(this.parseTargets(string), string);
        this.parseInjectionPoints(list);
        this.parseRequirements();
        this.injector = this.parseInjector(this.annotation);
    }

    protected Set<MemberInfo> parseTargets(String string) {
        List list = Annotations.getValue(this.annotation, "method", false);
        if (InjectionInfo.lIlIlllI(list)) {
            throw new InvalidInjectionException(this, String.format("%s annotation on %s is missing method name", string, this.method.name));
        }
        LinkedHashSet<MemberInfo> linkedHashSet = new LinkedHashSet<MemberInfo>();
        Iterator iterator = list.iterator();
        while (InjectionInfo.lIlIllll(iterator.hasNext() ? 1 : 0)) {
            String string2 = (String)iterator.next();
            try {
                MemberInfo memberInfo = MemberInfo.parseAndValidate(string2, this.mixin);
                if (InjectionInfo.lIllIIII(memberInfo.owner) && InjectionInfo.lIllIIIl(memberInfo.owner.equals(this.mixin.getTargetClassRef()) ? 1 : 0)) {
                    throw new InvalidInjectionException(this, String.format("%s annotation on %s specifies a target class '%s', which is not supported", string, this.method.name, memberInfo.owner));
                }
                linkedHashSet.add(memberInfo);
                "".length();
            }
            catch (InvalidMemberDescriptorException invalidMemberDescriptorException) {
                throw new InvalidInjectionException(this, String.format("%s annotation on %s, has invalid target descriptor: \"%s\". %s", string, this.method.name, string2, this.mixin.getReferenceMapper().getStatus()));
            }
            "".length();
            if (-" ".length() > "  ".length()) {
                return null;
            }
            "".length();
            if (((0x47 ^ 0x62) & ~(0x9B ^ 0xBE)) == 0) continue;
            return null;
        }
        return linkedHashSet;
    }

    protected List<AnnotationNode> readInjectionPoints(String string) {
        List<AnnotationNode> list = Annotations.getValue(this.annotation, this.atKey, false);
        if (InjectionInfo.lIlIlllI(list)) {
            throw new InvalidInjectionException(this, String.format("%s annotation on %s is missing '%s' value(s)", string, this.method.name, this.atKey));
        }
        return list;
    }

    protected void parseInjectionPoints(List<AnnotationNode> list) {
        this.injectionPoints.addAll(InjectionPoint.parse((IMixinContext)this.mixin, this.method, this.annotation, list));
        "".length();
    }

    protected void parseRequirements() {
        Integer n;
        Integer n2;
        this.group = this.mixin.getInjectorGroups().parseGroup(this.method, this.mixin.getDefaultInjectorGroup()).add(this);
        Integer n3 = (Integer)Annotations.getValue(this.annotation, "expect");
        if (InjectionInfo.lIllIIII(n3)) {
            this.expectedCallbackCount = n3;
        }
        if (InjectionInfo.lIllIIII(n2 = (Integer)Annotations.getValue(this.annotation, "require")) && InjectionInfo.lIllIIlI(n2, -1)) {
            this.requiredCallbackCount = n2;
            "".length();
            if (null != null) {
                return;
            }
        } else if (InjectionInfo.lIlIllll(this.group.isDefault() ? 1 : 0)) {
            this.requiredCallbackCount = this.mixin.getDefaultRequiredInjections();
        }
        if (InjectionInfo.lIllIIII(n = (Integer)Annotations.getValue(this.annotation, "allow"))) {
            this.maxCallbackCount = Math.max(Math.max(this.requiredCallbackCount, 1), n);
        }
    }

    protected abstract Injector parseInjector(AnnotationNode var1);

    public boolean isValid() {
        boolean bl;
        if (InjectionInfo.lIllIIll(this.targets.size()) && InjectionInfo.lIllIIll(this.injectionPoints.size())) {
            bl = true;
            "".length();
            if ("  ".length() != "  ".length()) {
                return ((85 + 221 - 83 + 27 ^ 171 + 48 - 140 + 114) & (0x88 ^ 0x91 ^ (0x9D ^ 0xBF) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public void prepare() {
        this.targetNodes.clear();
        Iterator<MethodNode> iterator = this.targets.iterator();
        while (InjectionInfo.lIlIllll(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            Target target = this.mixin.getTargetMethod(methodNode);
            InjectorTarget injectorTarget = new InjectorTarget(this, target);
            this.targetNodes.put(target, this.injector.find(injectorTarget, this.injectionPoints));
            "".length();
            injectorTarget.dispose();
            "".length();
            if (((0x24 ^ 0x39) & ~(0x8B ^ 0x96)) <= " ".length()) continue;
            return;
        }
    }

    public void inject() {
        Iterator<Map.Entry<Target, List<InjectionNodes$InjectionNode>>> iterator = this.targetNodes.entrySet().iterator();
        while (InjectionInfo.lIlIllll(iterator.hasNext() ? 1 : 0)) {
            Map.Entry<Target, List<InjectionNodes$InjectionNode>> entry = iterator.next();
            this.injector.inject(entry.getKey(), entry.getValue());
            "".length();
            if ("   ".length() != 0) continue;
            return;
        }
        this.targets.clear();
    }

    public void postInject() {
        Object object;
        Object object2 = this.injectedMethods.iterator();
        while (InjectionInfo.lIlIllll(object2.hasNext() ? 1 : 0)) {
            object = object2.next();
            this.classNode.methods.add((MethodNode)object);
            "".length();
            "".length();
            if (-" ".length() <= -" ".length()) continue;
            return;
        }
        object2 = this.getDescription();
        object = this.mixin.getReferenceMapper().getStatus();
        String string = this.getDynamicInfo();
        if (InjectionInfo.lIlIllll(this.mixin.getEnvironment().getOption(MixinEnvironment$Option.DEBUG_INJECTORS) ? 1 : 0) && InjectionInfo.lIllIlII(this.injectedCallbackCount, this.expectedCallbackCount)) {
            throw new InvalidInjectionException(this, String.format("Injection validation failed: %s %s%s in %s expected %d invocation(s) but %d succeeded. %s%s", object2, this.method.name, this.method.desc, this.mixin, this.expectedCallbackCount, this.injectedCallbackCount, object, string));
        }
        if (InjectionInfo.lIllIlII(this.injectedCallbackCount, this.requiredCallbackCount)) {
            throw new InjectionError(String.format("Critical injection failure: %s %s%s in %s failed injection check, (%d/%d) succeeded. %s%s", object2, this.method.name, this.method.desc, this.mixin, this.injectedCallbackCount, this.requiredCallbackCount, object, string));
        }
        if (InjectionInfo.lIllIIlI(this.injectedCallbackCount, this.maxCallbackCount)) {
            throw new InjectionError(String.format("Critical injection failure: %s %s%s in %s failed injection check, %d succeeded of %d allowed.%s", object2, this.method.name, this.method.desc, this.mixin, this.injectedCallbackCount, this.maxCallbackCount, string));
        }
    }

    public void notifyInjected(Target target) {
    }

    protected String getDescription() {
        return "Callback method";
    }

    public String toString() {
        return InjectionInfo.describeInjector(this.mixin, this.annotation, this.method);
    }

    public Collection<MethodNode> getTargets() {
        return this.targets;
    }

    @Override
    public MethodSlice getSlice(String string) {
        return this.slices.get(this.getSliceId(string));
    }

    public String getSliceId(String string) {
        return "";
    }

    public int getInjectedCallbackCount() {
        return this.injectedCallbackCount;
    }

    public MethodNode addMethod(int n, String string, String string2) {
        MethodNode methodNode = new MethodNode(327680, n | 0x1000, string, string2, null, null);
        this.injectedMethods.add(methodNode);
        "".length();
        return methodNode;
    }

    public void addCallbackInvocation(MethodNode methodNode) {
        ++this.injectedCallbackCount;
    }

    private void findMethods(Set<MemberInfo> set, String string) {
        int n;
        this.targets.clear();
        if (InjectionInfo.lIlIllll(this.mixin.getEnvironment().getOption(MixinEnvironment$Option.REFMAP_REMAP) ? 1 : 0)) {
            n = 2;
            "".length();
            if ("   ".length() != "   ".length()) {
                return;
            }
        } else {
            n = 1;
        }
        int n2 = n;
        Iterator<MemberInfo> iterator = set.iterator();
        while (InjectionInfo.lIlIllll(iterator.hasNext() ? 1 : 0)) {
            MemberInfo memberInfo = iterator.next();
            int n3 = 0;
            int n4 = 0;
            while (InjectionInfo.lIllIlII(n4, n2) && InjectionInfo.lIllIlII(n3, 1)) {
                int n5 = 0;
                Iterator<MethodNode> iterator2 = this.classNode.methods.iterator();
                while (InjectionInfo.lIlIllll(iterator2.hasNext() ? 1 : 0)) {
                    MethodNode methodNode = iterator2.next();
                    if (InjectionInfo.lIlIllll(memberInfo.matches(methodNode.name, methodNode.desc, n5) ? 1 : 0)) {
                        int n6;
                        int n7;
                        if (InjectionInfo.lIllIIII(Annotations.getVisible(methodNode, MixinMerged.class))) {
                            n7 = 1;
                            "".length();
                            if (null != null) {
                                return;
                            }
                        } else {
                            n7 = n6 = 0;
                        }
                        if (InjectionInfo.lIlIllll(memberInfo.matchAll ? 1 : 0)) {
                            if (!InjectionInfo.lIllIlIl(Bytecode.methodIsStatic(methodNode) ? 1 : 0, this.isStatic ? 1 : 0) || !InjectionInfo.lIllIllI(methodNode, this.method)) continue;
                            if (InjectionInfo.lIlIllll(n6)) {
                                "".length();
                                if (-"  ".length() <= 0) continue;
                                return;
                            }
                        }
                        this.checkTarget(methodNode);
                        this.targets.add(methodNode);
                        "".length();
                        ++n5;
                        ++n3;
                    }
                    "".length();
                    if ("  ".length() == "  ".length()) continue;
                    return;
                }
                memberInfo = memberInfo.transform(null);
                ++n4;
                "".length();
                if ("  ".length() != 0) continue;
                return;
            }
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return;
        }
        if (InjectionInfo.lIllIIIl(this.targets.size())) {
            throw new InvalidInjectionException(this, String.format("%s annotation on %s could not find any targets matching %s in the target class %s. %s%s", string, this.method.name, InjectionInfo.namesOf(set), this.mixin.getTarget(), this.mixin.getReferenceMapper().getStatus(), this.getDynamicInfo()));
        }
    }

    private void checkTarget(MethodNode methodNode) {
        AnnotationNode annotationNode = Annotations.getVisible(methodNode, MixinMerged.class);
        if (InjectionInfo.lIlIlllI(annotationNode)) {
            return;
        }
        if (InjectionInfo.lIllIIII(Annotations.getVisible(methodNode, Final.class))) {
            throw new InvalidInjectionException(this, String.format("%s cannot inject into @Final method %s::%s%s merged by %s", this, this.classNode.name, methodNode.name, methodNode.desc, Annotations.getValue(annotationNode, "mixin")));
        }
    }

    protected String getDynamicInfo() {
        String string;
        AnnotationNode annotationNode = Annotations.getInvisible(this.method, Dynamic.class);
        String string2 = Strings.nullToEmpty((String)((String)Annotations.getValue(annotationNode)));
        Type type = (Type)Annotations.getValue(annotationNode, "mixin");
        if (InjectionInfo.lIllIIII(type)) {
            string2 = String.format("{%s} %s", type.getClassName(), string2).trim();
        }
        if (InjectionInfo.lIllIIll(string2.length())) {
            string = String.format(" Method is @Dynamic(%s)", string2);
            "".length();
            if ("   ".length() <= 0) {
                return null;
            }
        } else {
            string = "";
        }
        return string;
    }

    public static InjectionInfo parse(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        AnnotationNode annotationNode = InjectionInfo.getInjectorAnnotation(mixinTargetContext.getMixin(), methodNode);
        if (InjectionInfo.lIlIlllI(annotationNode)) {
            return null;
        }
        if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(Inject.class.getSimpleName()).append(";"))) ? 1 : 0)) {
            return new CallbackInjectionInfo(mixinTargetContext, methodNode, annotationNode);
        }
        if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyArg.class.getSimpleName()).append(";"))) ? 1 : 0)) {
            return new ModifyArgInjectionInfo(mixinTargetContext, methodNode, annotationNode);
        }
        if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyArgs.class.getSimpleName()).append(";"))) ? 1 : 0)) {
            return new ModifyArgsInjectionInfo(mixinTargetContext, methodNode, annotationNode);
        }
        if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(Redirect.class.getSimpleName()).append(";"))) ? 1 : 0)) {
            return new RedirectInjectionInfo(mixinTargetContext, methodNode, annotationNode);
        }
        if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyVariable.class.getSimpleName()).append(";"))) ? 1 : 0)) {
            return new ModifyVariableInjectionInfo(mixinTargetContext, methodNode, annotationNode);
        }
        if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyConstant.class.getSimpleName()).append(";"))) ? 1 : 0)) {
            return new ModifyConstantInjectionInfo(mixinTargetContext, methodNode, annotationNode);
        }
        return null;
    }

    public static AnnotationNode getInjectorAnnotation(IMixinInfo iMixinInfo, MethodNode methodNode) {
        AnnotationNode annotationNode = null;
        try {
            annotationNode = Annotations.getSingleVisible(methodNode, Inject.class, ModifyArg.class, ModifyArgs.class, Redirect.class, ModifyVariable.class, ModifyConstant.class);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw new InvalidMixinException(iMixinInfo, String.format("Error parsing annotations on %s in %s: %s", methodNode.name, iMixinInfo.getClassName(), illegalArgumentException.getMessage()));
        }
        "".length();
        if (((0xA2 ^ 0xBD) & ~(0x40 ^ 0x5F)) != 0) {
            return null;
        }
        return annotationNode;
    }

    public static String getInjectorPrefix(AnnotationNode annotationNode) {
        if (InjectionInfo.lIllIIII(annotationNode)) {
            if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyArg.class.getSimpleName()).append(";"))) ? 1 : 0)) {
                return "modify";
            }
            if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyArgs.class.getSimpleName()).append(";"))) ? 1 : 0)) {
                return "args";
            }
            if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(Redirect.class.getSimpleName()).append(";"))) ? 1 : 0)) {
                return "redirect";
            }
            if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyVariable.class.getSimpleName()).append(";"))) ? 1 : 0)) {
                return "localvar";
            }
            if (InjectionInfo.lIlIllll(annotationNode.desc.endsWith(String.valueOf(new StringBuilder().append(ModifyConstant.class.getSimpleName()).append(";"))) ? 1 : 0)) {
                return "constant";
            }
        }
        return "handler";
    }

    static String describeInjector(IMixinContext iMixinContext, AnnotationNode annotationNode, MethodNode methodNode) {
        return String.format("%s->@%s::%s%s", iMixinContext.toString(), Bytecode.getSimpleName(annotationNode), methodNode.name, methodNode.desc);
    }

    private static String namesOf(Collection<MemberInfo> collection) {
        int n = 0;
        int n2 = collection.size();
        StringBuilder stringBuilder = new StringBuilder();
        Iterator<MemberInfo> iterator = collection.iterator();
        while (InjectionInfo.lIlIllll(iterator.hasNext() ? 1 : 0)) {
            MemberInfo memberInfo = iterator.next();
            if (InjectionInfo.lIllIIll(n)) {
                if (InjectionInfo.lIllIlIl(n, n2 - 1)) {
                    stringBuilder.append(" or ");
                    "".length();
                    "".length();
                    if ("  ".length() <= 0) {
                        return null;
                    }
                } else {
                    stringBuilder.append(", ");
                    "".length();
                }
            }
            stringBuilder.append('\'').append(memberInfo.name).append('\'');
            "".length();
            ++n;
            "".length();
            if (null == null) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    private static boolean lIllIlIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIllIlII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllIIlI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllIllI(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIllIIII(Object object) {
        return object != null;
    }

    private static boolean lIlIlllI(Object object) {
        return object == null;
    }

    private static boolean lIlIllll(int n) {
        return n != 0;
    }

    private static boolean lIllIIIl(int n) {
        return n == 0;
    }

    private static boolean lIllIIll(int n) {
        return n > 0;
    }
}

