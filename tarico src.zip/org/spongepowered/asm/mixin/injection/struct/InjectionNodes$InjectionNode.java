/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.struct;

import java.util.HashMap;
import java.util.Map;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.util.Bytecode;

public class InjectionNodes$InjectionNode
implements Comparable<InjectionNodes$InjectionNode> {
    private static int nextId = 0;
    private final int id;
    private final AbstractInsnNode originalTarget;
    private AbstractInsnNode currentTarget;
    private Map<String, Object> decorations;

    public InjectionNodes$InjectionNode(AbstractInsnNode abstractInsnNode) {
        this.currentTarget = this.originalTarget = abstractInsnNode;
        this.id = nextId++;
    }

    public int getId() {
        return this.id;
    }

    public AbstractInsnNode getOriginalTarget() {
        return this.originalTarget;
    }

    public AbstractInsnNode getCurrentTarget() {
        return this.currentTarget;
    }

    public InjectionNodes$InjectionNode replace(AbstractInsnNode abstractInsnNode) {
        this.currentTarget = abstractInsnNode;
        return this;
    }

    public InjectionNodes$InjectionNode remove() {
        this.currentTarget = null;
        return this;
    }

    public boolean matches(AbstractInsnNode abstractInsnNode) {
        boolean bl;
        if (!InjectionNodes$InjectionNode.lIllIlIIl(this.originalTarget, abstractInsnNode) || InjectionNodes$InjectionNode.lIllIlIlI(this.currentTarget, abstractInsnNode)) {
            bl = true;
            "".length();
            if (-" ".length() > -" ".length()) {
                return ((0x14 ^ 0x67 ^ (0x15 ^ 0x57)) & (0xF8 ^ 0x96 ^ (0x4E ^ 0x11) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isReplaced() {
        boolean bl;
        if (InjectionNodes$InjectionNode.lIllIlIIl(this.originalTarget, this.currentTarget)) {
            bl = true;
            "".length();
            if ("  ".length() <= -" ".length()) {
                return ((0x9A ^ 0x8D) & ~(0x4C ^ 0x5B)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isRemoved() {
        boolean bl;
        if (InjectionNodes$InjectionNode.lIllIlIll(this.currentTarget)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x8F ^ 0xC6) & ~(0xD2 ^ 0x9B)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public <V> InjectionNodes$InjectionNode decorate(String string, V v) {
        if (InjectionNodes$InjectionNode.lIllIlIll(this.decorations)) {
            this.decorations = new HashMap<String, Object>();
        }
        this.decorations.put(string, v);
        "".length();
        return this;
    }

    public boolean hasDecoration(String string) {
        boolean bl;
        if (InjectionNodes$InjectionNode.lIllIllII(this.decorations) && InjectionNodes$InjectionNode.lIllIllII(this.decorations.get(string))) {
            bl = true;
            "".length();
            if ("  ".length() == "   ".length()) {
                return ((0x6E ^ 0x22) & ~(9 ^ 0x45)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public <V> V getDecoration(String string) {
        Object object;
        if (InjectionNodes$InjectionNode.lIllIlIll(this.decorations)) {
            object = null;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            object = this.decorations.get(string);
        }
        return (V)object;
    }

    @Override
    public int compareTo(InjectionNodes$InjectionNode injectionNodes$InjectionNode) {
        int n;
        if (InjectionNodes$InjectionNode.lIllIlIll(injectionNodes$InjectionNode)) {
            n = Integer.MAX_VALUE;
            "".length();
            if (((0xDF ^ 0x98) & ~(0x43 ^ 4)) > " ".length()) {
                return (0x6D ^ 0x73) & ~(2 ^ 0x1C);
            }
        } else {
            n = this.hashCode() - injectionNodes$InjectionNode.hashCode();
        }
        return n;
    }

    public String toString() {
        return String.format("InjectionNode[%s]", Bytecode.describeNode(this.currentTarget).replaceAll("\\s+", " "));
    }

    private static boolean lIllIlIIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIllIlIlI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIllIllII(Object object) {
        return object != null;
    }

    private static boolean lIllIlIll(Object object) {
        return object == null;
    }
}

