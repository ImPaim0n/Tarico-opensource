/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.struct;

import java.util.ArrayList;
import java.util.Iterator;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.mixin.injection.struct.InjectionNodes$InjectionNode;

public class InjectionNodes
extends ArrayList<InjectionNodes$InjectionNode> {
    private static final long serialVersionUID = 1L;

    public InjectionNodes$InjectionNode add(AbstractInsnNode abstractInsnNode) {
        InjectionNodes$InjectionNode injectionNodes$InjectionNode = this.get(abstractInsnNode);
        if (InjectionNodes.lIIlIlIll(injectionNodes$InjectionNode)) {
            injectionNodes$InjectionNode = new InjectionNodes$InjectionNode(abstractInsnNode);
            this.add(injectionNodes$InjectionNode);
            "".length();
        }
        return injectionNodes$InjectionNode;
    }

    public InjectionNodes$InjectionNode get(AbstractInsnNode abstractInsnNode) {
        Iterator iterator = this.iterator();
        while (InjectionNodes.lIIlIllII(iterator.hasNext() ? 1 : 0)) {
            InjectionNodes$InjectionNode injectionNodes$InjectionNode = (InjectionNodes$InjectionNode)iterator.next();
            if (InjectionNodes.lIIlIllII(injectionNodes$InjectionNode.matches(abstractInsnNode) ? 1 : 0)) {
                return injectionNodes$InjectionNode;
            }
            "".length();
            if (-(0xA0 ^ 0xA5) < 0) continue;
            return null;
        }
        return null;
    }

    public boolean contains(AbstractInsnNode abstractInsnNode) {
        boolean bl;
        if (InjectionNodes.lIIlIlllI(this.get(abstractInsnNode))) {
            bl = true;
            "".length();
            if (" ".length() < ((0x39 ^ 0x72) & ~(0x8F ^ 0xC4))) {
                return ((0x97 ^ 0x9E) & ~(0x63 ^ 0x6A)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public void replace(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        InjectionNodes$InjectionNode injectionNodes$InjectionNode = this.get(abstractInsnNode);
        if (InjectionNodes.lIIlIlllI(injectionNodes$InjectionNode)) {
            injectionNodes$InjectionNode.replace(abstractInsnNode2);
            "".length();
        }
    }

    public void remove(AbstractInsnNode abstractInsnNode) {
        InjectionNodes$InjectionNode injectionNodes$InjectionNode = this.get(abstractInsnNode);
        if (InjectionNodes.lIIlIlllI(injectionNodes$InjectionNode)) {
            injectionNodes$InjectionNode.remove();
            "".length();
        }
    }

    private static boolean lIIlIlllI(Object object) {
        return object != null;
    }

    private static boolean lIIlIlIll(Object object) {
        return object == null;
    }

    private static boolean lIIlIllII(int n) {
        return n != 0;
    }
}

