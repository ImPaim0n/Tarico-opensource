/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.struct;

import java.util.HashMap;
import java.util.Iterator;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.injection.Group;
import org.spongepowered.asm.mixin.injection.struct.InjectorGroupInfo;
import org.spongepowered.asm.util.Annotations;

public final class InjectorGroupInfo$Map
extends HashMap<String, InjectorGroupInfo> {
    private static final long serialVersionUID = 1L;
    private static final InjectorGroupInfo NO_GROUP = new InjectorGroupInfo("NONE", true);

    @Override
    public InjectorGroupInfo get(Object object) {
        return this.forName(object.toString());
    }

    public InjectorGroupInfo forName(String string) {
        InjectorGroupInfo injectorGroupInfo = (InjectorGroupInfo)super.get(string);
        if (InjectorGroupInfo$Map.lIIlIlIIlII(injectorGroupInfo)) {
            injectorGroupInfo = new InjectorGroupInfo(string);
            this.put(string, injectorGroupInfo);
            "".length();
        }
        return injectorGroupInfo;
    }

    public InjectorGroupInfo parseGroup(MethodNode methodNode, String string) {
        return this.parseGroup(Annotations.getInvisible(methodNode, Group.class), string);
    }

    public InjectorGroupInfo parseGroup(AnnotationNode annotationNode, String string) {
        Integer n;
        if (InjectorGroupInfo$Map.lIIlIlIIlII(annotationNode)) {
            return NO_GROUP;
        }
        String string2 = (String)Annotations.getValue(annotationNode, "name");
        if (!InjectorGroupInfo$Map.lIIlIlIIlll(string2) || InjectorGroupInfo$Map.lIIlIlIlIIl(string2.isEmpty() ? 1 : 0)) {
            string2 = string;
        }
        InjectorGroupInfo injectorGroupInfo = this.forName(string2);
        Integer n2 = (Integer)Annotations.getValue(annotationNode, "min");
        if (InjectorGroupInfo$Map.lIIlIlIIlll(n2) && InjectorGroupInfo$Map.lIIlIlIlIlI(n2, -1)) {
            injectorGroupInfo.setMinRequired(n2);
        }
        if (InjectorGroupInfo$Map.lIIlIlIIlll(n = (Integer)Annotations.getValue(annotationNode, "max")) && InjectorGroupInfo$Map.lIIlIlIlIlI(n, -1)) {
            injectorGroupInfo.setMaxAllowed(n);
        }
        return injectorGroupInfo;
    }

    public void validateAll() {
        Iterator iterator = this.values().iterator();
        while (InjectorGroupInfo$Map.lIIlIlIlIIl(iterator.hasNext() ? 1 : 0)) {
            InjectorGroupInfo injectorGroupInfo = (InjectorGroupInfo)iterator.next();
            injectorGroupInfo.validate();
            "".length();
            "".length();
            if (-"  ".length() < 0) continue;
            return;
        }
    }

    private static boolean lIIlIlIIlll(Object object) {
        return object != null;
    }

    private static boolean lIIlIlIIlII(Object object) {
        return object == null;
    }

    private static boolean lIIlIlIlIIl(int n) {
        return n != 0;
    }

    private static boolean lIIlIlIlIlI(int n, int n2) {
        return n != n2;
    }
}

