/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 */
package org.spongepowered.asm.mixin.injection.struct;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.throwables.InjectionValidationException;

public class InjectorGroupInfo {
    private final String name;
    private final List<InjectionInfo> members = new ArrayList<InjectionInfo>();
    private final boolean isDefault;
    private int minCallbackCount = -1;
    private int maxCallbackCount = Integer.MAX_VALUE;

    public InjectorGroupInfo(String string) {
        this(string, false);
    }

    InjectorGroupInfo(String string, boolean bl) {
        this.name = string;
        this.isDefault = bl;
    }

    public String toString() {
        return String.format("@Group(name=%s, min=%d, max=%d)", this.getName(), this.getMinRequired(), this.getMaxAllowed());
    }

    public boolean isDefault() {
        return this.isDefault;
    }

    public String getName() {
        return this.name;
    }

    public int getMinRequired() {
        return Math.max(this.minCallbackCount, 1);
    }

    public int getMaxAllowed() {
        return Math.min(this.maxCallbackCount, Integer.MAX_VALUE);
    }

    public Collection<InjectionInfo> getMembers() {
        return Collections.unmodifiableCollection(this.members);
    }

    public void setMinRequired(int n) {
        if (InjectorGroupInfo.lllllIlIIIl(n, 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Cannot set zero or negative value for injector group min count. Attempted to set min=").append(n).append(" on ").append(this)));
        }
        if (InjectorGroupInfo.lllllIlIIlI(this.minCallbackCount) && InjectorGroupInfo.lllllIlIIll(this.minCallbackCount, n)) {
            LogManager.getLogger((String)"mixin").warn("Conflicting min value '{}' on @Group({}), previously specified {}", new Object[]{n, this.name, this.minCallbackCount});
        }
        this.minCallbackCount = Math.max(this.minCallbackCount, n);
    }

    public void setMaxAllowed(int n) {
        if (InjectorGroupInfo.lllllIlIIIl(n, 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Cannot set zero or negative value for injector group max count. Attempted to set max=").append(n).append(" on ").append(this)));
        }
        if (InjectorGroupInfo.lllllIlIIIl(this.maxCallbackCount, Integer.MAX_VALUE) && InjectorGroupInfo.lllllIlIIll(this.maxCallbackCount, n)) {
            LogManager.getLogger((String)"mixin").warn("Conflicting max value '{}' on @Group({}), previously specified {}", new Object[]{n, this.name, this.maxCallbackCount});
        }
        this.maxCallbackCount = Math.min(this.maxCallbackCount, n);
    }

    public InjectorGroupInfo add(InjectionInfo injectionInfo) {
        this.members.add(injectionInfo);
        "".length();
        return this;
    }

    public InjectorGroupInfo validate() {
        if (InjectorGroupInfo.lllllIlIlII(this.members.size())) {
            return this;
        }
        int n = 0;
        Iterator<InjectionInfo> iterator = this.members.iterator();
        while (InjectorGroupInfo.lllllIlIlIl(iterator.hasNext() ? 1 : 0)) {
            InjectionInfo injectionInfo = iterator.next();
            n += injectionInfo.getInjectedCallbackCount();
            "".length();
            if (" ".length() >= 0) continue;
            return null;
        }
        int n2 = this.getMinRequired();
        int n3 = this.getMaxAllowed();
        if (InjectorGroupInfo.lllllIlIIIl(n, n2)) {
            throw new InjectionValidationException(this, String.format("expected %d invocation(s) but only %d succeeded", n2, n));
        }
        if (InjectorGroupInfo.lllllIlIllI(n, n3)) {
            throw new InjectionValidationException(this, String.format("maximum of %d invocation(s) allowed but %d succeeded", n3, n));
        }
        return this;
    }

    private static boolean lllllIlIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lllllIlIllI(int n, int n2) {
        return n > n2;
    }

    private static boolean lllllIlIlIl(int n) {
        return n != 0;
    }

    private static boolean lllllIlIlII(int n) {
        return n == 0;
    }

    private static boolean lllllIlIIlI(int n) {
        return n > 0;
    }

    private static boolean lllllIlIIll(int n, int n2) {
        return n != n2;
    }
}

