/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Objects
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.mixin.injection.struct;

import com.google.common.base.Objects;
import com.google.common.base.Strings;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.mixin.injection.struct.InvalidMemberDescriptorException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.refmap.IReferenceMapper;
import org.spongepowered.asm.mixin.throwables.MixinException;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.asm.util.SignaturePrinter;

public final class MemberInfo {
    public final String owner;
    public final String name;
    public final String desc;
    public final boolean matchAll;
    private final boolean forceField;
    private final String unparsed;

    public MemberInfo(String string, boolean bl) {
        this(string, null, null, bl);
    }

    public MemberInfo(String string, String string2, boolean bl) {
        this(string, string2, null, bl);
    }

    public MemberInfo(String string, String string2, String string3) {
        this(string, string2, string3, false);
    }

    public MemberInfo(String string, String string2, String string3, boolean bl) {
        this(string, string2, string3, bl, null);
    }

    public MemberInfo(String string, String string2, String string3, boolean bl, String string4) {
        if (MemberInfo.lIIIlIlll(string2) && MemberInfo.lIIIllIII(string2.contains(".") ? 1 : 0)) {
            throw new IllegalArgumentException("Attempt to instance a MemberInfo with an invalid owner format");
        }
        this.owner = string2;
        this.name = string;
        this.desc = string3;
        this.matchAll = bl;
        this.forceField = false;
        this.unparsed = string4;
    }

    public MemberInfo(AbstractInsnNode abstractInsnNode) {
        this.matchAll = false;
        this.forceField = false;
        this.unparsed = null;
        if (MemberInfo.lIIIllIII(abstractInsnNode instanceof MethodInsnNode)) {
            MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
            this.owner = methodInsnNode.owner;
            this.name = methodInsnNode.name;
            this.desc = methodInsnNode.desc;
            "".length();
            if ("   ".length() < 0) {
                throw null;
            }
        } else if (MemberInfo.lIIIllIII(abstractInsnNode instanceof FieldInsnNode)) {
            FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
            this.owner = fieldInsnNode.owner;
            this.name = fieldInsnNode.name;
            this.desc = fieldInsnNode.desc;
            "".length();
            if ("   ".length() == " ".length()) {
                throw null;
            }
        } else {
            throw new IllegalArgumentException("insn must be an instance of MethodInsnNode or FieldInsnNode");
        }
    }

    public MemberInfo(IMapping<?> iMapping) {
        boolean bl;
        this.owner = iMapping.getOwner();
        this.name = iMapping.getSimpleName();
        this.desc = iMapping.getDesc();
        this.matchAll = false;
        if (MemberInfo.lIIIllIIl((Object)iMapping.getType(), (Object)IMapping$Type.FIELD)) {
            bl = true;
            "".length();
            if (((0xE5 ^ 0x86) & ~(0x70 ^ 0x13)) < 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.forceField = bl;
        this.unparsed = null;
    }

    private MemberInfo(MemberInfo memberInfo, MappingMethod mappingMethod, boolean bl) {
        String string;
        if (MemberInfo.lIIIllIII(bl ? 1 : 0)) {
            string = mappingMethod.getOwner();
            "".length();
            if (((0xE3 ^ 0xB3) & ~(0x17 ^ 0x47)) != 0) {
                throw null;
            }
        } else {
            string = memberInfo.owner;
        }
        this.owner = string;
        this.name = mappingMethod.getSimpleName();
        this.desc = mappingMethod.getDesc();
        this.matchAll = memberInfo.matchAll;
        this.forceField = false;
        this.unparsed = null;
    }

    private MemberInfo(MemberInfo memberInfo, String string) {
        this.owner = string;
        this.name = memberInfo.name;
        this.desc = memberInfo.desc;
        this.matchAll = memberInfo.matchAll;
        this.forceField = memberInfo.forceField;
        this.unparsed = null;
    }

    public String toString() {
        String string;
        String string2;
        String string3;
        String string4;
        String string5;
        String string6;
        String string7;
        String string8;
        String string9;
        if (MemberInfo.lIIIlIlll(this.owner)) {
            string9 = String.valueOf(new StringBuilder().append("L").append(this.owner).append(";"));
            "".length();
            if (" ".length() <= 0) {
                return null;
            }
        } else {
            string9 = string8 = "";
        }
        if (MemberInfo.lIIIlIlll(this.name)) {
            string7 = this.name;
            "".length();
            if (-"  ".length() >= 0) {
                return null;
            }
        } else {
            string7 = string6 = "";
        }
        if (MemberInfo.lIIIllIII(this.matchAll ? 1 : 0)) {
            string5 = "*";
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string5 = string4 = "";
        }
        if (MemberInfo.lIIIlIlll(this.desc)) {
            string3 = this.desc;
            "".length();
            if (-" ".length() > -" ".length()) {
                return null;
            }
        } else {
            string3 = "";
        }
        if (MemberInfo.lIIIllIII((string2 = string3).startsWith("(") ? 1 : 0)) {
            string = "";
            "".length();
            if (null != null) {
                return null;
            }
        } else if (MemberInfo.lIIIlIlll(this.desc)) {
            string = ":";
            "".length();
            if (" ".length() != " ".length()) {
                return null;
            }
        } else {
            string = "";
        }
        String string10 = string;
        return String.valueOf(new StringBuilder().append(string8).append(string6).append(string4).append(string10).append(string2));
    }

    @Deprecated
    public String toSrg() {
        if (MemberInfo.lIIIllIlI(this.isFullyQualified() ? 1 : 0)) {
            throw new MixinException("Cannot convert unqualified reference to SRG mapping");
        }
        if (MemberInfo.lIIIllIII(this.desc.startsWith("(") ? 1 : 0)) {
            return String.valueOf(new StringBuilder().append(this.owner).append("/").append(this.name).append(" ").append(this.desc));
        }
        return String.valueOf(new StringBuilder().append(this.owner).append("/").append(this.name));
    }

    public String toDescriptor() {
        if (MemberInfo.lIIIllIll(this.desc)) {
            return "";
        }
        return new SignaturePrinter(this).setFullyQualified(true).toDescriptor();
    }

    public String toCtorType() {
        String string;
        if (MemberInfo.lIIIllIll(this.unparsed)) {
            return null;
        }
        String string2 = this.getReturnType();
        if (MemberInfo.lIIIlIlll(string2)) {
            return string2;
        }
        if (MemberInfo.lIIIlIlll(this.owner)) {
            return this.owner;
        }
        if (MemberInfo.lIIIlIlll(this.name) && MemberInfo.lIIIllIll(this.desc)) {
            return this.name;
        }
        if (MemberInfo.lIIIlIlll(this.desc)) {
            string = this.desc;
            "".length();
            if ("  ".length() >= (51 + 131 - 30 + 4 ^ 79 + 82 - 132 + 123)) {
                return null;
            }
        } else {
            string = this.unparsed;
        }
        return string;
    }

    public String toCtorDesc() {
        if (MemberInfo.lIIIlIlll(this.desc) && MemberInfo.lIIIllIII(this.desc.startsWith("(") ? 1 : 0) && MemberInfo.lIIIlllII(this.desc.indexOf(41), -1)) {
            return String.valueOf(new StringBuilder().append(this.desc.substring(0, this.desc.indexOf(41) + 1)).append("V"));
        }
        return null;
    }

    public String getReturnType() {
        if (!MemberInfo.lIIIlIlll(this.desc) || !MemberInfo.lIIIlllIl(this.desc.indexOf(41), -1) || MemberInfo.lIIIllIII(this.desc.indexOf(40))) {
            return null;
        }
        String string = this.desc.substring(this.desc.indexOf(41) + 1);
        if (MemberInfo.lIIIllIII(string.startsWith("L") ? 1 : 0) && MemberInfo.lIIIllIII(string.endsWith(";") ? 1 : 0)) {
            return string.substring(1, string.length() - 1);
        }
        return string;
    }

    public IMapping<?> asMapping() {
        IMapping<MappingField> iMapping;
        if (MemberInfo.lIIIllIII(this.isField() ? 1 : 0)) {
            iMapping = this.asFieldMapping();
            "".length();
            if (-(84 + 125 - 155 + 128 ^ 136 + 24 - 24 + 43) >= 0) {
                return null;
            }
        } else {
            iMapping = this.asMethodMapping();
        }
        return iMapping;
    }

    public MappingMethod asMethodMapping() {
        if (MemberInfo.lIIIllIlI(this.isFullyQualified() ? 1 : 0)) {
            throw new MixinException(String.valueOf(new StringBuilder().append("Cannot convert unqualified reference ").append(this).append(" to MethodMapping")));
        }
        if (MemberInfo.lIIIllIII(this.isField() ? 1 : 0)) {
            throw new MixinException(String.valueOf(new StringBuilder().append("Cannot convert a non-method reference ").append(this).append(" to MethodMapping")));
        }
        return new MappingMethod(this.owner, this.name, this.desc);
    }

    public MappingField asFieldMapping() {
        if (MemberInfo.lIIIllIlI(this.isField() ? 1 : 0)) {
            throw new MixinException(String.valueOf(new StringBuilder().append("Cannot convert non-field reference ").append(this).append(" to FieldMapping")));
        }
        return new MappingField(this.owner, this.name, this.desc);
    }

    public boolean isFullyQualified() {
        boolean bl;
        if (MemberInfo.lIIIlIlll(this.owner) && MemberInfo.lIIIlIlll(this.name) && MemberInfo.lIIIlIlll(this.desc)) {
            bl = true;
            "".length();
            if ("   ".length() < 0) {
                return ((0x46 ^ 0xD) & ~(0x2E ^ 0x65)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isField() {
        boolean bl;
        if (!MemberInfo.lIIIllIlI(this.forceField ? 1 : 0) || MemberInfo.lIIIlIlll(this.desc) && MemberInfo.lIIIllIlI(this.desc.startsWith("(") ? 1 : 0)) {
            bl = true;
            "".length();
            if (-(39 + 121 - 121 + 115 ^ 104 + 153 - 175 + 76) > 0) {
                return ((4 ^ 0x7A ^ (0x1E ^ 0x4A)) & (0x75 ^ 0x23 ^ (4 ^ 0x78) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isConstructor() {
        return "<init>".equals(this.name);
    }

    public boolean isClassInitialiser() {
        return "<clinit>".equals(this.name);
    }

    public boolean isInitialiser() {
        boolean bl;
        if (!MemberInfo.lIIIllIlI(this.isConstructor() ? 1 : 0) || MemberInfo.lIIIllIII(this.isClassInitialiser() ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0xEE ^ 0x96 ^ (0xF8 ^ 0xAA)) & (76 + 146 - 178 + 112 ^ 162 + 24 - 175 + 171 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public MemberInfo validate() {
        block13: {
            block14: {
                if (MemberInfo.lIIIlIlll(this.owner)) {
                    if (MemberInfo.lIIIllIlI(this.owner.matches("(?i)^[\\w\\p{Sc}/]+$") ? 1 : 0)) {
                        throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid owner: ").append(this.owner)));
                    }
                    if (MemberInfo.lIIIlIlll(this.unparsed) && MemberInfo.lIIIllllI(this.unparsed.lastIndexOf(46)) && MemberInfo.lIIIllIII(this.owner.startsWith("L") ? 1 : 0)) {
                        throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Malformed owner: ").append(this.owner).append(" If you are seeing this message unexpectedly and the owner appears to be correct, replace the owner descriptor with formal type L").append(this.owner).append("; to suppress this error")));
                    }
                }
                if (MemberInfo.lIIIlIlll(this.name) && MemberInfo.lIIIllIlI(this.name.matches("(?i)^<?[\\w\\p{Sc}]+>?$") ? 1 : 0)) {
                    throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid name: ").append(this.name)));
                }
                if (!MemberInfo.lIIIlIlll(this.desc)) break block13;
                if (MemberInfo.lIIIllIlI(this.desc.matches("^(\\([\\w\\p{Sc}\\[/;]*\\))?\\[*[\\w\\p{Sc}/;]+$") ? 1 : 0)) {
                    throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(this.desc)));
                }
                if (!MemberInfo.lIIIllIII(this.isField() ? 1 : 0)) break block14;
                if (MemberInfo.lIIIllIlI(this.desc.equals(Type.getType(this.desc).getDescriptor()) ? 1 : 0)) {
                    throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid field type in descriptor: ").append(this.desc)));
                }
                break block13;
            }
            try {
                Type.getArgumentTypes(this.desc);
                "".length();
                "".length();
            }
            catch (Exception exception) {
                throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid descriptor: ").append(this.desc)));
            }
            if (-" ".length() > -" ".length()) {
                return null;
            }
            String string = this.desc.substring(this.desc.indexOf(41) + 1);
            try {
                Type type = Type.getType(string);
                if (MemberInfo.lIIIllIlI(string.equals(type.getDescriptor()) ? 1 : 0)) {
                    throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid return type \"").append(string).append("\" in descriptor: ").append(this.desc)));
                }
                "".length();
            }
            catch (Exception exception) {
                throw new InvalidMemberDescriptorException(String.valueOf(new StringBuilder().append("Invalid return type \"").append(string).append("\" in descriptor: ").append(this.desc)));
            }
            if (((0x4D ^ 0x18 ^ (0xC ^ 0x38)) & (0x29 ^ 0x4B ^ "   ".length() ^ -" ".length())) != 0) {
                return null;
            }
        }
        return this;
    }

    public boolean matches(String string, String string2, String string3) {
        return this.matches(string, string2, string3, 0);
    }

    public boolean matches(String string, String string2, String string3, int n) {
        boolean bl;
        if (MemberInfo.lIIIlIlll(this.desc) && MemberInfo.lIIIlIlll(string3) && MemberInfo.lIIIllIlI(this.desc.equals(string3) ? 1 : 0)) {
            return false;
        }
        if (MemberInfo.lIIIlIlll(this.name) && MemberInfo.lIIIlIlll(string2) && MemberInfo.lIIIllIlI(this.name.equals(string2) ? 1 : 0)) {
            return false;
        }
        if (MemberInfo.lIIIlIlll(this.owner) && MemberInfo.lIIIlIlll(string) && MemberInfo.lIIIllIlI(this.owner.equals(string) ? 1 : 0)) {
            return false;
        }
        if (!MemberInfo.lIIIllIII(n) || MemberInfo.lIIIllIII(this.matchAll ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((34 + 32 - -47 + 31 ^ 106 + 57 - 68 + 39) & (6 ^ 0x40 ^ (0x7E ^ 0x2E) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean matches(String string, String string2) {
        return this.matches(string, string2, 0);
    }

    public boolean matches(String string, String string2, int n) {
        boolean bl;
        if (!(MemberInfo.lIIIlIlll(this.name) && !MemberInfo.lIIIllIII(this.name.equals(string) ? 1 : 0) || MemberInfo.lIIIlIlll(this.desc) && (!MemberInfo.lIIIlIlll(string2) || !MemberInfo.lIIIllIII(string2.equals(this.desc) ? 1 : 0)) || MemberInfo.lIIIllIII(n) && !MemberInfo.lIIIllIII(this.matchAll ? 1 : 0))) {
            bl = true;
            "".length();
            if ((0x7B ^ 0x7F) <= 0) {
                return ((0x86 ^ 0xAC) & ~(0x1C ^ 0x36)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (!MemberInfo.lIIIlIlll(object) || MemberInfo.lIIIlllll(object.getClass(), MemberInfo.class)) {
            return false;
        }
        MemberInfo memberInfo = (MemberInfo)object;
        if (MemberInfo.lIIlIIIII(this.matchAll ? 1 : 0, memberInfo.matchAll ? 1 : 0) && MemberInfo.lIIlIIIII(this.forceField ? 1 : 0, memberInfo.forceField ? 1 : 0) && MemberInfo.lIIIllIII(Objects.equal((Object)this.owner, (Object)memberInfo.owner) ? 1 : 0) && MemberInfo.lIIIllIII(Objects.equal((Object)this.name, (Object)memberInfo.name) ? 1 : 0) && MemberInfo.lIIIllIII(Objects.equal((Object)this.desc, (Object)memberInfo.desc) ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0xA2 ^ 0xBA) & ~(0x19 ^ 1)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return Objects.hashCode((Object[])new Object[]{this.matchAll, this.owner, this.name, this.desc});
    }

    public MemberInfo move(String string) {
        if (MemberInfo.lIIIllIll(string) && !MemberInfo.lIIIlIlll(this.owner) || MemberInfo.lIIIlIlll(string) && MemberInfo.lIIIllIII(string.equals(this.owner) ? 1 : 0)) {
            return this;
        }
        return new MemberInfo(this, string);
    }

    public MemberInfo transform(String string) {
        if (MemberInfo.lIIIllIll(string) && !MemberInfo.lIIIlIlll(this.desc) || MemberInfo.lIIIlIlll(string) && MemberInfo.lIIIllIII(string.equals(this.desc) ? 1 : 0)) {
            return this;
        }
        return new MemberInfo(this.name, this.owner, string, this.matchAll);
    }

    public MemberInfo remapUsing(MappingMethod mappingMethod, boolean bl) {
        return new MemberInfo(this, mappingMethod, bl);
    }

    public static MemberInfo parseAndValidate(String string) {
        return MemberInfo.parse(string, null, null).validate();
    }

    public static MemberInfo parseAndValidate(String string, IMixinContext iMixinContext) {
        return MemberInfo.parse(string, iMixinContext.getReferenceMapper(), iMixinContext.getClassRef()).validate();
    }

    public static MemberInfo parse(String string) {
        return MemberInfo.parse(string, null, null);
    }

    public static MemberInfo parse(String string, IMixinContext iMixinContext) {
        return MemberInfo.parse(string, iMixinContext.getReferenceMapper(), iMixinContext.getClassRef());
    }

    private static MemberInfo parse(String string, IReferenceMapper iReferenceMapper, String string2) {
        boolean bl;
        String string3 = null;
        String string4 = null;
        String string5 = Strings.nullToEmpty((String)string).replaceAll("\\s", "");
        if (MemberInfo.lIIIlIlll(iReferenceMapper)) {
            string5 = iReferenceMapper.remap(string2, string5);
        }
        int n = string5.lastIndexOf(46);
        int n2 = string5.indexOf(59);
        if (MemberInfo.lIIIlllII(n, -1)) {
            string4 = string5.substring(0, n).replace('.', '/');
            string5 = string5.substring(n + 1);
            "".length();
            if (" ".length() != " ".length()) {
                return null;
            }
        } else if (MemberInfo.lIIIlllII(n2, -1) && MemberInfo.lIIIllIII(string5.startsWith("L") ? 1 : 0)) {
            string4 = string5.substring(1, n2).replace('.', '/');
            string5 = string5.substring(n2 + 1);
        }
        int n3 = string5.indexOf(40);
        int n4 = string5.indexOf(58);
        if (MemberInfo.lIIIlllII(n3, -1)) {
            string3 = string5.substring(n3);
            string5 = string5.substring(0, n3);
            "".length();
            if ("  ".length() >= (0x33 ^ 0x37)) {
                return null;
            }
        } else if (MemberInfo.lIIIlllII(n4, -1)) {
            string3 = string5.substring(n4 + 1);
            string5 = string5.substring(0, n4);
        }
        if ((!MemberInfo.lIIlIIlII(string5.indexOf(47), -1) || MemberInfo.lIIIlllII(string5.indexOf(46), -1)) && MemberInfo.lIIIllIll(string4)) {
            string4 = string5;
            string5 = "";
        }
        if (MemberInfo.lIIIllIII((bl = string5.endsWith("*")) ? 1 : 0)) {
            string5 = string5.substring(0, string5.length() - 1);
        }
        if (MemberInfo.lIIIllIII(string5.isEmpty() ? 1 : 0)) {
            string5 = null;
        }
        return new MemberInfo(string5, string4, string3, bl, string);
    }

    public static MemberInfo fromMapping(IMapping<?> iMapping) {
        return new MemberInfo(iMapping);
    }

    private static boolean lIIlIIIII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIlIIlII(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIlllII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlllll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIlIlll(Object object) {
        return object != null;
    }

    private static boolean lIIIllIIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIllIll(Object object) {
        return object == null;
    }

    private static boolean lIIIllIII(int n) {
        return n != 0;
    }

    private static boolean lIIIllIlI(int n) {
        return n == 0;
    }

    private static boolean lIIIllllI(int n) {
        return n > 0;
    }

    private static boolean lIIIlllIl(int n, int n2) {
        return n != n2;
    }
}

