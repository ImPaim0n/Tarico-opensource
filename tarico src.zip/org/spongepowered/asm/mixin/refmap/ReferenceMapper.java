/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonParseException
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.refmap;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.refmap.IReferenceMapper;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.MixinService;

public final class ReferenceMapper
implements Serializable,
IReferenceMapper {
    private static final long serialVersionUID = 2L;
    public static final String DEFAULT_RESOURCE = "mixin.refmap.json";
    public static final ReferenceMapper DEFAULT_MAPPER = new ReferenceMapper(true, "invalid");
    private final Map<String, Map<String, String>> mappings = Maps.newHashMap();
    private final Map<String, Map<String, Map<String, String>>> data = Maps.newHashMap();
    private final transient boolean readOnly;
    private transient String context = null;
    private transient String resource;

    public ReferenceMapper() {
        this(false, "mixin.refmap.json");
    }

    private ReferenceMapper(boolean bl, String string) {
        this.readOnly = bl;
        this.resource = string;
    }

    @Override
    public boolean isDefault() {
        return this.readOnly;
    }

    private void setResourceName(String string) {
        if (ReferenceMapper.lIIlIIIIIllI(this.readOnly ? 1 : 0)) {
            String string2;
            if (ReferenceMapper.lIIlIIIIIlll(string)) {
                string2 = string;
                "".length();
                if (((0x4B ^ 0x17) & ~(0x14 ^ 0x48)) >= "   ".length()) {
                    return;
                }
            } else {
                string2 = "<unknown resource>";
            }
            this.resource = string2;
        }
    }

    @Override
    public String getResourceName() {
        return this.resource;
    }

    @Override
    public String getStatus() {
        String string;
        if (ReferenceMapper.lIIlIIIIlIII(this.isDefault() ? 1 : 0)) {
            string = "No refMap loaded.";
            "".length();
            if ((0x12 ^ 0x16) <= ((0x3F ^ 0x6C) & ~(0xCB ^ 0x98))) {
                return null;
            }
        } else {
            string = String.valueOf(new StringBuilder().append("Using refmap ").append(this.getResourceName()));
        }
        return string;
    }

    @Override
    public String getContext() {
        return this.context;
    }

    @Override
    public void setContext(String string) {
        this.context = string;
    }

    @Override
    public String remap(String string, String string2) {
        return this.remapWithContext(this.context, string, string2);
    }

    @Override
    public String remapWithContext(String string, String string2, String string3) {
        Map<String, Map<String, String>> map = this.mappings;
        if (ReferenceMapper.lIIlIIIIIlll(string) && ReferenceMapper.lIIlIIIIlIIl(map = this.data.get(string))) {
            map = this.mappings;
        }
        return this.remap(map, string2, string3);
    }

    private String remap(Map<String, Map<String, String>> map, String string, String string2) {
        Object object;
        Object object2;
        Object object3;
        if (ReferenceMapper.lIIlIIIIlIIl(string)) {
            object3 = map.values().iterator();
            while (ReferenceMapper.lIIlIIIIlIII(object3.hasNext() ? 1 : 0)) {
                object2 = (Map)object3.next();
                if (ReferenceMapper.lIIlIIIIlIII(object2.containsKey(string2) ? 1 : 0)) {
                    return (String)object2.get(string2);
                }
                "".length();
                if (-" ".length() <= 0) continue;
                return null;
            }
        }
        if (ReferenceMapper.lIIlIIIIlIIl(object3 = map.get(string))) {
            return string2;
        }
        object2 = (String)object3.get(string2);
        if (ReferenceMapper.lIIlIIIIIlll(object2)) {
            object = object2;
            "".length();
            if (-"   ".length() > 0) {
                return null;
            }
        } else {
            object = string2;
        }
        return object;
    }

    public String addMapping(String string, String string2, String string3, String string4) {
        Map<String, String> map;
        if (!ReferenceMapper.lIIlIIIIIllI(this.readOnly ? 1 : 0) || !ReferenceMapper.lIIlIIIIIlll(string3) || !ReferenceMapper.lIIlIIIIIlll(string4) || ReferenceMapper.lIIlIIIIlIII(string3.equals(string4) ? 1 : 0)) {
            return null;
        }
        HashMap hashMap = this.mappings;
        if (ReferenceMapper.lIIlIIIIIlll(string) && ReferenceMapper.lIIlIIIIlIIl(hashMap = this.data.get(string))) {
            hashMap = Maps.newHashMap();
            this.data.put(string, hashMap);
            "".length();
        }
        if (ReferenceMapper.lIIlIIIIlIIl(map = hashMap.get(string2))) {
            map = new HashMap<String, String>();
            hashMap.put(string2, map);
            "".length();
        }
        return map.put(string3, string4);
    }

    public void write(Appendable appendable) {
        new GsonBuilder().setPrettyPrinting().create().toJson((Object)this, appendable);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     */
    public static ReferenceMapper read(String string) {
        InputStreamReader inputStreamReader;
        block9: {
            ReferenceMapper referenceMapper;
            Logger logger = LogManager.getLogger((String)"mixin");
            inputStreamReader = null;
            try {
                IMixinService iMixinService = MixinService.getService();
                InputStream inputStream = iMixinService.getResourceAsStream(string);
                if (!ReferenceMapper.lIIlIIIIIlll(inputStream)) break block9;
                inputStreamReader = new InputStreamReader(inputStream);
                ReferenceMapper referenceMapper2 = ReferenceMapper.readJson(inputStreamReader);
                referenceMapper2.setResourceName(string);
                referenceMapper = referenceMapper2;
            }
            catch (JsonParseException jsonParseException) {
                logger.error(String.valueOf(new StringBuilder().append("Invalid REFMAP JSON in ").append(string).append(": ").append(((Object)((Object)jsonParseException)).getClass().getName()).append(" ").append(jsonParseException.getMessage())));
                IOUtils.closeQuietly((Reader)inputStreamReader);
                "".length();
                if ("  ".length() < 0) {
                    return null;
                }
            }
            catch (Exception exception) {
                logger.error(String.valueOf(new StringBuilder().append("Failed reading REFMAP JSON from ").append(string).append(": ").append(exception.getClass().getName()).append(" ").append(exception.getMessage())));
                {
                    catch (Throwable throwable) {
                        IOUtils.closeQuietly(inputStreamReader);
                        throw throwable;
                    }
                }
                IOUtils.closeQuietly((Reader)inputStreamReader);
                "".length();
                if (-" ".length() >= "  ".length()) {
                    return null;
                }
            }
            IOUtils.closeQuietly((Reader)inputStreamReader);
            return referenceMapper;
        }
        IOUtils.closeQuietly(inputStreamReader);
        "".length();
        if ("   ".length() != "   ".length()) {
            return null;
        }
        return DEFAULT_MAPPER;
    }

    public static ReferenceMapper read(Reader reader, String string) {
        try {
            ReferenceMapper referenceMapper = ReferenceMapper.readJson(reader);
            referenceMapper.setResourceName(string);
            return referenceMapper;
        }
        catch (Exception exception) {
            return DEFAULT_MAPPER;
        }
    }

    private static ReferenceMapper readJson(Reader reader) {
        return (ReferenceMapper)new Gson().fromJson(reader, ReferenceMapper.class);
    }

    private static boolean lIIlIIIIIlll(Object object) {
        return object != null;
    }

    private static boolean lIIlIIIIlIIl(Object object) {
        return object == null;
    }

    private static boolean lIIlIIIIlIII(int n) {
        return n != 0;
    }

    private static boolean lIIlIIIIIllI(int n) {
        return n == 0;
    }
}

