/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  com.google.common.io.LineProcessor
 */
package org.spongepowered.asm.mixin.refmap;

import com.google.common.base.Strings;
import com.google.common.io.LineProcessor;
import java.util.Map;

final class RemappingReferenceMapper$1
implements LineProcessor<Object> {
    final /* synthetic */ Map val$map;

    RemappingReferenceMapper$1(Map map) {
        this.val$map = map;
    }

    public Object getResult() {
        return null;
    }

    public boolean processLine(String string) {
        int n;
        if (!RemappingReferenceMapper$1.llIllIIIIll(Strings.isNullOrEmpty((String)string) ? 1 : 0) || RemappingReferenceMapper$1.llIllIIIlII(string.startsWith("#") ? 1 : 0)) {
            return true;
        }
        int n2 = 0;
        int n3 = 0;
        if (RemappingReferenceMapper$1.llIllIIIlII(string.startsWith("MD: ") ? 1 : 0)) {
            n = 2;
            "".length();
            if (" ".length() < -" ".length()) {
                return ((0xB0 ^ 0xBF) & ~(0x2F ^ 0x20)) != 0;
            }
        } else if (RemappingReferenceMapper$1.llIllIIIlII(string.startsWith("FD: ") ? 1 : 0)) {
            n = 1;
            "".length();
            if (-(0x5A ^ 3 ^ (0xCB ^ 0x96)) >= 0) {
                return ((2 + 28 - -59 + 54 ^ 20 + 108 - 48 + 107) & (21 + 34 - -51 + 30 ^ 102 + 117 - 67 + 36 ^ -" ".length())) != 0;
            }
        } else {
            n = n3 = 0;
        }
        if (RemappingReferenceMapper$1.llIllIIIlIl(n)) {
            String[] stringArray = string.substring(4).split(" ", 4);
            this.val$map.put(stringArray[n2].substring(stringArray[n2].lastIndexOf(47) + 1), stringArray[n3].substring(stringArray[n3].lastIndexOf(47) + 1));
            "".length();
        }
        return true;
    }

    private static boolean llIllIIIlII(int n) {
        return n != 0;
    }

    private static boolean llIllIIIIll(int n) {
        return n == 0;
    }

    private static boolean llIllIIIlIl(int n) {
        return n > 0;
    }
}

