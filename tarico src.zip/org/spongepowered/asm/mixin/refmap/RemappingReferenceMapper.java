/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Charsets
 *  com.google.common.base.Strings
 *  com.google.common.io.Files
 *  com.google.common.io.LineProcessor
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.refmap;

import com.google.common.base.Charsets;
import com.google.common.base.Strings;
import com.google.common.io.Files;
import com.google.common.io.LineProcessor;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.refmap.IReferenceMapper;
import org.spongepowered.asm.mixin.refmap.RemappingReferenceMapper$1;

public final class RemappingReferenceMapper
implements IReferenceMapper {
    private static final String DEFAULT_RESOURCE_PATH_PROPERTY = "net.minecraftforge.gradle.GradleStart.srg.srg-mcp";
    private static final String DEFAULT_MAPPING_ENV = "searge";
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private static final Map<String, Map<String, String>> srgs = new HashMap<String, Map<String, String>>();
    private final IReferenceMapper refMap;
    private final Map<String, String> mappings;
    private final Map<String, Map<String, String>> cache = new HashMap<String, Map<String, String>>();

    private RemappingReferenceMapper(MixinEnvironment mixinEnvironment, IReferenceMapper iReferenceMapper) {
        this.refMap = iReferenceMapper;
        this.refMap.setContext(RemappingReferenceMapper.getMappingEnv(mixinEnvironment));
        String string = RemappingReferenceMapper.getResource(mixinEnvironment);
        this.mappings = RemappingReferenceMapper.loadSrgs(string);
        logger.info("Remapping refMap {} using {}", new Object[]{iReferenceMapper.getResourceName(), string});
    }

    @Override
    public boolean isDefault() {
        return this.refMap.isDefault();
    }

    @Override
    public String getResourceName() {
        return this.refMap.getResourceName();
    }

    @Override
    public String getStatus() {
        return this.refMap.getStatus();
    }

    @Override
    public String getContext() {
        return this.refMap.getContext();
    }

    @Override
    public void setContext(String string) {
    }

    @Override
    public String remap(String string, String string2) {
        Map<String, String> map = this.getCache(string);
        String string3 = map.get(string2);
        if (RemappingReferenceMapper.lIIll(string3)) {
            string3 = this.refMap.remap(string, string2);
            Iterator<Map.Entry<String, String>> iterator = this.mappings.entrySet().iterator();
            while (RemappingReferenceMapper.lIlII(iterator.hasNext() ? 1 : 0)) {
                Map.Entry<String, String> entry = iterator.next();
                string3 = string3.replace(entry.getKey(), entry.getValue());
                "".length();
                if (null == null) continue;
                return null;
            }
            map.put(string2, string3);
            "".length();
        }
        return string3;
    }

    private Map<String, String> getCache(String string) {
        Map<String, String> map = this.cache.get(string);
        if (RemappingReferenceMapper.lIIll(map)) {
            map = new HashMap<String, String>();
            this.cache.put(string, map);
            "".length();
        }
        return map;
    }

    @Override
    public String remapWithContext(String string, String string2, String string3) {
        return this.refMap.remapWithContext(string, string2, string3);
    }

    private static Map<String, String> loadSrgs(String string) {
        if (RemappingReferenceMapper.lIlII(srgs.containsKey(string) ? 1 : 0)) {
            return srgs.get(string);
        }
        HashMap<String, String> hashMap = new HashMap<String, String>();
        srgs.put(string, hashMap);
        "".length();
        File file = new File(string);
        if (RemappingReferenceMapper.lIlIl(file.isFile() ? 1 : 0)) {
            return hashMap;
        }
        try {
            Files.readLines((File)file, (Charset)Charsets.UTF_8, (LineProcessor)new RemappingReferenceMapper$1(hashMap));
            "".length();
            "".length();
        }
        catch (IOException iOException) {
            logger.warn("Could not read input SRG file: {}", new Object[]{string});
            logger.catching((Throwable)iOException);
        }
        if (-"  ".length() > 0) {
            return null;
        }
        return hashMap;
    }

    public static IReferenceMapper of(MixinEnvironment mixinEnvironment, IReferenceMapper iReferenceMapper) {
        if (RemappingReferenceMapper.lIlIl(iReferenceMapper.isDefault() ? 1 : 0) && RemappingReferenceMapper.lIlII(RemappingReferenceMapper.hasData(mixinEnvironment) ? 1 : 0)) {
            return new RemappingReferenceMapper(mixinEnvironment, iReferenceMapper);
        }
        return iReferenceMapper;
    }

    private static boolean hasData(MixinEnvironment mixinEnvironment) {
        boolean bl;
        String string = RemappingReferenceMapper.getResource(mixinEnvironment);
        if (RemappingReferenceMapper.lIllI(string) && RemappingReferenceMapper.lIlII(new File(string).exists() ? 1 : 0)) {
            bl = true;
            "".length();
            if (((91 + 133 - 134 + 102 ^ 76 + 7 - -13 + 32) & (0 ^ 0x5B ^ (0xDD ^ 0xC6) ^ -" ".length())) != 0) {
                return ((7 + 155 - 62 + 94 ^ 4 + 93 - 17 + 54) & (0x97 ^ 0xB4 ^ (0xD1 ^ 0xB6) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private static String getResource(MixinEnvironment mixinEnvironment) {
        String string;
        String string2 = mixinEnvironment.getOptionValue(MixinEnvironment$Option.REFMAP_REMAP_RESOURCE);
        if (RemappingReferenceMapper.lIlII(Strings.isNullOrEmpty((String)string2) ? 1 : 0)) {
            string = System.getProperty("net.minecraftforge.gradle.GradleStart.srg.srg-mcp");
            "".length();
            if (-" ".length() >= (0x52 ^ 0x56)) {
                return null;
            }
        } else {
            string = string2;
        }
        return string;
    }

    private static String getMappingEnv(MixinEnvironment mixinEnvironment) {
        String string;
        String string2 = mixinEnvironment.getOptionValue(MixinEnvironment$Option.REFMAP_REMAP_SOURCE_ENV);
        if (RemappingReferenceMapper.lIlII(Strings.isNullOrEmpty((String)string2) ? 1 : 0)) {
            string = "searge";
            "".length();
            if (-(62 + 119 - -7 + 3 ^ 157 + 167 - 201 + 64) >= 0) {
                return null;
            }
        } else {
            string = string2;
        }
        return string;
    }

    private static boolean lIllI(Object object) {
        return object != null;
    }

    private static boolean lIIll(Object object) {
        return object == null;
    }

    private static boolean lIlII(int n) {
        return n != 0;
    }

    private static boolean lIlIl(int n) {
        return n == 0;
    }
}

