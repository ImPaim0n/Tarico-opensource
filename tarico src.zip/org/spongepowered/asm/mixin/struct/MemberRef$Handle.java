/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.struct;

import org.spongepowered.asm.lib.Handle;
import org.spongepowered.asm.mixin.struct.MemberRef;
import org.spongepowered.asm.mixin.transformer.throwables.MixinTransformerError;
import org.spongepowered.asm.util.Bytecode;

public final class MemberRef$Handle
extends MemberRef {
    private Handle handle;

    public MemberRef$Handle(Handle handle) {
        this.handle = handle;
    }

    public Handle getMethodHandle() {
        return this.handle;
    }

    @Override
    public boolean isField() {
        switch (this.handle.getTag()) {
            case 5: 
            case 6: 
            case 7: 
            case 8: 
            case 9: {
                return false;
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: {
                return true;
            }
        }
        throw new MixinTransformerError(String.valueOf(new StringBuilder().append("Invalid tag ").append(this.handle.getTag()).append(" for method handle ").append(this.handle).append(".")));
    }

    @Override
    public int getOpcode() {
        int n = MemberRef.opcodeFromTag(this.handle.getTag());
        if (MemberRef$Handle.lIlllIIIIl(n)) {
            throw new MixinTransformerError(String.valueOf(new StringBuilder().append("Invalid tag ").append(this.handle.getTag()).append(" for method handle ").append(this.handle).append(".")));
        }
        return n;
    }

    @Override
    public void setOpcode(int n) {
        boolean bl;
        int n2 = MemberRef.tagFromOpcode(n);
        if (MemberRef$Handle.lIlllIIIIl(n2)) {
            throw new MixinTransformerError(String.valueOf(new StringBuilder().append("Invalid opcode ").append(Bytecode.getOpcodeName(n)).append(" for method handle ").append(this.handle).append(".")));
        }
        if (MemberRef$Handle.lIlllIIIlI(n2, 9)) {
            bl = true;
            "".length();
            if (-" ".length() == "   ".length()) {
                return;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        this.handle = new Handle(n2, this.handle.getOwner(), this.handle.getName(), this.handle.getDesc(), bl2);
    }

    @Override
    public String getOwner() {
        return this.handle.getOwner();
    }

    @Override
    public void setOwner(String string) {
        boolean bl;
        if (MemberRef$Handle.lIlllIIIlI(this.handle.getTag(), 9)) {
            bl = true;
            "".length();
            if ((0x3D ^ 0x39) == 0) {
                return;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        this.handle = new Handle(this.handle.getTag(), string, this.handle.getName(), this.handle.getDesc(), bl2);
    }

    @Override
    public String getName() {
        return this.handle.getName();
    }

    @Override
    public void setName(String string) {
        boolean bl;
        if (MemberRef$Handle.lIlllIIIlI(this.handle.getTag(), 9)) {
            bl = true;
            "".length();
            if (null != null) {
                return;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        this.handle = new Handle(this.handle.getTag(), this.handle.getOwner(), string, this.handle.getDesc(), bl2);
    }

    @Override
    public String getDesc() {
        return this.handle.getDesc();
    }

    @Override
    public void setDesc(String string) {
        boolean bl;
        if (MemberRef$Handle.lIlllIIIlI(this.handle.getTag(), 9)) {
            bl = true;
            "".length();
            if ((0xE ^ 0xA) < 0) {
                return;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        this.handle = new Handle(this.handle.getTag(), this.handle.getOwner(), this.handle.getName(), string, bl2);
    }

    private static boolean lIlllIIIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlllIIIIl(int n) {
        return n == 0;
    }
}

