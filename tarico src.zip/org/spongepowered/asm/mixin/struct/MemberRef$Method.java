/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.struct;

import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.mixin.struct.MemberRef;

public final class MemberRef$Method
extends MemberRef {
    private static final int OPCODES = 191;
    public final MethodInsnNode insn;

    public MemberRef$Method(MethodInsnNode methodInsnNode) {
        this.insn = methodInsnNode;
    }

    @Override
    public boolean isField() {
        return false;
    }

    @Override
    public int getOpcode() {
        return this.insn.getOpcode();
    }

    @Override
    public void setOpcode(int n) {
        if (MemberRef$Method.llIIIlIIlll(n & 0xBF)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid opcode for method instruction: 0x").append(Integer.toHexString(n))));
        }
        this.insn.setOpcode(n);
    }

    @Override
    public String getOwner() {
        return this.insn.owner;
    }

    @Override
    public void setOwner(String string) {
        this.insn.owner = string;
    }

    @Override
    public String getName() {
        return this.insn.name;
    }

    @Override
    public void setName(String string) {
        this.insn.name = string;
    }

    @Override
    public String getDesc() {
        return this.insn.desc;
    }

    @Override
    public void setDesc(String string) {
        this.insn.desc = string;
    }

    private static boolean llIIIlIIlll(int n) {
        return n == 0;
    }
}

