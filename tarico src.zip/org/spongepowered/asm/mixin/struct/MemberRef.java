/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.struct;

import org.spongepowered.asm.util.Bytecode;

public abstract class MemberRef {
    private static final int[] H_OPCODES = new int[]{0, 180, 178, 181, 179, 182, 184, 183, 183, 185};

    public abstract boolean isField();

    public abstract int getOpcode();

    public abstract void setOpcode(int var1);

    public abstract String getOwner();

    public abstract void setOwner(String var1);

    public abstract String getName();

    public abstract void setName(String var1);

    public abstract String getDesc();

    public abstract void setDesc(String var1);

    public String toString() {
        String string;
        String string2 = Bytecode.getOpcodeName(this.getOpcode());
        Object[] objectArray = new Object[5];
        objectArray[0] = string2;
        objectArray[1] = this.getOwner();
        objectArray[2] = this.getName();
        if (MemberRef.lIllIIIllll(this.isField() ? 1 : 0)) {
            string = ":";
            "".length();
            if (" ".length() <= 0) {
                return null;
            }
        } else {
            string = "";
        }
        objectArray[3] = string;
        objectArray[4] = this.getDesc();
        return String.format("%s for %s.%s%s%s", objectArray);
    }

    public boolean equals(Object object) {
        boolean bl;
        if (MemberRef.lIllIIlIIII(object instanceof MemberRef)) {
            return false;
        }
        MemberRef memberRef = (MemberRef)object;
        if (MemberRef.lIllIIlIIIl(this.getOpcode(), memberRef.getOpcode()) && MemberRef.lIllIIIllll(this.getOwner().equals(memberRef.getOwner()) ? 1 : 0) && MemberRef.lIllIIIllll(this.getName().equals(memberRef.getName()) ? 1 : 0) && MemberRef.lIllIIIllll(this.getDesc().equals(memberRef.getDesc()) ? 1 : 0)) {
            bl = true;
            "".length();
            if (-"   ".length() >= 0) {
                return ((168 + 241 - 162 + 2 ^ 120 + 82 - 166 + 137) & ("   ".length() ^ (0x1F ^ 0x48) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.toString().hashCode();
    }

    static int opcodeFromTag(int n) {
        int n2;
        if (MemberRef.lIllIIlIIlI(n) && MemberRef.lIllIIlIIll(n, H_OPCODES.length)) {
            n2 = H_OPCODES[n];
            "".length();
            if ((0xE6 ^ 0x8D ^ (0x21 ^ 0x4F)) <= 0) {
                return (0xF1 ^ 0x99 ^ (0x38 ^ 0x73)) & (0xE7 ^ 0x8C ^ (0x60 ^ 0x28) ^ -" ".length());
            }
        } else {
            n2 = 0;
        }
        return n2;
    }

    static int tagFromOpcode(int n) {
        int n2 = 1;
        while (MemberRef.lIllIIlIIll(n2, H_OPCODES.length)) {
            if (MemberRef.lIllIIlIIIl(H_OPCODES[n2], n)) {
                return n2;
            }
            ++n2;
            "".length();
            if ("   ".length() > -" ".length()) continue;
            return (0x78 ^ 0x3B) & ~(0x40 ^ 3);
        }
        return 0;
    }

    private static boolean lIllIIlIIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIllIIlIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllIIIllll(int n) {
        return n != 0;
    }

    private static boolean lIllIIlIIII(int n) {
        return n == 0;
    }

    private static boolean lIllIIlIIlI(int n) {
        return n >= 0;
    }
}

