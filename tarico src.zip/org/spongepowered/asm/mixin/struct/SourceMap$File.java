/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.struct;

import java.util.Iterator;
import java.util.ListIterator;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.LineNumberNode;
import org.spongepowered.asm.lib.tree.MethodNode;

public class SourceMap$File {
    public final int id;
    public final int lineOffset;
    public final int size;
    public final String sourceFileName;
    public final String sourceFilePath;

    public SourceMap$File(int n, int n2, int n3, String string) {
        this(n, n2, n3, string, null);
    }

    public SourceMap$File(int n, int n2, int n3, String string, String string2) {
        this.id = n;
        this.lineOffset = n2;
        this.size = n3;
        this.sourceFileName = string;
        this.sourceFilePath = string2;
    }

    public void applyOffset(ClassNode classNode) {
        Iterator<MethodNode> iterator = classNode.methods.iterator();
        while (SourceMap$File.lIIIllIIll(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            this.applyOffset(methodNode);
            "".length();
            if (((0x7A ^ 0x75 ^ (0x90 ^ 0x82)) & (0x59 ^ 0x4E ^ (0xA7 ^ 0xAD) ^ -" ".length())) <= (0x73 ^ 0x19 ^ (0x71 ^ 0x1F))) continue;
            return;
        }
    }

    public void applyOffset(MethodNode methodNode) {
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (SourceMap$File.lIIIllIIll(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (SourceMap$File.lIIIllIIll(abstractInsnNode instanceof LineNumberNode)) {
                ((LineNumberNode)abstractInsnNode).line += this.lineOffset - 1;
            }
            "".length();
            if (" ".length() > ((0x1C ^ 0xA) & ~(0xB0 ^ 0xA6))) continue;
            return;
        }
    }

    void appendFile(StringBuilder stringBuilder) {
        if (SourceMap$File.lIIIllIlIl(this.sourceFilePath)) {
            stringBuilder.append("+ ").append(this.id).append(" ").append(this.sourceFileName).append("\n");
            "".length();
            stringBuilder.append(this.sourceFilePath).append("\n");
            "".length();
            "".length();
            if (" ".length() <= 0) {
                return;
            }
        } else {
            stringBuilder.append(this.id).append(" ").append(this.sourceFileName).append("\n");
            "".length();
        }
    }

    public void appendLines(StringBuilder stringBuilder) {
        stringBuilder.append("1#").append(this.id).append(",").append(this.size).append(":").append(this.lineOffset).append("\n");
        "".length();
    }

    private static boolean lIIIllIlIl(Object object) {
        return object != null;
    }

    private static boolean lIIIllIIll(int n) {
        return n != 0;
    }
}

