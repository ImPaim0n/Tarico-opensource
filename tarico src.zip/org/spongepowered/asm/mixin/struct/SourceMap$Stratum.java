/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.struct;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import org.spongepowered.asm.mixin.struct.SourceMap$File;

class SourceMap$Stratum {
    private static final String STRATUM_MARK;
    private static final String FILE_MARK;
    private static final String LINES_MARK;
    public final String name;
    private final Map<String, SourceMap$File> files = new LinkedHashMap<String, SourceMap$File>();

    public SourceMap$Stratum(String string) {
        this.name = string;
    }

    public SourceMap$File addFile(int n, int n2, String string, String string2) {
        SourceMap$File sourceMap$File = this.files.get(string2);
        if (SourceMap$Stratum.lIIIIIllllIl(sourceMap$File)) {
            sourceMap$File = new SourceMap$File(this.files.size() + 1, n, n2, string, string2);
            this.files.put(string2, sourceMap$File);
            "".length();
        }
        return sourceMap$File;
    }

    void appendTo(StringBuilder stringBuilder) {
        SourceMap$File sourceMap$File;
        stringBuilder.append("*S").append(" ").append(this.name).append("\n");
        "".length();
        stringBuilder.append("*F").append("\n");
        "".length();
        Iterator<SourceMap$File> iterator = this.files.values().iterator();
        while (SourceMap$Stratum.lIIIIIlllllI(iterator.hasNext() ? 1 : 0)) {
            sourceMap$File = iterator.next();
            sourceMap$File.appendFile(stringBuilder);
            "".length();
            if ((0x3B ^ 0x3F) >= " ".length()) continue;
            return;
        }
        stringBuilder.append("*L").append("\n");
        "".length();
        iterator = this.files.values().iterator();
        while (SourceMap$Stratum.lIIIIIlllllI(iterator.hasNext() ? 1 : 0)) {
            sourceMap$File = iterator.next();
            sourceMap$File.appendLines(stringBuilder);
            "".length();
            if (-"   ".length() <= 0) continue;
            return;
        }
    }

    static {
        FILE_MARK = "*F";
        STRATUM_MARK = "*S";
        LINES_MARK = "*L";
    }

    private static boolean lIIIIIllllIl(Object object) {
        return object == null;
    }

    private static boolean lIIIIIlllllI(int n) {
        return n != 0;
    }
}

