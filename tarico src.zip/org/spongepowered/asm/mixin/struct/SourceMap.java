/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.struct;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.struct.SourceMap$File;
import org.spongepowered.asm.mixin.struct.SourceMap$Stratum;
import org.spongepowered.asm.util.Bytecode;

public class SourceMap {
    private static final String DEFAULT_STRATUM = "Mixin";
    private static final String NEWLINE = "\n";
    private final String sourceFile;
    private final Map<String, SourceMap$Stratum> strata = new LinkedHashMap<String, SourceMap$Stratum>();
    private int nextLineOffset = 1;
    private String defaultStratum = "Mixin";

    public SourceMap(String string) {
        this.sourceFile = string;
    }

    public String getSourceFile() {
        return this.sourceFile;
    }

    public String getPseudoGeneratedSourceFile() {
        return this.sourceFile.replace(".java", "$mixin.java");
    }

    public SourceMap$File addFile(ClassNode classNode) {
        return this.addFile(this.defaultStratum, classNode);
    }

    public SourceMap$File addFile(String string, ClassNode classNode) {
        return this.addFile(string, classNode.sourceFile, String.valueOf(new StringBuilder().append(classNode.name).append(".java")), Bytecode.getMaxLineNumber(classNode, 500, 50));
    }

    public SourceMap$File addFile(String string, String string2, int n) {
        return this.addFile(this.defaultStratum, string, string2, n);
    }

    public SourceMap$File addFile(String string, String string2, String string3, int n) {
        SourceMap$Stratum sourceMap$Stratum = this.strata.get(string);
        if (SourceMap.llIlIIIlIIl(sourceMap$Stratum)) {
            sourceMap$Stratum = new SourceMap$Stratum(string);
            this.strata.put(string, sourceMap$Stratum);
            "".length();
        }
        SourceMap$File sourceMap$File = sourceMap$Stratum.addFile(this.nextLineOffset, n, string2, string3);
        this.nextLineOffset += n;
        return sourceMap$File;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        this.appendTo(stringBuilder);
        return String.valueOf(stringBuilder);
    }

    private void appendTo(StringBuilder stringBuilder) {
        stringBuilder.append("SMAP").append("\n");
        "".length();
        stringBuilder.append(this.getSourceFile()).append("\n");
        "".length();
        stringBuilder.append(this.defaultStratum).append("\n");
        "".length();
        Iterator<SourceMap$Stratum> iterator = this.strata.values().iterator();
        while (SourceMap.llIlIIIlIlI(iterator.hasNext() ? 1 : 0)) {
            SourceMap$Stratum sourceMap$Stratum = iterator.next();
            sourceMap$Stratum.appendTo(stringBuilder);
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
        stringBuilder.append("*E").append("\n");
        "".length();
    }

    private static boolean llIlIIIlIIl(Object object) {
        return object == null;
    }

    private static boolean llIlIIIlIlI(int n) {
        return n != 0;
    }
}

