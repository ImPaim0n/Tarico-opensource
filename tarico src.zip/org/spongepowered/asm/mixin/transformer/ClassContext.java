/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Set;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.struct.MemberRef;
import org.spongepowered.asm.mixin.struct.MemberRef$Method;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;

abstract class ClassContext {
    private final Set<ClassInfo$Method> upgradedMethods = new HashSet<ClassInfo$Method>();

    ClassContext() {
    }

    abstract String getClassRef();

    abstract ClassNode getClassNode();

    abstract ClassInfo getClassInfo();

    void addUpgradedMethod(MethodNode methodNode) {
        ClassInfo$Method classInfo$Method = this.getClassInfo().findMethod(methodNode);
        if (ClassContext.llIIIIIll(classInfo$Method)) {
            throw new IllegalStateException(String.valueOf(new StringBuilder().append("Meta method for ").append(methodNode.name).append(" not located in ").append(this)));
        }
        this.upgradedMethods.add(classInfo$Method);
        "".length();
    }

    protected void upgradeMethods() {
        Iterator<MethodNode> iterator = this.getClassNode().methods.iterator();
        while (ClassContext.llIIIIlII(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            this.upgradeMethod(methodNode);
            "".length();
            if (((0x4C ^ 0x17) & ~(0x56 ^ 0xD)) == 0) continue;
            return;
        }
    }

    private void upgradeMethod(MethodNode methodNode) {
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (ClassContext.llIIIIlII(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (ClassContext.llIIIIlIl(abstractInsnNode instanceof MethodInsnNode)) {
                "".length();
                if ((0x16 ^ 0x13) > 0) continue;
                return;
            }
            MemberRef$Method memberRef$Method = new MemberRef$Method((MethodInsnNode)abstractInsnNode);
            if (ClassContext.llIIIIlII(((MemberRef)memberRef$Method).getOwner().equals(this.getClassRef()) ? 1 : 0)) {
                ClassInfo$Method classInfo$Method = this.getClassInfo().findMethod(((MemberRef)memberRef$Method).getName(), ((MemberRef)memberRef$Method).getDesc(), 10);
                this.upgradeMethodRef(methodNode, memberRef$Method, classInfo$Method);
            }
            "".length();
            if ((0xC2 ^ 0xC6) >= 0) continue;
            return;
        }
    }

    protected void upgradeMethodRef(MethodNode methodNode, MemberRef memberRef, ClassInfo$Method classInfo$Method) {
        if (ClassContext.llIIIIllI(memberRef.getOpcode(), 183)) {
            return;
        }
        if (ClassContext.llIIIIlII(this.upgradedMethods.contains(classInfo$Method) ? 1 : 0)) {
            memberRef.setOpcode(182);
        }
    }

    private static boolean llIIIIIll(Object object) {
        return object == null;
    }

    private static boolean llIIIIlII(int n) {
        return n != 0;
    }

    private static boolean llIIIIlIl(int n) {
        return n == 0;
    }

    private static boolean llIIIIllI(int n, int n2) {
        return n != n2;
    }
}

