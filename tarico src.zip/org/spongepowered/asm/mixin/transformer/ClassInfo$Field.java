/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member$Type;
import org.spongepowered.asm.util.Annotations;

class ClassInfo$Field
extends ClassInfo$Member {
    final /* synthetic */ ClassInfo this$0;

    public ClassInfo$Field(ClassInfo classInfo, ClassInfo$Member classInfo$Member) {
        this.this$0 = classInfo;
        super(classInfo$Member);
    }

    public ClassInfo$Field(ClassInfo classInfo, FieldNode fieldNode) {
        this(classInfo, fieldNode, false);
    }

    public ClassInfo$Field(ClassInfo classInfo, FieldNode fieldNode, boolean bl) {
        boolean bl2;
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.FIELD, fieldNode.name, fieldNode.desc, fieldNode.access, bl);
        if (ClassInfo$Field.lIIllIIIl(Annotations.getVisible(fieldNode, Unique.class))) {
            bl2 = true;
            "".length();
            if (-(0x3F ^ 0x3A) >= 0) {
                throw null;
            }
        } else {
            bl2 = false;
        }
        this.setUnique(bl2);
        if (ClassInfo$Field.lIIllIIIl(Annotations.getVisible(fieldNode, Shadow.class))) {
            boolean bl3;
            boolean bl4;
            boolean bl5;
            if (ClassInfo$Field.lIIllIIIl(Annotations.getVisible(fieldNode, Final.class))) {
                bl5 = true;
                "".length();
                if ("   ".length() <= -" ".length()) {
                    throw null;
                }
            } else {
                bl5 = bl4 = false;
            }
            if (ClassInfo$Field.lIIllIIIl(Annotations.getVisible(fieldNode, Mutable.class))) {
                bl3 = true;
                "".length();
                if (" ".length() == 0) {
                    throw null;
                }
            } else {
                bl3 = false;
            }
            boolean bl6 = bl3;
            this.setDecoratedFinal(bl4, bl6);
        }
    }

    public ClassInfo$Field(ClassInfo classInfo, String string, String string2, int n) {
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.FIELD, string, string2, n, false);
    }

    public ClassInfo$Field(ClassInfo classInfo, String string, String string2, int n, boolean bl) {
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.FIELD, string, string2, n, bl);
    }

    @Override
    public ClassInfo getOwner() {
        return this.this$0;
    }

    @Override
    public boolean equals(Object object) {
        if (ClassInfo$Field.lIIllIIlI(object instanceof ClassInfo$Field)) {
            return false;
        }
        return super.equals(object);
    }

    @Override
    protected String getDisplayFormat() {
        return "%s:%s";
    }

    private static boolean lIIllIIIl(Object object) {
        return object != null;
    }

    private static boolean lIIllIIlI(int n) {
        return n == 0;
    }
}

