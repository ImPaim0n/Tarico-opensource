/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.lib.tree.FrameNode;

public class ClassInfo$FrameData {
    private static final String[] FRAMETYPES = new String[]{"NEW", "FULL", "APPEND", "CHOP", "SAME", "SAME1"};
    public final int index;
    public final int type;
    public final int locals;

    ClassInfo$FrameData(int n, int n2, int n3) {
        this.index = n;
        this.type = n2;
        this.locals = n3;
    }

    ClassInfo$FrameData(int n, FrameNode frameNode) {
        int n2;
        this.index = n;
        this.type = frameNode.type;
        if (ClassInfo$FrameData.llllllIIlII(frameNode.local)) {
            n2 = frameNode.local.size();
            "".length();
            if ("   ".length() <= 0) {
                throw null;
            }
        } else {
            n2 = 0;
        }
        this.locals = n2;
    }

    public String toString() {
        return String.format("FrameData[index=%d, type=%s, locals=%d]", this.index, FRAMETYPES[this.type + 1], this.locals);
    }

    private static boolean llllllIIlII(Object object) {
        return object != null;
    }
}

