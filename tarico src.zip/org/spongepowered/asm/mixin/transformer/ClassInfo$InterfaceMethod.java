/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;

public class ClassInfo$InterfaceMethod
extends ClassInfo$Method {
    private final ClassInfo owner;
    final /* synthetic */ ClassInfo this$0;

    public ClassInfo$InterfaceMethod(ClassInfo classInfo, ClassInfo$Member classInfo$Member) {
        this.this$0 = classInfo;
        super(classInfo, classInfo$Member);
        this.owner = classInfo$Member.getOwner();
    }

    @Override
    public ClassInfo getOwner() {
        return this.owner;
    }

    @Override
    public ClassInfo getImplementor() {
        return this.this$0;
    }
}

