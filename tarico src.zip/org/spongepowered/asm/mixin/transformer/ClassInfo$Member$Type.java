/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

enum ClassInfo$Member$Type {
    METHOD,
    FIELD;

}

