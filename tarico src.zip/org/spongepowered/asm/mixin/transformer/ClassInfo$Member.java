/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member$Type;

abstract class ClassInfo$Member {
    private final Type type;
    private final String memberName;
    private final String memberDesc;
    private final boolean isInjected;
    private final int modifiers;
    private String currentName;
    private String currentDesc;
    private boolean decoratedFinal;
    private boolean decoratedMutable;
    private boolean unique;

    protected ClassInfo$Member(ClassInfo$Member classInfo$Member) {
        this(classInfo$Member.type, classInfo$Member.memberName, classInfo$Member.memberDesc, classInfo$Member.modifiers, classInfo$Member.isInjected);
        this.currentName = classInfo$Member.currentName;
        this.currentDesc = classInfo$Member.currentDesc;
        this.unique = classInfo$Member.unique;
    }

    protected ClassInfo$Member(Type type, String string, String string2, int n) {
        this(type, string, string2, n, false);
    }

    protected ClassInfo$Member(Type type, String string, String string2, int n, boolean bl) {
        this.type = type;
        this.memberName = string;
        this.memberDesc = string2;
        this.isInjected = bl;
        this.currentName = string;
        this.currentDesc = string2;
        this.modifiers = n;
    }

    public String getOriginalName() {
        return this.memberName;
    }

    public String getName() {
        return this.currentName;
    }

    public String getOriginalDesc() {
        return this.memberDesc;
    }

    public String getDesc() {
        return this.currentDesc;
    }

    public boolean isInjected() {
        return this.isInjected;
    }

    public boolean isRenamed() {
        boolean bl;
        if (ClassInfo$Member.lIllIll(this.currentName.equals(this.memberName) ? 1 : 0)) {
            bl = true;
            "".length();
            if (" ".length() <= 0) {
                return ((0xDB ^ 0x80) & ~(0x14 ^ 0x4F)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isRemapped() {
        boolean bl;
        if (ClassInfo$Member.lIllIll(this.currentDesc.equals(this.memberDesc) ? 1 : 0)) {
            bl = true;
            "".length();
            if (((0xEF ^ 0x8E) & ~(0x24 ^ 0x45)) != ((0x77 ^ 0x7F) & ~(0x85 ^ 0x8D))) {
                return ((0xFB ^ 0xB3) & ~(0x1B ^ 0x53)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isPrivate() {
        boolean bl;
        if (ClassInfo$Member.lIlllII(this.modifiers & 2)) {
            bl = true;
            "".length();
            if (-"   ".length() >= 0) {
                return (("   ".length() ^ (0x67 ^ 0x7B)) & (0x37 ^ 0x10 ^ (0x4D ^ 0x75) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isStatic() {
        boolean bl;
        if (ClassInfo$Member.lIlllII(this.modifiers & 8)) {
            bl = true;
            "".length();
            if ("   ".length() <= ((97 + 174 - 156 + 66 ^ 110 + 48 - 74 + 60) & (7 + 140 - 101 + 106 ^ 160 + 46 - 191 + 174 ^ -" ".length()))) {
                return ((18 + 77 - 33 + 86 ^ 148 + 51 - 54 + 40) & (0x22 ^ 0x48 ^ (0x7D ^ 0x3A) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isAbstract() {
        boolean bl;
        if (ClassInfo$Member.lIlllII(this.modifiers & 0x400)) {
            bl = true;
            "".length();
            if (((0x1D ^ 0x4F) & ~(0xD9 ^ 0x8B)) > 0) {
                return ((0x74 ^ 0x41) & ~(0x28 ^ 0x1D)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isFinal() {
        boolean bl;
        if (ClassInfo$Member.lIlllII(this.modifiers & 0x10)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x4B ^ 0x74 ^ (0x67 ^ 0x79)) & (0x37 ^ 0x5A ^ (0xE6 ^ 0xAA) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isSynthetic() {
        boolean bl;
        if (ClassInfo$Member.lIlllII(this.modifiers & 0x1000)) {
            bl = true;
            "".length();
            if (-"   ".length() >= 0) {
                return ((0xA5 ^ 0xBF) & ~(0x53 ^ 0x49)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isUnique() {
        return this.unique;
    }

    public void setUnique(boolean bl) {
        this.unique = bl;
    }

    public boolean isDecoratedFinal() {
        return this.decoratedFinal;
    }

    public boolean isDecoratedMutable() {
        return this.decoratedMutable;
    }

    public void setDecoratedFinal(boolean bl, boolean bl2) {
        this.decoratedFinal = bl;
        this.decoratedMutable = bl2;
    }

    public boolean matchesFlags(int n) {
        boolean bl;
        if (ClassInfo$Member.lIlllII((~this.modifiers | n & 2) & 2) && ClassInfo$Member.lIlllII((~this.modifiers | n & 8) & 8)) {
            bl = true;
            "".length();
            if ("  ".length() < 0) {
                return ((0x53 ^ 0x7D) & ~(0x57 ^ 0x79)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public abstract ClassInfo getOwner();

    public ClassInfo getImplementor() {
        return this.getOwner();
    }

    public int getAccess() {
        return this.modifiers;
    }

    public String renameTo(String string) {
        this.currentName = string;
        return string;
    }

    public String remapTo(String string) {
        this.currentDesc = string;
        return string;
    }

    public boolean equals(String string, String string2) {
        boolean bl;
        if (!(ClassInfo$Member.lIllIll(this.memberName.equals(string) ? 1 : 0) && !ClassInfo$Member.lIlllII(this.currentName.equals(string) ? 1 : 0) || ClassInfo$Member.lIllIll(this.memberDesc.equals(string2) ? 1 : 0) && !ClassInfo$Member.lIlllII(this.currentDesc.equals(string2) ? 1 : 0))) {
            bl = true;
            "".length();
            if (((0 ^ 0x3D) & ~(0xA8 ^ 0x95)) != 0) {
                return ((0xB2 ^ 0xA7) & ~(0xA9 ^ 0xBC)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (ClassInfo$Member.lIllIll(object instanceof ClassInfo$Member)) {
            return false;
        }
        ClassInfo$Member classInfo$Member = (ClassInfo$Member)object;
        if (!(ClassInfo$Member.lIllIll(classInfo$Member.memberName.equals(this.memberName) ? 1 : 0) && !ClassInfo$Member.lIlllII(classInfo$Member.currentName.equals(this.currentName) ? 1 : 0) || ClassInfo$Member.lIllIll(classInfo$Member.memberDesc.equals(this.memberDesc) ? 1 : 0) && !ClassInfo$Member.lIlllII(classInfo$Member.currentDesc.equals(this.currentDesc) ? 1 : 0))) {
            bl = true;
            "".length();
            if (" ".length() == -" ".length()) {
                return ((0xB ^ 0x38) & ~(0xA9 ^ 0x9A)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.toString().hashCode();
    }

    public String toString() {
        return String.format(this.getDisplayFormat(), this.memberName, this.memberDesc);
    }

    protected String getDisplayFormat() {
        return "%s%s";
    }

    private static boolean lIlllII(int n) {
        return n != 0;
    }

    private static boolean lIllIll(int n) {
        return n == 0;
    }
}

