/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.FrameNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$FrameData;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member$Type;
import org.spongepowered.asm.util.Annotations;

public class ClassInfo$Method
extends ClassInfo$Member {
    private final List<ClassInfo$FrameData> frames;
    private boolean isAccessor;
    final /* synthetic */ ClassInfo this$0;

    public ClassInfo$Method(ClassInfo classInfo, ClassInfo$Member classInfo$Member) {
        List<ClassInfo$FrameData> list;
        this.this$0 = classInfo;
        super(classInfo$Member);
        if (ClassInfo$Method.llIlIIlIIIl(classInfo$Member instanceof ClassInfo$Method)) {
            list = ((ClassInfo$Method)classInfo$Member).frames;
            "".length();
            if (-" ".length() >= (0xBB ^ 0x93 ^ (1 ^ 0x2D))) {
                throw null;
            }
        } else {
            list = null;
        }
        this.frames = list;
    }

    public ClassInfo$Method(ClassInfo classInfo, MethodNode methodNode) {
        this(classInfo, methodNode, false);
        boolean bl;
        boolean bl2;
        if (ClassInfo$Method.llIlIIlIIlI(Annotations.getVisible(methodNode, Unique.class))) {
            bl2 = true;
            "".length();
            if ((0x5D ^ 0x59) <= -" ".length()) {
                throw null;
            }
        } else {
            bl2 = false;
        }
        this.setUnique(bl2);
        if (ClassInfo$Method.llIlIIlIIlI(Annotations.getSingleVisible(methodNode, Accessor.class, Invoker.class))) {
            bl = true;
            "".length();
            if (-"   ".length() >= 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.isAccessor = bl;
    }

    public ClassInfo$Method(ClassInfo classInfo, MethodNode methodNode, boolean bl) {
        boolean bl2;
        boolean bl3;
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.METHOD, methodNode.name, methodNode.desc, methodNode.access, bl);
        this.frames = this.gatherFrames(methodNode);
        if (ClassInfo$Method.llIlIIlIIlI(Annotations.getVisible(methodNode, Unique.class))) {
            bl3 = true;
            "".length();
            if (-(0x8D ^ 0x88) >= 0) {
                throw null;
            }
        } else {
            bl3 = false;
        }
        this.setUnique(bl3);
        if (ClassInfo$Method.llIlIIlIIlI(Annotations.getSingleVisible(methodNode, Accessor.class, Invoker.class))) {
            bl2 = true;
            "".length();
            if (-" ".length() >= 0) {
                throw null;
            }
        } else {
            bl2 = false;
        }
        this.isAccessor = bl2;
    }

    public ClassInfo$Method(ClassInfo classInfo, String string, String string2) {
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.METHOD, string, string2, 1, false);
        this.frames = null;
    }

    public ClassInfo$Method(ClassInfo classInfo, String string, String string2, int n) {
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.METHOD, string, string2, n, false);
        this.frames = null;
    }

    public ClassInfo$Method(ClassInfo classInfo, String string, String string2, int n, boolean bl) {
        this.this$0 = classInfo;
        super(ClassInfo$Member$Type.METHOD, string, string2, n, bl);
        this.frames = null;
    }

    private List<ClassInfo$FrameData> gatherFrames(MethodNode methodNode) {
        ArrayList<ClassInfo$FrameData> arrayList = new ArrayList<ClassInfo$FrameData>();
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (ClassInfo$Method.llIlIIlIIIl(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (ClassInfo$Method.llIlIIlIIIl(abstractInsnNode instanceof FrameNode)) {
                arrayList.add(new ClassInfo$FrameData(methodNode.instructions.indexOf(abstractInsnNode), (FrameNode)abstractInsnNode));
                "".length();
            }
            "".length();
            if ("  ".length() == "  ".length()) continue;
            return null;
        }
        return arrayList;
    }

    public List<ClassInfo$FrameData> getFrames() {
        return this.frames;
    }

    @Override
    public ClassInfo getOwner() {
        return this.this$0;
    }

    public boolean isAccessor() {
        return this.isAccessor;
    }

    @Override
    public boolean equals(Object object) {
        if (ClassInfo$Method.llIlIIlIIll(object instanceof ClassInfo$Method)) {
            return false;
        }
        return super.equals(object);
    }

    private static boolean llIlIIlIIlI(Object object) {
        return object != null;
    }

    private static boolean llIlIIlIIIl(int n) {
        return n != 0;
    }

    private static boolean llIlIIlIIll(int n) {
        return n == 0;
    }
}

