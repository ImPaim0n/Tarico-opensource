/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

public enum ClassInfo$SearchType {
    ALL_CLASSES,
    SUPER_CLASSES_ONLY;

}

