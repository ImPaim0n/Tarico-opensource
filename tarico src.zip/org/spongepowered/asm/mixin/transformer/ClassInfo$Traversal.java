/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.transformer.ClassInfo$SearchType;

public enum ClassInfo$Traversal {
    NONE(null, false, ClassInfo$SearchType.SUPER_CLASSES_ONLY),
    ALL(null, true, ClassInfo$SearchType.ALL_CLASSES),
    IMMEDIATE(NONE, true, ClassInfo$SearchType.SUPER_CLASSES_ONLY),
    SUPER(ALL, false, ClassInfo$SearchType.SUPER_CLASSES_ONLY);

    private final ClassInfo$Traversal next;
    private final boolean traverse;
    private final ClassInfo$SearchType searchType;

    private ClassInfo$Traversal(ClassInfo$Traversal classInfo$Traversal, boolean bl, ClassInfo$SearchType classInfo$SearchType) {
        ClassInfo$Traversal classInfo$Traversal2;
        if (ClassInfo$Traversal.lllIIIIllll((Object)classInfo$Traversal)) {
            classInfo$Traversal2 = classInfo$Traversal;
            "".length();
            if (-(0x4B ^ 0x4F) > 0) {
                throw null;
            }
        } else {
            classInfo$Traversal2 = this;
        }
        this.next = classInfo$Traversal2;
        this.traverse = bl;
        this.searchType = classInfo$SearchType;
    }

    public ClassInfo$Traversal next() {
        return this.next;
    }

    public boolean canTraverse() {
        return this.traverse;
    }

    public ClassInfo$SearchType getSearchType() {
        return this.searchType;
    }

    private static boolean lllIIIIllll(Object object) {
        return object != null;
    }
}

