/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableSet
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Field;
import org.spongepowered.asm.mixin.transformer.ClassInfo$InterfaceMethod;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Member$Type;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.ClassInfo$SearchType;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Traversal;
import org.spongepowered.asm.mixin.transformer.MethodMapper;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.service.MixinService;
import org.spongepowered.asm.util.ClassSignature;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;

public final class ClassInfo {
    public static final int INCLUDE_PRIVATE;
    public static final int INCLUDE_STATIC;
    public static final int INCLUDE_ALL;
    private static final Logger logger;
    private static final Profiler profiler;
    private static final String JAVA_LANG_OBJECT;
    private static final Map<String, ClassInfo> cache;
    private static final ClassInfo OBJECT;
    private final String name;
    private final String superName;
    private final String outerName;
    private final boolean isProbablyStatic;
    private final Set<String> interfaces;
    private final Set<ClassInfo$Method> methods;
    private final Set<ClassInfo$Field> fields;
    private final Set<MixinInfo> mixins;
    private final Map<ClassInfo, ClassInfo> correspondingTypes;
    private final MixinInfo mixin;
    private final MethodMapper methodMapper;
    private final boolean isMixin;
    private final boolean isInterface;
    private final int access;
    private ClassInfo superClass;
    private ClassInfo outerClass;
    private ClassSignature signature;

    private ClassInfo() {
        this.mixins = new HashSet<MixinInfo>();
        this.correspondingTypes = new HashMap<ClassInfo, ClassInfo>();
        this.name = "java/lang/Object";
        this.superName = null;
        this.outerName = null;
        this.isProbablyStatic = true;
        this.methods = ImmutableSet.of((Object)new ClassInfo$Method(this, "getClass", "()Ljava/lang/Class;"), (Object)new ClassInfo$Method(this, "hashCode", "()I"), (Object)new ClassInfo$Method(this, "equals", "(Ljava/lang/Object;)Z"), (Object)new ClassInfo$Method(this, "clone", "()Ljava/lang/Object;"), (Object)new ClassInfo$Method(this, "toString", "()Ljava/lang/String;"), (Object)new ClassInfo$Method(this, "notify", "()V"), (Object[])new ClassInfo$Method[]{new ClassInfo$Method(this, "notifyAll", "()V"), new ClassInfo$Method(this, "wait", "(J)V"), new ClassInfo$Method(this, "wait", "(JI)V"), new ClassInfo$Method(this, "wait", "()V"), new ClassInfo$Method(this, "finalize", "()V")});
        this.fields = Collections.emptySet();
        this.isInterface = false;
        this.interfaces = Collections.emptySet();
        this.access = 1;
        this.isMixin = false;
        this.mixin = null;
        this.methodMapper = null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private ClassInfo(ClassNode classNode) {
        block17: {
            Object object;
            MixinInfo mixinInfo;
            boolean bl;
            String string;
            this.mixins = new HashSet<MixinInfo>();
            this.correspondingTypes = new HashMap<ClassInfo, ClassInfo>();
            Profiler$Section profiler$Section = profiler.begin(1, "class.meta");
            this.name = classNode.name;
            if (ClassInfo.lIIIIllIIlII(classNode.superName)) {
                string = classNode.superName;
                "".length();
                if (((0x6A ^ 0x54 ^ (0xBC ^ 0x9B)) & (43 + 9 - 31 + 118 ^ 32 + 94 - 55 + 75 ^ -" ".length())) < 0) {
                    throw null;
                }
            } else {
                string = "java/lang/Object";
            }
            this.superName = string;
            this.methods = new HashSet<ClassInfo$Method>();
            this.fields = new HashSet<ClassInfo$Field>();
            if (ClassInfo.lIIIIllIIlIl(classNode.access & 0x200)) {
                bl = true;
                "".length();
                if ("  ".length() != "  ".length()) {
                    throw null;
                }
            } else {
                bl = false;
            }
            this.isInterface = bl;
            this.interfaces = new HashSet<String>();
            this.access = classNode.access;
            this.isMixin = classNode instanceof MixinInfo$MixinClassNode;
            if (ClassInfo.lIIIIllIIlIl(this.isMixin ? 1 : 0)) {
                mixinInfo = ((MixinInfo$MixinClassNode)classNode).getMixin();
                "".length();
                if (" ".length() != " ".length()) {
                    throw null;
                }
            } else {
                mixinInfo = null;
            }
            this.mixin = mixinInfo;
            this.interfaces.addAll(classNode.interfaces);
            "".length();
            Iterator<MethodNode> iterator = classNode.methods.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object = iterator.next();
                this.addMethod((MethodNode)object, this.isMixin);
                "".length();
                if (-(0x57 ^ 5 ^ (0xD2 ^ 0x84)) <= 0) continue;
                throw null;
            }
            boolean bl2 = true;
            object = classNode.outerClass;
            Iterator<FieldNode> iterator2 = classNode.fields.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator2.hasNext() ? 1 : 0)) {
                FieldNode fieldNode = iterator2.next();
                if (ClassInfo.lIIIIllIIlIl(fieldNode.access & 0x1000) && ClassInfo.lIIIIllIIlIl(fieldNode.name.startsWith("this$") ? 1 : 0)) {
                    bl2 = false;
                    if (ClassInfo.lIIIIllIIllI(object) && ClassInfo.lIIIIllIIlII(object = fieldNode.desc) && ClassInfo.lIIIIllIIlIl(((String)object).startsWith("L") ? 1 : 0)) {
                        object = ((String)object).substring(1, ((String)object).length() - 1);
                    }
                }
                this.fields.add(new ClassInfo$Field(this, fieldNode, this.isMixin));
                "".length();
                "".length();
                if (-"   ".length() < 0) continue;
                throw null;
            }
            this.isProbablyStatic = bl2;
            this.outerName = object;
            this.methodMapper = new MethodMapper(MixinEnvironment.getCurrentEnvironment(), this);
            this.signature = ClassSignature.ofLazy(classNode);
            "".length();
            if (" ".length() < 0) {
                throw null;
            }
            break block17;
            finally {
                profiler$Section.end();
                "".length();
            }
        }
    }

    void addInterface(String string) {
        this.interfaces.add(string);
        "".length();
        this.getSignature().addInterface(string);
    }

    void addMethod(MethodNode methodNode) {
        this.addMethod(methodNode, true);
    }

    private void addMethod(MethodNode methodNode, boolean bl) {
        if (ClassInfo.lIIIIllIIlll(methodNode.name.startsWith("<") ? 1 : 0)) {
            this.methods.add(new ClassInfo$Method(this, methodNode, bl));
            "".length();
        }
    }

    void addMixin(MixinInfo mixinInfo) {
        if (ClassInfo.lIIIIllIIlIl(this.isMixin ? 1 : 0)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Cannot add target ").append(this.name).append(" for ").append(mixinInfo.getClassName()).append(" because the target is a mixin")));
        }
        this.mixins.add(mixinInfo);
        "".length();
    }

    public Set<MixinInfo> getMixins() {
        return Collections.unmodifiableSet(this.mixins);
    }

    public boolean isMixin() {
        return this.isMixin;
    }

    public boolean isPublic() {
        boolean bl;
        if (ClassInfo.lIIIIllIIlIl(this.access & 1)) {
            bl = true;
            "".length();
            if (null != null) {
                return ("   ".length() & ~"   ".length()) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isAbstract() {
        boolean bl;
        if (ClassInfo.lIIIIllIIlIl(this.access & 0x400)) {
            bl = true;
            "".length();
            if ("  ".length() == 0) {
                return ("   ".length() & ~"   ".length()) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isSynthetic() {
        boolean bl;
        if (ClassInfo.lIIIIllIIlIl(this.access & 0x1000)) {
            bl = true;
            "".length();
            if (((0x80 ^ 0xA6 ^ (0x58 ^ 0x25)) & (84 + 61 - 49 + 109 ^ 138 + 55 - 69 + 26 ^ -" ".length())) != 0) {
                return ((0x69 ^ 0x4F ^ (0x3C ^ 0x4A)) & (6 ^ 0x3A ^ (0x2E ^ 0x42) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isProbablyStatic() {
        return this.isProbablyStatic;
    }

    public boolean isInner() {
        boolean bl;
        if (ClassInfo.lIIIIllIIlII(this.outerName)) {
            bl = true;
            "".length();
            if (-" ".length() != -" ".length()) {
                return ((0x6B ^ 0x41) & ~(0x79 ^ 0x53)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isInterface() {
        return this.isInterface;
    }

    public Set<String> getInterfaces() {
        return Collections.unmodifiableSet(this.interfaces);
    }

    public String toString() {
        return this.name;
    }

    public MethodMapper getMethodMapper() {
        return this.methodMapper;
    }

    public int getAccess() {
        return this.access;
    }

    public String getName() {
        return this.name;
    }

    public String getClassName() {
        return this.name.replace('/', '.');
    }

    public String getSuperName() {
        return this.superName;
    }

    public ClassInfo getSuperClass() {
        if (ClassInfo.lIIIIllIIllI(this.superClass) && ClassInfo.lIIIIllIIlII(this.superName)) {
            this.superClass = ClassInfo.forName(this.superName);
        }
        return this.superClass;
    }

    public String getOuterName() {
        return this.outerName;
    }

    public ClassInfo getOuterClass() {
        if (ClassInfo.lIIIIllIIllI(this.outerClass) && ClassInfo.lIIIIllIIlII(this.outerName)) {
            this.outerClass = ClassInfo.forName(this.outerName);
        }
        return this.outerClass;
    }

    public ClassSignature getSignature() {
        return this.signature.wake();
    }

    List<ClassInfo> getTargets() {
        if (ClassInfo.lIIIIllIIlII(this.mixin)) {
            ArrayList<ClassInfo> arrayList = new ArrayList<ClassInfo>();
            arrayList.add(this);
            "".length();
            arrayList.addAll(this.mixin.getTargets());
            "".length();
            return arrayList;
        }
        return ImmutableList.of((Object)this);
    }

    public Set<ClassInfo$Method> getMethods() {
        return Collections.unmodifiableSet(this.methods);
    }

    public Set<ClassInfo$Method> getInterfaceMethods(boolean bl) {
        HashSet<ClassInfo$Method> hashSet = new HashSet<ClassInfo$Method>();
        ClassInfo classInfo = this.addMethodsRecursive(hashSet, bl);
        if (ClassInfo.lIIIIllIIlll(this.isInterface ? 1 : 0)) {
            while (ClassInfo.lIIIIllIIlII(classInfo) && ClassInfo.lIIIIllIlIII(classInfo, OBJECT)) {
                classInfo = classInfo.addMethodsRecursive(hashSet, bl);
                "".length();
                if (((0x8B ^ 0x93) & ~(0x93 ^ 0x8B)) == 0) continue;
                return null;
            }
        }
        Iterator iterator = hashSet.iterator();
        while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
            if (!ClassInfo.lIIIIllIIlll(((ClassInfo$Method)iterator.next()).isAbstract() ? 1 : 0)) continue;
            iterator.remove();
            "".length();
            if (-"   ".length() < 0) continue;
            return null;
        }
        return Collections.unmodifiableSet(hashSet);
    }

    private ClassInfo addMethodsRecursive(Set<ClassInfo$Method> set, boolean bl) {
        Object object;
        Iterator<Object> iterator;
        if (ClassInfo.lIIIIllIIlIl(this.isInterface ? 1 : 0)) {
            iterator = this.methods.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object = (ClassInfo$Method)iterator.next();
                if (ClassInfo.lIIIIllIIlll(((ClassInfo$Method)object).isAbstract() ? 1 : 0)) {
                    set.remove(object);
                    "".length();
                }
                set.add((ClassInfo$Method)object);
                "".length();
                "".length();
                if (((5 ^ 0x26) & ~(0x54 ^ 0x77)) <= ((0x73 ^ 0x3E) & ~(7 ^ 0x4A))) continue;
                return null;
            }
            "".length();
            if (-"  ".length() >= 0) {
                return null;
            }
        } else if (ClassInfo.lIIIIllIIlll(this.isMixin ? 1 : 0) && ClassInfo.lIIIIllIIlIl(bl ? 1 : 0)) {
            iterator = this.mixins.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object = (MixinInfo)iterator.next();
                ((MixinInfo)object).getClassInfo().addMethodsRecursive(set, bl);
                "".length();
                "".length();
                if (-" ".length() <= "   ".length()) continue;
                return null;
            }
        }
        iterator = this.interfaces.iterator();
        while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
            object = (String)iterator.next();
            ClassInfo.forName((String)object).addMethodsRecursive(set, bl);
            "".length();
            "".length();
            if (-" ".length() <= 0) continue;
            return null;
        }
        return this.getSuperClass();
    }

    public boolean hasSuperClass(String string) {
        return this.hasSuperClass(string, ClassInfo$Traversal.NONE);
    }

    public boolean hasSuperClass(String string, ClassInfo$Traversal classInfo$Traversal) {
        boolean bl;
        if (ClassInfo.lIIIIllIIlIl("java/lang/Object".equals(string) ? 1 : 0)) {
            return true;
        }
        if (ClassInfo.lIIIIllIIlII(this.findSuperClass(string, classInfo$Traversal))) {
            bl = true;
            "".length();
            if (("  ".length() ^ (0x3F ^ 0x39)) <= 0) {
                return ((4 ^ 0x32 ^ (0xA5 ^ 0xB9)) & (0xC ^ 0x15 ^ (0x6F ^ 0x5C) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean hasSuperClass(ClassInfo classInfo) {
        return this.hasSuperClass(classInfo, ClassInfo$Traversal.NONE, false);
    }

    public boolean hasSuperClass(ClassInfo classInfo, ClassInfo$Traversal classInfo$Traversal) {
        return this.hasSuperClass(classInfo, classInfo$Traversal, false);
    }

    public boolean hasSuperClass(ClassInfo classInfo, ClassInfo$Traversal classInfo$Traversal, boolean bl) {
        boolean bl2;
        if (ClassInfo.lIIIIllIlIIl(OBJECT, classInfo)) {
            return true;
        }
        if (ClassInfo.lIIIIllIIlII(this.findSuperClass(classInfo.name, classInfo$Traversal, bl))) {
            bl2 = true;
            "".length();
            if (((0x2A ^ 0x22 ^ (0x75 ^ 0x56)) & (220 + 53 - 175 + 139 ^ 45 + 116 - 55 + 92 ^ -" ".length())) != 0) {
                return ((83 + 30 - 4 + 63 ^ 119 + 63 - 7 + 12) & (0x9D ^ 0x81 ^ (0x95 ^ 0x9E) ^ -" ".length())) != 0;
            }
        } else {
            bl2 = false;
        }
        return bl2;
    }

    public ClassInfo findSuperClass(String string) {
        return this.findSuperClass(string, ClassInfo$Traversal.NONE);
    }

    public ClassInfo findSuperClass(String string, ClassInfo$Traversal classInfo$Traversal) {
        return this.findSuperClass(string, classInfo$Traversal, false, new HashSet<String>());
    }

    public ClassInfo findSuperClass(String string, ClassInfo$Traversal classInfo$Traversal, boolean bl) {
        if (ClassInfo.lIIIIllIIlIl(ClassInfo.OBJECT.name.equals(string) ? 1 : 0)) {
            return null;
        }
        return this.findSuperClass(string, classInfo$Traversal, bl, new HashSet<String>());
    }

    private ClassInfo findSuperClass(String string, ClassInfo$Traversal classInfo$Traversal, boolean bl, Set<String> set) {
        Object object;
        Object object2;
        Iterator<MixinInfo> iterator;
        ClassInfo classInfo = this.getSuperClass();
        if (ClassInfo.lIIIIllIIlII(classInfo)) {
            iterator = classInfo.getTargets().iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object2 = (ClassInfo)iterator.next();
                if (ClassInfo.lIIIIllIIlIl(string.equals(((ClassInfo)object2).getName()) ? 1 : 0)) {
                    return classInfo;
                }
                object = ((ClassInfo)object2).findSuperClass(string, classInfo$Traversal.next(), bl, set);
                if (ClassInfo.lIIIIllIIlII(object)) {
                    return object;
                }
                "".length();
                if ((0xF ^ 0xA) != 0) continue;
                return null;
            }
        }
        if (ClassInfo.lIIIIllIIlIl(bl ? 1 : 0) && ClassInfo.lIIIIllIIlII(iterator = this.findInterface(string))) {
            return iterator;
        }
        if (ClassInfo.lIIIIllIIlIl(classInfo$Traversal.canTraverse() ? 1 : 0)) {
            iterator = this.mixins.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object2 = iterator.next();
                object = ((MixinInfo)object2).getClassName();
                if (ClassInfo.lIIIIllIIlIl(set.contains(object) ? 1 : 0)) {
                    "".length();
                    if (-"  ".length() <= 0) continue;
                    return null;
                }
                set.add((String)object);
                "".length();
                ClassInfo classInfo2 = ((MixinInfo)object2).getClassInfo();
                if (ClassInfo.lIIIIllIIlIl(string.equals(classInfo2.getName()) ? 1 : 0)) {
                    return classInfo2;
                }
                ClassInfo classInfo3 = classInfo2.findSuperClass(string, ClassInfo$Traversal.ALL, bl, set);
                if (ClassInfo.lIIIIllIIlII(classInfo3)) {
                    return classInfo3;
                }
                "".length();
                if ("  ".length() >= 0) continue;
                return null;
            }
        }
        return null;
    }

    private ClassInfo findInterface(String string) {
        Iterator<String> iterator = this.getInterfaces().iterator();
        while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
            String string2 = iterator.next();
            ClassInfo classInfo = ClassInfo.forName(string2);
            if (ClassInfo.lIIIIllIIlIl(string.equals(string2) ? 1 : 0)) {
                return classInfo;
            }
            ClassInfo classInfo2 = classInfo.findInterface(string);
            if (ClassInfo.lIIIIllIIlII(classInfo2)) {
                return classInfo2;
            }
            "".length();
            if (" ".length() <= "   ".length()) continue;
            return null;
        }
        return null;
    }

    ClassInfo findCorrespondingType(ClassInfo classInfo) {
        if (!ClassInfo.lIIIIllIIlII(classInfo) || !ClassInfo.lIIIIllIIlIl(classInfo.isMixin ? 1 : 0) || ClassInfo.lIIIIllIIlIl(this.isMixin ? 1 : 0)) {
            return null;
        }
        ClassInfo classInfo2 = this.correspondingTypes.get(classInfo);
        if (ClassInfo.lIIIIllIIllI(classInfo2)) {
            classInfo2 = this.findSuperTypeForMixin(classInfo);
            this.correspondingTypes.put(classInfo, classInfo2);
            "".length();
        }
        return classInfo2;
    }

    private ClassInfo findSuperTypeForMixin(ClassInfo classInfo) {
        ClassInfo classInfo2 = this;
        while (ClassInfo.lIIIIllIIlII(classInfo2) && ClassInfo.lIIIIllIlIII(classInfo2, OBJECT)) {
            Iterator<MixinInfo> iterator = classInfo2.mixins.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                MixinInfo mixinInfo = iterator.next();
                if (ClassInfo.lIIIIllIIlIl(mixinInfo.getClassInfo().equals(classInfo) ? 1 : 0)) {
                    return classInfo2;
                }
                "".length();
                if (null == null) continue;
                return null;
            }
            classInfo2 = classInfo2.getSuperClass();
            "".length();
            if ((0x99 ^ 0x9D) >= "  ".length()) continue;
            return null;
        }
        return null;
    }

    public boolean hasMixinInHierarchy() {
        if (ClassInfo.lIIIIllIIlll(this.isMixin ? 1 : 0)) {
            return false;
        }
        ClassInfo classInfo = this.getSuperClass();
        while (ClassInfo.lIIIIllIIlII(classInfo) && ClassInfo.lIIIIllIlIII(classInfo, OBJECT)) {
            if (ClassInfo.lIIIIllIIlIl(classInfo.isMixin ? 1 : 0)) {
                return true;
            }
            classInfo = classInfo.getSuperClass();
            "".length();
            if (((0xCA ^ 0xB7 ^ (0x79 ^ 0x2C)) & (0x97 ^ 0xC1 ^ (0xE7 ^ 0x99) ^ -" ".length())) == 0) continue;
            return ((0x95 ^ 0xBE ^ (0xA4 ^ 0xBA)) & (67 + 14 - 11 + 120 ^ 121 + 130 - 164 + 52 ^ -" ".length())) != 0;
        }
        return false;
    }

    public boolean hasMixinTargetInHierarchy() {
        if (ClassInfo.lIIIIllIIlIl(this.isMixin ? 1 : 0)) {
            return false;
        }
        ClassInfo classInfo = this.getSuperClass();
        while (ClassInfo.lIIIIllIIlII(classInfo) && ClassInfo.lIIIIllIlIII(classInfo, OBJECT)) {
            if (ClassInfo.lIIIIllIlIlI(classInfo.mixins.size())) {
                return true;
            }
            classInfo = classInfo.getSuperClass();
            "".length();
            if (null == null) continue;
            return ((0xAB ^ 0xB0 ^ (0x5E ^ 0x24)) & (0x44 ^ 0x1B ^ (0x7B ^ 0x45) ^ -" ".length())) != 0;
        }
        return false;
    }

    public ClassInfo$Method findMethodInHierarchy(MethodNode methodNode, ClassInfo$SearchType classInfo$SearchType) {
        return this.findMethodInHierarchy(methodNode.name, methodNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE);
    }

    public ClassInfo$Method findMethodInHierarchy(MethodNode methodNode, ClassInfo$SearchType classInfo$SearchType, int n) {
        return this.findMethodInHierarchy(methodNode.name, methodNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE, n);
    }

    public ClassInfo$Method findMethodInHierarchy(MethodInsnNode methodInsnNode, ClassInfo$SearchType classInfo$SearchType) {
        return this.findMethodInHierarchy(methodInsnNode.name, methodInsnNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE);
    }

    public ClassInfo$Method findMethodInHierarchy(MethodInsnNode methodInsnNode, ClassInfo$SearchType classInfo$SearchType, int n) {
        return this.findMethodInHierarchy(methodInsnNode.name, methodInsnNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE, n);
    }

    public ClassInfo$Method findMethodInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType) {
        return this.findMethodInHierarchy(string, string2, classInfo$SearchType, ClassInfo$Traversal.NONE);
    }

    public ClassInfo$Method findMethodInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType, ClassInfo$Traversal classInfo$Traversal) {
        return this.findMethodInHierarchy(string, string2, classInfo$SearchType, classInfo$Traversal, 0);
    }

    public ClassInfo$Method findMethodInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType, ClassInfo$Traversal classInfo$Traversal, int n) {
        return (ClassInfo$Method)this.findInHierarchy(string, string2, classInfo$SearchType, classInfo$Traversal, n, ClassInfo$Member$Type.METHOD);
    }

    public ClassInfo$Field findFieldInHierarchy(FieldNode fieldNode, ClassInfo$SearchType classInfo$SearchType) {
        return this.findFieldInHierarchy(fieldNode.name, fieldNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE);
    }

    public ClassInfo$Field findFieldInHierarchy(FieldNode fieldNode, ClassInfo$SearchType classInfo$SearchType, int n) {
        return this.findFieldInHierarchy(fieldNode.name, fieldNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE, n);
    }

    public ClassInfo$Field findFieldInHierarchy(FieldInsnNode fieldInsnNode, ClassInfo$SearchType classInfo$SearchType) {
        return this.findFieldInHierarchy(fieldInsnNode.name, fieldInsnNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE);
    }

    public ClassInfo$Field findFieldInHierarchy(FieldInsnNode fieldInsnNode, ClassInfo$SearchType classInfo$SearchType, int n) {
        return this.findFieldInHierarchy(fieldInsnNode.name, fieldInsnNode.desc, classInfo$SearchType, ClassInfo$Traversal.NONE, n);
    }

    public ClassInfo$Field findFieldInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType) {
        return this.findFieldInHierarchy(string, string2, classInfo$SearchType, ClassInfo$Traversal.NONE);
    }

    public ClassInfo$Field findFieldInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType, ClassInfo$Traversal classInfo$Traversal) {
        return this.findFieldInHierarchy(string, string2, classInfo$SearchType, classInfo$Traversal, 0);
    }

    public ClassInfo$Field findFieldInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType, ClassInfo$Traversal classInfo$Traversal, int n) {
        return (ClassInfo$Field)this.findInHierarchy(string, string2, classInfo$SearchType, classInfo$Traversal, n, ClassInfo$Member$Type.FIELD);
    }

    private <M extends ClassInfo$Member> M findInHierarchy(String string, String string2, ClassInfo$SearchType classInfo$SearchType, ClassInfo$Traversal classInfo$Traversal, int n, ClassInfo$Member$Type classInfo$Member$Type) {
        ClassInfo classInfo;
        Object object;
        Iterator<Object> iterator;
        ClassInfo classInfo2;
        if (ClassInfo.lIIIIllIlIIl((Object)classInfo$SearchType, (Object)ClassInfo$SearchType.ALL_CLASSES)) {
            classInfo2 = this.findMember(string, string2, n, classInfo$Member$Type);
            if (ClassInfo.lIIIIllIIlII(classInfo2)) {
                return (M)classInfo2;
            }
            if (ClassInfo.lIIIIllIIlIl(classInfo$Traversal.canTraverse() ? 1 : 0)) {
                iterator = this.mixins.iterator();
                while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                    object = (MixinInfo)iterator.next();
                    classInfo = ((MixinInfo)object).getClassInfo().findMember(string, string2, n, classInfo$Member$Type);
                    if (ClassInfo.lIIIIllIIlII(classInfo)) {
                        return (M)this.cloneMember(classInfo);
                    }
                    "".length();
                    if ("   ".length() > 0) continue;
                    return null;
                }
            }
        }
        if (ClassInfo.lIIIIllIIlII(classInfo2 = this.getSuperClass())) {
            iterator = classInfo2.getTargets().iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object = iterator.next();
                classInfo = ((ClassInfo)object).findInHierarchy(string, string2, ClassInfo$SearchType.ALL_CLASSES, classInfo$Traversal.next(), n & 0xFFFFFFFD, classInfo$Member$Type);
                if (ClassInfo.lIIIIllIIlII(classInfo)) {
                    return (M)classInfo;
                }
                "".length();
                if (((0xE8 ^ 0x95 ^ (0x24 ^ 0x61)) & (23 + 82 - 64 + 94 ^ 144 + 165 - 295 + 177 ^ -" ".length())) <= "   ".length()) continue;
                return null;
            }
        }
        if (ClassInfo.lIIIIllIlIIl((Object)classInfo$Member$Type, (Object)ClassInfo$Member$Type.METHOD) && (!ClassInfo.lIIIIllIIlll(this.isInterface ? 1 : 0) || ClassInfo.lIIIIllIIlIl(MixinEnvironment.getCompatibilityLevel().supportsMethodsInInterfaces() ? 1 : 0))) {
            iterator = this.interfaces.iterator();
            while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
                object = (String)iterator.next();
                classInfo = ClassInfo.forName((String)object);
                if (ClassInfo.lIIIIllIIllI(classInfo)) {
                    logger.debug("Failed to resolve declared interface {} on {}", new Object[]{object, this.name});
                    "".length();
                    if ("   ".length() > " ".length()) continue;
                    return null;
                }
                M m = classInfo.findInHierarchy(string, string2, ClassInfo$SearchType.ALL_CLASSES, classInfo$Traversal.next(), n & 0xFFFFFFFD, classInfo$Member$Type);
                if (ClassInfo.lIIIIllIIlII(m)) {
                    Object object2;
                    if (ClassInfo.lIIIIllIIlIl(this.isInterface ? 1 : 0)) {
                        object2 = m;
                        "".length();
                        if (" ".length() == 0) {
                            return null;
                        }
                    } else {
                        object2 = new ClassInfo$InterfaceMethod(this, (ClassInfo$Member)m);
                    }
                    return object2;
                }
                "".length();
                if (((0xA9 ^ 0xB8 ^ (0x81 ^ 0x98)) & (0x2A ^ 0x37 ^ (0x13 ^ 6) ^ -" ".length())) == 0) continue;
                return null;
            }
        }
        return null;
    }

    private <M extends ClassInfo$Member> M cloneMember(M m) {
        if (ClassInfo.lIIIIllIIlIl(m instanceof ClassInfo$Method)) {
            return (M)new ClassInfo$Method(this, m);
        }
        return (M)new ClassInfo$Field(this, m);
    }

    public ClassInfo$Method findMethod(MethodNode methodNode) {
        return this.findMethod(methodNode.name, methodNode.desc, methodNode.access);
    }

    public ClassInfo$Method findMethod(MethodNode methodNode, int n) {
        return this.findMethod(methodNode.name, methodNode.desc, n);
    }

    public ClassInfo$Method findMethod(MethodInsnNode methodInsnNode) {
        return this.findMethod(methodInsnNode.name, methodInsnNode.desc, 0);
    }

    public ClassInfo$Method findMethod(MethodInsnNode methodInsnNode, int n) {
        return this.findMethod(methodInsnNode.name, methodInsnNode.desc, n);
    }

    public ClassInfo$Method findMethod(String string, String string2, int n) {
        return (ClassInfo$Method)this.findMember(string, string2, n, ClassInfo$Member$Type.METHOD);
    }

    public ClassInfo$Field findField(FieldNode fieldNode) {
        return this.findField(fieldNode.name, fieldNode.desc, fieldNode.access);
    }

    public ClassInfo$Field findField(FieldInsnNode fieldInsnNode, int n) {
        return this.findField(fieldInsnNode.name, fieldInsnNode.desc, n);
    }

    public ClassInfo$Field findField(String string, String string2, int n) {
        return (ClassInfo$Field)this.findMember(string, string2, n, ClassInfo$Member$Type.FIELD);
    }

    private <M extends ClassInfo$Member> M findMember(String string, String string2, int n, ClassInfo$Member$Type classInfo$Member$Type) {
        Set<ClassInfo$Member> set;
        if (ClassInfo.lIIIIllIlIIl((Object)classInfo$Member$Type, (Object)ClassInfo$Member$Type.METHOD)) {
            set = this.methods;
            "".length();
            if ("  ".length() <= -" ".length()) {
                return null;
            }
        } else {
            set = this.fields;
        }
        Set<ClassInfo$Member> set2 = set;
        Iterator<ClassInfo$Member> iterator = set2.iterator();
        while (ClassInfo.lIIIIllIIlIl(iterator.hasNext() ? 1 : 0)) {
            ClassInfo$Member classInfo$Member = iterator.next();
            if (ClassInfo.lIIIIllIIlIl(classInfo$Member.equals(string, string2) ? 1 : 0) && ClassInfo.lIIIIllIIlIl(classInfo$Member.matchesFlags(n) ? 1 : 0)) {
                return (M)classInfo$Member;
            }
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return null;
        }
        return null;
    }

    public boolean equals(Object object) {
        if (ClassInfo.lIIIIllIIlll(object instanceof ClassInfo)) {
            return false;
        }
        return ((ClassInfo)object).name.equals(this.name);
    }

    public int hashCode() {
        return this.name.hashCode();
    }

    static ClassInfo fromClassNode(ClassNode classNode) {
        ClassInfo classInfo = cache.get(classNode.name);
        if (ClassInfo.lIIIIllIIllI(classInfo)) {
            classInfo = new ClassInfo(classNode);
            cache.put(classNode.name, classInfo);
            "".length();
        }
        return classInfo;
    }

    public static ClassInfo forName(String string) {
        ClassInfo classInfo;
        block3: {
            classInfo = cache.get(string = string.replace('.', '/'));
            if (!ClassInfo.lIIIIllIIllI(classInfo)) break block3;
            try {
                ClassNode classNode = MixinService.getService().getBytecodeProvider().getClassNode(string);
                classInfo = new ClassInfo(classNode);
                "".length();
            }
            catch (Exception exception) {
                logger.catching(Level.TRACE, (Throwable)exception);
                logger.warn("Error loading class: {} ({}: {})", new Object[]{string, exception.getClass().getName(), exception.getMessage()});
            }
            if (-" ".length() >= 0) {
                return null;
            }
            cache.put(string, classInfo);
            "".length();
            logger.trace("Added class metadata for {} to metadata cache", new Object[]{string});
        }
        return classInfo;
    }

    public static ClassInfo forType(Type type) {
        if (ClassInfo.lIIIIllIlIll(type.getSort(), 9)) {
            return ClassInfo.forType(type.getElementType());
        }
        if (ClassInfo.lIIIIllIllII(type.getSort(), 9)) {
            return null;
        }
        return ClassInfo.forName(type.getClassName().replace('.', '/'));
    }

    public static ClassInfo getCommonSuperClass(String string, String string2) {
        if (!ClassInfo.lIIIIllIIlII(string) || ClassInfo.lIIIIllIIllI(string2)) {
            return OBJECT;
        }
        return ClassInfo.getCommonSuperClass(ClassInfo.forName(string), ClassInfo.forName(string2));
    }

    public static ClassInfo getCommonSuperClass(Type type, Type type2) {
        if (!ClassInfo.lIIIIllIIlII(type) || !ClassInfo.lIIIIllIIlII(type2) || !ClassInfo.lIIIIllIlIll(type.getSort(), 10) || ClassInfo.lIIIIllIllIl(type2.getSort(), 10)) {
            return OBJECT;
        }
        return ClassInfo.getCommonSuperClass(ClassInfo.forType(type), ClassInfo.forType(type2));
    }

    private static ClassInfo getCommonSuperClass(ClassInfo classInfo, ClassInfo classInfo2) {
        return ClassInfo.getCommonSuperClass(classInfo, classInfo2, false);
    }

    public static ClassInfo getCommonSuperClassOrInterface(String string, String string2) {
        if (!ClassInfo.lIIIIllIIlII(string) || ClassInfo.lIIIIllIIllI(string2)) {
            return OBJECT;
        }
        return ClassInfo.getCommonSuperClassOrInterface(ClassInfo.forName(string), ClassInfo.forName(string2));
    }

    public static ClassInfo getCommonSuperClassOrInterface(Type type, Type type2) {
        if (!ClassInfo.lIIIIllIIlII(type) || !ClassInfo.lIIIIllIIlII(type2) || !ClassInfo.lIIIIllIlIll(type.getSort(), 10) || ClassInfo.lIIIIllIllIl(type2.getSort(), 10)) {
            return OBJECT;
        }
        return ClassInfo.getCommonSuperClassOrInterface(ClassInfo.forType(type), ClassInfo.forType(type2));
    }

    public static ClassInfo getCommonSuperClassOrInterface(ClassInfo classInfo, ClassInfo classInfo2) {
        return ClassInfo.getCommonSuperClass(classInfo, classInfo2, true);
    }

    private static ClassInfo getCommonSuperClass(ClassInfo classInfo, ClassInfo classInfo2, boolean bl) {
        if (ClassInfo.lIIIIllIIlIl(classInfo.hasSuperClass(classInfo2, ClassInfo$Traversal.NONE, bl) ? 1 : 0)) {
            return classInfo2;
        }
        if (ClassInfo.lIIIIllIIlIl(classInfo2.hasSuperClass(classInfo, ClassInfo$Traversal.NONE, bl) ? 1 : 0)) {
            return classInfo;
        }
        if (!ClassInfo.lIIIIllIIlll(classInfo.isInterface() ? 1 : 0) || ClassInfo.lIIIIllIIlIl(classInfo2.isInterface() ? 1 : 0)) {
            return OBJECT;
        }
        do {
            if (!ClassInfo.lIIIIllIIllI(classInfo = classInfo.getSuperClass())) continue;
            return OBJECT;
        } while (!ClassInfo.lIIIIllIIlIl(classInfo2.hasSuperClass(classInfo, ClassInfo$Traversal.NONE, bl) ? 1 : 0));
        return classInfo;
    }

    static {
        INCLUDE_STATIC = 8;
        JAVA_LANG_OBJECT = "java/lang/Object";
        INCLUDE_PRIVATE = 2;
        INCLUDE_ALL = 10;
        logger = LogManager.getLogger((String)"mixin");
        profiler = MixinEnvironment.getProfiler();
        cache = new HashMap<String, ClassInfo>();
        OBJECT = new ClassInfo();
        cache.put("java/lang/Object", OBJECT);
        "".length();
    }

    private static boolean lIIIIllIlIll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIllIllII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIllIlIII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIIllIIlII(Object object) {
        return object != null;
    }

    private static boolean lIIIIllIlIIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIIllIIllI(Object object) {
        return object == null;
    }

    private static boolean lIIIIllIIlIl(int n) {
        return n != 0;
    }

    private static boolean lIIIIllIIlll(int n) {
        return n == 0;
    }

    private static boolean lIIIIllIlIlI(int n) {
        return n > 0;
    }

    private static boolean lIIIIllIllIl(int n, int n2) {
        return n != n2;
    }
}

