/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.extensibility.IMixinConfig;
import org.spongepowered.asm.mixin.transformer.MixinConfig;

public class Config {
    private final String name;
    private final MixinConfig config;

    public Config(MixinConfig mixinConfig) {
        this.name = mixinConfig.getName();
        this.config = mixinConfig;
    }

    public String getName() {
        return this.name;
    }

    MixinConfig get() {
        return this.config;
    }

    public boolean isVisited() {
        return this.config.isVisited();
    }

    public IMixinConfig getConfig() {
        return this.config;
    }

    public MixinEnvironment getEnvironment() {
        return this.config.getEnvironment();
    }

    public String toString() {
        return this.config.toString();
    }

    public boolean equals(Object object) {
        boolean bl;
        if (Config.lIlIlIl(object instanceof Config) && Config.lIlIlIl(this.name.equals(((Config)object).name) ? 1 : 0)) {
            bl = true;
            "".length();
            if (-" ".length() > (0xA2 ^ 0x98 ^ (0x14 ^ 0x2A))) {
                return ((0x94 ^ 0x8E ^ (0x3B ^ 9)) & (151 + 128 - 252 + 206 ^ 67 + 47 - -42 + 37 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.name.hashCode();
    }

    @Deprecated
    public static Config create(String string, MixinEnvironment mixinEnvironment) {
        return MixinConfig.create(string, mixinEnvironment);
    }

    public static Config create(String string) {
        return MixinConfig.create(string, MixinEnvironment.getDefaultEnvironment());
    }

    private static boolean lIlIlIl(int n) {
        return n != 0;
    }
}

