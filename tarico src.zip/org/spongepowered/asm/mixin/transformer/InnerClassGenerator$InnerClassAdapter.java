/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.lib.AnnotationVisitor;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.commons.ClassRemapper;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.InnerClassGenerator$InnerClassInfo;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

class InnerClassGenerator$InnerClassAdapter
extends ClassRemapper {
    private final InnerClassGenerator$InnerClassInfo info;

    public InnerClassGenerator$InnerClassAdapter(ClassVisitor classVisitor, InnerClassGenerator$InnerClassInfo innerClassGenerator$InnerClassInfo) {
        super(327680, classVisitor, innerClassGenerator$InnerClassInfo);
        this.info = innerClassGenerator$InnerClassInfo;
    }

    @Override
    public void visitSource(String string, String string2) {
        super.visitSource(string, string2);
        AnnotationVisitor annotationVisitor = this.cv.visitAnnotation("Lorg/spongepowered/asm/mixin/transformer/meta/MixinInner;", false);
        annotationVisitor.visit("mixin", this.info.getOwner().toString());
        annotationVisitor.visit("name", this.info.getOriginalName().substring(this.info.getOriginalName().lastIndexOf(47) + 1));
        annotationVisitor.visitEnd();
    }

    @Override
    public void visitInnerClass(String string, String string2, String string3, int n) {
        if (InnerClassGenerator$InnerClassAdapter.lIIIIIlll(string.startsWith(String.valueOf(new StringBuilder().append(this.info.getOriginalName()).append("$"))) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.info.getOwner(), String.valueOf(new StringBuilder().append("Found unsupported nested inner class ").append(string).append(" in ").append(this.info.getOriginalName())));
        }
        super.visitInnerClass(string, string2, string3, n);
    }

    private static boolean lIIIIIlll(int n) {
        return n != 0;
    }
}

