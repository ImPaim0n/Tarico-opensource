/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.lib.commons.Remapper;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.service.MixinService;

class InnerClassGenerator$InnerClassInfo
extends Remapper {
    private final String name;
    private final String originalName;
    private final MixinInfo owner;
    private final MixinTargetContext target;
    private final String ownerName;
    private final String targetName;

    InnerClassGenerator$InnerClassInfo(String string, String string2, MixinInfo mixinInfo, MixinTargetContext mixinTargetContext) {
        this.name = string;
        this.originalName = string2;
        this.owner = mixinInfo;
        this.ownerName = mixinInfo.getClassRef();
        this.target = mixinTargetContext;
        this.targetName = mixinTargetContext.getTargetClassRef();
    }

    String getName() {
        return this.name;
    }

    String getOriginalName() {
        return this.originalName;
    }

    MixinInfo getOwner() {
        return this.owner;
    }

    MixinTargetContext getTarget() {
        return this.target;
    }

    String getOwnerName() {
        return this.ownerName;
    }

    String getTargetName() {
        return this.targetName;
    }

    byte[] getClassBytes() {
        return MixinService.getService().getBytecodeProvider().getClassBytes(this.originalName, true);
    }

    @Override
    public String mapMethodName(String string, String string2, String string3) {
        ClassInfo$Method classInfo$Method;
        if (InnerClassGenerator$InnerClassInfo.llIlllIlIl(this.ownerName.equalsIgnoreCase(string) ? 1 : 0) && InnerClassGenerator$InnerClassInfo.llIlllIllI(classInfo$Method = this.owner.getClassInfo().findMethod(string2, string3, 10))) {
            return classInfo$Method.getName();
        }
        return super.mapMethodName(string, string2, string3);
    }

    @Override
    public String map(String string) {
        if (InnerClassGenerator$InnerClassInfo.llIlllIlIl(this.originalName.equals(string) ? 1 : 0)) {
            return this.name;
        }
        if (InnerClassGenerator$InnerClassInfo.llIlllIlIl(this.ownerName.equals(string) ? 1 : 0)) {
            return this.targetName;
        }
        return string;
    }

    public String toString() {
        return this.name;
    }

    private static boolean llIlllIllI(Object object) {
        return object != null;
    }

    private static boolean llIlllIlIl(int n) {
        return n != 0;
    }
}

