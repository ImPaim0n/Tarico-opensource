/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.mixin.transformer.InnerClassGenerator$InnerClassAdapter;
import org.spongepowered.asm.mixin.transformer.InnerClassGenerator$InnerClassInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.ext.IClassGenerator;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.transformers.MixinClassWriter;

final class InnerClassGenerator
implements IClassGenerator {
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private final Map<String, String> innerClassNames = new HashMap<String, String>();
    private final Map<String, InnerClassGenerator$InnerClassInfo> innerClasses = new HashMap<String, InnerClassGenerator$InnerClassInfo>();

    InnerClassGenerator() {
    }

    public String registerInnerClass(MixinInfo mixinInfo, String string, MixinTargetContext mixinTargetContext) {
        String string2 = String.format("%s%s", string, mixinTargetContext);
        String string3 = this.innerClassNames.get(string2);
        if (InnerClassGenerator.llllIllll(string3)) {
            string3 = InnerClassGenerator.getUniqueReference(string, mixinTargetContext);
            this.innerClassNames.put(string2, string3);
            "".length();
            this.innerClasses.put(string3, new InnerClassGenerator$InnerClassInfo(string3, string, mixinInfo, mixinTargetContext));
            "".length();
            logger.debug("Inner class {} in {} on {} gets unique name {}", new Object[]{string, mixinInfo.getClassRef(), mixinTargetContext.getTargetClassRef(), string3});
        }
        return string3;
    }

    @Override
    public byte[] generate(String string) {
        String string2 = string.replace('.', '/');
        InnerClassGenerator$InnerClassInfo innerClassGenerator$InnerClassInfo = this.innerClasses.get(string2);
        if (InnerClassGenerator.lllllIIIl(innerClassGenerator$InnerClassInfo)) {
            return this.generate(innerClassGenerator$InnerClassInfo);
        }
        return null;
    }

    private byte[] generate(InnerClassGenerator$InnerClassInfo innerClassGenerator$InnerClassInfo) {
        try {
            logger.debug("Generating mapped inner class {} (originally {})", new Object[]{innerClassGenerator$InnerClassInfo.getName(), innerClassGenerator$InnerClassInfo.getOriginalName()});
            ClassReader classReader = new ClassReader(innerClassGenerator$InnerClassInfo.getClassBytes());
            MixinClassWriter mixinClassWriter = new MixinClassWriter(classReader, 0);
            classReader.accept(new InnerClassGenerator$InnerClassAdapter((ClassVisitor)mixinClassWriter, innerClassGenerator$InnerClassInfo), 8);
            return mixinClassWriter.toByteArray();
        }
        catch (InvalidMixinException invalidMixinException) {
            throw invalidMixinException;
        }
        catch (Exception exception) {
            logger.catching((Throwable)exception);
            return null;
        }
    }

    private static String getUniqueReference(String string, MixinTargetContext mixinTargetContext) {
        String string2 = string.substring(string.lastIndexOf(36) + 1);
        if (InnerClassGenerator.lllllIIlI(string2.matches("^[0-9]+$") ? 1 : 0)) {
            string2 = "Anonymous";
        }
        return String.format("%s$%s$%s", mixinTargetContext.getTargetClassRef(), string2, UUID.randomUUID().toString().replace("-", ""));
    }

    private static boolean lllllIIIl(Object object) {
        return object != null;
    }

    private static boolean llllIllll(Object object) {
        return object == null;
    }

    private static boolean lllllIIlI(int n) {
        return n != 0;
    }
}

