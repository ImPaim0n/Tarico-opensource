/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.meta.MixinRenamed;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.util.Annotations;

public final class InterfaceInfo {
    private final MixinInfo mixin;
    private final String prefix;
    private final Type iface;
    private final boolean unique;
    private Set<String> methods;

    private InterfaceInfo(MixinInfo mixinInfo, String string, Type type, boolean bl) {
        if (!InterfaceInfo.lIIIlIIllIIl(string) || !InterfaceInfo.lIIIlIIllIlI(string.length(), 2) || InterfaceInfo.lIIIlIIllIll(string.endsWith("$") ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)mixinInfo, String.format("Prefix %s for iface %s is not valid", string, type.toString()));
        }
        this.mixin = mixinInfo;
        this.prefix = string;
        this.iface = type;
        this.unique = bl;
    }

    private void initMethods() {
        this.methods = new HashSet<String>();
        this.readInterface(this.iface.getInternalName());
    }

    private void readInterface(String string) {
        Object object;
        ClassInfo classInfo = ClassInfo.forName(string);
        Iterator<Object> iterator = classInfo.getMethods().iterator();
        while (InterfaceInfo.lIIIlIIlllII(iterator.hasNext() ? 1 : 0)) {
            object = iterator.next();
            this.methods.add(((ClassInfo$Method)object).toString());
            "".length();
            "".length();
            if (-(0x94 ^ 0x98 ^ (0x3C ^ 0x35)) < 0) continue;
            return;
        }
        iterator = classInfo.getInterfaces().iterator();
        while (InterfaceInfo.lIIIlIIlllII(iterator.hasNext() ? 1 : 0)) {
            object = (String)iterator.next();
            this.readInterface((String)object);
            "".length();
            if (-" ".length() < (0x8F ^ 0x8B)) continue;
            return;
        }
    }

    public String getPrefix() {
        return this.prefix;
    }

    public Type getIface() {
        return this.iface;
    }

    public String getName() {
        return this.iface.getClassName();
    }

    public String getInternalName() {
        return this.iface.getInternalName();
    }

    public boolean isUnique() {
        return this.unique;
    }

    public boolean renameMethod(MethodNode methodNode) {
        if (InterfaceInfo.lIIIlIIlllIl(this.methods)) {
            this.initMethods();
        }
        if (InterfaceInfo.lIIIlIIllIll(methodNode.name.startsWith(this.prefix) ? 1 : 0)) {
            if (InterfaceInfo.lIIIlIIlllII(this.methods.contains(String.valueOf(new StringBuilder().append(methodNode.name).append(methodNode.desc))) ? 1 : 0)) {
                this.decorateUniqueMethod(methodNode);
            }
            return false;
        }
        String string = methodNode.name.substring(this.prefix.length());
        String string2 = String.valueOf(new StringBuilder().append(string).append(methodNode.desc));
        if (InterfaceInfo.lIIIlIIllIll(this.methods.contains(string2) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("%s does not exist in target interface %s", string, this.getName()));
        }
        if (InterfaceInfo.lIIIlIIllIll(methodNode.access & 1)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("%s cannot implement %s because it is not visible", string, this.getName()));
        }
        Annotations.setVisible(methodNode, MixinRenamed.class, "originalName", methodNode.name, "isInterfaceMember", true);
        this.decorateUniqueMethod(methodNode);
        methodNode.name = string;
        return true;
    }

    private void decorateUniqueMethod(MethodNode methodNode) {
        if (InterfaceInfo.lIIIlIIllIll(this.unique ? 1 : 0)) {
            return;
        }
        if (InterfaceInfo.lIIIlIIlllIl(Annotations.getVisible(methodNode, Unique.class))) {
            Annotations.setVisible(methodNode, Unique.class, new Object[0]);
            this.mixin.getClassInfo().findMethod(methodNode).setUnique(true);
        }
    }

    static InterfaceInfo fromAnnotation(MixinInfo mixinInfo, AnnotationNode annotationNode) {
        boolean bl;
        String string = (String)Annotations.getValue(annotationNode, "prefix");
        Type type = (Type)Annotations.getValue(annotationNode, "iface");
        Boolean bl2 = (Boolean)Annotations.getValue(annotationNode, "unique");
        if (!InterfaceInfo.lIIIlIIllIIl(string) || InterfaceInfo.lIIIlIIlllIl(type)) {
            throw new InvalidMixinException((IMixinInfo)mixinInfo, String.format("@Interface annotation on %s is missing a required parameter", mixinInfo));
        }
        if (InterfaceInfo.lIIIlIIllIIl(bl2) && InterfaceInfo.lIIIlIIlllII(bl2.booleanValue() ? 1 : 0)) {
            bl = true;
            "".length();
            if (-" ".length() > -" ".length()) {
                return null;
            }
        } else {
            bl = false;
        }
        return new InterfaceInfo(mixinInfo, string, type, bl);
    }

    public boolean equals(Object object) {
        boolean bl;
        if (InterfaceInfo.lIIIlIIllllI(this, object)) {
            return true;
        }
        if (!InterfaceInfo.lIIIlIIllIIl(object) || InterfaceInfo.lIIIlIIlllll(this.getClass(), object.getClass())) {
            return false;
        }
        InterfaceInfo interfaceInfo = (InterfaceInfo)object;
        if (InterfaceInfo.lIIIlIIlllII(this.mixin.equals(interfaceInfo.mixin) ? 1 : 0) && InterfaceInfo.lIIIlIIlllII(this.prefix.equals(interfaceInfo.prefix) ? 1 : 0) && InterfaceInfo.lIIIlIIlllII(this.iface.equals(interfaceInfo.iface) ? 1 : 0)) {
            bl = true;
            "".length();
            if ((0 + 101 - 63 + 110 ^ 122 + 128 - 210 + 104) <= ((0x50 ^ 0x15 ^ (0x6A ^ 0x3A)) & (14 + 60 - 17 + 110 ^ 127 + 5 - 75 + 121 ^ -" ".length()))) {
                return ((166 + 159 - 310 + 167 ^ 26 + 49 - 15 + 107) & (0x94 ^ 0xA5 ^ (0x2C ^ 0xC) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        int n = this.mixin.hashCode();
        n = 31 * n + this.prefix.hashCode();
        n = 31 * n + this.iface.hashCode();
        return n;
    }

    private static boolean lIIIlIIllIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIlIIlllll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIlIIllIIl(Object object) {
        return object != null;
    }

    private static boolean lIIIlIIllllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIlIIlllIl(Object object) {
        return object == null;
    }

    private static boolean lIIIlIIlllII(int n) {
        return n != 0;
    }

    private static boolean lIIIlIIllIll(int n) {
        return n == 0;
    }
}

