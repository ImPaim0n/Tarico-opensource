/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.common.base.Strings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinMethodNode;
import org.spongepowered.asm.util.Counter;

public class MethodMapper {
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private static final List<String> classes = new ArrayList<String>();
    private static final Map<String, Counter> methods = new HashMap<String, Counter>();
    private final ClassInfo info;

    public MethodMapper(MixinEnvironment mixinEnvironment, ClassInfo classInfo) {
        this.info = classInfo;
    }

    public ClassInfo getClassInfo() {
        return this.info;
    }

    public void remapHandlerMethod(MixinInfo mixinInfo, MethodNode methodNode, ClassInfo$Method classInfo$Method) {
        if (!MethodMapper.lIlllIllI(methodNode instanceof MixinInfo$MixinMethodNode) || MethodMapper.lIlllIlll(((MixinInfo$MixinMethodNode)methodNode).isInjector() ? 1 : 0)) {
            return;
        }
        if (MethodMapper.lIlllIllI(classInfo$Method.isUnique() ? 1 : 0)) {
            logger.warn("Redundant @Unique on injector method {} in {}. Injectors are implicitly unique", new Object[]{classInfo$Method, mixinInfo});
        }
        if (MethodMapper.lIlllIllI(classInfo$Method.isRenamed() ? 1 : 0)) {
            methodNode.name = classInfo$Method.getName();
            return;
        }
        String string = this.getHandlerName((MixinInfo$MixinMethodNode)methodNode);
        methodNode.name = classInfo$Method.renameTo(string);
    }

    public String getHandlerName(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        boolean bl;
        String string = InjectionInfo.getInjectorPrefix(mixinInfo$MixinMethodNode.getInjectorAnnotation());
        String string2 = MethodMapper.getClassUID(mixinInfo$MixinMethodNode.getOwner().getClassRef());
        String string3 = mixinInfo$MixinMethodNode.name;
        String string4 = mixinInfo$MixinMethodNode.desc;
        if (MethodMapper.lIlllIlll(mixinInfo$MixinMethodNode.isSurrogate() ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            bl = false;
        }
        String string5 = MethodMapper.getMethodUID(string3, string4, bl);
        return String.format("%s$%s$%s%s", string, mixinInfo$MixinMethodNode.name, string2, string5);
    }

    private static String getClassUID(String string) {
        int n = classes.indexOf(string);
        if (MethodMapper.lIllllIII(n)) {
            n = classes.size();
            classes.add(string);
            "".length();
        }
        return MethodMapper.finagle(n);
    }

    private static String getMethodUID(String string, String string2, boolean bl) {
        String string3 = String.format("%s%s", string, string2);
        Counter counter = methods.get(string3);
        if (MethodMapper.lIllllIIl(counter)) {
            counter = new Counter();
            methods.put(string3, counter);
            "".length();
            "".length();
            if ((134 + 191 - 193 + 66 ^ 113 + 115 - 70 + 37) == 0) {
                return null;
            }
        } else if (MethodMapper.lIlllIllI(bl ? 1 : 0)) {
            ++counter.value;
        }
        return String.format("%03x", counter.value);
    }

    private static String finagle(int n) {
        String string = Integer.toHexString(n);
        StringBuilder stringBuilder = new StringBuilder();
        int n2 = 0;
        while (MethodMapper.lIllllIlI(n2, string.length())) {
            int n3;
            char c = string.charAt(n2);
            if (MethodMapper.lIllllIlI(c, 58)) {
                n3 = 49;
                "".length();
                if (" ".length() != " ".length()) {
                    return null;
                }
            } else {
                n3 = 10;
            }
            c = (char)(c + n3);
            stringBuilder.append(c);
            "".length();
            ++n2;
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return null;
        }
        return Strings.padStart((String)String.valueOf(stringBuilder), (int)3, (char)'z');
    }

    private static boolean lIllllIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIllllIIl(Object object) {
        return object == null;
    }

    private static boolean lIlllIllI(int n) {
        return n != 0;
    }

    private static boolean lIlllIlll(int n) {
        return n == 0;
    }

    private static boolean lIllllIII(int n) {
        return n < 0;
    }
}

