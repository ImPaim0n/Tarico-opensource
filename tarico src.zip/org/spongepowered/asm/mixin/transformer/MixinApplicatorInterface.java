/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.Iterator;
import java.util.Map;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Field;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.TargetClassContext;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidInterfaceMixinException;

class MixinApplicatorInterface
extends MixinApplicatorStandard {
    MixinApplicatorInterface(TargetClassContext targetClassContext) {
        super(targetClassContext);
    }

    @Override
    protected void applyInterfaces(MixinTargetContext mixinTargetContext) {
        Iterator<String> iterator = mixinTargetContext.getInterfaces().iterator();
        while (MixinApplicatorInterface.lIIIIll(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            if (MixinApplicatorInterface.lIIIlII(this.targetClass.name.equals(string) ? 1 : 0) && MixinApplicatorInterface.lIIIlII(this.targetClass.interfaces.contains(string) ? 1 : 0)) {
                this.targetClass.interfaces.add(string);
                "".length();
                mixinTargetContext.getTargetClassInfo().addInterface(string);
            }
            "".length();
            if (-" ".length() <= " ".length()) continue;
            return;
        }
    }

    @Override
    protected void applyFields(MixinTargetContext mixinTargetContext) {
        Iterator<Map.Entry<FieldNode, ClassInfo.Field>> iterator = mixinTargetContext.getShadowFields().iterator();
        while (MixinApplicatorInterface.lIIIIll(iterator.hasNext() ? 1 : 0)) {
            Map.Entry<FieldNode, ClassInfo.Field> entry = iterator.next();
            FieldNode fieldNode = entry.getKey();
            this.logger.error("Ignoring redundant @Shadow field {}:{} in {}", new Object[]{fieldNode.name, fieldNode.desc, mixinTargetContext});
            "".length();
            if (null == null) continue;
            return;
        }
        this.mergeNewFields(mixinTargetContext);
    }

    @Override
    protected void applyInitialisers(MixinTargetContext mixinTargetContext) {
    }

    @Override
    protected void prepareInjections(MixinTargetContext mixinTargetContext) {
        Iterator<MethodNode> iterator = this.targetClass.methods.iterator();
        while (MixinApplicatorInterface.lIIIIll(iterator.hasNext() ? 1 : 0)) {
            block7: {
                MethodNode methodNode = iterator.next();
                try {
                    InjectionInfo injectionInfo = InjectionInfo.parse(mixinTargetContext, methodNode);
                    if (!MixinApplicatorInterface.lIIIlIl(injectionInfo)) break block7;
                    throw new InvalidInterfaceMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append(injectionInfo).append(" is not supported on interface mixin method ").append(methodNode.name)));
                }
                catch (InvalidInjectionException invalidInjectionException) {
                    String string;
                    if (MixinApplicatorInterface.lIIIlIl(invalidInjectionException.getInjectionInfo())) {
                        string = invalidInjectionException.getInjectionInfo().toString();
                        "".length();
                        if (-(0x1F ^ 0x1B) >= 0) {
                            return;
                        }
                    } else {
                        string = "Injection";
                    }
                    String string2 = string;
                    throw new InvalidInterfaceMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append(string2).append(" is not supported in interface mixin")));
                }
            }
            "".length();
            if (" ".length() == "   ".length()) {
                return;
            }
            "".length();
            if ((0x25 ^ 0x77 ^ (7 ^ 0x51)) > -" ".length()) continue;
            return;
        }
    }

    @Override
    protected void applyInjections(MixinTargetContext mixinTargetContext) {
    }

    private static boolean lIIIlIl(Object object) {
        return object != null;
    }

    private static boolean lIIIIll(int n) {
        return n != 0;
    }

    private static boolean lIIIlII(int n) {
        return n == 0;
    }
}

