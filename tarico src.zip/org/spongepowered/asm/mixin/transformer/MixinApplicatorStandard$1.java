/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard$ApplicatorPass;

class MixinApplicatorStandard$1 {
    static final /* synthetic */ int[] $SwitchMap$org$spongepowered$asm$mixin$transformer$MixinApplicatorStandard$ApplicatorPass;

    static {
        block8: {
            block9: {
                block7: {
                    $SwitchMap$org$spongepowered$asm$mixin$transformer$MixinApplicatorStandard$ApplicatorPass = new int[MixinApplicatorStandard$ApplicatorPass.values().length];
                    try {
                        MixinApplicatorStandard$1.$SwitchMap$org$spongepowered$asm$mixin$transformer$MixinApplicatorStandard$ApplicatorPass[MixinApplicatorStandard$ApplicatorPass.MAIN.ordinal()] = 1;
                        "".length();
                    }
                    catch (NoSuchFieldError noSuchFieldError) {
                        // empty catch block
                    }
                    if ("  ".length() != 0) break block7;
                    break block8;
                }
                try {
                    MixinApplicatorStandard$1.$SwitchMap$org$spongepowered$asm$mixin$transformer$MixinApplicatorStandard$ApplicatorPass[MixinApplicatorStandard$ApplicatorPass.PREINJECT.ordinal()] = 2;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if (-" ".length() < (0x7B ^ 0x7F)) break block9;
                break block8;
            }
            try {
                MixinApplicatorStandard$1.$SwitchMap$org$spongepowered$asm$mixin$transformer$MixinApplicatorStandard$ApplicatorPass[MixinApplicatorStandard$ApplicatorPass.INJECT.ordinal()] = 3;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if (" ".length() != " ".length()) {
                // empty if block
            }
        }
    }
}

