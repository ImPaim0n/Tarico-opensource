/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard;

class MixinApplicatorStandard$Range {
    final int start;
    final int end;
    final int marker;
    final /* synthetic */ MixinApplicatorStandard this$0;

    MixinApplicatorStandard$Range(MixinApplicatorStandard mixinApplicatorStandard, int n, int n2, int n3) {
        this.this$0 = mixinApplicatorStandard;
        this.start = n;
        this.end = n2;
        this.marker = n3;
    }

    boolean isValid() {
        boolean bl;
        if (MixinApplicatorStandard$Range.lIIIllIIIIl(this.start) && MixinApplicatorStandard$Range.lIIIllIIIIl(this.end) && MixinApplicatorStandard$Range.lIIIllIIIlI(this.end, this.start)) {
            bl = true;
            "".length();
            if (-(171 + 114 - 214 + 107 ^ 113 + 28 - 45 + 86) > 0) {
                return ("   ".length() & ("   ".length() ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    boolean contains(int n) {
        boolean bl;
        if (MixinApplicatorStandard$Range.lIIIllIIIlI(n, this.start) && MixinApplicatorStandard$Range.lIIIllIIIll(n, this.end)) {
            bl = true;
            "".length();
            if ("  ".length() <= ((0x8B ^ 0x97 ^ (0x2A ^ 0x6F)) & (0x89 ^ 0xBC ^ (0x4A ^ 0x26) ^ -" ".length()))) {
                return ((0x59 ^ 0x64 ^ (0x7A ^ 0x1C)) & (0x23 ^ 0x73 ^ (0x6F ^ 0x64) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    boolean excludes(int n) {
        boolean bl;
        if (!MixinApplicatorStandard$Range.lIIIllIIIlI(n, this.start) || MixinApplicatorStandard$Range.lIIIllIIlII(n, this.end)) {
            bl = true;
            "".length();
            if ("   ".length() <= 0) {
                return ((0x14 ^ 1) & ~(4 ^ 0x11)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public String toString() {
        return String.format("Range[%d-%d,%d,valid=%s)", this.start, this.end, this.marker, this.isValid());
    }

    private static boolean lIIIllIIIlI(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIIllIIIll(int n, int n2) {
        return n <= n2;
    }

    private static boolean lIIIllIIlII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIllIIIIl(int n) {
        return n != 0;
    }
}

