/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.common.collect.ImmutableList;
import java.lang.annotation.Annotation;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.SortedSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.Label;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.signature.SignatureReader;
import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.LineNumberNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Intrinsic;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Field;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard$1;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard$ApplicatorPass;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard$InitialiserInjectionMode;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard$Range;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.TargetClassContext;
import org.spongepowered.asm.mixin.transformer.meta.MixinMerged;
import org.spongepowered.asm.mixin.transformer.meta.MixinRenamed;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.ConstraintParser;
import org.spongepowered.asm.util.ConstraintParser$Constraint;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;
import org.spongepowered.asm.util.throwables.ConstraintViolationException;
import org.spongepowered.asm.util.throwables.InvalidConstraintException;

class MixinApplicatorStandard {
    protected static final List<Class<? extends Annotation>> CONSTRAINED_ANNOTATIONS = ImmutableList.of(Overwrite.class, Inject.class, ModifyArg.class, ModifyArgs.class, Redirect.class, ModifyVariable.class, ModifyConstant.class);
    protected static final int[] INITIALISER_OPCODE_BLACKLIST = new int[]{177, 21, 22, 23, 24, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 79, 80, 81, 82, 83, 84, 85, 86};
    protected final Logger logger = LogManager.getLogger((String)"mixin");
    protected final TargetClassContext context;
    protected final String targetName;
    protected final ClassNode targetClass;
    protected final Profiler profiler = MixinEnvironment.getProfiler();

    MixinApplicatorStandard(TargetClassContext targetClassContext) {
        this.context = targetClassContext;
        this.targetName = targetClassContext.getClassName();
        this.targetClass = targetClassContext.getClassNode();
    }

    void apply(SortedSet<MixinInfo> sortedSet) {
        Object object;
        ArrayList<MixinTargetContext> arrayList = new ArrayList<MixinTargetContext>();
        Object object2 = sortedSet.iterator();
        while (MixinApplicatorStandard.lllIIIllI(object2.hasNext() ? 1 : 0)) {
            object = (MixinInfo)object2.next();
            this.logger.log(((MixinInfo)object).getLoggingLevel(), "Mixing {} from {} into {}", new Object[]{((MixinInfo)object).getName(), ((MixinInfo)object).getParent(), this.targetName});
            arrayList.add(((MixinInfo)object).createContextFor(this.context));
            "".length();
            "".length();
            if ((148 + 158 - 174 + 51 ^ 143 + 134 - 219 + 121) != 0) continue;
            return;
        }
        object2 = null;
        try {
            object = arrayList.iterator();
            while (MixinApplicatorStandard.lllIIIllI(object.hasNext() ? 1 : 0)) {
                MixinTargetContext mixinTargetContext = (MixinTargetContext)object.next();
                object2 = mixinTargetContext;
                ((MixinTargetContext)object2).preApply(this.targetName, this.targetClass);
                "".length();
                if (((0x6A ^ 0x40) & ~(0x6E ^ 0x44)) > -" ".length()) continue;
                return;
            }
            object = MixinApplicatorStandard$ApplicatorPass.values();
            int n = ((MixinApplicatorStandard$ApplicatorPass[])object).length;
            int n2 = 0;
            while (MixinApplicatorStandard.lllIIlIII(n2, n)) {
                MixinApplicatorStandard$ApplicatorPass mixinApplicatorStandard$ApplicatorPass = object[n2];
                Profiler$Section profiler$Section = this.profiler.begin("pass", mixinApplicatorStandard$ApplicatorPass.name().toLowerCase());
                Iterator iterator = arrayList.iterator();
                while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
                    MixinTargetContext mixinTargetContext = (MixinTargetContext)iterator.next();
                    object2 = mixinTargetContext;
                    this.applyMixin((MixinTargetContext)object2, mixinApplicatorStandard$ApplicatorPass);
                    "".length();
                    if (((0x4F ^ 0x15 ^ (0x44 ^ 0x4E)) & ("  ".length() ^ (0xD7 ^ 0x85) ^ -" ".length())) == 0) continue;
                    return;
                }
                profiler$Section.end();
                "".length();
                ++n2;
                "".length();
                if (" ".length() < (0x83 ^ 0x87)) continue;
                return;
            }
            object = arrayList.iterator();
            while (MixinApplicatorStandard.lllIIIllI(object.hasNext() ? 1 : 0)) {
                MixinTargetContext mixinTargetContext = (MixinTargetContext)object.next();
                object2 = mixinTargetContext;
                ((MixinTargetContext)object2).postApply(this.targetName, this.targetClass);
                "".length();
                if (((0x82 ^ 0x98 ^ (0x57 ^ 1)) & (110 + 18 - -83 + 24 ^ 69 + 67 - 44 + 75 ^ -" ".length())) >= 0) continue;
                return;
            }
        }
        catch (InvalidMixinException invalidMixinException) {
            throw invalidMixinException;
        }
        catch (Exception exception) {
            throw new InvalidMixinException((IMixinContext)object2, String.valueOf(new StringBuilder().append("Unexpecteded ").append(exception.getClass().getSimpleName()).append(" whilst applying the mixin class: ").append(exception.getMessage())), (Throwable)exception);
        }
        "".length();
        if (null != null) {
            return;
        }
        this.applySourceMap(this.context);
        this.context.processDebugTasks();
    }

    protected final void applyMixin(MixinTargetContext mixinTargetContext, MixinApplicatorStandard$ApplicatorPass mixinApplicatorStandard$ApplicatorPass) {
        switch (MixinApplicatorStandard$1.$SwitchMap$org$spongepowered$asm$mixin$transformer$MixinApplicatorStandard$ApplicatorPass[mixinApplicatorStandard$ApplicatorPass.ordinal()]) {
            case 1: {
                this.applySignature(mixinTargetContext);
                this.applyInterfaces(mixinTargetContext);
                this.applyAttributes(mixinTargetContext);
                this.applyAnnotations(mixinTargetContext);
                this.applyFields(mixinTargetContext);
                this.applyMethods(mixinTargetContext);
                this.applyInitialisers(mixinTargetContext);
                "".length();
                if (((0x3D ^ 0x12) & ~(0xA3 ^ 0x8C)) == 0) break;
                return;
            }
            case 2: {
                this.prepareInjections(mixinTargetContext);
                "".length();
                if (-"  ".length() < 0) break;
                return;
            }
            case 3: {
                this.applyAccessors(mixinTargetContext);
                this.applyInjections(mixinTargetContext);
                "".length();
                if (-"   ".length() <= 0) break;
                return;
            }
            default: {
                throw new IllegalStateException(String.valueOf(new StringBuilder().append("Invalid pass specified ").append((Object)mixinApplicatorStandard$ApplicatorPass)));
            }
        }
    }

    protected void applySignature(MixinTargetContext mixinTargetContext) {
        this.context.mergeSignature(mixinTargetContext.getSignature());
    }

    protected void applyInterfaces(MixinTargetContext mixinTargetContext) {
        Iterator<String> iterator = mixinTargetContext.getInterfaces().iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            if (MixinApplicatorStandard.lllIIlllI(this.targetClass.interfaces.contains(string) ? 1 : 0)) {
                this.targetClass.interfaces.add(string);
                "".length();
                mixinTargetContext.getTargetClassInfo().addInterface(string);
            }
            "".length();
            if (" ".length() < (42 + 155 - 131 + 128 ^ 26 + 51 - -75 + 46)) continue;
            return;
        }
    }

    protected void applyAttributes(MixinTargetContext mixinTargetContext) {
        if (MixinApplicatorStandard.lllIIIllI(mixinTargetContext.shouldSetSourceFile() ? 1 : 0)) {
            this.targetClass.sourceFile = mixinTargetContext.getSourceFile();
        }
        this.targetClass.version = Math.max(this.targetClass.version, mixinTargetContext.getMinRequiredClassVersion());
    }

    protected void applyAnnotations(MixinTargetContext mixinTargetContext) {
        ClassNode classNode = mixinTargetContext.getClassNode();
        Bytecode.mergeAnnotations(classNode, this.targetClass);
    }

    protected void applyFields(MixinTargetContext mixinTargetContext) {
        this.mergeShadowFields(mixinTargetContext);
        this.mergeNewFields(mixinTargetContext);
    }

    protected void mergeShadowFields(MixinTargetContext mixinTargetContext) {
        Iterator<Map.Entry<FieldNode, ClassInfo$Field>> iterator = mixinTargetContext.getShadowFields().iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            Map.Entry<FieldNode, ClassInfo$Field> entry = iterator.next();
            FieldNode fieldNode = entry.getKey();
            FieldNode fieldNode2 = this.findTargetField(fieldNode);
            if (MixinApplicatorStandard.lllIIllll(fieldNode2)) {
                Bytecode.mergeAnnotations(fieldNode, fieldNode2);
                if (MixinApplicatorStandard.lllIIIllI(entry.getValue().isDecoratedMutable() ? 1 : 0) && MixinApplicatorStandard.lllIIlllI(Bytecode.hasFlag(fieldNode2, 2) ? 1 : 0)) {
                    fieldNode2.access &= 0xFFFFFFEF;
                }
            }
            "".length();
            if ("   ".length() == "   ".length()) continue;
            return;
        }
    }

    protected void mergeNewFields(MixinTargetContext mixinTargetContext) {
        Iterator<FieldNode> iterator = mixinTargetContext.getFields().iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            FieldNode fieldNode = iterator.next();
            FieldNode fieldNode2 = this.findTargetField(fieldNode);
            if (MixinApplicatorStandard.lllIlIIII(fieldNode2)) {
                this.targetClass.fields.add(fieldNode);
                "".length();
            }
            "".length();
            if (-" ".length() < 0) continue;
            return;
        }
    }

    protected void applyMethods(MixinTargetContext mixinTargetContext) {
        MethodNode methodNode;
        Iterator<MethodNode> iterator = mixinTargetContext.getShadowMethods().iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            methodNode = iterator.next();
            this.applyShadowMethod(mixinTargetContext, methodNode);
            "".length();
            if (" ".length() <= "   ".length()) continue;
            return;
        }
        iterator = mixinTargetContext.getMethods().iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            methodNode = iterator.next();
            this.applyNormalMethod(mixinTargetContext, methodNode);
            "".length();
            if ((0x88 ^ 0x8C) > 0) continue;
            return;
        }
    }

    protected void applyShadowMethod(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        MethodNode methodNode2 = this.findTargetMethod(methodNode);
        if (MixinApplicatorStandard.lllIIllll(methodNode2)) {
            Bytecode.mergeAnnotations(methodNode, methodNode2);
        }
    }

    protected void applyNormalMethod(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        mixinTargetContext.transformMethod(methodNode);
        if (MixinApplicatorStandard.lllIIlllI(methodNode.name.startsWith("<") ? 1 : 0)) {
            this.checkMethodVisibility(mixinTargetContext, methodNode);
            this.checkMethodConstraints(mixinTargetContext, methodNode);
            this.mergeMethod(mixinTargetContext, methodNode);
            "".length();
            if (null != null) {
                return;
            }
        } else if (MixinApplicatorStandard.lllIIIllI("<clinit>".equals(methodNode.name) ? 1 : 0)) {
            this.appendInsns(mixinTargetContext, methodNode);
        }
    }

    protected void mergeMethod(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        Object object;
        MethodNode methodNode2;
        boolean bl;
        boolean bl2;
        if (MixinApplicatorStandard.lllIIllll(Annotations.getVisible(methodNode, Overwrite.class))) {
            bl2 = true;
            "".length();
            if ((0x40 ^ 0x44) < "   ".length()) {
                return;
            }
        } else {
            bl2 = bl = false;
        }
        if (MixinApplicatorStandard.lllIIllll(methodNode2 = this.findTargetMethod(methodNode))) {
            if (MixinApplicatorStandard.lllIIIllI(this.isAlreadyMerged(mixinTargetContext, methodNode, bl, methodNode2) ? 1 : 0)) {
                return;
            }
            object = Annotations.getInvisible(methodNode, Intrinsic.class);
            if (MixinApplicatorStandard.lllIIllll(object)) {
                if (MixinApplicatorStandard.lllIIIllI(this.mergeIntrinsic(mixinTargetContext, methodNode, bl, methodNode2, (AnnotationNode)object) ? 1 : 0)) {
                    mixinTargetContext.getTarget().methodMerged(methodNode);
                    return;
                }
            } else {
                if (MixinApplicatorStandard.lllIIIllI(mixinTargetContext.requireOverwriteAnnotations() ? 1 : 0) && MixinApplicatorStandard.lllIIlllI(bl ? 1 : 0)) {
                    throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.format("%s%s in %s cannot overwrite method in %s because @Overwrite is required by the parent configuration", methodNode.name, methodNode.desc, mixinTargetContext, mixinTargetContext.getTarget().getClassName()));
                }
                this.targetClass.methods.remove(methodNode2);
                "".length();
            }
            "".length();
            if (" ".length() >= "  ".length()) {
                return;
            }
        } else if (MixinApplicatorStandard.lllIIIllI(bl ? 1 : 0)) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.format("Overwrite target \"%s\" was not located in target class %s", methodNode.name, mixinTargetContext.getTargetClassRef()));
        }
        this.targetClass.methods.add(methodNode);
        "".length();
        mixinTargetContext.methodMerged(methodNode);
        if (MixinApplicatorStandard.lllIIllll(methodNode.signature)) {
            object = mixinTargetContext.getSignature().getRemapper();
            new SignatureReader(methodNode.signature).accept((SignatureVisitor)object);
            methodNode.signature = object.toString();
        }
    }

    protected boolean isAlreadyMerged(MixinTargetContext mixinTargetContext, MethodNode methodNode, boolean bl, MethodNode methodNode2) {
        AnnotationNode annotationNode = Annotations.getVisible(methodNode2, MixinMerged.class);
        if (MixinApplicatorStandard.lllIlIIII(annotationNode)) {
            if (MixinApplicatorStandard.lllIIllll(Annotations.getVisible(methodNode2, Final.class))) {
                this.logger.warn("Overwrite prohibited for @Final method {} in {}. Skipping method.", new Object[]{methodNode.name, mixinTargetContext});
                return true;
            }
            return false;
        }
        String string = (String)Annotations.getValue(annotationNode, "sessionId");
        if (MixinApplicatorStandard.lllIIlllI(this.context.getSessionId().equals(string) ? 1 : 0)) {
            throw new ClassFormatError(String.valueOf(new StringBuilder().append("Invalid @MixinMerged annotation found in").append(mixinTargetContext).append(" at ").append(methodNode.name).append(" in ").append(this.targetClass.name)));
        }
        if (MixinApplicatorStandard.lllIIIllI(Bytecode.hasFlag(methodNode2, 4160) ? 1 : 0) && MixinApplicatorStandard.lllIIIllI(Bytecode.hasFlag(methodNode, 4160) ? 1 : 0)) {
            if (MixinApplicatorStandard.lllIIIllI(mixinTargetContext.getEnvironment().getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
                this.logger.warn("Synthetic bridge method clash for {} in {}", new Object[]{methodNode.name, mixinTargetContext});
            }
            return true;
        }
        String string2 = (String)Annotations.getValue(annotationNode, "mixin");
        int n = (Integer)Annotations.getValue(annotationNode, "priority");
        if (MixinApplicatorStandard.lllIlIIIl(n, mixinTargetContext.getPriority()) && MixinApplicatorStandard.lllIIlllI(string2.equals(mixinTargetContext.getClassName()) ? 1 : 0)) {
            this.logger.warn("Method overwrite conflict for {} in {}, previously written by {}. Skipping method.", new Object[]{methodNode.name, mixinTargetContext, string2});
            return true;
        }
        if (MixinApplicatorStandard.lllIIllll(Annotations.getVisible(methodNode2, Final.class))) {
            this.logger.warn("Method overwrite conflict for @Final method {} in {} declared by {}. Skipping method.", new Object[]{methodNode.name, mixinTargetContext, string2});
            return true;
        }
        return false;
    }

    protected boolean mergeIntrinsic(MixinTargetContext mixinTargetContext, MethodNode methodNode, boolean bl, MethodNode methodNode2, AnnotationNode annotationNode) {
        AnnotationNode annotationNode2;
        if (MixinApplicatorStandard.lllIIIllI(bl ? 1 : 0)) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("@Intrinsic is not compatible with @Overwrite, remove one of these annotations on ").append(methodNode.name).append(" in ").append(mixinTargetContext)));
        }
        String string = String.valueOf(new StringBuilder().append(methodNode.name).append(methodNode.desc));
        if (MixinApplicatorStandard.lllIIIllI(Bytecode.hasFlag(methodNode, 8) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("@Intrinsic method cannot be static, found ").append(string).append(" in ").append(mixinTargetContext)));
        }
        if (MixinApplicatorStandard.lllIIlllI(Bytecode.hasFlag(methodNode, 4096) ? 1 : 0) && (!MixinApplicatorStandard.lllIIllll(annotationNode2 = Annotations.getVisible(methodNode, MixinRenamed.class)) || MixinApplicatorStandard.lllIIlllI(Annotations.getValue(annotationNode2, "isInterfaceMember", Boolean.FALSE).booleanValue() ? 1 : 0))) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("@Intrinsic method must be prefixed interface method, no rename encountered on ").append(string).append(" in ").append(mixinTargetContext)));
        }
        if (MixinApplicatorStandard.lllIIlllI(Annotations.getValue(annotationNode, "displace", Boolean.FALSE).booleanValue() ? 1 : 0)) {
            this.logger.log(mixinTargetContext.getLoggingLevel(), "Skipping Intrinsic mixin method {} for {}", new Object[]{string, mixinTargetContext.getTargetClassRef()});
            return true;
        }
        this.displaceIntrinsic(mixinTargetContext, methodNode, methodNode2);
        return false;
    }

    protected void displaceIntrinsic(MixinTargetContext mixinTargetContext, MethodNode methodNode, MethodNode methodNode2) {
        String string = String.valueOf(new StringBuilder().append("proxy+").append(methodNode2.name));
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (MixinApplicatorStandard.lllIIIllI(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode instanceof MethodInsnNode) && MixinApplicatorStandard.lllIlIIlI(abstractInsnNode.getOpcode(), 184)) {
                MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
                if (MixinApplicatorStandard.lllIIIllI(methodInsnNode.owner.equals(this.targetClass.name) ? 1 : 0) && MixinApplicatorStandard.lllIIIllI(methodInsnNode.name.equals(methodNode2.name) ? 1 : 0) && MixinApplicatorStandard.lllIIIllI(methodInsnNode.desc.equals(methodNode2.desc) ? 1 : 0)) {
                    methodInsnNode.name = string;
                }
            }
            "".length();
            if ("   ".length() > ((0x42 ^ 0x71 ^ (0xBF ^ 0xAE)) & (0xCF ^ 0x97 ^ (0x1B ^ 0x61) ^ -" ".length()))) continue;
            return;
        }
        methodNode2.name = string;
    }

    protected final void appendInsns(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        if (MixinApplicatorStandard.lllIlIIll(Type.getReturnType(methodNode.desc), Type.VOID_TYPE)) {
            throw new IllegalArgumentException("Attempted to merge insns from a method which does not return void");
        }
        MethodNode methodNode2 = this.findTargetMethod(methodNode);
        if (MixinApplicatorStandard.lllIIllll(methodNode2)) {
            AbstractInsnNode abstractInsnNode = Bytecode.findInsn(methodNode2, 177);
            if (MixinApplicatorStandard.lllIIllll(abstractInsnNode)) {
                ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
                while (MixinApplicatorStandard.lllIIIllI(listIterator.hasNext() ? 1 : 0)) {
                    AbstractInsnNode abstractInsnNode2 = (AbstractInsnNode)listIterator.next();
                    if (MixinApplicatorStandard.lllIIlllI(abstractInsnNode2 instanceof LineNumberNode) && MixinApplicatorStandard.lllIlIIlI(abstractInsnNode2.getOpcode(), 177)) {
                        methodNode2.instructions.insertBefore(abstractInsnNode, abstractInsnNode2);
                    }
                    "".length();
                    if (-"  ".length() < 0) continue;
                    return;
                }
                methodNode2.maxLocals = Math.max(methodNode2.maxLocals, methodNode.maxLocals);
                methodNode2.maxStack = Math.max(methodNode2.maxStack, methodNode.maxStack);
            }
            return;
        }
        this.targetClass.methods.add(methodNode);
        "".length();
    }

    protected void applyInitialisers(MixinTargetContext mixinTargetContext) {
        MethodNode methodNode = this.getConstructor(mixinTargetContext);
        if (MixinApplicatorStandard.lllIlIIII(methodNode)) {
            return;
        }
        Deque<AbstractInsnNode> deque = this.getInitialiser(mixinTargetContext, methodNode);
        if (!MixinApplicatorStandard.lllIIllll(deque) || MixinApplicatorStandard.lllIIlllI(deque.size())) {
            return;
        }
        Iterator<MethodNode> iterator = this.targetClass.methods.iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode2 = iterator.next();
            if (MixinApplicatorStandard.lllIIIllI("<init>".equals(methodNode2.name) ? 1 : 0)) {
                methodNode2.maxStack = Math.max(methodNode2.maxStack, methodNode.maxStack);
                this.injectInitialiser(mixinTargetContext, methodNode2, deque);
            }
            "".length();
            if (" ".length() == " ".length()) continue;
            return;
        }
    }

    protected MethodNode getConstructor(MixinTargetContext mixinTargetContext) {
        MethodNode methodNode = null;
        Iterator<MethodNode> iterator = mixinTargetContext.getMethods().iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode2 = iterator.next();
            if (MixinApplicatorStandard.lllIIIllI("<init>".equals(methodNode2.name) ? 1 : 0) && MixinApplicatorStandard.lllIIIllI(Bytecode.methodHasLineNumbers(methodNode2) ? 1 : 0)) {
                if (MixinApplicatorStandard.lllIlIIII(methodNode)) {
                    methodNode = methodNode2;
                    "".length();
                    if (((0x65 ^ 0x2D) & ~(5 ^ 0x4D)) != ((0xD7 ^ 0x9C) & ~(0xCC ^ 0x87))) {
                        return null;
                    }
                } else {
                    this.logger.warn(String.format("Mixin %s has multiple constructors, %s was selected\n", mixinTargetContext, methodNode.desc));
                }
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        return methodNode;
    }

    private MixinApplicatorStandard$Range getConstructorRange(MethodNode methodNode) {
        int n = 0;
        AbstractInsnNode abstractInsnNode = null;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        int n5 = -1;
        Object object = methodNode.instructions.iterator();
        while (MixinApplicatorStandard.lllIIIllI(object.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode2 = (AbstractInsnNode)object.next();
            if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode2 instanceof LineNumberNode)) {
                n2 = ((LineNumberNode)abstractInsnNode2).line;
                n = 1;
                "".length();
                if ((0x12 ^ 0x16) <= " ".length()) {
                    return null;
                }
            } else if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode2 instanceof MethodInsnNode)) {
                if (MixinApplicatorStandard.lllIlIlII(abstractInsnNode2.getOpcode(), 183) && MixinApplicatorStandard.lllIIIllI("<init>".equals(((MethodInsnNode)abstractInsnNode2).name) ? 1 : 0) && MixinApplicatorStandard.lllIlIlII(n5, -1)) {
                    n5 = methodNode.instructions.indexOf(abstractInsnNode2);
                    n3 = n2;
                    "".length();
                    if (" ".length() == ((0xFB ^ 0xA3) & ~(0x42 ^ 0x1A))) {
                        return null;
                    }
                }
            } else if (MixinApplicatorStandard.lllIlIlII(abstractInsnNode2.getOpcode(), 181)) {
                n = 0;
                "".length();
                if ("  ".length() == "   ".length()) {
                    return null;
                }
            } else if (MixinApplicatorStandard.lllIlIlII(abstractInsnNode2.getOpcode(), 177)) {
                if (MixinApplicatorStandard.lllIIIllI(n)) {
                    n4 = n2;
                    "".length();
                    if (null != null) {
                        return null;
                    }
                } else {
                    n4 = n3;
                    abstractInsnNode = abstractInsnNode2;
                }
            }
            "".length();
            if (((0x15 ^ 8) & ~(0x62 ^ 0x7F)) != "   ".length()) continue;
            return null;
        }
        if (MixinApplicatorStandard.lllIIllll(abstractInsnNode)) {
            object = new LabelNode(new Label());
            methodNode.instructions.insertBefore(abstractInsnNode, (AbstractInsnNode)object);
            methodNode.instructions.insertBefore(abstractInsnNode, new LineNumberNode(n3, (LabelNode)object));
        }
        return new MixinApplicatorStandard$Range(this, n3, n4, n5);
    }

    protected final Deque<AbstractInsnNode> getInitialiser(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        MixinApplicatorStandard$Range mixinApplicatorStandard$Range = this.getConstructorRange(methodNode);
        if (MixinApplicatorStandard.lllIIlllI(mixinApplicatorStandard$Range.isValid() ? 1 : 0)) {
            return null;
        }
        int n = 0;
        ArrayDeque<AbstractInsnNode> arrayDeque = new ArrayDeque<AbstractInsnNode>();
        int n2 = 0;
        int n3 = -1;
        LabelNode labelNode = null;
        Object object = methodNode.instructions.iterator(mixinApplicatorStandard$Range.marker);
        while (MixinApplicatorStandard.lllIIIllI(object.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)object.next();
            if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode instanceof LineNumberNode)) {
                n = ((LineNumberNode)abstractInsnNode).line;
                AbstractInsnNode abstractInsnNode2 = methodNode.instructions.get(methodNode.instructions.indexOf(abstractInsnNode) + 1);
                if (MixinApplicatorStandard.lllIlIlII(n, mixinApplicatorStandard$Range.end) && MixinApplicatorStandard.lllIlIIlI(abstractInsnNode2.getOpcode(), 177)) {
                    n2 = 1;
                    n3 = 177;
                    "".length();
                    if (null != null) {
                        return null;
                    }
                } else {
                    n2 = mixinApplicatorStandard$Range.excludes(n) ? 1 : 0;
                    n3 = -1;
                }
                "".length();
                if ((0x37 ^ 0x33) <= "  ".length()) {
                    return null;
                }
            } else if (MixinApplicatorStandard.lllIIIllI(n2)) {
                if (MixinApplicatorStandard.lllIIllll(labelNode)) {
                    arrayDeque.add(labelNode);
                    "".length();
                    labelNode = null;
                }
                if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode instanceof LabelNode)) {
                    labelNode = (LabelNode)abstractInsnNode;
                    "".length();
                    if (((0xA2 ^ 0x90 ^ (0x54 ^ 0x2E)) & (19 + 90 - -101 + 14 ^ 65 + 133 - 35 + 5 ^ -" ".length()) & ((215 + 63 - 182 + 120 ^ 6 + 57 - -32 + 89) & (74 + 11 - 10 + 89 ^ 147 + 44 - 41 + 46 ^ -" ".length()) ^ -" ".length())) >= "   ".length()) {
                        return null;
                    }
                } else {
                    int n4 = abstractInsnNode.getOpcode();
                    if (MixinApplicatorStandard.lllIlIlII(n4, n3)) {
                        n3 = -1;
                        "".length();
                        if ((0x7B ^ 0x22 ^ (0x48 ^ 0x15)) <= (0x43 ^ 0x74 ^ (0xBE ^ 0x8D))) continue;
                        return null;
                    }
                    int[] nArray = INITIALISER_OPCODE_BLACKLIST;
                    int n5 = nArray.length;
                    int n6 = 0;
                    while (MixinApplicatorStandard.lllIIlIII(n6, n5)) {
                        int n7 = nArray[n6];
                        if (MixinApplicatorStandard.lllIlIlII(n4, n7)) {
                            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("Cannot handle ").append(Bytecode.getOpcodeName(n4)).append(" opcode (0x").append(Integer.toHexString(n4).toUpperCase()).append(") in class initialiser")));
                        }
                        ++n6;
                        "".length();
                        if ("   ".length() >= " ".length()) continue;
                        return null;
                    }
                    arrayDeque.add(abstractInsnNode);
                    "".length();
                }
            }
            "".length();
            if (-" ".length() < 0) continue;
            return null;
        }
        object = (AbstractInsnNode)arrayDeque.peekLast();
        if (MixinApplicatorStandard.lllIIllll(object) && MixinApplicatorStandard.lllIlIIlI(((AbstractInsnNode)object).getOpcode(), 181)) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("Could not parse initialiser, expected 0xB5, found 0x").append(Integer.toHexString(((AbstractInsnNode)object).getOpcode())).append(" in ").append(mixinTargetContext)));
        }
        return arrayDeque;
    }

    protected final void injectInitialiser(MixinTargetContext mixinTargetContext, MethodNode methodNode, Deque<AbstractInsnNode> deque) {
        Map<LabelNode, LabelNode> map = Bytecode.cloneLabels(methodNode.instructions);
        AbstractInsnNode abstractInsnNode = this.findInitialiserInjectionPoint(mixinTargetContext, methodNode, deque);
        if (MixinApplicatorStandard.lllIlIIII(abstractInsnNode)) {
            this.logger.warn("Failed to locate initialiser injection point in <init>{}, initialiser was not mixed in.", new Object[]{methodNode.desc});
            return;
        }
        Iterator<AbstractInsnNode> iterator = deque.iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode2 = iterator.next();
            if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode2 instanceof LabelNode)) {
                "".length();
                if (" ".length() != 0) continue;
                return;
            }
            if (MixinApplicatorStandard.lllIIIllI(abstractInsnNode2 instanceof JumpInsnNode)) {
                throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append("Unsupported JUMP opcode in initialiser in ").append(mixinTargetContext)));
            }
            AbstractInsnNode abstractInsnNode3 = abstractInsnNode2.clone(map);
            methodNode.instructions.insert(abstractInsnNode, abstractInsnNode3);
            abstractInsnNode = abstractInsnNode3;
            "".length();
            if ("   ".length() != 0) continue;
            return;
        }
    }

    protected AbstractInsnNode findInitialiserInjectionPoint(MixinTargetContext mixinTargetContext, MethodNode methodNode, Deque<AbstractInsnNode> deque) {
        Object object;
        HashSet<String> hashSet = new HashSet<String>();
        Object object2 = deque.iterator();
        while (MixinApplicatorStandard.lllIIIllI(object2.hasNext() ? 1 : 0)) {
            object = object2.next();
            if (MixinApplicatorStandard.lllIlIlII(((AbstractInsnNode)object).getOpcode(), 181)) {
                hashSet.add(MixinApplicatorStandard.fieldKey((FieldInsnNode)object));
                "".length();
            }
            "".length();
            if (-" ".length() <= -" ".length()) continue;
            return null;
        }
        object2 = this.getInitialiserInjectionMode(mixinTargetContext.getEnvironment());
        object = mixinTargetContext.getTargetClassInfo().getName();
        String string = mixinTargetContext.getTargetClassInfo().getSuperName();
        AbstractInsnNode abstractInsnNode = null;
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (MixinApplicatorStandard.lllIIIllI(listIterator.hasNext() ? 1 : 0)) {
            String string2;
            AbstractInsnNode abstractInsnNode2 = (AbstractInsnNode)listIterator.next();
            if (MixinApplicatorStandard.lllIlIlII(abstractInsnNode2.getOpcode(), 183) && MixinApplicatorStandard.lllIIIllI("<init>".equals(((MethodInsnNode)abstractInsnNode2).name) ? 1 : 0)) {
                string2 = ((MethodInsnNode)abstractInsnNode2).owner;
                if (!MixinApplicatorStandard.lllIIlllI(string2.equals(object) ? 1 : 0) || MixinApplicatorStandard.lllIIIllI(string2.equals(string) ? 1 : 0)) {
                    abstractInsnNode = abstractInsnNode2;
                    if (MixinApplicatorStandard.lllIlIlIl(object2, (Object)MixinApplicatorStandard$InitialiserInjectionMode.SAFE)) {
                        "".length();
                        if (((0x30 ^ 0x7F) & ~(0xFA ^ 0xB5)) <= (0x4E ^ 0x4A)) break;
                        return null;
                    }
                }
                "".length();
                if ((9 + 28 - 32 + 175 ^ 37 + 44 - -82 + 13) <= "   ".length()) {
                    return null;
                }
            } else if (MixinApplicatorStandard.lllIlIlII(abstractInsnNode2.getOpcode(), 181) && MixinApplicatorStandard.lllIlIlIl(object2, (Object)MixinApplicatorStandard$InitialiserInjectionMode.DEFAULT) && MixinApplicatorStandard.lllIIIllI(hashSet.contains(string2 = MixinApplicatorStandard.fieldKey((FieldInsnNode)abstractInsnNode2)) ? 1 : 0)) {
                abstractInsnNode = abstractInsnNode2;
            }
            "".length();
            if ("   ".length() > 0) continue;
            return null;
        }
        return abstractInsnNode;
    }

    private MixinApplicatorStandard$InitialiserInjectionMode getInitialiserInjectionMode(MixinEnvironment mixinEnvironment) {
        String string = mixinEnvironment.getOptionValue(MixinEnvironment$Option.INITIALISER_INJECTION_MODE);
        if (MixinApplicatorStandard.lllIlIIII(string)) {
            return MixinApplicatorStandard$InitialiserInjectionMode.DEFAULT;
        }
        try {
            return MixinApplicatorStandard$InitialiserInjectionMode.valueOf(string.toUpperCase());
        }
        catch (Exception exception) {
            this.logger.warn("Could not parse unexpected value \"{}\" for mixin.initialiserInjectionMode, reverting to DEFAULT", new Object[]{string});
            return MixinApplicatorStandard$InitialiserInjectionMode.DEFAULT;
        }
    }

    private static String fieldKey(FieldInsnNode fieldInsnNode) {
        return String.format("%s:%s", fieldInsnNode.desc, fieldInsnNode.name);
    }

    protected void prepareInjections(MixinTargetContext mixinTargetContext) {
        mixinTargetContext.prepareInjections();
    }

    protected void applyInjections(MixinTargetContext mixinTargetContext) {
        mixinTargetContext.applyInjections();
    }

    protected void applyAccessors(MixinTargetContext mixinTargetContext) {
        List<MethodNode> list = mixinTargetContext.generateAccessors();
        Iterator<MethodNode> iterator = list.iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            if (MixinApplicatorStandard.lllIIlllI(methodNode.name.startsWith("<") ? 1 : 0)) {
                this.mergeMethod(mixinTargetContext, methodNode);
            }
            "".length();
            if (-"  ".length() < 0) continue;
            return;
        }
    }

    protected void checkMethodVisibility(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        if (MixinApplicatorStandard.lllIIIllI(Bytecode.hasFlag(methodNode, 8) ? 1 : 0) && MixinApplicatorStandard.lllIIlllI(Bytecode.hasFlag(methodNode, 2) ? 1 : 0) && MixinApplicatorStandard.lllIIlllI(Bytecode.hasFlag(methodNode, 4096) ? 1 : 0) && MixinApplicatorStandard.lllIlIIII(Annotations.getVisible(methodNode, Overwrite.class))) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.format("Mixin %s contains non-private static method %s", mixinTargetContext, methodNode));
        }
    }

    protected void applySourceMap(TargetClassContext targetClassContext) {
        this.targetClass.sourceDebug = targetClassContext.getSourceMap().toString();
    }

    protected void checkMethodConstraints(MixinTargetContext mixinTargetContext, MethodNode methodNode) {
        Iterator<Class<? extends Annotation>> iterator = CONSTRAINED_ANNOTATIONS.iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            Class<? extends Annotation> clazz = iterator.next();
            AnnotationNode annotationNode = Annotations.getVisible(methodNode, clazz);
            if (MixinApplicatorStandard.lllIIllll(annotationNode)) {
                this.checkConstraints(mixinTargetContext, methodNode, annotationNode);
            }
            "".length();
            if ((25 + 25 - 30 + 109 ^ 128 + 14 - 120 + 110) != 0) continue;
            return;
        }
    }

    protected final void checkConstraints(MixinTargetContext mixinTargetContext, MethodNode methodNode, AnnotationNode annotationNode) {
        block6: {
            try {
                ConstraintParser$Constraint constraintParser$Constraint = ConstraintParser.parse(annotationNode);
                try {
                    constraintParser$Constraint.check(mixinTargetContext.getEnvironment());
                    "".length();
                }
                catch (ConstraintViolationException constraintViolationException) {
                    String string = String.format("Constraint violation: %s on %s in %s", constraintViolationException.getMessage(), methodNode, mixinTargetContext);
                    this.logger.warn(string);
                    if (!MixinApplicatorStandard.lllIIlllI(mixinTargetContext.getEnvironment().getOption(MixinEnvironment$Option.IGNORE_CONSTRAINTS) ? 1 : 0)) break block6;
                    throw new InvalidMixinException(mixinTargetContext, string, (Throwable)constraintViolationException);
                }
                if ("   ".length() >= (0x94 ^ 0xB5 ^ (0x9D ^ 0xB8))) {
                    return;
                }
            }
            catch (InvalidConstraintException invalidConstraintException) {
                throw new InvalidMixinException((IMixinContext)mixinTargetContext, invalidConstraintException.getMessage());
            }
        }
        "".length();
        if (-"  ".length() >= 0) {
            return;
        }
    }

    protected final MethodNode findTargetMethod(MethodNode methodNode) {
        Iterator<MethodNode> iterator = this.targetClass.methods.iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode2 = iterator.next();
            if (MixinApplicatorStandard.lllIIIllI(methodNode2.name.equals(methodNode.name) ? 1 : 0) && MixinApplicatorStandard.lllIIIllI(methodNode2.desc.equals(methodNode.desc) ? 1 : 0)) {
                return methodNode2;
            }
            "".length();
            if ((0x84 ^ 0x80) > ((0x33 ^ 0x19) & ~(0x4C ^ 0x66))) continue;
            return null;
        }
        return null;
    }

    protected final FieldNode findTargetField(FieldNode fieldNode) {
        Iterator<FieldNode> iterator = this.targetClass.fields.iterator();
        while (MixinApplicatorStandard.lllIIIllI(iterator.hasNext() ? 1 : 0)) {
            FieldNode fieldNode2 = iterator.next();
            if (MixinApplicatorStandard.lllIIIllI(fieldNode2.name.equals(fieldNode.name) ? 1 : 0)) {
                return fieldNode2;
            }
            "".length();
            if ("   ".length() >= " ".length()) continue;
            return null;
        }
        return null;
    }

    private static boolean lllIlIlII(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIlIIIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lllIIlIII(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIlIIll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lllIIllll(Object object) {
        return object != null;
    }

    private static boolean lllIlIlIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIlIIII(Object object) {
        return object == null;
    }

    private static boolean lllIIIllI(int n) {
        return n != 0;
    }

    private static boolean lllIIlllI(int n) {
        return n == 0;
    }

    private static boolean lllIlIIlI(int n, int n2) {
        return n != n2;
    }
}

