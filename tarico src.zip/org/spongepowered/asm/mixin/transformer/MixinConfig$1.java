/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.MixinEnvironment$Side;

class MixinConfig$1 {
    static final /* synthetic */ int[] $SwitchMap$org$spongepowered$asm$mixin$MixinEnvironment$Side;

    static {
        block8: {
            block9: {
                block7: {
                    $SwitchMap$org$spongepowered$asm$mixin$MixinEnvironment$Side = new int[MixinEnvironment$Side.values().length];
                    try {
                        MixinConfig$1.$SwitchMap$org$spongepowered$asm$mixin$MixinEnvironment$Side[MixinEnvironment$Side.CLIENT.ordinal()] = 1;
                        "".length();
                    }
                    catch (NoSuchFieldError noSuchFieldError) {
                        // empty catch block
                    }
                    if (null == null) break block7;
                    break block8;
                }
                try {
                    MixinConfig$1.$SwitchMap$org$spongepowered$asm$mixin$MixinEnvironment$Side[MixinEnvironment$Side.SERVER.ordinal()] = 2;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if (-"   ".length() <= 0) break block9;
                break block8;
            }
            try {
                MixinConfig$1.$SwitchMap$org$spongepowered$asm$mixin$MixinEnvironment$Side[MixinEnvironment$Side.UNKNOWN.ordinal()] = 3;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if (" ".length() == (0x15 ^ 0x7F ^ (0xE3 ^ 0x8D))) {
                // empty if block
            }
        }
    }
}

