/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.annotations.SerializedName
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.MixinInitialisationError;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.extensibility.IMixinConfig;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.injection.InjectionPoint;
import org.spongepowered.asm.mixin.refmap.IReferenceMapper;
import org.spongepowered.asm.mixin.refmap.ReferenceMapper;
import org.spongepowered.asm.mixin.refmap.RemappingReferenceMapper;
import org.spongepowered.asm.mixin.transformer.Config;
import org.spongepowered.asm.mixin.transformer.MixinConfig$1;
import org.spongepowered.asm.mixin.transformer.MixinConfig$IListener;
import org.spongepowered.asm.mixin.transformer.MixinConfig$InjectorOptions;
import org.spongepowered.asm.mixin.transformer.MixinConfig$OverwriteOptions;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.MixinService;
import org.spongepowered.asm.util.VersionNumber;

final class MixinConfig
implements Comparable<MixinConfig>,
IMixinConfig {
    private static int configOrder = 0;
    private static final Set<String> globalMixinList = new HashSet<String>();
    private final Logger logger = LogManager.getLogger((String)"mixin");
    private final transient Map<String, List<MixinInfo>> mixinMapping = new HashMap<String, List<MixinInfo>>();
    private final transient Set<String> unhandledTargets = new HashSet<String>();
    private final transient List<MixinInfo> mixins = new ArrayList<MixinInfo>();
    private transient Config handle;
    @SerializedName(value="target")
    private String selector;
    @SerializedName(value="minVersion")
    private String version;
    @SerializedName(value="compatibilityLevel")
    private String compatibility;
    @SerializedName(value="required")
    private boolean required;
    @SerializedName(value="priority")
    private int priority = 1000;
    @SerializedName(value="mixinPriority")
    private int mixinPriority = 1000;
    @SerializedName(value="package")
    private String mixinPackage;
    @SerializedName(value="mixins")
    private List<String> mixinClasses;
    @SerializedName(value="client")
    private List<String> mixinClassesClient;
    @SerializedName(value="server")
    private List<String> mixinClassesServer;
    @SerializedName(value="setSourceFile")
    private boolean setSourceFile = false;
    @SerializedName(value="refmap")
    private String refMapperConfig;
    @SerializedName(value="verbose")
    private boolean verboseLogging;
    private final transient int order = configOrder++;
    private final transient List<MixinConfig$IListener> listeners = new ArrayList<MixinConfig$IListener>();
    private transient IMixinService service;
    private transient MixinEnvironment env;
    private transient String name;
    @SerializedName(value="plugin")
    private String pluginClassName;
    @SerializedName(value="injectors")
    private MixinConfig$InjectorOptions injectorOptions = new MixinConfig$InjectorOptions();
    @SerializedName(value="overwrites")
    private MixinConfig$OverwriteOptions overwriteOptions = new MixinConfig$OverwriteOptions();
    private transient IMixinConfigPlugin plugin;
    private transient IReferenceMapper refMapper;
    private transient boolean prepared = false;
    private transient boolean visited = false;

    private MixinConfig() {
    }

    private boolean onLoad(IMixinService iMixinService, String string, MixinEnvironment mixinEnvironment) {
        boolean bl;
        this.service = iMixinService;
        this.name = string;
        this.env = this.parseSelector(this.selector, mixinEnvironment);
        if (MixinConfig.llIlIllIlI(this.env.getOption(MixinEnvironment$Option.IGNORE_REQUIRED) ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((109 + 138 - 112 + 82 ^ 43 + 25 - 25 + 111) & (174 + 93 - 146 + 107 ^ 125 + 53 - 51 + 40 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        this.required &= bl;
        this.initCompatibilityLevel();
        this.initInjectionPoints();
        return this.checkVersion();
    }

    private void initCompatibilityLevel() {
        MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel;
        if (MixinConfig.llIlIllIll(this.compatibility)) {
            return;
        }
        MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel2 = MixinEnvironment$CompatibilityLevel.valueOf(this.compatibility.trim().toUpperCase());
        if (MixinConfig.llIlIlllII((Object)mixinEnvironment$CompatibilityLevel2, (Object)(mixinEnvironment$CompatibilityLevel = MixinEnvironment.getCompatibilityLevel()))) {
            return;
        }
        if (MixinConfig.llIlIlllIl(mixinEnvironment$CompatibilityLevel.isAtLeast(mixinEnvironment$CompatibilityLevel2) ? 1 : 0) && MixinConfig.llIlIllIlI(mixinEnvironment$CompatibilityLevel.canSupport(mixinEnvironment$CompatibilityLevel2) ? 1 : 0)) {
            throw new MixinInitialisationError(String.valueOf(new StringBuilder().append("Mixin config ").append(this.name).append(" requires compatibility level ").append((Object)mixinEnvironment$CompatibilityLevel2).append(" which is too old")));
        }
        if (MixinConfig.llIlIllIlI(mixinEnvironment$CompatibilityLevel.canElevateTo(mixinEnvironment$CompatibilityLevel2) ? 1 : 0)) {
            throw new MixinInitialisationError(String.valueOf(new StringBuilder().append("Mixin config ").append(this.name).append(" requires compatibility level ").append((Object)mixinEnvironment$CompatibilityLevel2).append(" which is prohibited by ").append((Object)mixinEnvironment$CompatibilityLevel)));
        }
        MixinEnvironment.setCompatibilityLevel(mixinEnvironment$CompatibilityLevel2);
    }

    private MixinEnvironment parseSelector(String string, MixinEnvironment mixinEnvironment) {
        if (MixinConfig.llIlIlllll(string)) {
            String[] stringArray;
            Object object = stringArray = string.split("[&\\| ]");
            int n = ((String[])object).length;
            int n2 = 0;
            while (MixinConfig.llIllIIIII(n2, n)) {
                String string2 = object[n2];
                string2 = string2.trim();
                Pattern pattern = Pattern.compile("^@env(?:ironment)?\\(([A-Z]+)\\)$");
                Matcher matcher = pattern.matcher(string2);
                if (MixinConfig.llIlIlllIl(matcher.matches() ? 1 : 0)) {
                    return MixinEnvironment.getEnvironment(MixinEnvironment$Phase.forName(matcher.group(1)));
                }
                ++n2;
                "".length();
                if ("   ".length() >= "   ".length()) continue;
                return null;
            }
            object = MixinEnvironment$Phase.forName(string);
            if (MixinConfig.llIlIlllll(object)) {
                return MixinEnvironment.getEnvironment((MixinEnvironment$Phase)object);
            }
        }
        return mixinEnvironment;
    }

    private void initInjectionPoints() {
        if (MixinConfig.llIlIllIll(this.injectorOptions.injectionPoints)) {
            return;
        }
        Iterator<String> iterator = this.injectorOptions.injectionPoints.iterator();
        while (MixinConfig.llIlIlllIl(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            try {
                Class<?> clazz = this.service.getClassProvider().findClass(string, true);
                if (MixinConfig.llIlIlllIl(InjectionPoint.class.isAssignableFrom(clazz) ? 1 : 0)) {
                    InjectionPoint.register(clazz);
                    "".length();
                    if (null != null) {
                        return;
                    }
                } else {
                    this.logger.error("Unable to register injection point {} for {}, class must extend InjectionPoint", new Object[]{clazz, this});
                }
                "".length();
            }
            catch (Throwable throwable) {
                this.logger.catching(throwable);
            }
            if (null != null) {
                return;
            }
            "".length();
            if (((0x64 ^ 0x6C) & ~(0xD ^ 5)) >= -" ".length()) continue;
            return;
        }
    }

    private boolean checkVersion() {
        VersionNumber versionNumber;
        VersionNumber versionNumber2;
        if (MixinConfig.llIlIllIll(this.version)) {
            this.logger.error("Mixin config {} does not specify \"minVersion\" property", new Object[]{this.name});
        }
        if (MixinConfig.llIllIIIll((versionNumber2 = VersionNumber.parse(this.version)).compareTo(versionNumber = VersionNumber.parse(this.env.getVersion())))) {
            this.logger.warn("Mixin config {} requires mixin subsystem version {} but {} was found. The mixin config will not be applied.", new Object[]{this.name, versionNumber2, versionNumber});
            if (MixinConfig.llIlIlllIl(this.required ? 1 : 0)) {
                throw new MixinInitialisationError(String.valueOf(new StringBuilder().append("Required mixin config ").append(this.name).append(" requires mixin subsystem version ").append(versionNumber2)));
            }
            return false;
        }
        return true;
    }

    void addListener(MixinConfig$IListener iListener) {
        this.listeners.add(iListener);
        "".length();
    }

    void onSelect() {
        if (MixinConfig.llIlIlllll(this.pluginClassName)) {
            try {
                Class<?> clazz = this.service.getClassProvider().findClass(this.pluginClassName, true);
                this.plugin = (IMixinConfigPlugin)clazz.newInstance();
                if (MixinConfig.llIlIlllll(this.plugin)) {
                    this.plugin.onLoad(this.mixinPackage);
                }
                "".length();
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
                this.plugin = null;
            }
            if (" ".length() <= ((0x93 ^ 0x85 ^ (0xE8 ^ 0xB9)) & (18 + 179 - 56 + 114 ^ 73 + 105 - 98 + 104 ^ -" ".length()))) {
                return;
            }
        }
        if (MixinConfig.llIlIllIlI(this.mixinPackage.endsWith(".") ? 1 : 0)) {
            this.mixinPackage = String.valueOf(new StringBuilder().append(this.mixinPackage).append("."));
        }
        int n = 0;
        if (MixinConfig.llIlIllIll(this.refMapperConfig)) {
            if (MixinConfig.llIlIlllll(this.plugin)) {
                this.refMapperConfig = this.plugin.getRefMapperConfig();
            }
            if (MixinConfig.llIlIllIll(this.refMapperConfig)) {
                n = 1;
                this.refMapperConfig = "mixin.refmap.json";
            }
        }
        this.refMapper = ReferenceMapper.read(this.refMapperConfig);
        this.verboseLogging |= this.env.getOption(MixinEnvironment$Option.DEBUG_VERBOSE);
        if (MixinConfig.llIlIllIlI(n) && MixinConfig.llIlIlllIl(this.refMapper.isDefault() ? 1 : 0) && MixinConfig.llIlIllIlI(this.env.getOption(MixinEnvironment$Option.DISABLE_REFMAP) ? 1 : 0)) {
            this.logger.warn("Reference map '{}' for {} could not be read. If this is a development environment you can ignore this message", new Object[]{this.refMapperConfig, this});
        }
        if (MixinConfig.llIlIlllIl(this.env.getOption(MixinEnvironment$Option.REFMAP_REMAP) ? 1 : 0)) {
            this.refMapper = RemappingReferenceMapper.of(this.env, this.refMapper);
        }
    }

    void prepare() {
        if (MixinConfig.llIlIlllIl(this.prepared ? 1 : 0)) {
            return;
        }
        this.prepared = true;
        this.prepareMixins(this.mixinClasses, false);
        switch (MixinConfig$1.$SwitchMap$org$spongepowered$asm$mixin$MixinEnvironment$Side[this.env.getSide().ordinal()]) {
            case 1: {
                this.prepareMixins(this.mixinClassesClient, false);
                "".length();
                if (null == null) break;
                return;
            }
            case 2: {
                this.prepareMixins(this.mixinClassesServer, false);
                "".length();
                if (" ".length() > -" ".length()) break;
                return;
            }
            default: {
                this.logger.warn("Mixin environment was unable to detect the current side, sided mixins will not be applied");
            }
        }
    }

    void postInitialise() {
        Object object;
        if (MixinConfig.llIlIlllll(this.plugin)) {
            object = this.plugin.getMixins();
            this.prepareMixins((List<String>)object, true);
        }
        object = this.mixins.iterator();
        while (MixinConfig.llIlIlllIl(object.hasNext() ? 1 : 0)) {
            MixinInfo mixinInfo = (MixinInfo)object.next();
            try {
                mixinInfo.validate();
                Iterator<MixinConfig$IListener> iterator = this.listeners.iterator();
                while (MixinConfig.llIlIlllIl(iterator.hasNext() ? 1 : 0)) {
                    MixinConfig$IListener mixinConfig$IListener = iterator.next();
                    mixinConfig$IListener.onInit(mixinInfo);
                    "".length();
                    if (-" ".length() != "   ".length()) continue;
                    return;
                }
            }
            catch (InvalidMixinException invalidMixinException) {
                this.logger.error(String.valueOf(new StringBuilder().append(invalidMixinException.getMixin()).append(": ").append(invalidMixinException.getMessage())), (Throwable)invalidMixinException);
                this.removeMixin(mixinInfo);
                object.remove();
                "".length();
                if (-(6 + 21 - -87 + 19 ^ 87 + 127 - 102 + 16) >= 0) {
                    return;
                }
            }
            catch (Exception exception) {
                this.logger.error(exception.getMessage(), (Throwable)exception);
                this.removeMixin(mixinInfo);
                object.remove();
            }
            "".length();
            if (((201 + 169 - 182 + 20 ^ 49 + 22 - -14 + 73) & (50 + 131 - 144 + 161 ^ 131 + 25 - 141 + 121 ^ -" ".length())) > 0) {
                return;
            }
            "".length();
            if ("   ".length() >= ((0x67 ^ 0x62) & ~(0 ^ 5))) continue;
            return;
        }
    }

    private void removeMixin(MixinInfo mixinInfo) {
        Iterator<List<MixinInfo>> iterator = this.mixinMapping.values().iterator();
        while (MixinConfig.llIlIlllIl(iterator.hasNext() ? 1 : 0)) {
            List<MixinInfo> list = iterator.next();
            Iterator<MixinInfo> iterator2 = list.iterator();
            while (MixinConfig.llIlIlllIl(iterator2.hasNext() ? 1 : 0)) {
                if (!MixinConfig.llIlIlllII(mixinInfo, iterator2.next())) continue;
                iterator2.remove();
                "".length();
                if (" ".length() > 0) continue;
                return;
            }
            "".length();
            if (((6 + 86 - 6 + 49 ^ 175 + 151 - 267 + 117) & (0x73 ^ 0xB ^ (0xF6 ^ 0xB9) ^ -" ".length())) < "  ".length()) continue;
            return;
        }
    }

    private void prepareMixins(List<String> list, boolean bl) {
        if (MixinConfig.llIlIllIll(list)) {
            return;
        }
        Iterator<String> iterator = list.iterator();
        while (MixinConfig.llIlIlllIl(iterator.hasNext() ? 1 : 0)) {
            block12: {
                String string = iterator.next();
                String string2 = String.valueOf(new StringBuilder().append(this.mixinPackage).append(string));
                if (!MixinConfig.llIlIlllll(string)) continue;
                if (MixinConfig.llIlIlllIl(globalMixinList.contains(string2) ? 1 : 0)) {
                    "".length();
                    if (-" ".length() < ((0xAD ^ 0x83) & ~(0x78 ^ 0x56))) continue;
                    return;
                }
                MixinInfo mixinInfo = null;
                try {
                    Object object;
                    mixinInfo = new MixinInfo(this.service, this, string, true, this.plugin, bl);
                    if (!MixinConfig.llIllIIIll(mixinInfo.getTargetClasses().size())) break block12;
                    globalMixinList.add(string2);
                    "".length();
                    Iterator<Object> iterator2 = mixinInfo.getTargetClasses().iterator();
                    while (MixinConfig.llIlIlllIl(iterator2.hasNext() ? 1 : 0)) {
                        object = iterator2.next();
                        String string3 = ((String)object).replace('/', '.');
                        this.mixinsFor(string3).add(mixinInfo);
                        "".length();
                        this.unhandledTargets.add(string3);
                        "".length();
                        "".length();
                        if (((120 + 39 - 49 + 60 ^ 27 + 128 - 22 + 0) & (0xC3 ^ 0xAB ^ (5 ^ 0x42) ^ -" ".length())) == 0) continue;
                        return;
                    }
                    iterator2 = this.listeners.iterator();
                    while (MixinConfig.llIlIlllIl(iterator2.hasNext() ? 1 : 0)) {
                        object = (MixinConfig$IListener)iterator2.next();
                        object.onPrepare(mixinInfo);
                        "".length();
                        if ("   ".length() > ((0x38 ^ 0x2A) & ~(0x62 ^ 0x70))) continue;
                        return;
                    }
                    this.mixins.add(mixinInfo);
                    "".length();
                }
                catch (InvalidMixinException invalidMixinException) {
                    if (MixinConfig.llIlIlllIl(this.required ? 1 : 0)) {
                        throw invalidMixinException;
                    }
                    this.logger.error(invalidMixinException.getMessage(), (Throwable)invalidMixinException);
                    "".length();
                    if (null != null) {
                        return;
                    }
                }
                catch (Exception exception) {
                    if (MixinConfig.llIlIlllIl(this.required ? 1 : 0)) {
                        throw new InvalidMixinException(mixinInfo, String.valueOf(new StringBuilder().append("Error initialising mixin ").append(mixinInfo).append(" - ").append(exception.getClass()).append(": ").append(exception.getMessage())), (Throwable)exception);
                    }
                    this.logger.error(exception.getMessage(), (Throwable)exception);
                }
            }
            "".length();
            if (-"  ".length() >= 0) {
                return;
            }
            "".length();
            if (-" ".length() <= "   ".length()) continue;
            return;
        }
    }

    void postApply(String string, ClassNode classNode) {
        this.unhandledTargets.remove(string);
        "".length();
    }

    public Config getHandle() {
        if (MixinConfig.llIlIllIll(this.handle)) {
            this.handle = new Config(this);
        }
        return this.handle;
    }

    @Override
    public boolean isRequired() {
        return this.required;
    }

    @Override
    public MixinEnvironment getEnvironment() {
        return this.env;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getMixinPackage() {
        return this.mixinPackage;
    }

    @Override
    public int getPriority() {
        return this.priority;
    }

    public int getDefaultMixinPriority() {
        return this.mixinPriority;
    }

    public int getDefaultRequiredInjections() {
        return this.injectorOptions.defaultRequireValue;
    }

    public String getDefaultInjectorGroup() {
        String string;
        String string2 = this.injectorOptions.defaultGroup;
        if (MixinConfig.llIlIlllll(string2) && MixinConfig.llIlIllIlI(string2.isEmpty() ? 1 : 0)) {
            string = string2;
            "".length();
            if ("  ".length() > "  ".length()) {
                return null;
            }
        } else {
            string = "default";
        }
        return string;
    }

    public boolean conformOverwriteVisibility() {
        return this.overwriteOptions.conformAccessModifiers;
    }

    public boolean requireOverwriteAnnotations() {
        return this.overwriteOptions.requireOverwriteAnnotations;
    }

    public int getMaxShiftByValue() {
        return Math.min(Math.max(this.injectorOptions.maxShiftBy, 0), 0);
    }

    public boolean select(MixinEnvironment mixinEnvironment) {
        boolean bl;
        this.visited = true;
        if (MixinConfig.llIlIlllII(this.env, mixinEnvironment)) {
            bl = true;
            "".length();
            if (" ".length() != " ".length()) {
                return ((0x3B ^ 0x14) & ~(0xC ^ 0x23)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    boolean isVisited() {
        return this.visited;
    }

    int getDeclaredMixinCount() {
        return MixinConfig.getCollectionSize(this.mixinClasses, this.mixinClassesClient, this.mixinClassesServer);
    }

    int getMixinCount() {
        return this.mixins.size();
    }

    public List<String> getClasses() {
        return Collections.unmodifiableList(this.mixinClasses);
    }

    public boolean shouldSetSourceFile() {
        return this.setSourceFile;
    }

    public IReferenceMapper getReferenceMapper() {
        if (MixinConfig.llIlIlllIl(this.env.getOption(MixinEnvironment$Option.DISABLE_REFMAP) ? 1 : 0)) {
            return ReferenceMapper.DEFAULT_MAPPER;
        }
        this.refMapper.setContext(this.env.getRefmapObfuscationContext());
        return this.refMapper;
    }

    String remapClassName(String string, String string2) {
        return this.getReferenceMapper().remap(string, string2);
    }

    @Override
    public IMixinConfigPlugin getPlugin() {
        return this.plugin;
    }

    @Override
    public Set<String> getTargets() {
        return Collections.unmodifiableSet(this.mixinMapping.keySet());
    }

    public Set<String> getUnhandledTargets() {
        return Collections.unmodifiableSet(this.unhandledTargets);
    }

    public Level getLoggingLevel() {
        Level level;
        if (MixinConfig.llIlIlllIl(this.verboseLogging ? 1 : 0)) {
            level = Level.INFO;
            "".length();
            if (" ".length() >= (0x50 ^ 0x54)) {
                return null;
            }
        } else {
            level = Level.DEBUG;
        }
        return level;
    }

    public boolean packageMatch(String string) {
        return string.startsWith(this.mixinPackage);
    }

    public boolean hasMixinsFor(String string) {
        return this.mixinMapping.containsKey(string);
    }

    public List<MixinInfo> getMixinsFor(String string) {
        return this.mixinsFor(string);
    }

    private List<MixinInfo> mixinsFor(String string) {
        List<MixinInfo> list = this.mixinMapping.get(string);
        if (MixinConfig.llIlIllIll(list)) {
            list = new ArrayList<MixinInfo>();
            this.mixinMapping.put(string, list);
            "".length();
        }
        return list;
    }

    public List<String> reloadMixin(String string, byte[] byArray) {
        Iterator<MixinInfo> iterator = this.mixins.iterator();
        while (MixinConfig.llIlIlllIl(iterator.hasNext() ? 1 : 0)) {
            MixinInfo mixinInfo = iterator.next();
            if (MixinConfig.llIlIlllIl(mixinInfo.getClassName().equals(string) ? 1 : 0)) {
                mixinInfo.reloadMixin(byArray);
                return mixinInfo.getTargetClasses();
            }
            "".length();
            if ("   ".length() <= "   ".length()) continue;
            return null;
        }
        return Collections.emptyList();
    }

    public String toString() {
        return this.name;
    }

    @Override
    public int compareTo(MixinConfig mixinConfig) {
        if (MixinConfig.llIlIllIll(mixinConfig)) {
            return 0;
        }
        if (MixinConfig.llIllIIlll(mixinConfig.priority, this.priority)) {
            return this.order - mixinConfig.order;
        }
        return this.priority - mixinConfig.priority;
    }

    static Config create(String string, MixinEnvironment mixinEnvironment) {
        try {
            IMixinService iMixinService = MixinService.getService();
            MixinConfig mixinConfig = (MixinConfig)new Gson().fromJson((Reader)new InputStreamReader(iMixinService.getResourceAsStream(string)), MixinConfig.class);
            if (MixinConfig.llIlIlllIl(mixinConfig.onLoad(iMixinService, string, mixinEnvironment) ? 1 : 0)) {
                return mixinConfig.getHandle();
            }
            return null;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            throw new IllegalArgumentException(String.format("The specified resource '%s' was invalid or could not be read", string), exception);
        }
    }

    private static int getCollectionSize(Collection<?> ... collectionArray) {
        int n = 0;
        Collection<?>[] collectionArray2 = collectionArray;
        int n2 = collectionArray2.length;
        int n3 = 0;
        while (MixinConfig.llIllIIIII(n3, n2)) {
            Collection<?> collection = collectionArray2[n3];
            if (MixinConfig.llIlIlllll(collection)) {
                n += collection.size();
            }
            ++n3;
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return ("  ".length() ^ (0x23 ^ 0x17)) & (0xC8 ^ 0xB2 ^ (0xC4 ^ 0x88) ^ -" ".length());
        }
        return n;
    }

    private static boolean llIllIIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean llIllIIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIlllII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIlIlllll(Object object) {
        return object != null;
    }

    private static boolean llIlIllIll(Object object) {
        return object == null;
    }

    private static boolean llIlIlllIl(int n) {
        return n != 0;
    }

    private static boolean llIlIllIlI(int n) {
        return n == 0;
    }

    private static boolean llIllIIIll(int n) {
        return n > 0;
    }
}

