/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Function
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.common.base.Function;
import org.spongepowered.asm.mixin.transformer.MixinInfo;

class MixinInfo$2
implements Function<String, String> {
    final /* synthetic */ MixinInfo this$0;

    MixinInfo$2(MixinInfo mixinInfo) {
        this.this$0 = mixinInfo;
    }

    public String apply(String string) {
        return this.this$0.getParent().remapClassName(this.this$0.getClassRef(), string);
    }
}

