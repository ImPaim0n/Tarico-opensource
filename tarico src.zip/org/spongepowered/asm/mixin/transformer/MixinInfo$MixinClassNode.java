/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.List;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinMethodNode;

class MixinInfo$MixinClassNode
extends ClassNode {
    public final List<MixinInfo$MixinMethodNode> mixinMethods;
    final /* synthetic */ MixinInfo this$0;

    public MixinInfo$MixinClassNode(MixinInfo mixinInfo, MixinInfo mixinInfo2) {
        this(mixinInfo, 327680);
    }

    public MixinInfo$MixinClassNode(MixinInfo mixinInfo, int n) {
        this.this$0 = mixinInfo;
        super(n);
        this.mixinMethods = this.methods;
    }

    public MixinInfo getMixin() {
        return this.this$0;
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode = new MixinInfo$MixinMethodNode(this.this$0, n, string, string2, string3, stringArray);
        this.methods.add(mixinInfo$MixinMethodNode);
        "".length();
        return mixinInfo$MixinMethodNode;
    }
}

