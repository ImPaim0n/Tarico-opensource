/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.lang.annotation.Annotation;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.injection.Surrogate;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;

class MixinInfo$MixinMethodNode
extends MethodNode {
    private final String originalName;
    final /* synthetic */ MixinInfo this$0;

    public MixinInfo$MixinMethodNode(MixinInfo mixinInfo, int n, String string, String string2, String string3, String[] stringArray) {
        this.this$0 = mixinInfo;
        super(327680, n, string, string2, string3, stringArray);
        this.originalName = string;
    }

    public String toString() {
        return String.format("%s%s", this.originalName, this.desc);
    }

    public String getOriginalName() {
        return this.originalName;
    }

    public boolean isInjector() {
        boolean bl;
        if (!MixinInfo$MixinMethodNode.lIIllllll(this.getInjectorAnnotation()) || MixinInfo$MixinMethodNode.lIlIIIIII(this.isSurrogate() ? 1 : 0)) {
            bl = true;
            "".length();
            if ("  ".length() >= "   ".length()) {
                return ((0xE9 ^ 0x9B ^ (7 ^ 0x35)) & (0x56 ^ 0x41 ^ (0x6D ^ 0x3A) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isSurrogate() {
        boolean bl;
        if (MixinInfo$MixinMethodNode.lIlIIIIIl(this.getVisibleAnnotation(Surrogate.class))) {
            bl = true;
            "".length();
            if (-" ".length() >= " ".length()) {
                return (" ".length() & ~" ".length()) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isSynthetic() {
        return Bytecode.hasFlag(this, 4096);
    }

    public AnnotationNode getVisibleAnnotation(Class<? extends Annotation> clazz) {
        return Annotations.getVisible(this, clazz);
    }

    public AnnotationNode getInjectorAnnotation() {
        return InjectionInfo.getInjectorAnnotation(this.this$0, this);
    }

    public IMixinInfo getOwner() {
        return this.this$0;
    }

    private static boolean lIlIIIIIl(Object object) {
        return object != null;
    }

    private static boolean lIIllllll(Object object) {
        return object == null;
    }

    private static boolean lIlIIIIII(int n) {
        return n != 0;
    }
}

