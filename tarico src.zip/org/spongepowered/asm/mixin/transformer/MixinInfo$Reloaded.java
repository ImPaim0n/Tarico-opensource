/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.HashSet;
import java.util.List;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.InterfaceInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$State;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType;
import org.spongepowered.asm.mixin.transformer.throwables.MixinReloadException;

class MixinInfo$Reloaded
extends MixinInfo$State {
    private final MixinInfo$State previous;
    final /* synthetic */ MixinInfo this$0;

    MixinInfo$Reloaded(MixinInfo mixinInfo, MixinInfo$State mixinInfo$State, byte[] byArray) {
        this.this$0 = mixinInfo;
        super(mixinInfo, byArray, mixinInfo$State.getClassInfo());
        this.previous = mixinInfo$State;
    }

    @Override
    protected void validateChanges(MixinInfo.SubType subType, List<ClassInfo> list) {
        if (MixinInfo$Reloaded.lIlIllI(this.syntheticInnerClasses.equals(this.previous.syntheticInnerClasses) ? 1 : 0)) {
            throw new MixinReloadException(this.this$0, "Cannot change inner classes");
        }
        if (MixinInfo$Reloaded.lIlIllI(this.interfaces.equals(this.previous.interfaces) ? 1 : 0)) {
            throw new MixinReloadException(this.this$0, "Cannot change interfaces");
        }
        if (MixinInfo$Reloaded.lIlIllI(new HashSet(this.softImplements).equals(new HashSet<InterfaceInfo>(this.previous.softImplements)) ? 1 : 0)) {
            throw new MixinReloadException(this.this$0, "Cannot change soft interfaces");
        }
        List<ClassInfo> list2 = this.this$0.readTargetClasses(this.classNode, true);
        if (MixinInfo$Reloaded.lIlIllI(new HashSet<ClassInfo>(list2).equals(new HashSet<ClassInfo>(list)) ? 1 : 0)) {
            throw new MixinReloadException(this.this$0, "Cannot change target classes");
        }
        int n = this.this$0.readPriority(this.classNode);
        if (MixinInfo$Reloaded.lIlIlll(n, this.this$0.getPriority())) {
            throw new MixinReloadException(this.this$0, "Cannot change mixin priority");
        }
    }

    private static boolean lIlIllI(int n) {
        return n == 0;
    }

    private static boolean lIlIlll(int n, int n2) {
        return n != n2;
    }
}

