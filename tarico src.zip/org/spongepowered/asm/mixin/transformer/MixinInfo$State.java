/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.InnerClassNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.InterfaceInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$Reloaded;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.util.Annotations;

class MixinInfo$State {
    private byte[] mixinBytes;
    private final ClassInfo classInfo;
    private boolean detachedSuper;
    private boolean unique;
    protected final Set<String> interfaces = new HashSet<String>();
    protected final List<InterfaceInfo> softImplements = new ArrayList<InterfaceInfo>();
    protected final Set<String> syntheticInnerClasses = new HashSet<String>();
    protected final Set<String> innerClasses = new HashSet<String>();
    protected MixinInfo$MixinClassNode classNode;
    final /* synthetic */ MixinInfo this$0;

    MixinInfo$State(MixinInfo mixinInfo, byte[] byArray) {
        this(mixinInfo, byArray, null);
    }

    MixinInfo$State(MixinInfo mixinInfo, byte[] byArray, ClassInfo classInfo) {
        ClassInfo classInfo2;
        this.this$0 = mixinInfo;
        this.mixinBytes = byArray;
        this.connect();
        if (MixinInfo$State.lIlIIIIIlll(classInfo)) {
            classInfo2 = classInfo;
            "".length();
            if (((0x59 ^ 0x35 ^ (0xC ^ 0x2D)) & (168 + 81 - 49 + 7 ^ 94 + 18 - 1 + 19 ^ -" ".length())) != 0) {
                throw null;
            }
        } else {
            classInfo2 = ClassInfo.fromClassNode(this.getClassNode());
        }
        this.classInfo = classInfo2;
    }

    private void connect() {
        this.classNode = this.createClassNode(0);
    }

    private void complete() {
        this.classNode = null;
    }

    ClassInfo getClassInfo() {
        return this.classInfo;
    }

    byte[] getClassBytes() {
        return this.mixinBytes;
    }

    MixinInfo$MixinClassNode getClassNode() {
        return this.classNode;
    }

    boolean isDetachedSuper() {
        return this.detachedSuper;
    }

    boolean isUnique() {
        return this.unique;
    }

    List<? extends InterfaceInfo> getSoftImplements() {
        return this.softImplements;
    }

    Set<String> getSyntheticInnerClasses() {
        return this.syntheticInnerClasses;
    }

    Set<String> getInnerClasses() {
        return this.innerClasses;
    }

    Set<String> getInterfaces() {
        return this.interfaces;
    }

    MixinInfo$MixinClassNode createClassNode(int n) {
        MixinInfo$MixinClassNode mixinInfo$MixinClassNode = new MixinInfo$MixinClassNode(this.this$0, this.this$0);
        ClassReader classReader = new ClassReader(this.mixinBytes);
        classReader.accept(mixinInfo$MixinClassNode, n);
        return mixinInfo$MixinClassNode;
    }

    void validate(MixinInfo$SubType mixinInfo$SubType, List<ClassInfo> list) {
        boolean bl;
        MixinPreProcessorStandard mixinPreProcessorStandard = mixinInfo$SubType.createPreProcessor(this.getClassNode()).prepare();
        Iterator<ClassInfo> iterator = list.iterator();
        while (MixinInfo$State.lIlIIIIlIII(iterator.hasNext() ? 1 : 0)) {
            ClassInfo classInfo = iterator.next();
            mixinPreProcessorStandard.conform(classInfo);
            "".length();
            "".length();
            if ("   ".length() > -" ".length()) continue;
            return;
        }
        mixinInfo$SubType.validate(this, list);
        this.detachedSuper = mixinInfo$SubType.isDetachedSuper();
        if (MixinInfo$State.lIlIIIIIlll(Annotations.getVisible(this.getClassNode(), Unique.class))) {
            bl = true;
            "".length();
            if ("  ".length() == 0) {
                return;
            }
        } else {
            bl = false;
        }
        this.unique = bl;
        this.validateInner();
        this.validateClassVersion();
        this.validateRemappables(list);
        this.readImplementations(mixinInfo$SubType);
        this.readInnerClasses();
        this.validateChanges(mixinInfo$SubType, list);
        this.complete();
    }

    private void validateInner() {
        if (MixinInfo$State.lIlIIIIlIIl(this.classInfo.isProbablyStatic() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.this$0, "Inner class mixin must be declared static");
        }
    }

    private void validateClassVersion() {
        if (MixinInfo$State.lIlIIIIlIlI(this.classNode.version, MixinEnvironment.getCompatibilityLevel().classVersion())) {
            String string = ".";
            MixinEnvironment$CompatibilityLevel[] mixinEnvironment$CompatibilityLevelArray = MixinEnvironment$CompatibilityLevel.values();
            int n = mixinEnvironment$CompatibilityLevelArray.length;
            int n2 = 0;
            while (MixinInfo$State.lIlIIIIlIll(n2, n)) {
                MixinEnvironment$CompatibilityLevel mixinEnvironment$CompatibilityLevel = mixinEnvironment$CompatibilityLevelArray[n2];
                if (MixinInfo$State.lIlIIIIllII(mixinEnvironment$CompatibilityLevel.classVersion(), this.classNode.version)) {
                    string = String.format(". Mixin requires compatibility level %s or above.", mixinEnvironment$CompatibilityLevel.name());
                }
                ++n2;
                "".length();
                if ("  ".length() != 0) continue;
                return;
            }
            throw new InvalidMixinException((IMixinInfo)this.this$0, String.valueOf(new StringBuilder().append("Unsupported mixin class version ").append(this.classNode.version).append(string)));
        }
    }

    private void validateRemappables(List<ClassInfo> list) {
        if (MixinInfo$State.lIlIIIIlIlI(list.size(), 1)) {
            Object object;
            Iterator iterator = this.classNode.fields.iterator();
            while (MixinInfo$State.lIlIIIIlIII(iterator.hasNext() ? 1 : 0)) {
                object = (FieldNode)iterator.next();
                this.validateRemappable(Shadow.class, ((FieldNode)object).name, Annotations.getVisible((FieldNode)object, Shadow.class));
                "".length();
                if (-" ".length() < 0) continue;
                return;
            }
            iterator = this.classNode.methods.iterator();
            while (MixinInfo$State.lIlIIIIlIII(iterator.hasNext() ? 1 : 0)) {
                object = (MethodNode)iterator.next();
                this.validateRemappable(Shadow.class, ((MethodNode)object).name, Annotations.getVisible((MethodNode)object, Shadow.class));
                AnnotationNode annotationNode = Annotations.getVisible((MethodNode)object, Overwrite.class);
                if (MixinInfo$State.lIlIIIIIlll(annotationNode) && (!MixinInfo$State.lIlIIIIlIII(((MethodNode)object).access & 8) || MixinInfo$State.lIlIIIIlIIl(((MethodNode)object).access & 1))) {
                    throw new InvalidMixinException((IMixinInfo)this.this$0, String.valueOf(new StringBuilder().append("Found @Overwrite annotation on ").append(((MethodNode)object).name).append(" in ").append(this.this$0)));
                }
                "".length();
                if (((0x33 ^ 0x78) & ~(0x54 ^ 0x1F)) != "  ".length()) continue;
                return;
            }
        }
    }

    private void validateRemappable(Class<Shadow> clazz, String string, AnnotationNode annotationNode) {
        if (MixinInfo$State.lIlIIIIIlll(annotationNode) && MixinInfo$State.lIlIIIIlIII(Annotations.getValue(annotationNode, "remap", Boolean.TRUE).booleanValue() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.this$0, String.valueOf(new StringBuilder().append("Found a remappable @").append(clazz.getSimpleName()).append(" annotation on ").append(string).append(" in ").append(this)));
        }
    }

    void readImplementations(MixinInfo$SubType mixinInfo$SubType) {
        this.interfaces.addAll(this.classNode.interfaces);
        "".length();
        this.interfaces.addAll(mixinInfo$SubType.getInterfaces());
        "".length();
        AnnotationNode annotationNode = Annotations.getInvisible(this.classNode, Implements.class);
        if (MixinInfo$State.lIlIIIIllIl(annotationNode)) {
            return;
        }
        List list = (List)Annotations.getValue(annotationNode);
        if (MixinInfo$State.lIlIIIIllIl(list)) {
            return;
        }
        Iterator iterator = list.iterator();
        while (MixinInfo$State.lIlIIIIlIII(iterator.hasNext() ? 1 : 0)) {
            AnnotationNode annotationNode2 = (AnnotationNode)iterator.next();
            InterfaceInfo interfaceInfo = InterfaceInfo.fromAnnotation(this.this$0, annotationNode2);
            this.softImplements.add(interfaceInfo);
            "".length();
            this.interfaces.add(interfaceInfo.getInternalName());
            "".length();
            if (MixinInfo$State.lIlIIIIlIIl(this instanceof MixinInfo$Reloaded)) {
                this.classInfo.addInterface(interfaceInfo.getInternalName());
            }
            "".length();
            if (null == null) continue;
            return;
        }
    }

    void readInnerClasses() {
        Iterator iterator = this.classNode.innerClasses.iterator();
        while (MixinInfo$State.lIlIIIIlIII(iterator.hasNext() ? 1 : 0)) {
            InnerClassNode innerClassNode = (InnerClassNode)iterator.next();
            ClassInfo classInfo = ClassInfo.forName(innerClassNode.name);
            if (MixinInfo$State.lIlIIIIIlll(innerClassNode.outerName) && !MixinInfo$State.lIlIIIIlIIl(innerClassNode.outerName.equals(this.classInfo.getName()) ? 1 : 0) || MixinInfo$State.lIlIIIIlIII(innerClassNode.name.startsWith(String.valueOf(new StringBuilder().append(this.classNode.name).append("$"))) ? 1 : 0)) {
                if (MixinInfo$State.lIlIIIIlIII(classInfo.isProbablyStatic() ? 1 : 0) && MixinInfo$State.lIlIIIIlIII(classInfo.isSynthetic() ? 1 : 0)) {
                    this.syntheticInnerClasses.add(innerClassNode.name);
                    "".length();
                    "".length();
                    if (-" ".length() > "  ".length()) {
                        return;
                    }
                } else {
                    this.innerClasses.add(innerClassNode.name);
                    "".length();
                }
            }
            "".length();
            if ("  ".length() >= -" ".length()) continue;
            return;
        }
    }

    protected void validateChanges(MixinInfo$SubType mixinInfo$SubType, List<ClassInfo> list) {
        mixinInfo$SubType.createPreProcessor(this.classNode).prepare();
        "".length();
    }

    private static boolean lIlIIIIllII(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIlIIIIlIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIIIlIlI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIlIIIIIlll(Object object) {
        return object != null;
    }

    private static boolean lIlIIIIllIl(Object object) {
        return object == null;
    }

    private static boolean lIlIIIIlIII(int n) {
        return n != 0;
    }

    private static boolean lIlIIIIlIIl(int n) {
        return n == 0;
    }
}

