/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$State;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorAccessor;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

class MixinInfo$SubType$Accessor
extends MixinInfo$SubType {
    private final Collection<String> interfaces = new ArrayList<String>();

    MixinInfo$SubType$Accessor(MixinInfo mixinInfo) {
        super(mixinInfo, "@Mixin", false);
        this.interfaces.add(mixinInfo.getClassRef());
        "".length();
    }

    @Override
    boolean isLoadable() {
        return true;
    }

    @Override
    Collection<String> getInterfaces() {
        return this.interfaces;
    }

    @Override
    void validateTarget(String string, ClassInfo classInfo) {
        int n = classInfo.isInterface() ? 1 : 0;
        if (MixinInfo$SubType$Accessor.llIllIIlIl(n) && MixinInfo$SubType$Accessor.llIllIIllI(MixinEnvironment.getCompatibilityLevel().supportsMethodsInInterfaces() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, "Accessor mixin targetting an interface is not supported in current enviromnment");
        }
    }

    @Override
    void validate(MixinInfo$State mixinInfo$State, List<ClassInfo> list) {
        MixinInfo$MixinClassNode mixinInfo$MixinClassNode = mixinInfo$State.getClassNode();
        if (MixinInfo$SubType$Accessor.llIllIIllI("java/lang/Object".equals(mixinInfo$MixinClassNode.superName) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Super class of ").append(this).append(" is invalid, found ").append(mixinInfo$MixinClassNode.superName.replace('/', '.'))));
        }
    }

    @Override
    MixinPreProcessorStandard createPreProcessor(MixinInfo$MixinClassNode mixinInfo$MixinClassNode) {
        return new MixinPreProcessorAccessor(this.mixin, mixinInfo$MixinClassNode);
    }

    private static boolean llIllIIlIl(int n) {
        return n != 0;
    }

    private static boolean llIllIIllI(int n) {
        return n == 0;
    }
}

