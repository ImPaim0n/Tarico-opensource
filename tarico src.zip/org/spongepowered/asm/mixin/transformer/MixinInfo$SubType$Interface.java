/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.List;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$State;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorInterface;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

class MixinInfo$SubType$Interface
extends MixinInfo$SubType {
    MixinInfo$SubType$Interface(MixinInfo mixinInfo) {
        super(mixinInfo, "@Mixin", true);
    }

    @Override
    void validate(MixinInfo$State mixinInfo$State, List<ClassInfo> list) {
        if (MixinInfo$SubType$Interface.lIIllIlIII(MixinEnvironment.getCompatibilityLevel().supportsMethodsInInterfaces() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, "Interface mixin not supported in current enviromnment");
        }
        MixinInfo$MixinClassNode mixinInfo$MixinClassNode = mixinInfo$State.getClassNode();
        if (MixinInfo$SubType$Interface.lIIllIlIII("java/lang/Object".equals(mixinInfo$MixinClassNode.superName) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Super class of ").append(this).append(" is invalid, found ").append(mixinInfo$MixinClassNode.superName.replace('/', '.'))));
        }
    }

    @Override
    MixinPreProcessorStandard createPreProcessor(MixinInfo$MixinClassNode mixinInfo$MixinClassNode) {
        return new MixinPreProcessorInterface(this.mixin, mixinInfo$MixinClassNode);
    }

    private static boolean lIIllIlIII(int n) {
        return n == 0;
    }
}

