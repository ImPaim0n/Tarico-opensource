/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Traversal;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$State;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

class MixinInfo$SubType$Standard
extends MixinInfo$SubType {
    MixinInfo$SubType$Standard(MixinInfo mixinInfo) {
        super(mixinInfo, "@Mixin", false);
    }

    @Override
    void validate(MixinInfo$State mixinInfo$State, List<ClassInfo> list) {
        MixinInfo$MixinClassNode mixinInfo$MixinClassNode = mixinInfo$State.getClassNode();
        Iterator<ClassInfo> iterator = list.iterator();
        while (MixinInfo$SubType$Standard.lIIlIIllllI(iterator.hasNext() ? 1 : 0)) {
            ClassInfo classInfo = iterator.next();
            if (MixinInfo$SubType$Standard.lIIlIIllllI(mixinInfo$MixinClassNode.superName.equals(classInfo.getSuperName()) ? 1 : 0)) {
                "".length();
                if ("   ".length() >= 0) continue;
                return;
            }
            if (MixinInfo$SubType$Standard.lIIlIIlllll(classInfo.hasSuperClass(mixinInfo$MixinClassNode.superName, ClassInfo$Traversal.SUPER) ? 1 : 0)) {
                ClassInfo classInfo2 = ClassInfo.forName(mixinInfo$MixinClassNode.superName);
                if (MixinInfo$SubType$Standard.lIIlIIllllI(classInfo2.isMixin() ? 1 : 0)) {
                    Iterator<ClassInfo> iterator2 = classInfo2.getTargets().iterator();
                    while (MixinInfo$SubType$Standard.lIIlIIllllI(iterator2.hasNext() ? 1 : 0)) {
                        ClassInfo classInfo3 = iterator2.next();
                        if (MixinInfo$SubType$Standard.lIIlIIllllI(list.contains(classInfo3) ? 1 : 0)) {
                            throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Illegal hierarchy detected. Derived mixin ").append(this).append(" targets the same class ").append(classInfo3.getClassName()).append(" as its superclass ").append(classInfo2.getClassName())));
                        }
                        "".length();
                        if (((0xFD ^ 0xA3) & ~(0x4B ^ 0x15)) >= 0) continue;
                        return;
                    }
                }
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Super class '").append(mixinInfo$MixinClassNode.superName.replace('/', '.')).append("' of ").append(this.mixin.getName()).append(" was not found in the hierarchy of target class '").append(classInfo).append("'")));
            }
            this.detached = true;
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
    }

    @Override
    MixinPreProcessorStandard createPreProcessor(MixinInfo$MixinClassNode mixinInfo$MixinClassNode) {
        return new MixinPreProcessorStandard(this.mixin, mixinInfo$MixinClassNode);
    }

    private static boolean lIIlIIllllI(int n) {
        return n != 0;
    }

    private static boolean lIIlIIlllll(int n) {
        return n == 0;
    }
}

