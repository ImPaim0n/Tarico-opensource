/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$State;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType$Accessor;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType$Interface;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType$Standard;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

abstract class MixinInfo$SubType {
    protected final MixinInfo mixin;
    protected final String annotationType;
    protected final boolean targetMustBeInterface;
    protected boolean detached;

    MixinInfo$SubType(MixinInfo mixinInfo, String string, boolean bl) {
        this.mixin = mixinInfo;
        this.annotationType = string;
        this.targetMustBeInterface = bl;
    }

    Collection<String> getInterfaces() {
        return Collections.emptyList();
    }

    boolean isDetachedSuper() {
        return this.detached;
    }

    boolean isLoadable() {
        return false;
    }

    void validateTarget(String string, ClassInfo classInfo) {
        int n = classInfo.isInterface() ? 1 : 0;
        if (MixinInfo$SubType.lIIlllIII(n, this.targetMustBeInterface ? 1 : 0)) {
            String string2;
            if (MixinInfo$SubType.lIIlllIIl(n)) {
                string2 = "";
                "".length();
                if ((0x11 ^ 0x14 ^ (0x2B ^ 0x3C) & ~(0x6D ^ 0x7A)) <= 0) {
                    return;
                }
            } else {
                string2 = "not ";
            }
            String string3 = string2;
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append(this.annotationType).append(" target type mismatch: ").append(string).append(" is ").append(string3).append("an interface in ").append(this)));
        }
    }

    abstract void validate(MixinInfo$State var1, List<ClassInfo> var2);

    abstract MixinPreProcessorStandard createPreProcessor(MixinInfo$MixinClassNode var1);

    static MixinInfo$SubType getTypeFor(MixinInfo mixinInfo) {
        if (MixinInfo$SubType.lIIlllIlI(mixinInfo.getClassInfo().isInterface() ? 1 : 0)) {
            return new MixinInfo$SubType$Standard(mixinInfo);
        }
        int n = 0;
        Iterator<ClassInfo$Method> iterator = mixinInfo.getClassInfo().getMethods().iterator();
        while (MixinInfo$SubType.lIIlllIIl(iterator.hasNext() ? 1 : 0)) {
            int n2;
            ClassInfo$Method classInfo$Method = iterator.next();
            if (MixinInfo$SubType.lIIlllIlI(classInfo$Method.isAccessor() ? 1 : 0)) {
                n2 = 1;
                "".length();
                if (" ".length() < -" ".length()) {
                    return null;
                }
            } else {
                n2 = 0;
            }
            n |= n2;
            "".length();
            if (null == null) continue;
            return null;
        }
        if (MixinInfo$SubType.lIIlllIIl(n)) {
            return new MixinInfo$SubType$Interface(mixinInfo);
        }
        return new MixinInfo$SubType$Accessor(mixinInfo);
    }

    private static boolean lIIlllIIl(int n) {
        return n != 0;
    }

    private static boolean lIIlllIlI(int n) {
        return n == 0;
    }

    private static boolean lIIlllIII(int n, int n2) {
        return n != n2;
    }
}

