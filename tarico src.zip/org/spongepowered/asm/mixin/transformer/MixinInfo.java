/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Function
 *  com.google.common.base.Functions
 *  com.google.common.collect.Lists
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.common.base.Function;
import com.google.common.base.Functions;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.extensibility.IMixinConfig;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.InterfaceInfo;
import org.spongepowered.asm.mixin.transformer.MixinConfig;
import org.spongepowered.asm.mixin.transformer.MixinInfo$1;
import org.spongepowered.asm.mixin.transformer.MixinInfo$2;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$Reloaded;
import org.spongepowered.asm.mixin.transformer.MixinInfo$State;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType;
import org.spongepowered.asm.mixin.transformer.MixinInfo$SubType$Accessor;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.TargetClassContext;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.mixin.transformer.throwables.MixinTargetAlreadyLoadedException;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.MixinService;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;

class MixinInfo
implements Comparable<MixinInfo>,
IMixinInfo {
    private static final IMixinService classLoaderUtil = MixinService.getService();
    static int mixinOrder = 0;
    private final transient Logger logger = LogManager.getLogger((String)"mixin");
    private final transient Profiler profiler = MixinEnvironment.getProfiler();
    private final transient MixinConfig parent;
    private final String name;
    private final String className;
    private final int priority;
    private final boolean virtual;
    private final List<ClassInfo> targetClasses;
    private final List<String> targetClassNames;
    private final transient int order = mixinOrder++;
    private final transient IMixinService service;
    private final transient IMixinConfigPlugin plugin;
    private final transient MixinEnvironment$Phase phase;
    private final transient ClassInfo info;
    private final transient MixinInfo$SubType type;
    private final transient boolean strict;
    private transient MixinInfo$State pendingState;
    private transient MixinInfo$State state;

    MixinInfo(IMixinService iMixinService, MixinConfig mixinConfig, String string, boolean bl, IMixinConfigPlugin iMixinConfigPlugin, boolean bl2) {
        this.service = iMixinService;
        this.parent = mixinConfig;
        this.name = string;
        this.className = String.valueOf(new StringBuilder().append(mixinConfig.getMixinPackage()).append(string));
        this.plugin = iMixinConfigPlugin;
        this.phase = mixinConfig.getEnvironment().getPhase();
        this.strict = mixinConfig.getEnvironment().getOption(MixinEnvironment$Option.DEBUG_TARGETS);
        try {
            byte[] byArray = this.loadMixinClass(this.className, bl);
            this.pendingState = new MixinInfo$State(this, byArray);
            this.info = this.pendingState.getClassInfo();
            this.type = MixinInfo$SubType.getTypeFor(this);
        }
        catch (InvalidMixinException invalidMixinException) {
            throw invalidMixinException;
        }
        catch (Exception exception) {
            throw new InvalidMixinException((IMixinInfo)this, (Throwable)exception);
        }
        "".length();
        if (" ".length() == 0) {
            throw null;
        }
        if (MixinInfo.llIllIlllII(this.type.isLoadable() ? 1 : 0)) {
            classLoaderUtil.registerInvalidClass(this.className);
        }
        try {
            this.priority = this.readPriority(this.pendingState.getClassNode());
            this.virtual = this.readPseudo(this.pendingState.getClassNode());
            this.targetClasses = this.readTargetClasses(this.pendingState.getClassNode(), bl2);
            this.targetClassNames = Collections.unmodifiableList(Lists.transform(this.targetClasses, (Function)Functions.toStringFunction()));
        }
        catch (InvalidMixinException invalidMixinException) {
            throw invalidMixinException;
        }
        catch (Exception exception) {
            throw new InvalidMixinException((IMixinInfo)this, (Throwable)exception);
        }
        "".length();
        if (" ".length() <= ((0x2F ^ 0x6D ^ (0x14 ^ 0x52)) & (0x26 ^ 3 ^ (0x3E ^ 0x1F) ^ -" ".length()))) {
            throw null;
        }
    }

    void validate() {
        block5: {
            if (MixinInfo.llIllIlllIl(this.pendingState)) {
                throw new IllegalStateException(String.valueOf(new StringBuilder().append("No pending validation state for ").append(this)));
            }
            this.pendingState.validate(this.type, this.targetClasses);
            this.state = this.pendingState;
            "".length();
            if (" ".length() > "   ".length()) {
                return;
            }
            break block5;
            finally {
                this.pendingState = null;
            }
        }
    }

    protected List<ClassInfo> readTargetClasses(MixinInfo$MixinClassNode mixinInfo$MixinClassNode, boolean bl) {
        if (MixinInfo.llIllIlllIl(mixinInfo$MixinClassNode)) {
            return Collections.emptyList();
        }
        AnnotationNode annotationNode = Annotations.getInvisible(mixinInfo$MixinClassNode, Mixin.class);
        if (MixinInfo.llIllIlllIl(annotationNode)) {
            throw new InvalidMixinException((IMixinInfo)this, String.format("The mixin '%s' is missing an @Mixin annotation", this.className));
        }
        ArrayList<ClassInfo> arrayList = new ArrayList<ClassInfo>();
        List list = (List)Annotations.getValue(annotationNode, "value");
        List list2 = (List)Annotations.getValue(annotationNode, "targets");
        if (MixinInfo.llIllIllllI(list)) {
            this.readTargets(arrayList, Lists.transform((List)list, (Function)new MixinInfo$1(this)), bl, false);
        }
        if (MixinInfo.llIllIllllI(list2)) {
            this.readTargets(arrayList, Lists.transform((List)list2, (Function)new MixinInfo$2(this)), bl, true);
        }
        return arrayList;
    }

    private void readTargets(Collection<ClassInfo> collection, Collection<String> collection2, boolean bl, boolean bl2) {
        Iterator<String> iterator = collection2.iterator();
        while (MixinInfo.llIllIlllll(iterator.hasNext() ? 1 : 0)) {
            Object object;
            String string = iterator.next();
            String string2 = string.replace('/', '.');
            if (MixinInfo.llIllIlllll(classLoaderUtil.isClassLoaded(string2) ? 1 : 0) && MixinInfo.llIllIlllII(this.isReloading() ? 1 : 0)) {
                object = String.format("Critical problem: %s target %s was already transformed.", this, string2);
                if (MixinInfo.llIllIlllll(this.parent.isRequired() ? 1 : 0)) {
                    throw new MixinTargetAlreadyLoadedException((IMixinInfo)this, (String)object, string2);
                }
                this.logger.error((String)object);
            }
            if (MixinInfo.llIllIlllll(this.shouldApplyMixin(bl, string2) ? 1 : 0) && MixinInfo.llIllIllllI(object = this.getTarget(string2, bl2)) && MixinInfo.llIllIlllII(collection.contains(object) ? 1 : 0)) {
                collection.add((ClassInfo)object);
                "".length();
                ((ClassInfo)object).addMixin(this);
            }
            "".length();
            if (((0x1C ^ 0x15) & ~(0xCA ^ 0xC3)) == 0) continue;
            return;
        }
    }

    private boolean shouldApplyMixin(boolean bl, String string) {
        boolean bl2;
        Profiler$Section profiler$Section = this.profiler.begin("plugin");
        if (!MixinInfo.llIllIllllI(this.plugin) || !MixinInfo.llIllIlllII(bl ? 1 : 0) || MixinInfo.llIllIlllll(this.plugin.shouldApplyMixin(string, this.className) ? 1 : 0)) {
            bl2 = true;
            "".length();
            if (-" ".length() >= ((0x72 ^ 0x66 ^ (0xF8 ^ 0xC4)) & (0xE ^ 0x78 ^ (0xDF ^ 0x81) ^ -" ".length()))) {
                return ((0x41 ^ 0x1C ^ (0x5E ^ 0x1F)) & (0xF5 ^ 0x82 ^ (0x14 ^ 0x7F) ^ -" ".length())) != 0;
            }
        } else {
            bl2 = false;
        }
        boolean bl3 = bl2;
        profiler$Section.end();
        "".length();
        return bl3;
    }

    private ClassInfo getTarget(String string, boolean bl) {
        ClassInfo classInfo = ClassInfo.forName(string);
        if (MixinInfo.llIllIlllIl(classInfo)) {
            if (MixinInfo.llIllIlllll(this.isVirtual() ? 1 : 0)) {
                this.logger.debug("Skipping virtual target {} for {}", new Object[]{string, this});
                "".length();
                if ((0x4F ^ 0x4B) < " ".length()) {
                    return null;
                }
            } else {
                this.handleTargetError(String.format("@Mixin target %s was not found %s", string, this));
            }
            return null;
        }
        this.type.validateTarget(string, classInfo);
        if (MixinInfo.llIllIlllll(bl ? 1 : 0) && MixinInfo.llIllIlllll(classInfo.isPublic() ? 1 : 0) && MixinInfo.llIllIlllII(this.isVirtual() ? 1 : 0)) {
            this.handleTargetError(String.format("@Mixin target %s is public in %s and should be specified in value", string, this));
        }
        return classInfo;
    }

    private void handleTargetError(String string) {
        if (MixinInfo.llIllIlllll(this.strict ? 1 : 0)) {
            this.logger.error(string);
            throw new InvalidMixinException((IMixinInfo)this, string);
        }
        this.logger.warn(string);
    }

    protected int readPriority(ClassNode classNode) {
        int n;
        if (MixinInfo.llIllIlllIl(classNode)) {
            return this.parent.getDefaultMixinPriority();
        }
        AnnotationNode annotationNode = Annotations.getInvisible(classNode, Mixin.class);
        if (MixinInfo.llIllIlllIl(annotationNode)) {
            throw new InvalidMixinException((IMixinInfo)this, String.format("The mixin '%s' is missing an @Mixin annotation", this.className));
        }
        Integer n2 = (Integer)Annotations.getValue(annotationNode, "priority");
        if (MixinInfo.llIllIlllIl(n2)) {
            n = this.parent.getDefaultMixinPriority();
            "".length();
            if ("   ".length() == ((0x20 ^ 0xA) & ~(0xAE ^ 0x84))) {
                return "   ".length() & ~"   ".length();
            }
        } else {
            n = n2;
        }
        return n;
    }

    protected boolean readPseudo(ClassNode classNode) {
        boolean bl;
        if (MixinInfo.llIllIllllI(Annotations.getInvisible(classNode, Pseudo.class))) {
            bl = true;
            "".length();
            if ((0x42 ^ 0x46) == 0) {
                return ((0x27 ^ 5) & ~(0x86 ^ 0xA4)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private boolean isReloading() {
        return this.pendingState instanceof MixinInfo$Reloaded;
    }

    private MixinInfo$State getState() {
        MixinInfo$State mixinInfo$State;
        if (MixinInfo.llIllIllllI(this.state)) {
            mixinInfo$State = this.state;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            mixinInfo$State = this.pendingState;
        }
        return mixinInfo$State;
    }

    ClassInfo getClassInfo() {
        return this.info;
    }

    @Override
    public IMixinConfig getConfig() {
        return this.parent;
    }

    MixinConfig getParent() {
        return this.parent;
    }

    @Override
    public int getPriority() {
        return this.priority;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getClassName() {
        return this.className;
    }

    @Override
    public String getClassRef() {
        return this.getClassInfo().getName();
    }

    @Override
    public byte[] getClassBytes() {
        return this.getState().getClassBytes();
    }

    @Override
    public boolean isDetachedSuper() {
        return this.getState().isDetachedSuper();
    }

    public boolean isUnique() {
        return this.getState().isUnique();
    }

    public boolean isVirtual() {
        return this.virtual;
    }

    public boolean isAccessor() {
        return this.type instanceof MixinInfo$SubType$Accessor;
    }

    public boolean isLoadable() {
        return this.type.isLoadable();
    }

    public Level getLoggingLevel() {
        return this.parent.getLoggingLevel();
    }

    @Override
    public MixinEnvironment$Phase getPhase() {
        return this.phase;
    }

    @Override
    public MixinInfo$MixinClassNode getClassNode(int n) {
        return this.getState().createClassNode(n);
    }

    @Override
    public List<String> getTargetClasses() {
        return this.targetClassNames;
    }

    List<InterfaceInfo> getSoftImplements() {
        return Collections.unmodifiableList(this.getState().getSoftImplements());
    }

    Set<String> getSyntheticInnerClasses() {
        return Collections.unmodifiableSet(this.getState().getSyntheticInnerClasses());
    }

    Set<String> getInnerClasses() {
        return Collections.unmodifiableSet(this.getState().getInnerClasses());
    }

    List<ClassInfo> getTargets() {
        return Collections.unmodifiableList(this.targetClasses);
    }

    Set<String> getInterfaces() {
        return this.getState().getInterfaces();
    }

    MixinTargetContext createContextFor(TargetClassContext targetClassContext) {
        MixinInfo$MixinClassNode mixinInfo$MixinClassNode = this.getClassNode(8);
        Profiler$Section profiler$Section = this.profiler.begin("pre");
        MixinTargetContext mixinTargetContext = this.type.createPreProcessor(mixinInfo$MixinClassNode).prepare().createContextFor(targetClassContext);
        profiler$Section.end();
        "".length();
        return mixinTargetContext;
    }

    private byte[] loadMixinClass(String string, boolean bl) {
        byte[] byArray = null;
        try {
            String string2;
            if (MixinInfo.llIllIlllll(bl ? 1 : 0) && MixinInfo.llIlllIIIII((string2 = this.service.getClassRestrictions(string)).length())) {
                this.logger.error("Classloader restrictions [{}] encountered loading {}, name: {}", new Object[]{string2, this, string});
            }
            byArray = this.service.getBytecodeProvider().getClassBytes(string, bl);
            "".length();
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new ClassNotFoundException(String.format("The specified mixin '%s' was not found", string));
        }
        catch (IOException iOException) {
            this.logger.warn("Failed to load mixin {}, the specified mixin will not be applied", new Object[]{string});
            throw new InvalidMixinException(this, "An error was encountered whilst loading the mixin class", (Throwable)iOException);
        }
        if ((0x77 ^ 0x73) != (0x43 ^ 0x47)) {
            return null;
        }
        return byArray;
    }

    void reloadMixin(byte[] byArray) {
        if (MixinInfo.llIllIllllI(this.pendingState)) {
            throw new IllegalStateException("Cannot reload mixin while it is initialising");
        }
        this.pendingState = new MixinInfo$Reloaded(this, this.state, byArray);
        this.validate();
    }

    @Override
    public int compareTo(MixinInfo mixinInfo) {
        if (MixinInfo.llIllIlllIl(mixinInfo)) {
            return 0;
        }
        if (MixinInfo.llIlllIIIIl(mixinInfo.priority, this.priority)) {
            return this.order - mixinInfo.order;
        }
        return this.priority - mixinInfo.priority;
    }

    public void preApply(String string, ClassNode classNode) {
        if (MixinInfo.llIllIllllI(this.plugin)) {
            Profiler$Section profiler$Section = this.profiler.begin("plugin");
            this.plugin.preApply(string, classNode, this.className, this);
            profiler$Section.end();
            "".length();
        }
    }

    public void postApply(String string, ClassNode classNode) {
        if (MixinInfo.llIllIllllI(this.plugin)) {
            Profiler$Section profiler$Section = this.profiler.begin("plugin");
            this.plugin.postApply(string, classNode, this.className, this);
            profiler$Section.end();
            "".length();
        }
        this.parent.postApply(string, classNode);
    }

    public String toString() {
        return String.format("%s:%s", this.parent.getName(), this.name);
    }

    private static boolean llIlllIIIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean llIllIllllI(Object object) {
        return object != null;
    }

    private static boolean llIllIlllIl(Object object) {
        return object == null;
    }

    private static boolean llIllIlllll(int n) {
        return n != 0;
    }

    private static boolean llIllIlllII(int n) {
        return n == 0;
    }

    private static boolean llIlllIIIII(int n) {
        return n > 0;
    }
}

