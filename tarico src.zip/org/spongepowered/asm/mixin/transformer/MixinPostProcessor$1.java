/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.lib.ClassVisitor;
import org.spongepowered.asm.lib.FieldVisitor;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.mixin.transformer.MixinPostProcessor;

class MixinPostProcessor$1
extends ClassVisitor {
    final /* synthetic */ MixinPostProcessor this$0;

    MixinPostProcessor$1(MixinPostProcessor mixinPostProcessor, int n, ClassVisitor classVisitor) {
        this.this$0 = mixinPostProcessor;
        super(n, classVisitor);
    }

    @Override
    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
        super.visit(n, n2 | 1, string, string2, string3, stringArray);
    }

    @Override
    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
        if (MixinPostProcessor$1.lllIIlIlIII(n & 6)) {
            n |= 1;
        }
        return super.visitField(n, string, string2, string3, object);
    }

    @Override
    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
        if (MixinPostProcessor$1.lllIIlIlIII(n & 6)) {
            n |= 1;
        }
        return super.visitMethod(n, string, string2, string3, stringArray);
    }

    private static boolean lllIIlIlIII(int n) {
        return n == 0;
    }
}

