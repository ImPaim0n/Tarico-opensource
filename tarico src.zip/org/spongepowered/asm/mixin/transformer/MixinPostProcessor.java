/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.InsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.MixinConfig$IListener;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinMethodNode;
import org.spongepowered.asm.mixin.transformer.MixinPostProcessor$1;
import org.spongepowered.asm.mixin.transformer.throwables.MixinTransformerError;
import org.spongepowered.asm.transformers.MixinClassWriter;
import org.spongepowered.asm.transformers.TreeTransformer;
import org.spongepowered.asm.util.Bytecode;

class MixinPostProcessor
extends TreeTransformer
implements MixinConfig$IListener {
    private final Set<String> syntheticInnerClasses = new HashSet<String>();
    private final Map<String, MixinInfo> accessorMixins = new HashMap<String, MixinInfo>();
    private final Set<String> loadable = new HashSet<String>();

    MixinPostProcessor() {
    }

    @Override
    public void onInit(MixinInfo mixinInfo) {
        Iterator<String> iterator = mixinInfo.getSyntheticInnerClasses().iterator();
        while (MixinPostProcessor.llIlIIlllII(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            this.registerSyntheticInner(string.replace('/', '.'));
            "".length();
            if ((0xE7 ^ 0xB7 ^ (0x3B ^ 0x6F)) >= ((0x7C ^ 0x5E ^ (0x7C ^ 0x54)) & (0x80 ^ 0xA9 ^ (0xBE ^ 0x9D) ^ -" ".length()) & ((0x69 ^ 0x46 ^ (6 ^ 0xC)) & (0x5E ^ 0x2A ^ (0x1E ^ 0x4F) ^ -" ".length()) ^ -" ".length()))) continue;
            return;
        }
    }

    @Override
    public void onPrepare(MixinInfo mixinInfo) {
        String string = mixinInfo.getClassName();
        if (MixinPostProcessor.llIlIIlllII(mixinInfo.isLoadable() ? 1 : 0)) {
            this.registerLoadable(string);
        }
        if (MixinPostProcessor.llIlIIlllII(mixinInfo.isAccessor() ? 1 : 0)) {
            this.registerAccessor(mixinInfo);
        }
    }

    void registerSyntheticInner(String string) {
        this.syntheticInnerClasses.add(string);
        "".length();
    }

    void registerLoadable(String string) {
        this.loadable.add(string);
        "".length();
    }

    void registerAccessor(MixinInfo mixinInfo) {
        this.registerLoadable(mixinInfo.getClassName());
        this.accessorMixins.put(mixinInfo.getClassName(), mixinInfo);
        "".length();
    }

    boolean canTransform(String string) {
        boolean bl;
        if (!MixinPostProcessor.llIlIIlllIl(this.syntheticInnerClasses.contains(string) ? 1 : 0) || MixinPostProcessor.llIlIIlllII(this.loadable.contains(string) ? 1 : 0)) {
            bl = true;
            "".length();
            if (-" ".length() > "   ".length()) {
                return ((0x83 ^ 0xAF ^ (0x47 ^ 0x20)) & (0x22 ^ 9 ^ (0xDD ^ 0xBD) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public String getName() {
        return this.getClass().getName();
    }

    @Override
    public boolean isDelegationExcluded() {
        return true;
    }

    @Override
    public byte[] transformClassBytes(String string, String string2, byte[] byArray) {
        if (MixinPostProcessor.llIlIIlllII(this.syntheticInnerClasses.contains(string2) ? 1 : 0)) {
            return this.processSyntheticInner(byArray);
        }
        if (MixinPostProcessor.llIlIIlllII(this.accessorMixins.containsKey(string2) ? 1 : 0)) {
            MixinInfo mixinInfo = this.accessorMixins.get(string2);
            return this.processAccessor(byArray, mixinInfo);
        }
        return byArray;
    }

    private byte[] processSyntheticInner(byte[] byArray) {
        ClassReader classReader = new ClassReader(byArray);
        MixinClassWriter mixinClassWriter = new MixinClassWriter(classReader, 0);
        MixinPostProcessor$1 mixinPostProcessor$1 = new MixinPostProcessor$1(this, 327680, mixinClassWriter);
        classReader.accept(mixinPostProcessor$1, 8);
        return mixinClassWriter.toByteArray();
    }

    private byte[] processAccessor(byte[] byArray, MixinInfo mixinInfo) {
        if (MixinPostProcessor.llIlIIlllIl(MixinEnvironment.getCompatibilityLevel().isAtLeast(MixinEnvironment$CompatibilityLevel.JAVA_8) ? 1 : 0)) {
            return byArray;
        }
        int n = 0;
        MixinInfo$MixinClassNode mixinInfo$MixinClassNode = mixinInfo.getClassNode(0);
        ClassInfo classInfo = mixinInfo.getTargets().get(0);
        Iterator<MixinInfo$MixinMethodNode> iterator = mixinInfo$MixinClassNode.mixinMethods.iterator();
        while (MixinPostProcessor.llIlIIlllII(iterator.hasNext() ? 1 : 0)) {
            MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode = iterator.next();
            if (MixinPostProcessor.llIlIIlllIl(Bytecode.hasFlag(mixinInfo$MixinMethodNode, 8) ? 1 : 0)) {
                "".length();
                if (null == null) continue;
                return null;
            }
            AnnotationNode annotationNode = mixinInfo$MixinMethodNode.getVisibleAnnotation(Accessor.class);
            AnnotationNode annotationNode2 = mixinInfo$MixinMethodNode.getVisibleAnnotation(Invoker.class);
            if (!MixinPostProcessor.llIlIIllllI(annotationNode) || MixinPostProcessor.llIlIIlllll(annotationNode2)) {
                ClassInfo$Method classInfo$Method = MixinPostProcessor.getAccessorMethod(mixinInfo, mixinInfo$MixinMethodNode, classInfo);
                MixinPostProcessor.createProxy(mixinInfo$MixinMethodNode, classInfo, classInfo$Method);
                n = 1;
            }
            "".length();
            if ("  ".length() < "   ".length()) continue;
            return null;
        }
        if (MixinPostProcessor.llIlIIlllII(n)) {
            return this.writeClass(mixinInfo$MixinClassNode);
        }
        return byArray;
    }

    private static ClassInfo$Method getAccessorMethod(MixinInfo mixinInfo, MethodNode methodNode, ClassInfo classInfo) {
        ClassInfo$Method classInfo$Method = mixinInfo.getClassInfo().findMethod(methodNode, 10);
        if (MixinPostProcessor.llIlIIlllIl(classInfo$Method.isRenamed() ? 1 : 0)) {
            throw new MixinTransformerError(String.valueOf(new StringBuilder().append("Unexpected state: ").append(mixinInfo).append(" loaded before ").append(classInfo).append(" was conformed")));
        }
        return classInfo$Method;
    }

    private static void createProxy(MethodNode methodNode, ClassInfo classInfo, ClassInfo$Method classInfo$Method) {
        methodNode.instructions.clear();
        Type[] typeArray = Type.getArgumentTypes(methodNode.desc);
        Type type = Type.getReturnType(methodNode.desc);
        Bytecode.loadArgs(typeArray, methodNode.instructions, 0);
        methodNode.instructions.add(new MethodInsnNode(184, classInfo.getName(), classInfo$Method.getName(), methodNode.desc, false));
        methodNode.instructions.add(new InsnNode(type.getOpcode(172)));
        methodNode.maxStack = Bytecode.getFirstNonArgLocalIndex(typeArray, false);
        methodNode.maxLocals = 0;
    }

    private static boolean llIlIIlllll(Object object) {
        return object != null;
    }

    private static boolean llIlIIllllI(Object object) {
        return object == null;
    }

    private static boolean llIlIIlllII(int n) {
        return n != 0;
    }

    private static boolean llIlIIlllIl(int n) {
        return n == 0;
    }
}

