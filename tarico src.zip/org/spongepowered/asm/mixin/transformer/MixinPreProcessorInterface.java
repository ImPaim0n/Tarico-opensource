/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinMethodNode;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidInterfaceMixinException;
import org.spongepowered.asm.util.Bytecode;

class MixinPreProcessorInterface
extends MixinPreProcessorStandard {
    MixinPreProcessorInterface(MixinInfo mixinInfo, MixinInfo$MixinClassNode mixinInfo$MixinClassNode) {
        super(mixinInfo, mixinInfo$MixinClassNode);
    }

    @Override
    protected void prepareMethod(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, ClassInfo$Method classInfo$Method) {
        if (MixinPreProcessorInterface.lIIllIlIIII(Bytecode.hasFlag(mixinInfo$MixinMethodNode, 1) ? 1 : 0) && MixinPreProcessorInterface.lIIllIlIIII(Bytecode.hasFlag(mixinInfo$MixinMethodNode, 4096) ? 1 : 0)) {
            throw new InvalidInterfaceMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Interface mixin contains a non-public method! Found ").append(classInfo$Method).append(" in ").append(this.mixin)));
        }
        super.prepareMethod(mixinInfo$MixinMethodNode, classInfo$Method);
    }

    @Override
    protected boolean validateField(MixinTargetContext mixinTargetContext, FieldNode fieldNode, AnnotationNode annotationNode) {
        if (MixinPreProcessorInterface.lIIllIlIIII(Bytecode.hasFlag(fieldNode, 8) ? 1 : 0)) {
            throw new InvalidInterfaceMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Interface mixin contains an instance field! Found ").append(fieldNode.name).append(" in ").append(this.mixin)));
        }
        return super.validateField(mixinTargetContext, fieldNode, annotationNode);
    }

    private static boolean lIIllIlIIII(int n) {
        return n == 0;
    }
}

