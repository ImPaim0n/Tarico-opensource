/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import com.google.common.base.Strings;
import java.util.Iterator;
import java.util.ListIterator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$CompatibilityLevel;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.gen.throwables.InvalidAccessorException;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Field;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.mixin.transformer.ClassInfo$SearchType;
import org.spongepowered.asm.mixin.transformer.InterfaceInfo;
import org.spongepowered.asm.mixin.transformer.MethodMapper;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinClassNode;
import org.spongepowered.asm.mixin.transformer.MixinInfo$MixinMethodNode;
import org.spongepowered.asm.mixin.transformer.MixinPreProcessorStandard$SpecialMethod;
import org.spongepowered.asm.mixin.transformer.MixinTargetContext;
import org.spongepowered.asm.mixin.transformer.TargetClassContext;
import org.spongepowered.asm.mixin.transformer.meta.MixinRenamed;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.Bytecode$Visibility;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;
import org.spongepowered.asm.util.throwables.SyntheticBridgeException;

class MixinPreProcessorStandard {
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    protected final MixinInfo mixin;
    protected final MixinInfo$MixinClassNode classNode;
    protected final MixinEnvironment env;
    protected final Profiler profiler = MixinEnvironment.getProfiler();
    private final boolean verboseLogging;
    private final boolean strictUnique;
    private boolean prepared;
    private boolean attached;

    MixinPreProcessorStandard(MixinInfo mixinInfo, MixinInfo$MixinClassNode mixinInfo$MixinClassNode) {
        this.mixin = mixinInfo;
        this.classNode = mixinInfo$MixinClassNode;
        this.env = mixinInfo.getParent().getEnvironment();
        this.verboseLogging = this.env.getOption(MixinEnvironment$Option.DEBUG_VERBOSE);
        this.strictUnique = this.env.getOption(MixinEnvironment$Option.DEBUG_UNIQUE);
    }

    final MixinPreProcessorStandard prepare() {
        Object object;
        if (MixinPreProcessorStandard.lIIIlllIII(this.prepared ? 1 : 0)) {
            return this;
        }
        this.prepared = true;
        Profiler$Section profiler$Section = this.profiler.begin("prepare");
        Iterator<MixinInfo$MixinMethodNode> iterator = this.classNode.mixinMethods.iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            object = iterator.next();
            ClassInfo$Method classInfo$Method = this.mixin.getClassInfo().findMethod((MethodNode)object);
            this.prepareMethod((MixinInfo$MixinMethodNode)object, classInfo$Method);
            "".length();
            if ("  ".length() > " ".length()) continue;
            return null;
        }
        iterator = this.classNode.fields.iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            object = (FieldNode)((Object)iterator.next());
            this.prepareField((FieldNode)object);
            "".length();
            if (null == null) continue;
            return null;
        }
        profiler$Section.end();
        "".length();
        return this;
    }

    protected void prepareMethod(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, ClassInfo$Method classInfo$Method) {
        this.prepareShadow(mixinInfo$MixinMethodNode, classInfo$Method);
        this.prepareSoftImplements(mixinInfo$MixinMethodNode, classInfo$Method);
    }

    protected void prepareShadow(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, ClassInfo$Method classInfo$Method) {
        AnnotationNode annotationNode = Annotations.getVisible(mixinInfo$MixinMethodNode, Shadow.class);
        if (MixinPreProcessorStandard.lIIIlllIIl(annotationNode)) {
            return;
        }
        String string = (String)Annotations.getValue(annotationNode, "prefix", Shadow.class);
        if (MixinPreProcessorStandard.lIIIlllIII(mixinInfo$MixinMethodNode.name.startsWith(string) ? 1 : 0)) {
            Annotations.setVisible(mixinInfo$MixinMethodNode, MixinRenamed.class, "originalName", mixinInfo$MixinMethodNode.name);
            String string2 = mixinInfo$MixinMethodNode.name.substring(string.length());
            mixinInfo$MixinMethodNode.name = classInfo$Method.renameTo(string2);
        }
    }

    protected void prepareSoftImplements(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, ClassInfo$Method classInfo$Method) {
        Iterator<InterfaceInfo> iterator = this.mixin.getSoftImplements().iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            InterfaceInfo interfaceInfo = iterator.next();
            if (MixinPreProcessorStandard.lIIIlllIII(interfaceInfo.renameMethod(mixinInfo$MixinMethodNode) ? 1 : 0)) {
                classInfo$Method.renameTo(mixinInfo$MixinMethodNode.name);
                "".length();
            }
            "".length();
            if (" ".length() >= 0) continue;
            return;
        }
    }

    protected void prepareField(FieldNode fieldNode) {
    }

    final MixinPreProcessorStandard conform(TargetClassContext targetClassContext) {
        return this.conform(targetClassContext.getClassInfo());
    }

    final MixinPreProcessorStandard conform(ClassInfo classInfo) {
        Profiler$Section profiler$Section = this.profiler.begin("conform");
        Iterator<MixinInfo$MixinMethodNode> iterator = this.classNode.mixinMethods.iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode = iterator.next();
            if (MixinPreProcessorStandard.lIIIlllIII(mixinInfo$MixinMethodNode.isInjector() ? 1 : 0)) {
                ClassInfo$Method classInfo$Method = this.mixin.getClassInfo().findMethod(mixinInfo$MixinMethodNode, 10);
                this.conformInjector(classInfo, mixinInfo$MixinMethodNode, classInfo$Method);
            }
            "".length();
            if ((128 + 111 - 153 + 54 ^ 106 + 104 - 155 + 81) == (15 + 121 - 14 + 36 ^ 135 + 50 - 183 + 152)) continue;
            return null;
        }
        profiler$Section.end();
        "".length();
        return this;
    }

    private void conformInjector(ClassInfo classInfo, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, ClassInfo$Method classInfo$Method) {
        MethodMapper methodMapper = classInfo.getMethodMapper();
        methodMapper.remapHandlerMethod(this.mixin, mixinInfo$MixinMethodNode, classInfo$Method);
    }

    MixinTargetContext createContextFor(TargetClassContext targetClassContext) {
        MixinTargetContext mixinTargetContext = new MixinTargetContext(this.mixin, this.classNode, targetClassContext);
        this.conform(targetClassContext);
        "".length();
        this.attach(mixinTargetContext);
        "".length();
        return mixinTargetContext;
    }

    final MixinPreProcessorStandard attach(MixinTargetContext mixinTargetContext) {
        if (MixinPreProcessorStandard.lIIIlllIII(this.attached ? 1 : 0)) {
            throw new IllegalStateException("Preprocessor was already attached");
        }
        this.attached = true;
        Profiler$Section profiler$Section = this.profiler.begin("attach");
        Profiler$Section profiler$Section2 = this.profiler.begin("methods");
        this.attachMethods(mixinTargetContext);
        profiler$Section2 = profiler$Section2.next("fields");
        this.attachFields(mixinTargetContext);
        profiler$Section2 = profiler$Section2.next("transform");
        this.transform(mixinTargetContext);
        profiler$Section2.end();
        "".length();
        profiler$Section.end();
        "".length();
        return this;
    }

    protected void attachMethods(MixinTargetContext mixinTargetContext) {
        Iterator<MixinInfo$MixinMethodNode> iterator = this.classNode.mixinMethods.iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode = iterator.next();
            if (MixinPreProcessorStandard.lIIIlllIlI(this.validateMethod(mixinTargetContext, mixinInfo$MixinMethodNode) ? 1 : 0)) {
                iterator.remove();
                "".length();
                if ((53 + 82 - 21 + 41 ^ 128 + 32 - 51 + 50) >= "  ".length()) continue;
                return;
            }
            if (MixinPreProcessorStandard.lIIIlllIII(this.attachInjectorMethod(mixinTargetContext, mixinInfo$MixinMethodNode) ? 1 : 0)) {
                mixinTargetContext.addMixinMethod(mixinInfo$MixinMethodNode);
                "".length();
                if (((0x39 ^ 0x68) & ~(0x33 ^ 0x62)) < "  ".length()) continue;
                return;
            }
            if (MixinPreProcessorStandard.lIIIlllIII(this.attachAccessorMethod(mixinTargetContext, mixinInfo$MixinMethodNode) ? 1 : 0)) {
                iterator.remove();
                "".length();
                if ("   ".length() >= ((0x1F ^ 8) & ~(0x19 ^ 0xE))) continue;
                return;
            }
            if (MixinPreProcessorStandard.lIIIlllIII(this.attachShadowMethod(mixinTargetContext, mixinInfo$MixinMethodNode) ? 1 : 0)) {
                mixinTargetContext.addShadowMethod(mixinInfo$MixinMethodNode);
                iterator.remove();
                "".length();
                if ("   ".length() == "   ".length()) continue;
                return;
            }
            if (MixinPreProcessorStandard.lIIIlllIII(this.attachOverwriteMethod(mixinTargetContext, mixinInfo$MixinMethodNode) ? 1 : 0)) {
                mixinTargetContext.addMixinMethod(mixinInfo$MixinMethodNode);
                "".length();
                if (-(0x93 ^ 0x97) <= 0) continue;
                return;
            }
            if (MixinPreProcessorStandard.lIIIlllIII(this.attachUniqueMethod(mixinTargetContext, mixinInfo$MixinMethodNode) ? 1 : 0)) {
                iterator.remove();
                "".length();
                if (null == null) continue;
                return;
            }
            this.attachMethod(mixinTargetContext, mixinInfo$MixinMethodNode);
            mixinTargetContext.addMixinMethod(mixinInfo$MixinMethodNode);
            "".length();
            if (((0x45 ^ 0x63 ^ (0xB0 ^ 0xBA)) & (0x58 ^ 0x26 ^ (0x5F ^ 0xD) ^ -" ".length())) <= 0) continue;
            return;
        }
    }

    protected boolean validateMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        return true;
    }

    protected boolean attachInjectorMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        return mixinInfo$MixinMethodNode.isInjector();
    }

    protected boolean attachAccessorMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        boolean bl;
        if (!MixinPreProcessorStandard.lIIIlllIlI(this.attachAccessorMethod(mixinTargetContext, mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod.ACCESSOR) ? 1 : 0) || MixinPreProcessorStandard.lIIIlllIII(this.attachAccessorMethod(mixinTargetContext, mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod.INVOKER) ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x37 ^ 0x73 ^ "   ".length()) & (3 + 82 - -88 + 32 ^ 0 + 7 - -44 + 87 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    protected boolean attachAccessorMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod mixinPreProcessorStandard$SpecialMethod) {
        AnnotationNode annotationNode = mixinInfo$MixinMethodNode.getVisibleAnnotation(mixinPreProcessorStandard$SpecialMethod.annotation);
        if (MixinPreProcessorStandard.lIIIlllIIl(annotationNode)) {
            return false;
        }
        String string = String.valueOf(new StringBuilder().append((Object)mixinPreProcessorStandard$SpecialMethod).append(" method ").append(mixinInfo$MixinMethodNode.name));
        ClassInfo$Method classInfo$Method = this.getSpecialMethod(mixinInfo$MixinMethodNode, mixinPreProcessorStandard$SpecialMethod);
        if (MixinPreProcessorStandard.lIIIlllIII(MixinEnvironment.getCompatibilityLevel().isAtLeast(MixinEnvironment$CompatibilityLevel.JAVA_8) ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIII(classInfo$Method.isStatic() ? 1 : 0)) {
            if (MixinPreProcessorStandard.lIIIlllIll(this.mixin.getTargets().size(), 1)) {
                throw new InvalidAccessorException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append(string).append(" in multi-target mixin is invalid. Mixin must have exactly 1 target.")));
            }
            String string2 = mixinTargetContext.getUniqueName(mixinInfo$MixinMethodNode, true);
            logger.log(this.mixin.getLoggingLevel(), "Renaming @Unique method {}{} to {} in {}", new Object[]{mixinInfo$MixinMethodNode.name, mixinInfo$MixinMethodNode.desc, string2, this.mixin});
            mixinInfo$MixinMethodNode.name = classInfo$Method.renameTo(string2);
            "".length();
            if ((0x8E ^ 0x8B) == 0) {
                return ((0x6B ^ 0x52) & ~(0x81 ^ 0xB8)) != 0;
            }
        } else {
            if (MixinPreProcessorStandard.lIIIlllIlI(classInfo$Method.isAbstract() ? 1 : 0)) {
                throw new InvalidAccessorException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append(string).append(" is not abstract")));
            }
            if (MixinPreProcessorStandard.lIIIlllIII(classInfo$Method.isStatic() ? 1 : 0)) {
                throw new InvalidAccessorException((IMixinContext)mixinTargetContext, String.valueOf(new StringBuilder().append(string).append(" cannot be static")));
            }
        }
        mixinTargetContext.addAccessorMethod(mixinInfo$MixinMethodNode, mixinPreProcessorStandard$SpecialMethod.annotation);
        return true;
    }

    protected boolean attachShadowMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        return this.attachSpecialMethod(mixinTargetContext, mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod.SHADOW);
    }

    protected boolean attachOverwriteMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        return this.attachSpecialMethod(mixinTargetContext, mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod.OVERWRITE);
    }

    protected boolean attachSpecialMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod mixinPreProcessorStandard$SpecialMethod) {
        AnnotationNode annotationNode = mixinInfo$MixinMethodNode.getVisibleAnnotation(mixinPreProcessorStandard$SpecialMethod.annotation);
        if (MixinPreProcessorStandard.lIIIlllIIl(annotationNode)) {
            return false;
        }
        if (MixinPreProcessorStandard.lIIIlllIII(mixinPreProcessorStandard$SpecialMethod.isOverwrite ? 1 : 0)) {
            this.checkMixinNotUnique(mixinInfo$MixinMethodNode, mixinPreProcessorStandard$SpecialMethod);
        }
        ClassInfo$Method classInfo$Method = this.getSpecialMethod(mixinInfo$MixinMethodNode, mixinPreProcessorStandard$SpecialMethod);
        MethodNode methodNode = mixinTargetContext.findMethod(mixinInfo$MixinMethodNode, annotationNode);
        if (MixinPreProcessorStandard.lIIIlllIIl(methodNode)) {
            if (MixinPreProcessorStandard.lIIIlllIII(mixinPreProcessorStandard$SpecialMethod.isOverwrite ? 1 : 0)) {
                return false;
            }
            methodNode = mixinTargetContext.findRemappedMethod(mixinInfo$MixinMethodNode);
            if (MixinPreProcessorStandard.lIIIlllIIl(methodNode)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("%s method %s in %s was not located in the target class %s. %s%s", new Object[]{mixinPreProcessorStandard$SpecialMethod, mixinInfo$MixinMethodNode.name, this.mixin, mixinTargetContext.getTarget(), mixinTargetContext.getReferenceMapper().getStatus(), MixinPreProcessorStandard.getDynamicInfo(mixinInfo$MixinMethodNode)}));
            }
            mixinInfo$MixinMethodNode.name = classInfo$Method.renameTo(methodNode.name);
        }
        if (MixinPreProcessorStandard.lIIIlllIII("<init>".equals(methodNode.name) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("Nice try! %s in %s cannot alias a constructor", mixinInfo$MixinMethodNode.name, this.mixin));
        }
        if (MixinPreProcessorStandard.lIIIlllIlI(Bytecode.compareFlags(mixinInfo$MixinMethodNode, methodNode, 8) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("STATIC modifier of %s method %s in %s does not match the target", new Object[]{mixinPreProcessorStandard$SpecialMethod, mixinInfo$MixinMethodNode.name, this.mixin}));
        }
        this.conformVisibility(mixinTargetContext, mixinInfo$MixinMethodNode, mixinPreProcessorStandard$SpecialMethod, methodNode);
        if (MixinPreProcessorStandard.lIIIlllIlI(methodNode.name.equals(mixinInfo$MixinMethodNode.name) ? 1 : 0)) {
            if (MixinPreProcessorStandard.lIIIlllIII(mixinPreProcessorStandard$SpecialMethod.isOverwrite ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIlI(methodNode.access & 2)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Non-private method cannot be aliased. Found ").append(methodNode.name)));
            }
            mixinInfo$MixinMethodNode.name = classInfo$Method.renameTo(methodNode.name);
        }
        return true;
    }

    private void conformVisibility(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod mixinPreProcessorStandard$SpecialMethod, MethodNode methodNode) {
        Bytecode$Visibility bytecode$Visibility = Bytecode.getVisibility(methodNode);
        Bytecode$Visibility bytecode$Visibility2 = Bytecode.getVisibility(mixinInfo$MixinMethodNode);
        if (MixinPreProcessorStandard.lIIIllllIl(bytecode$Visibility2.ordinal(), bytecode$Visibility.ordinal())) {
            if (MixinPreProcessorStandard.lIIIlllllI((Object)bytecode$Visibility, (Object)Bytecode$Visibility.PRIVATE) && MixinPreProcessorStandard.lIIIlllIll(bytecode$Visibility2.ordinal(), Bytecode$Visibility.PRIVATE.ordinal())) {
                mixinTargetContext.getTarget().addUpgradedMethod(methodNode);
            }
            return;
        }
        String string = String.format("%s %s method %s in %s cannot reduce visibiliy of %s target method", new Object[]{bytecode$Visibility2, mixinPreProcessorStandard$SpecialMethod, mixinInfo$MixinMethodNode.name, this.mixin, bytecode$Visibility});
        if (MixinPreProcessorStandard.lIIIlllIII(mixinPreProcessorStandard$SpecialMethod.isOverwrite ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIlI(this.mixin.getParent().conformOverwriteVisibility() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, string);
        }
        if (MixinPreProcessorStandard.lIIIlllllI((Object)bytecode$Visibility2, (Object)Bytecode$Visibility.PRIVATE)) {
            if (MixinPreProcessorStandard.lIIIlllIII(mixinPreProcessorStandard$SpecialMethod.isOverwrite ? 1 : 0)) {
                logger.warn("Static binding violation: {}, visibility will be upgraded.", new Object[]{string});
            }
            mixinTargetContext.addUpgradedMethod(mixinInfo$MixinMethodNode);
            Bytecode.setVisibility((MethodNode)mixinInfo$MixinMethodNode, bytecode$Visibility);
        }
    }

    protected ClassInfo$Method getSpecialMethod(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod mixinPreProcessorStandard$SpecialMethod) {
        ClassInfo$Method classInfo$Method = this.mixin.getClassInfo().findMethod(mixinInfo$MixinMethodNode, 10);
        this.checkMethodNotUnique(classInfo$Method, mixinPreProcessorStandard$SpecialMethod);
        return classInfo$Method;
    }

    protected void checkMethodNotUnique(ClassInfo$Method classInfo$Method, MixinPreProcessorStandard$SpecialMethod mixinPreProcessorStandard$SpecialMethod) {
        if (MixinPreProcessorStandard.lIIIlllIII(classInfo$Method.isUnique() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("%s method %s in %s cannot be @Unique", new Object[]{mixinPreProcessorStandard$SpecialMethod, classInfo$Method.getName(), this.mixin}));
        }
    }

    protected void checkMixinNotUnique(MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod mixinPreProcessorStandard$SpecialMethod) {
        if (MixinPreProcessorStandard.lIIIlllIII(this.mixin.isUnique() ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("%s method %s found in a @Unique mixin %s", new Object[]{mixinPreProcessorStandard$SpecialMethod, mixinInfo$MixinMethodNode.name, this.mixin}));
        }
    }

    protected boolean attachUniqueMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        String string;
        String string2;
        MethodNode methodNode;
        ClassInfo$Method classInfo$Method = this.mixin.getClassInfo().findMethod(mixinInfo$MixinMethodNode, 10);
        if (!MixinPreProcessorStandard.lIIIllllll(classInfo$Method) || MixinPreProcessorStandard.lIIIlllIlI(classInfo$Method.isUnique() ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIlI(this.mixin.isUnique() ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIlI(classInfo$Method.isSynthetic() ? 1 : 0)) {
            return false;
        }
        if (MixinPreProcessorStandard.lIIIlllIII(classInfo$Method.isSynthetic() ? 1 : 0)) {
            mixinTargetContext.transformDescriptor(mixinInfo$MixinMethodNode);
            classInfo$Method.remapTo(mixinInfo$MixinMethodNode.desc);
            "".length();
        }
        if (MixinPreProcessorStandard.lIIIlllIIl(methodNode = mixinTargetContext.findMethod(mixinInfo$MixinMethodNode, null))) {
            return false;
        }
        if (MixinPreProcessorStandard.lIIIlllIII(classInfo$Method.isSynthetic() ? 1 : 0)) {
            string2 = "synthetic";
            "".length();
            if ("   ".length() <= ((0x10 ^ 0x49 ^ (0x99 ^ 0x81)) & (58 + 27 - 29 + 186 ^ 71 + 134 - 48 + 22 ^ -" ".length()))) {
                return ((154 + 199 - 301 + 148 ^ 3 + 2 - -47 + 140) & (58 + 111 - 163 + 153 ^ 93 + 72 - 68 + 54 ^ -" ".length())) != 0;
            }
        } else {
            string2 = string = "@Unique";
        }
        if (MixinPreProcessorStandard.lIIlIIIIII(Bytecode.getVisibility(mixinInfo$MixinMethodNode).ordinal(), Bytecode$Visibility.PUBLIC.ordinal())) {
            String string3 = mixinTargetContext.getUniqueName(mixinInfo$MixinMethodNode, false);
            logger.log(this.mixin.getLoggingLevel(), "Renaming {} method {}{} to {} in {}", new Object[]{string, mixinInfo$MixinMethodNode.name, mixinInfo$MixinMethodNode.desc, string3, this.mixin});
            mixinInfo$MixinMethodNode.name = classInfo$Method.renameTo(string3);
            return false;
        }
        if (MixinPreProcessorStandard.lIIIlllIII(this.strictUnique ? 1 : 0)) {
            throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("Method conflict, %s method %s in %s cannot overwrite %s%s in %s", string, mixinInfo$MixinMethodNode.name, this.mixin, methodNode.name, methodNode.desc, mixinTargetContext.getTarget()));
        }
        AnnotationNode annotationNode = Annotations.getVisible(mixinInfo$MixinMethodNode, Unique.class);
        if (!MixinPreProcessorStandard.lIIIllllll(annotationNode) || MixinPreProcessorStandard.lIIIlllIlI(Annotations.getValue(annotationNode, "silent", Boolean.FALSE).booleanValue() ? 1 : 0)) {
            if (MixinPreProcessorStandard.lIIIlllIII(Bytecode.hasFlag(mixinInfo$MixinMethodNode, 64) ? 1 : 0)) {
                try {
                    Bytecode.compareBridgeMethods(methodNode, mixinInfo$MixinMethodNode);
                    logger.debug("Discarding sythetic bridge method {} in {} because existing method in {} is compatible", new Object[]{string, mixinInfo$MixinMethodNode.name, this.mixin, mixinTargetContext.getTarget()});
                    return true;
                }
                catch (SyntheticBridgeException syntheticBridgeException) {
                    if (!MixinPreProcessorStandard.lIIIlllIlI(this.verboseLogging ? 1 : 0) || MixinPreProcessorStandard.lIIIlllIII(this.env.getOption(MixinEnvironment$Option.DEBUG_VERIFY) ? 1 : 0)) {
                        syntheticBridgeException.printAnalysis(mixinTargetContext, methodNode, mixinInfo$MixinMethodNode);
                    }
                    throw new InvalidMixinException((IMixinInfo)this.mixin, syntheticBridgeException.getMessage());
                }
            }
            logger.warn("Discarding {} public method {} in {} because it already exists in {}", new Object[]{string, mixinInfo$MixinMethodNode.name, this.mixin, mixinTargetContext.getTarget()});
            return true;
        }
        mixinTargetContext.addMixinMethod(mixinInfo$MixinMethodNode);
        return true;
    }

    protected void attachMethod(MixinTargetContext mixinTargetContext, MixinInfo$MixinMethodNode mixinInfo$MixinMethodNode) {
        MethodNode methodNode;
        ClassInfo$Method classInfo$Method = this.mixin.getClassInfo().findMethod(mixinInfo$MixinMethodNode);
        if (MixinPreProcessorStandard.lIIIlllIIl(classInfo$Method)) {
            return;
        }
        ClassInfo$Method classInfo$Method2 = this.mixin.getClassInfo().findMethodInHierarchy(mixinInfo$MixinMethodNode, ClassInfo$SearchType.SUPER_CLASSES_ONLY);
        if (MixinPreProcessorStandard.lIIIllllll(classInfo$Method2) && MixinPreProcessorStandard.lIIIlllIII(classInfo$Method2.isRenamed() ? 1 : 0)) {
            mixinInfo$MixinMethodNode.name = classInfo$Method.renameTo(classInfo$Method2.getName());
        }
        if (MixinPreProcessorStandard.lIIIllllll(methodNode = mixinTargetContext.findMethod(mixinInfo$MixinMethodNode, null))) {
            this.conformVisibility(mixinTargetContext, mixinInfo$MixinMethodNode, MixinPreProcessorStandard$SpecialMethod.MERGE, methodNode);
        }
    }

    protected void attachFields(MixinTargetContext mixinTargetContext) {
        Iterator iterator = this.classNode.fields.iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            int n;
            int n2;
            FieldNode fieldNode = (FieldNode)iterator.next();
            AnnotationNode annotationNode = Annotations.getVisible(fieldNode, Shadow.class);
            if (MixinPreProcessorStandard.lIIIllllll(annotationNode)) {
                n2 = 1;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                n2 = n = 0;
            }
            if (MixinPreProcessorStandard.lIIIlllIlI(this.validateField(mixinTargetContext, fieldNode, annotationNode) ? 1 : 0)) {
                iterator.remove();
                "".length();
                if (null == null) continue;
                return;
            }
            ClassInfo$Field classInfo$Field = this.mixin.getClassInfo().findField(fieldNode);
            mixinTargetContext.transformDescriptor(fieldNode);
            classInfo$Field.remapTo(fieldNode.desc);
            "".length();
            if (MixinPreProcessorStandard.lIIIlllIII(classInfo$Field.isUnique() ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIII(n)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("@Shadow field %s cannot be @Unique", fieldNode.name));
            }
            FieldNode fieldNode2 = mixinTargetContext.findField(fieldNode, annotationNode);
            if (MixinPreProcessorStandard.lIIIlllIIl(fieldNode2)) {
                if (MixinPreProcessorStandard.lIIIlllIIl(annotationNode)) {
                    "".length();
                    if (-"   ".length() < 0) continue;
                    return;
                }
                fieldNode2 = mixinTargetContext.findRemappedField(fieldNode);
                if (MixinPreProcessorStandard.lIIIlllIIl(fieldNode2)) {
                    throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("Shadow field %s was not located in the target class %s. %s%s", fieldNode.name, mixinTargetContext.getTarget(), mixinTargetContext.getReferenceMapper().getStatus(), MixinPreProcessorStandard.getDynamicInfo(fieldNode)));
                }
                fieldNode.name = classInfo$Field.renameTo(fieldNode2.name);
            }
            if (MixinPreProcessorStandard.lIIIlllIlI(Bytecode.compareFlags(fieldNode, fieldNode2, 8) ? 1 : 0)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("STATIC modifier of @Shadow field %s in %s does not match the target", fieldNode.name, this.mixin));
            }
            if (MixinPreProcessorStandard.lIIIlllIII(classInfo$Field.isUnique() ? 1 : 0)) {
                if (MixinPreProcessorStandard.lIIIlllIII(fieldNode.access & 6)) {
                    String string = mixinTargetContext.getUniqueName(fieldNode);
                    logger.log(this.mixin.getLoggingLevel(), "Renaming @Unique field {}{} to {} in {}", new Object[]{fieldNode.name, fieldNode.desc, string, this.mixin});
                    fieldNode.name = classInfo$Field.renameTo(string);
                    "".length();
                    if (null == null) continue;
                    return;
                }
                if (MixinPreProcessorStandard.lIIIlllIII(this.strictUnique ? 1 : 0)) {
                    throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("Field conflict, @Unique field %s in %s cannot overwrite %s%s in %s", fieldNode.name, this.mixin, fieldNode2.name, fieldNode2.desc, mixinTargetContext.getTarget()));
                }
                logger.warn("Discarding @Unique public field {} in {} because it already exists in {}. Note that declared FIELD INITIALISERS will NOT be removed!", new Object[]{fieldNode.name, this.mixin, mixinTargetContext.getTarget()});
                iterator.remove();
                "".length();
                if ("   ".length() < (0xF ^ 0x68 ^ (0x40 ^ 0x23))) continue;
                return;
            }
            if (MixinPreProcessorStandard.lIIIlllIlI(fieldNode2.desc.equals(fieldNode.desc) ? 1 : 0)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("The field %s in the target class has a conflicting signature", fieldNode.name));
            }
            if (MixinPreProcessorStandard.lIIIlllIlI(fieldNode2.name.equals(fieldNode.name) ? 1 : 0)) {
                if (MixinPreProcessorStandard.lIIIlllIlI(fieldNode2.access & 2) && MixinPreProcessorStandard.lIIIlllIlI(fieldNode2.access & 0x1000)) {
                    throw new InvalidMixinException((IMixinInfo)this.mixin, String.valueOf(new StringBuilder().append("Non-private field cannot be aliased. Found ").append(fieldNode2.name)));
                }
                fieldNode.name = classInfo$Field.renameTo(fieldNode2.name);
            }
            iterator.remove();
            if (MixinPreProcessorStandard.lIIIlllIII(n)) {
                int n3 = classInfo$Field.isDecoratedFinal();
                if (MixinPreProcessorStandard.lIIIlllIII(this.verboseLogging ? 1 : 0) && MixinPreProcessorStandard.lIIlIIIIIl(Bytecode.hasFlag(fieldNode2, 16) ? 1 : 0, n3)) {
                    String string;
                    if (MixinPreProcessorStandard.lIIIlllIII(n3)) {
                        string = "@Shadow field {}::{} is decorated with @Final but target is not final";
                        "".length();
                        if (-" ".length() != -" ".length()) {
                            return;
                        }
                    } else {
                        string = "@Shadow target {}::{} is final but shadow is not decorated with @Final";
                    }
                    String string2 = string;
                    logger.warn(string2, new Object[]{this.mixin, fieldNode.name});
                }
                mixinTargetContext.addShadowField(fieldNode, classInfo$Field);
            }
            "".length();
            if (((0x95 ^ 0xB6) & ~(0x9C ^ 0xBF)) == ((0x30 ^ 0x52) & ~(0xD3 ^ 0xB1))) continue;
            return;
        }
    }

    protected boolean validateField(MixinTargetContext mixinTargetContext, FieldNode fieldNode, AnnotationNode annotationNode) {
        if (MixinPreProcessorStandard.lIIIlllIII(Bytecode.hasFlag(fieldNode, 8) ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIlI(Bytecode.hasFlag(fieldNode, 2) ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIlI(Bytecode.hasFlag(fieldNode, 4096) ? 1 : 0) && MixinPreProcessorStandard.lIIIlllIIl(annotationNode)) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.format("Mixin %s contains non-private static field %s:%s", mixinTargetContext, fieldNode.name, fieldNode.desc));
        }
        String string = (String)Annotations.getValue(annotationNode, "prefix", Shadow.class);
        if (MixinPreProcessorStandard.lIIIlllIII(fieldNode.name.startsWith(string) ? 1 : 0)) {
            throw new InvalidMixinException((IMixinContext)mixinTargetContext, String.format("@Shadow field %s.%s has a shadow prefix. This is not allowed.", mixinTargetContext, fieldNode.name));
        }
        if (MixinPreProcessorStandard.lIIIlllIII("super$".equals(fieldNode.name) ? 1 : 0)) {
            if (MixinPreProcessorStandard.lIIlIIIIIl(fieldNode.access, 2)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("Imaginary super field %s.%s must be private and non-final", mixinTargetContext, fieldNode.name));
            }
            if (MixinPreProcessorStandard.lIIIlllIlI(fieldNode.desc.equals(String.valueOf(new StringBuilder().append("L").append(this.mixin.getClassRef()).append(";"))) ? 1 : 0)) {
                throw new InvalidMixinException((IMixinInfo)this.mixin, String.format("Imaginary super field %s.%s must have the same type as the parent mixin (%s)", mixinTargetContext, fieldNode.name, this.mixin.getClassName()));
            }
            return false;
        }
        return true;
    }

    protected void transform(MixinTargetContext mixinTargetContext) {
        Iterator iterator = this.classNode.methods.iterator();
        while (MixinPreProcessorStandard.lIIIlllIII(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = (MethodNode)iterator.next();
            ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
            while (MixinPreProcessorStandard.lIIIlllIII(listIterator.hasNext() ? 1 : 0)) {
                AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
                if (MixinPreProcessorStandard.lIIIlllIII(abstractInsnNode instanceof MethodInsnNode)) {
                    this.transformMethod((MethodInsnNode)abstractInsnNode);
                    "".length();
                    if ((0x7A ^ 0x55 ^ (0x11 ^ 0x3A)) < "  ".length()) {
                        return;
                    }
                } else if (MixinPreProcessorStandard.lIIIlllIII(abstractInsnNode instanceof FieldInsnNode)) {
                    this.transformField((FieldInsnNode)abstractInsnNode);
                }
                "".length();
                if ((0x76 ^ 0x73) > 0) continue;
                return;
            }
            "".length();
            if (((0x6D ^ 0x30) & ~(0xC7 ^ 0x9A)) < "   ".length()) continue;
            return;
        }
    }

    protected void transformMethod(MethodInsnNode methodInsnNode) {
        Profiler$Section profiler$Section = this.profiler.begin("meta");
        ClassInfo classInfo = ClassInfo.forName(methodInsnNode.owner);
        if (MixinPreProcessorStandard.lIIIlllIIl(classInfo)) {
            throw new RuntimeException(new ClassNotFoundException(methodInsnNode.owner.replace('/', '.')));
        }
        ClassInfo$Method classInfo$Method = classInfo.findMethodInHierarchy(methodInsnNode, ClassInfo$SearchType.ALL_CLASSES, 2);
        profiler$Section.end();
        "".length();
        if (MixinPreProcessorStandard.lIIIllllll(classInfo$Method) && MixinPreProcessorStandard.lIIIlllIII(classInfo$Method.isRenamed() ? 1 : 0)) {
            methodInsnNode.name = classInfo$Method.getName();
        }
    }

    protected void transformField(FieldInsnNode fieldInsnNode) {
        Profiler$Section profiler$Section = this.profiler.begin("meta");
        ClassInfo classInfo = ClassInfo.forName(fieldInsnNode.owner);
        if (MixinPreProcessorStandard.lIIIlllIIl(classInfo)) {
            throw new RuntimeException(new ClassNotFoundException(fieldInsnNode.owner.replace('/', '.')));
        }
        ClassInfo$Field classInfo$Field = classInfo.findField(fieldInsnNode, 2);
        profiler$Section.end();
        "".length();
        if (MixinPreProcessorStandard.lIIIllllll(classInfo$Field) && MixinPreProcessorStandard.lIIIlllIII(classInfo$Field.isRenamed() ? 1 : 0)) {
            fieldInsnNode.name = classInfo$Field.getName();
        }
    }

    protected static String getDynamicInfo(MethodNode methodNode) {
        return MixinPreProcessorStandard.getDynamicInfo("Method", Annotations.getInvisible(methodNode, Dynamic.class));
    }

    protected static String getDynamicInfo(FieldNode fieldNode) {
        return MixinPreProcessorStandard.getDynamicInfo("Field", Annotations.getInvisible(fieldNode, Dynamic.class));
    }

    private static String getDynamicInfo(String string, AnnotationNode annotationNode) {
        String string2;
        String string3 = Strings.nullToEmpty((String)((String)Annotations.getValue(annotationNode)));
        Type type = (Type)Annotations.getValue(annotationNode, "mixin");
        if (MixinPreProcessorStandard.lIIIllllll(type)) {
            string3 = String.format("{%s} %s", type.getClassName(), string3).trim();
        }
        if (MixinPreProcessorStandard.lIIlIIIIlI(string3.length())) {
            string2 = String.format(" %s is @Dynamic(%s)", string, string3);
            "".length();
            if (" ".length() >= "  ".length()) {
                return null;
            }
        } else {
            string2 = "";
        }
        return string2;
    }

    private static boolean lIIIllllIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean lIIlIIIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIlllllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIllllll(Object object) {
        return object != null;
    }

    private static boolean lIIIlllIIl(Object object) {
        return object == null;
    }

    private static boolean lIIIlllIII(int n) {
        return n != 0;
    }

    private static boolean lIIIlllIlI(int n) {
        return n == 0;
    }

    private static boolean lIIlIIIIlI(int n) {
        return n > 0;
    }

    private static boolean lIIlIIIIIl(int n, int n2) {
        return n != n2;
    }
}

