/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.transformer.MixinConfig$IListener;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinTransformer;
import org.spongepowered.asm.mixin.transformer.ext.IHotSwap;

class MixinTransformer$1
implements MixinConfig$IListener {
    final /* synthetic */ IHotSwap val$hotSwapper;
    final /* synthetic */ MixinTransformer this$0;

    MixinTransformer$1(MixinTransformer mixinTransformer, IHotSwap iHotSwap) {
        this.this$0 = mixinTransformer;
        this.val$hotSwapper = iHotSwap;
    }

    @Override
    public void onPrepare(MixinInfo mixinInfo) {
        this.val$hotSwapper.registerMixinClass(mixinInfo.getClassName());
    }

    @Override
    public void onInit(MixinInfo mixinInfo) {
    }
}

