/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler;
import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler$ErrorAction;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinTransformer$ErrorPhase;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

final class MixinTransformer$ErrorPhase$1
extends MixinTransformer$ErrorPhase {
    @Override
    IMixinErrorHandler$ErrorAction onError(IMixinErrorHandler iMixinErrorHandler, String string, InvalidMixinException invalidMixinException, IMixinInfo iMixinInfo, IMixinErrorHandler$ErrorAction iMixinErrorHandler$ErrorAction) {
        try {
            return iMixinErrorHandler.onPrepareError(iMixinInfo.getConfig(), invalidMixinException, iMixinInfo, iMixinErrorHandler$ErrorAction);
        }
        catch (AbstractMethodError abstractMethodError) {
            return iMixinErrorHandler$ErrorAction;
        }
    }

    @Override
    protected String getContext(IMixinInfo iMixinInfo, String string) {
        return String.format("preparing %s in %s", iMixinInfo.getName(), string);
    }
}

