/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer;

import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.extensibility.IMixinConfig;
import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler;
import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler$ErrorAction;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinTransformer$1;
import org.spongepowered.asm.mixin.transformer.MixinTransformer$ErrorPhase$1;
import org.spongepowered.asm.mixin.transformer.MixinTransformer$ErrorPhase$2;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;

abstract class MixinTransformer$ErrorPhase
extends Enum<MixinTransformer$ErrorPhase> {
    public static final /* enum */ MixinTransformer$ErrorPhase PREPARE = new MixinTransformer$ErrorPhase$1();
    public static final /* enum */ MixinTransformer$ErrorPhase APPLY = new MixinTransformer$ErrorPhase$2();
    private final String text = this.name().toLowerCase();
    private static final /* synthetic */ MixinTransformer$ErrorPhase[] $VALUES;

    public static MixinTransformer$ErrorPhase[] values() {
        return (MixinTransformer$ErrorPhase[])$VALUES.clone();
    }

    public static MixinTransformer$ErrorPhase valueOf(String string) {
        return Enum.valueOf(MixinTransformer$ErrorPhase.class, string);
    }

    private MixinTransformer$ErrorPhase() {
    }

    abstract IMixinErrorHandler$ErrorAction onError(IMixinErrorHandler var1, String var2, InvalidMixinException var3, IMixinInfo var4, IMixinErrorHandler$ErrorAction var5);

    protected abstract String getContext(IMixinInfo var1, String var2);

    public String getLogMessage(String string, InvalidMixinException invalidMixinException, IMixinInfo iMixinInfo) {
        return String.format("Mixin %s failed %s: %s %s", this.text, this.getContext(iMixinInfo, string), invalidMixinException.getClass().getName(), invalidMixinException.getMessage());
    }

    public String getErrorMessage(IMixinInfo iMixinInfo, IMixinConfig iMixinConfig, MixinEnvironment$Phase mixinEnvironment$Phase) {
        return String.format("Mixin [%s] from phase [%s] in config [%s] FAILED during %s", iMixinInfo, mixinEnvironment$Phase, iMixinConfig, this.name());
    }

    /* synthetic */ MixinTransformer$ErrorPhase(String string, int n, MixinTransformer$1 mixinTransformer$1) {
        this();
    }

    static {
        $VALUES = new MixinTransformer$ErrorPhase[]{PREPARE, APPLY};
    }
}

