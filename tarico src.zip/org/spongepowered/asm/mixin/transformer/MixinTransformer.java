/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.Mixins;
import org.spongepowered.asm.mixin.extensibility.IMixinConfig;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler;
import org.spongepowered.asm.mixin.extensibility.IMixinErrorHandler$ErrorAction;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.ArgsClassGenerator;
import org.spongepowered.asm.mixin.throwables.ClassAlreadyLoadedException;
import org.spongepowered.asm.mixin.throwables.MixinApplyError;
import org.spongepowered.asm.mixin.throwables.MixinException;
import org.spongepowered.asm.mixin.transformer.Config;
import org.spongepowered.asm.mixin.transformer.InnerClassGenerator;
import org.spongepowered.asm.mixin.transformer.MixinConfig;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.MixinPostProcessor;
import org.spongepowered.asm.mixin.transformer.MixinTransformer$1;
import org.spongepowered.asm.mixin.transformer.MixinTransformer$ErrorPhase;
import org.spongepowered.asm.mixin.transformer.TargetClassContext;
import org.spongepowered.asm.mixin.transformer.ext.Extensions;
import org.spongepowered.asm.mixin.transformer.ext.IClassGenerator;
import org.spongepowered.asm.mixin.transformer.ext.IHotSwap;
import org.spongepowered.asm.mixin.transformer.ext.extensions.ExtensionCheckClass;
import org.spongepowered.asm.mixin.transformer.ext.extensions.ExtensionCheckClass$ValidationFailedException;
import org.spongepowered.asm.mixin.transformer.ext.extensions.ExtensionCheckInterfaces;
import org.spongepowered.asm.mixin.transformer.ext.extensions.ExtensionClassExporter;
import org.spongepowered.asm.mixin.transformer.throwables.InvalidMixinException;
import org.spongepowered.asm.mixin.transformer.throwables.MixinTransformerError;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.ITransformer;
import org.spongepowered.asm.service.MixinService;
import org.spongepowered.asm.transformers.TreeTransformer;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.ReEntranceLock;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;

public class MixinTransformer
extends TreeTransformer {
    private static final String MIXIN_AGENT_CLASS;
    private static final String METRONOME_AGENT_CLASS;
    static final Logger logger;
    private final IMixinService service = MixinService.getService();
    private final List<MixinConfig> configs = new ArrayList<MixinConfig>();
    private final List<MixinConfig> pendingConfigs = new ArrayList<MixinConfig>();
    private final ReEntranceLock lock;
    private final String sessionId = UUID.randomUUID().toString();
    private final Extensions extensions;
    private final IHotSwap hotSwapper;
    private final MixinPostProcessor postProcessor;
    private final Profiler profiler;
    private MixinEnvironment currentEnvironment;
    private Level verboseLoggingLevel = Level.DEBUG;
    private boolean errorState = false;
    private int transformedCount = 0;

    MixinTransformer() {
        MixinEnvironment mixinEnvironment = MixinEnvironment.getCurrentEnvironment();
        Object object = mixinEnvironment.getActiveTransformer();
        if (MixinTransformer.llllIIIlIl(object instanceof ITransformer)) {
            throw new MixinException(String.valueOf(new StringBuilder().append("Terminating MixinTransformer instance ").append(this)));
        }
        mixinEnvironment.setActiveTransformer(this);
        this.lock = this.service.getReEntranceLock();
        this.extensions = new Extensions(this);
        this.hotSwapper = this.initHotSwapper(mixinEnvironment);
        this.postProcessor = new MixinPostProcessor();
        this.extensions.add(new ArgsClassGenerator());
        this.extensions.add(new InnerClassGenerator());
        this.extensions.add(new ExtensionClassExporter(mixinEnvironment));
        this.extensions.add(new ExtensionCheckClass());
        this.extensions.add(new ExtensionCheckInterfaces());
        this.profiler = MixinEnvironment.getProfiler();
    }

    private IHotSwap initHotSwapper(MixinEnvironment mixinEnvironment) {
        if (MixinTransformer.llllIIIllI(mixinEnvironment.getOption(MixinEnvironment$Option.HOT_SWAP) ? 1 : 0)) {
            return null;
        }
        try {
            logger.info("Attempting to load Hot-Swap agent");
            Class<?> clazz = Class.forName("org.spongepowered.tools.agent.MixinAgent");
            Constructor<?> constructor = clazz.getDeclaredConstructor(MixinTransformer.class);
            return (IHotSwap)constructor.newInstance(this);
        }
        catch (Throwable throwable) {
            logger.info("Hot-swap agent could not be loaded, hot swapping of mixins won't work. {}: {}", new Object[]{throwable.getClass().getSimpleName(), throwable.getMessage()});
            return null;
        }
    }

    public void audit(MixinEnvironment mixinEnvironment) {
        Object object;
        Iterator<MixinConfig> iterator;
        HashSet<String> hashSet = new HashSet<String>();
        Logger logger = this.configs.iterator();
        while (MixinTransformer.llllIIIlIl(logger.hasNext() ? 1 : 0)) {
            iterator = logger.next();
            hashSet.addAll(((MixinConfig)((Object)iterator)).getUnhandledTargets());
            "".length();
            "".length();
            if (null == null) continue;
            return;
        }
        logger = LogManager.getLogger((String)"mixin/audit");
        iterator = hashSet.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            object = (String)iterator.next();
            try {
                logger.info("Force-loading class {}", new Object[]{object});
                this.service.getClassProvider().findClass((String)object, true);
                "".length();
                "".length();
            }
            catch (ClassNotFoundException classNotFoundException) {
                logger.error(String.valueOf(new StringBuilder().append("Could not force-load ").append((String)object)), (Throwable)classNotFoundException);
            }
            if ("   ".length() <= 0) {
                return;
            }
            "".length();
            if ("   ".length() != 0) continue;
            return;
        }
        iterator = this.configs.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            object = iterator.next();
            Iterator<String> iterator2 = ((MixinConfig)object).getUnhandledTargets().iterator();
            while (MixinTransformer.llllIIIlIl(iterator2.hasNext() ? 1 : 0)) {
                String string = iterator2.next();
                ClassAlreadyLoadedException classAlreadyLoadedException = new ClassAlreadyLoadedException(String.valueOf(new StringBuilder().append(string).append(" was already classloaded")));
                logger.error(String.valueOf(new StringBuilder().append("Could not force-load ").append(string)), (Throwable)classAlreadyLoadedException);
                "".length();
                if (" ".length() >= 0) continue;
                return;
            }
            "".length();
            if (null == null) continue;
            return;
        }
        if (MixinTransformer.llllIIIlIl(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_PROFILER) ? 1 : 0)) {
            this.printProfilerSummary();
        }
    }

    private void printProfilerSummary() {
        Object object;
        DecimalFormat decimalFormat = new DecimalFormat("(###0.000");
        DecimalFormat decimalFormat2 = new DecimalFormat("(###0.0");
        PrettyPrinter prettyPrinter = this.profiler.printer(false, false);
        long l = this.profiler.get("mixin.prepare").getTotalTime();
        long l2 = this.profiler.get("mixin.read").getTotalTime();
        long l3 = this.profiler.get("mixin.apply").getTotalTime();
        long l4 = this.profiler.get("mixin.write").getTotalTime();
        long l5 = this.profiler.get("mixin").getTotalTime();
        long l6 = this.profiler.get("class.load").getTotalTime();
        long l7 = this.profiler.get("class.transform").getTotalTime();
        long l8 = this.profiler.get("mixin.debug.export").getTotalTime();
        long l9 = l5 - l6 - l7 - l8;
        double d = (double)l9 / (double)l5 * 100.0;
        double d2 = (double)l6 / (double)l5 * 100.0;
        double d3 = (double)l7 / (double)l5 * 100.0;
        double d4 = (double)l8 / (double)l5 * 100.0;
        long l10 = 0L;
        Profiler$Section profiler$Section = null;
        Object object2 = this.profiler.getSections().iterator();
        while (MixinTransformer.llllIIIlIl(object2.hasNext() ? 1 : 0)) {
            long l11;
            long l12;
            object = object2.next();
            if (MixinTransformer.llllIIIlIl(((Profiler$Section)object).getName().startsWith("class.transform.") ? 1 : 0)) {
                l12 = ((Profiler$Section)object).getTotalTime();
                "".length();
                if ("   ".length() != "   ".length()) {
                    return;
                }
            } else {
                l12 = 0L;
            }
            if (MixinTransformer.llllIIlIlI(MixinTransformer.llllIIlIIl(l11 = l12, l10))) {
                l10 = l11;
                profiler$Section = object;
            }
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return;
        }
        prettyPrinter.hr().add("Summary").hr().add();
        "".length();
        object2 = "%9d ms %12s seconds)";
        prettyPrinter.kv("Total mixin time", (String)object2, l5, decimalFormat.format((double)l5 * 0.001)).add();
        "".length();
        prettyPrinter.kv("Preparing mixins", (String)object2, l, decimalFormat.format((double)l * 0.001));
        "".length();
        prettyPrinter.kv("Reading input", (String)object2, l2, decimalFormat.format((double)l2 * 0.001));
        "".length();
        prettyPrinter.kv("Applying mixins", (String)object2, l3, decimalFormat.format((double)l3 * 0.001));
        "".length();
        prettyPrinter.kv("Writing output", (String)object2, l4, decimalFormat.format((double)l4 * 0.001)).add();
        "".length();
        prettyPrinter.kv("of which", "");
        "".length();
        prettyPrinter.kv("Time spent loading from disk", (String)object2, l6, decimalFormat.format((double)l6 * 0.001));
        "".length();
        prettyPrinter.kv("Time spent transforming classes", (String)object2, l7, decimalFormat.format((double)l7 * 0.001)).add();
        "".length();
        if (MixinTransformer.llllIIllIl(profiler$Section)) {
            prettyPrinter.kv("Worst transformer", profiler$Section.getName());
            "".length();
            prettyPrinter.kv("Class", profiler$Section.getInfo());
            "".length();
            prettyPrinter.kv("Time spent", "%s seconds", profiler$Section.getTotalSeconds());
            "".length();
            prettyPrinter.kv("called", "%d times", profiler$Section.getTotalCount()).add();
            "".length();
        }
        prettyPrinter.kv("   Time allocation:     Processing mixins", "%9d ms %10s%% of total)", l9, decimalFormat2.format(d));
        "".length();
        prettyPrinter.kv("Loading classes", "%9d ms %10s%% of total)", l6, decimalFormat2.format(d2));
        "".length();
        prettyPrinter.kv("Running transformers", "%9d ms %10s%% of total)", l7, decimalFormat2.format(d3));
        "".length();
        if (MixinTransformer.llllIIlIlI(MixinTransformer.llllIIlIIl(l8, 0L))) {
            prettyPrinter.kv("Exporting classes (debug)", "%9d ms %10s%% of total)", l8, decimalFormat2.format(d4));
            "".length();
        }
        prettyPrinter.add();
        "".length();
        try {
            Map.Entry entry;
            object = this.service.getClassProvider().findAgentClass("org.spongepowered.metronome.Agent", false);
            Method method = ((Class)object).getDeclaredMethod("getTimes", new Class[0]);
            Map map = (Map)method.invoke(null, new Object[0]);
            prettyPrinter.hr().add("Transformer Times").hr().add();
            "".length();
            int n = 10;
            Iterator iterator = map.entrySet().iterator();
            while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
                entry = iterator.next();
                n = Math.max(n, ((String)entry.getKey()).length());
                "".length();
                if (-(0x9B ^ 0x9F) <= 0) continue;
                return;
            }
            iterator = map.entrySet().iterator();
            while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
                entry = iterator.next();
                String string = (String)entry.getKey();
                long l13 = 0L;
                Iterator<Profiler$Section> iterator2 = this.profiler.getSections().iterator();
                while (MixinTransformer.llllIIIlIl(iterator2.hasNext() ? 1 : 0)) {
                    Profiler$Section profiler$Section2 = iterator2.next();
                    if (MixinTransformer.llllIIIlIl(string.equals(profiler$Section2.getInfo()) ? 1 : 0)) {
                        l13 = profiler$Section2.getTotalTime();
                        "".length();
                        if (((0xCC ^ 0xBC ^ (0xAF ^ 0x8D)) & (0x3D ^ 0x2C ^ (0x45 ^ 6) ^ -" ".length())) < " ".length()) break;
                        return;
                    }
                    "".length();
                    if ("  ".length() >= 0) continue;
                    return;
                }
                if (MixinTransformer.llllIIlIlI(MixinTransformer.llllIIlIIl(l13, 0L))) {
                    prettyPrinter.add(String.valueOf(new StringBuilder().append("%-").append(n).append("s %8s ms %8s ms in mixin)")), string, (Long)entry.getValue() + l13, String.valueOf(new StringBuilder().append("(").append(l13)));
                    "".length();
                    "".length();
                    if (" ".length() >= "  ".length()) {
                        return;
                    }
                } else {
                    prettyPrinter.add(String.valueOf(new StringBuilder().append("%-").append(n).append("s %8s ms")), string, entry.getValue());
                    "".length();
                }
                "".length();
                if ("  ".length() > ((0xDF ^ 0x9E) & ~(0x84 ^ 0xC5))) continue;
                return;
            }
            prettyPrinter.add();
            "".length();
            "".length();
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        if (-"  ".length() > 0) {
            return;
        }
        prettyPrinter.print();
        "".length();
    }

    @Override
    public String getName() {
        return this.getClass().getName();
    }

    @Override
    public boolean isDelegationExcluded() {
        return true;
    }

    @Override
    public synchronized byte[] transformClassBytes(String string, String string2, byte[] byArray) {
        if (!MixinTransformer.llllIIllIl(string2) || MixinTransformer.llllIIIlIl(this.errorState ? 1 : 0)) {
            return byArray;
        }
        MixinEnvironment mixinEnvironment = MixinEnvironment.getCurrentEnvironment();
        if (MixinTransformer.llllIlIIII(byArray)) {
            Iterator<IClassGenerator> iterator = this.extensions.getGenerators().iterator();
            while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
                IClassGenerator iClassGenerator = iterator.next();
                Profiler$Section profiler$Section = this.profiler.begin("generator", iClassGenerator.getClass().getSimpleName().toLowerCase());
                byArray = iClassGenerator.generate(string2);
                profiler$Section.end();
                "".length();
                if (MixinTransformer.llllIIllIl(byArray)) {
                    this.extensions.export(mixinEnvironment, string2.replace('.', '/'), false, byArray);
                    return byArray;
                }
                "".length();
                if (" ".length() == " ".length()) continue;
                return null;
            }
            return byArray;
        }
        int n = this.lock.push().check();
        Profiler$Section profiler$Section = this.profiler.begin("mixin");
        if (MixinTransformer.llllIIIllI(n)) {
            try {
                this.checkSelect(mixinEnvironment);
                "".length();
            }
            catch (Exception exception) {
                this.lock.pop();
                "".length();
                profiler$Section.end();
                "".length();
                throw new MixinException(exception);
            }
            if (" ".length() == "   ".length()) {
                return null;
            }
        }
        try {
            Object object;
            if (MixinTransformer.llllIIIlIl(this.postProcessor.canTransform(string2) ? 1 : 0)) {
                Profiler$Section profiler$Section2 = this.profiler.begin("postprocessor");
                byte[] byArray2 = this.postProcessor.transformClassBytes(string, string2, byArray);
                profiler$Section2.end();
                "".length();
                this.extensions.export(mixinEnvironment, string2, false, byArray2);
                byte[] byArray3 = byArray2;
                return byArray3;
            }
            TreeSet<MixinInfo> treeSet = null;
            int n2 = 0;
            Object object2 = this.configs.iterator();
            while (MixinTransformer.llllIIIlIl(object2.hasNext() ? 1 : 0)) {
                object = object2.next();
                if (MixinTransformer.llllIIIlIl(((MixinConfig)object).packageMatch(string2) ? 1 : 0)) {
                    n2 = 1;
                    "".length();
                    if (-" ".length() < (95 + 50 - 140 + 131 ^ 134 + 20 - 131 + 117)) continue;
                    return null;
                }
                if (MixinTransformer.llllIIIlIl(((MixinConfig)object).hasMixinsFor(string2) ? 1 : 0)) {
                    if (MixinTransformer.llllIlIIII(treeSet)) {
                        treeSet = new TreeSet<MixinInfo>();
                    }
                    treeSet.addAll(((MixinConfig)object).getMixinsFor(string2));
                    "".length();
                }
                "".length();
                if (null == null) continue;
                return null;
            }
            if (MixinTransformer.llllIIIlIl(n2)) {
                throw new NoClassDefFoundError(String.format("%s is a mixin class and cannot be referenced directly", string2));
            }
            if (MixinTransformer.llllIIllIl(treeSet)) {
                if (MixinTransformer.llllIIIlIl(n)) {
                    logger.warn("Re-entrance detected, this will cause serious problems.", (Throwable)new MixinException());
                    throw new MixinApplyError("Re-entrance error.");
                }
                if (MixinTransformer.llllIIllIl(this.hotSwapper)) {
                    this.hotSwapper.registerTargetClass(string2, byArray);
                }
                try {
                    object2 = this.profiler.begin("read");
                    object = this.readClass(byArray, true);
                    TargetClassContext targetClassContext = new TargetClassContext(mixinEnvironment, this.extensions, this.sessionId, string2, (ClassNode)object, treeSet);
                    ((Profiler$Section)object2).end();
                    "".length();
                    byArray = this.applyMixins(mixinEnvironment, targetClassContext);
                    ++this.transformedCount;
                }
                catch (InvalidMixinException invalidMixinException) {
                    this.dumpClassOnFailure(string2, byArray, mixinEnvironment);
                    this.handleMixinApplyError(string2, invalidMixinException, mixinEnvironment);
                }
                "".length();
                if ("  ".length() == 0) {
                    return null;
                }
            }
            object2 = byArray;
            return object2;
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            this.dumpClassOnFailure(string2, byArray, mixinEnvironment);
            throw new MixinTransformerError("An unexpected critical error was encountered", throwable);
        }
        finally {
            this.lock.pop();
            "".length();
            profiler$Section.end();
            "".length();
        }
    }

    public List<String> reload(String string, byte[] byArray) {
        if (MixinTransformer.llllIIlIlI(this.lock.getDepth())) {
            throw new MixinApplyError("Cannot reload mixin if re-entrant lock entered");
        }
        ArrayList<String> arrayList = new ArrayList<String>();
        Iterator<MixinConfig> iterator = this.configs.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            MixinConfig mixinConfig = iterator.next();
            arrayList.addAll(mixinConfig.reloadMixin(string, byArray));
            "".length();
            "".length();
            if (((0xAE ^ 0x80) & ~(0x69 ^ 0x47) ^ (0x80 ^ 0x84)) >= (7 ^ 0x31 ^ (0x1A ^ 0x28))) continue;
            return null;
        }
        return arrayList;
    }

    private void checkSelect(MixinEnvironment mixinEnvironment) {
        if (MixinTransformer.llllIlIIIl(this.currentEnvironment, mixinEnvironment)) {
            this.select(mixinEnvironment);
            return;
        }
        int n = Mixins.getUnvisitedCount();
        if (MixinTransformer.llllIIlIlI(n) && MixinTransformer.llllIIIllI(this.transformedCount)) {
            this.select(mixinEnvironment);
        }
    }

    private void select(MixinEnvironment mixinEnvironment) {
        String string;
        Level level;
        if (MixinTransformer.llllIIIlIl(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
            level = Level.INFO;
            "".length();
            if ((0x7F ^ 0x69 ^ (0x12 ^ 0)) <= "   ".length()) {
                return;
            }
        } else {
            level = this.verboseLoggingLevel = Level.DEBUG;
        }
        if (MixinTransformer.llllIIlIlI(this.transformedCount)) {
            logger.log(this.verboseLoggingLevel, "Ending {}, applied {} mixins", new Object[]{this.currentEnvironment, this.transformedCount});
        }
        if (MixinTransformer.llllIlIIll(this.currentEnvironment, mixinEnvironment)) {
            string = "Checking for additional";
            "".length();
            if ("   ".length() < "   ".length()) {
                return;
            }
        } else {
            string = "Preparing";
        }
        String string2 = string;
        logger.log(this.verboseLoggingLevel, "{} mixins for {}", new Object[]{string2, mixinEnvironment});
        this.profiler.setActive(true);
        this.profiler.mark(String.valueOf(new StringBuilder().append(mixinEnvironment.getPhase().toString()).append(":prepare")));
        Profiler$Section profiler$Section = this.profiler.begin("prepare");
        this.selectConfigs(mixinEnvironment);
        this.extensions.select(mixinEnvironment);
        int n = this.prepareConfigs(mixinEnvironment);
        this.currentEnvironment = mixinEnvironment;
        this.transformedCount = 0;
        profiler$Section.end();
        "".length();
        long l = profiler$Section.getTime();
        double d = profiler$Section.getSeconds();
        if (MixinTransformer.llllIIlIlI(MixinTransformer.llllIlIIlI(d, 0.25))) {
            long l2 = this.profiler.get("class.load").getTime();
            long l3 = this.profiler.get("class.transform").getTime();
            long l4 = this.profiler.get("mixin.plugin").getTime();
            String string3 = new DecimalFormat("###0.000").format(d);
            String string4 = new DecimalFormat("###0.0").format((double)l / (double)n);
            logger.log(this.verboseLoggingLevel, "Prepared {} mixins in {} sec ({}ms avg) ({}ms load, {}ms transform, {}ms plugin)", new Object[]{n, string3, string4, l2, l3, l4});
        }
        this.profiler.mark(String.valueOf(new StringBuilder().append(mixinEnvironment.getPhase().toString()).append(":apply")));
        this.profiler.setActive(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_PROFILER));
    }

    private void selectConfigs(MixinEnvironment mixinEnvironment) {
        Iterator<Config> iterator = Mixins.getConfigs().iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            Config config = iterator.next();
            try {
                MixinConfig mixinConfig = config.get();
                if (MixinTransformer.llllIIIlIl(mixinConfig.select(mixinEnvironment) ? 1 : 0)) {
                    iterator.remove();
                    logger.log(this.verboseLoggingLevel, "Selecting config {}", new Object[]{mixinConfig});
                    mixinConfig.onSelect();
                    this.pendingConfigs.add(mixinConfig);
                    "".length();
                }
                "".length();
            }
            catch (Exception exception) {
                logger.warn(String.format("Failed to select mixin config: %s", config), (Throwable)exception);
            }
            if (-" ".length() == ((0xF6 ^ 0x91 ^ (0x68 ^ 0xB)) & (117 + 27 - 6 + 59 ^ 164 + 30 - 75 + 74 ^ -" ".length()))) {
                return;
            }
            "".length();
            if (null == null) continue;
            return;
        }
        Collections.sort(this.pendingConfigs);
    }

    private int prepareConfigs(MixinEnvironment mixinEnvironment) {
        Object object;
        MixinConfig mixinConfig;
        int n = 0;
        IHotSwap iHotSwap = this.hotSwapper;
        Iterator<MixinConfig> iterator = this.pendingConfigs.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            mixinConfig = iterator.next();
            mixinConfig.addListener(this.postProcessor);
            if (MixinTransformer.llllIIllIl(iHotSwap)) {
                mixinConfig.addListener(new MixinTransformer$1(this, iHotSwap));
            }
            "".length();
            if (null == null) continue;
            return (116 + 105 - 137 + 80 ^ 147 + 12 - 58 + 84) & (0x42 ^ 0x5C ^ "   ".length() ^ -" ".length());
        }
        iterator = this.pendingConfigs.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            mixinConfig = iterator.next();
            try {
                logger.log(this.verboseLoggingLevel, "Preparing {} ({})", new Object[]{mixinConfig, mixinConfig.getDeclaredMixinCount()});
                mixinConfig.prepare();
                n += mixinConfig.getMixinCount();
            }
            catch (InvalidMixinException invalidMixinException) {
                this.handleMixinPrepareError(mixinConfig, invalidMixinException, mixinEnvironment);
                "".length();
                if (((0x18 ^ 0x45 ^ (9 ^ 0xE)) & (136 + 89 - 190 + 220 ^ 50 + 106 - 126 + 135 ^ -" ".length())) == "   ".length()) {
                    return (0x13 ^ 0x44 ^ (0x61 ^ 0x3A)) & (0x74 ^ 0x33 ^ (0x88 ^ 0xC3) ^ -" ".length());
                }
            }
            catch (Exception exception) {
                object = exception.getMessage();
                logger.error(String.valueOf(new StringBuilder().append("Error encountered whilst initialising mixin config '").append(mixinConfig.getName()).append("': ").append((String)object)), (Throwable)exception);
            }
            "".length();
            if ((0xAB ^ 0xAF) < "  ".length()) {
                return (0x2E ^ 0x63) & ~(0xF ^ 0x42);
            }
            "".length();
            if (" ".length() != "  ".length()) continue;
            return (0x13 ^ 0x16) & ~(0x5F ^ 0x5A);
        }
        iterator = this.pendingConfigs.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            mixinConfig = iterator.next();
            IMixinConfigPlugin iMixinConfigPlugin = mixinConfig.getPlugin();
            if (MixinTransformer.llllIlIIII(iMixinConfigPlugin)) {
                "".length();
                if (-"   ".length() < 0) continue;
                return (56 + 98 - 151 + 159 ^ 165 + 176 - 272 + 125) & (0x92 ^ 0x8F ^ (0xD6 ^ 0xAB) ^ -" ".length());
            }
            object = new HashSet();
            Iterator<MixinConfig> iterator2 = this.pendingConfigs.iterator();
            while (MixinTransformer.llllIIIlIl(iterator2.hasNext() ? 1 : 0)) {
                MixinConfig mixinConfig2 = iterator2.next();
                if (MixinTransformer.llllIIIllI(mixinConfig2.equals(mixinConfig) ? 1 : 0)) {
                    object.addAll(mixinConfig2.getTargets());
                    "".length();
                }
                "".length();
                if ((0x32 ^ 0x37) > 0) continue;
                return (0x69 ^ 0x44) & ~(0x97 ^ 0xBA);
            }
            iMixinConfigPlugin.acceptTargets(mixinConfig.getTargets(), Collections.unmodifiableSet(object));
            "".length();
            if (-" ".length() >= -" ".length()) continue;
            return (0x39 ^ 0x70 ^ (0xD5 ^ 0xC0)) & (0x72 ^ 0x5D ^ (0x31 ^ 0x42) ^ -" ".length());
        }
        iterator = this.pendingConfigs.iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            mixinConfig = iterator.next();
            try {
                mixinConfig.postInitialise();
            }
            catch (InvalidMixinException invalidMixinException) {
                this.handleMixinPrepareError(mixinConfig, invalidMixinException, mixinEnvironment);
                "".length();
                if (-" ".length() >= (0x57 ^ 0x53)) {
                    return (0x2E ^ 0x3D) & ~(0x93 ^ 0x80);
                }
            }
            catch (Exception exception) {
                object = exception.getMessage();
                logger.error(String.valueOf(new StringBuilder().append("Error encountered during mixin config postInit step'").append(mixinConfig.getName()).append("': ").append((String)object)), (Throwable)exception);
            }
            "".length();
            if (null != null) {
                return (0xEB ^ 0xAC) & ~(0xCF ^ 0x88);
            }
            "".length();
            if ("   ".length() >= 0) continue;
            return (0x4B ^ 0x78) & ~(0x5F ^ 0x6C);
        }
        this.configs.addAll(this.pendingConfigs);
        "".length();
        Collections.sort(this.configs);
        this.pendingConfigs.clear();
        return n;
    }

    private byte[] applyMixins(MixinEnvironment mixinEnvironment, TargetClassContext targetClassContext) {
        Profiler$Section profiler$Section;
        block3: {
            profiler$Section = this.profiler.begin("preapply");
            this.extensions.preApply(targetClassContext);
            profiler$Section = profiler$Section.next("apply");
            this.apply(targetClassContext);
            profiler$Section = profiler$Section.next("postapply");
            try {
                this.extensions.postApply(targetClassContext);
            }
            catch (ExtensionCheckClass$ValidationFailedException extensionCheckClass$ValidationFailedException) {
                logger.info(extensionCheckClass$ValidationFailedException.getMessage());
                if (MixinTransformer.llllIIIllI(targetClassContext.isExportForced() ? 1 : 0) && !MixinTransformer.llllIIIlIl(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_EXPORT) ? 1 : 0)) break block3;
                this.writeClass(targetClassContext);
                "".length();
            }
            "".length();
            if (null != null) {
                return null;
            }
        }
        profiler$Section.end();
        "".length();
        return this.writeClass(targetClassContext);
    }

    private void apply(TargetClassContext targetClassContext) {
        targetClassContext.applyMixins();
    }

    private void handleMixinPrepareError(MixinConfig mixinConfig, InvalidMixinException invalidMixinException, MixinEnvironment mixinEnvironment) {
        this.handleMixinError(mixinConfig.getName(), invalidMixinException, mixinEnvironment, MixinTransformer$ErrorPhase.PREPARE);
    }

    private void handleMixinApplyError(String string, InvalidMixinException invalidMixinException, MixinEnvironment mixinEnvironment) {
        this.handleMixinError(string, invalidMixinException, mixinEnvironment, MixinTransformer$ErrorPhase.APPLY);
    }

    private void handleMixinError(String string, InvalidMixinException invalidMixinException, MixinEnvironment mixinEnvironment, MixinTransformer$ErrorPhase mixinTransformer$ErrorPhase) {
        IMixinErrorHandler$ErrorAction iMixinErrorHandler$ErrorAction;
        IMixinErrorHandler$ErrorAction iMixinErrorHandler$ErrorAction2;
        this.errorState = true;
        IMixinInfo iMixinInfo = invalidMixinException.getMixin();
        if (MixinTransformer.llllIlIIII(iMixinInfo)) {
            logger.error("InvalidMixinException has no mixin!", (Throwable)invalidMixinException);
            throw invalidMixinException;
        }
        IMixinConfig iMixinConfig = iMixinInfo.getConfig();
        MixinEnvironment$Phase mixinEnvironment$Phase = iMixinInfo.getPhase();
        if (MixinTransformer.llllIIIlIl(iMixinConfig.isRequired() ? 1 : 0)) {
            iMixinErrorHandler$ErrorAction2 = IMixinErrorHandler$ErrorAction.ERROR;
            "".length();
            if ("   ".length() < " ".length()) {
                return;
            }
        } else {
            iMixinErrorHandler$ErrorAction2 = iMixinErrorHandler$ErrorAction = IMixinErrorHandler$ErrorAction.WARN;
        }
        if (MixinTransformer.llllIIIlIl(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
            new PrettyPrinter().add("Invalid Mixin").centre().hr('-').kvWidth(10).kv("Action", mixinTransformer$ErrorPhase.name()).kv("Mixin", iMixinInfo.getClassName()).kv("Config", iMixinConfig.getName()).kv("Phase", mixinEnvironment$Phase).hr('-').add("    %s", invalidMixinException.getClass().getName()).hr('-').addWrapped("    %s", invalidMixinException.getMessage()).hr('-').add(invalidMixinException, 8).trace(iMixinErrorHandler$ErrorAction.logLevel);
            "".length();
        }
        Iterator<IMixinErrorHandler> iterator = this.getErrorHandlers(iMixinInfo.getPhase()).iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            IMixinErrorHandler iMixinErrorHandler = iterator.next();
            IMixinErrorHandler$ErrorAction iMixinErrorHandler$ErrorAction3 = mixinTransformer$ErrorPhase.onError(iMixinErrorHandler, string, invalidMixinException, iMixinInfo, iMixinErrorHandler$ErrorAction);
            if (MixinTransformer.llllIIllIl((Object)iMixinErrorHandler$ErrorAction3)) {
                iMixinErrorHandler$ErrorAction = iMixinErrorHandler$ErrorAction3;
            }
            "".length();
            if (null == null) continue;
            return;
        }
        logger.log(iMixinErrorHandler$ErrorAction.logLevel, mixinTransformer$ErrorPhase.getLogMessage(string, invalidMixinException, iMixinInfo), (Throwable)invalidMixinException);
        this.errorState = false;
        if (MixinTransformer.llllIlIIll((Object)iMixinErrorHandler$ErrorAction, (Object)IMixinErrorHandler$ErrorAction.ERROR)) {
            throw new MixinApplyError(mixinTransformer$ErrorPhase.getErrorMessage(iMixinInfo, iMixinConfig, mixinEnvironment$Phase), invalidMixinException);
        }
    }

    private List<IMixinErrorHandler> getErrorHandlers(MixinEnvironment$Phase mixinEnvironment$Phase) {
        ArrayList<IMixinErrorHandler> arrayList = new ArrayList<IMixinErrorHandler>();
        Iterator<String> iterator = Mixins.getErrorHandlerClasses().iterator();
        while (MixinTransformer.llllIIIlIl(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            try {
                logger.info("Instancing error handler class {}", new Object[]{string});
                Class<?> clazz = this.service.getClassProvider().findClass(string, true);
                IMixinErrorHandler iMixinErrorHandler = (IMixinErrorHandler)clazz.newInstance();
                if (MixinTransformer.llllIIllIl(iMixinErrorHandler)) {
                    arrayList.add(iMixinErrorHandler);
                    "".length();
                }
                "".length();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (" ".length() < -" ".length()) {
                return null;
            }
            "".length();
            if (-" ".length() <= 0) continue;
            return null;
        }
        return arrayList;
    }

    private byte[] writeClass(TargetClassContext targetClassContext) {
        return this.writeClass(targetClassContext.getClassName(), targetClassContext.getClassNode(), targetClassContext.isExportForced());
    }

    private byte[] writeClass(String string, ClassNode classNode, boolean bl) {
        Profiler$Section profiler$Section = this.profiler.begin("write");
        byte[] byArray = this.writeClass(classNode);
        profiler$Section.end();
        "".length();
        this.extensions.export(this.currentEnvironment, string, bl, byArray);
        return byArray;
    }

    private void dumpClassOnFailure(String string, byte[] byArray, MixinEnvironment mixinEnvironment) {
        if (MixinTransformer.llllIIIlIl(mixinEnvironment.getOption(MixinEnvironment$Option.DUMP_TARGET_ON_FAILURE) ? 1 : 0)) {
            ExtensionClassExporter extensionClassExporter = (ExtensionClassExporter)this.extensions.getExtension(ExtensionClassExporter.class);
            extensionClassExporter.dumpClass(String.valueOf(new StringBuilder().append(string.replace('.', '/')).append(".target")), byArray);
            "".length();
        }
    }

    static {
        METRONOME_AGENT_CLASS = "org.spongepowered.metronome.Agent";
        MIXIN_AGENT_CLASS = "org.spongepowered.tools.agent.MixinAgent";
        logger = LogManager.getLogger((String)"mixin");
    }

    private static boolean llllIlIIIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llllIIllIl(Object object) {
        return object != null;
    }

    private static boolean llllIlIIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llllIlIIII(Object object) {
        return object == null;
    }

    private static boolean llllIIIlIl(int n) {
        return n != 0;
    }

    private static boolean llllIIIllI(int n) {
        return n == 0;
    }

    private static boolean llllIIlIlI(int n) {
        return n > 0;
    }

    private static int llllIIlIIl(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }

    private static int llllIlIIlI(double d, double d2) {
        return d == d2 ? 0 : (d > d2 ? 1 : -1);
    }
}

