/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer;

import java.io.OutputStream;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.Debug;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.struct.SourceMap;
import org.spongepowered.asm.mixin.transformer.ClassContext;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorInterface;
import org.spongepowered.asm.mixin.transformer.MixinApplicatorStandard;
import org.spongepowered.asm.mixin.transformer.MixinInfo;
import org.spongepowered.asm.mixin.transformer.ext.Extensions;
import org.spongepowered.asm.mixin.transformer.ext.ITargetClassContext;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.ClassSignature;

class TargetClassContext
extends ClassContext
implements ITargetClassContext {
    private static final Logger logger = LogManager.getLogger((String)"mixin");
    private final MixinEnvironment env;
    private final Extensions extensions;
    private final String sessionId;
    private final String className;
    private final ClassNode classNode;
    private final ClassInfo classInfo;
    private final SourceMap sourceMap;
    private final ClassSignature signature;
    private final SortedSet<MixinInfo> mixins;
    private final Map<String, Target> targetMethods = new HashMap<String, Target>();
    private final Set<MethodNode> mixinMethods = new HashSet<MethodNode>();
    private int nextUniqueMethodIndex;
    private int nextUniqueFieldIndex;
    private boolean applied;
    private boolean forceExport;

    TargetClassContext(MixinEnvironment mixinEnvironment, Extensions extensions, String string, String string2, ClassNode classNode, SortedSet<MixinInfo> sortedSet) {
        this.env = mixinEnvironment;
        this.extensions = extensions;
        this.sessionId = string;
        this.className = string2;
        this.classNode = classNode;
        this.classInfo = ClassInfo.fromClassNode(classNode);
        this.signature = this.classInfo.getSignature();
        this.mixins = sortedSet;
        this.sourceMap = new SourceMap(classNode.sourceFile);
        this.sourceMap.addFile(this.classNode);
        "".length();
    }

    public String toString() {
        return this.className;
    }

    boolean isApplied() {
        return this.applied;
    }

    boolean isExportForced() {
        return this.forceExport;
    }

    Extensions getExtensions() {
        return this.extensions;
    }

    String getSessionId() {
        return this.sessionId;
    }

    @Override
    String getClassRef() {
        return this.classNode.name;
    }

    String getClassName() {
        return this.className;
    }

    @Override
    public ClassNode getClassNode() {
        return this.classNode;
    }

    List<MethodNode> getMethods() {
        return this.classNode.methods;
    }

    List<FieldNode> getFields() {
        return this.classNode.fields;
    }

    @Override
    public ClassInfo getClassInfo() {
        return this.classInfo;
    }

    SortedSet<MixinInfo> getMixins() {
        return this.mixins;
    }

    SourceMap getSourceMap() {
        return this.sourceMap;
    }

    void mergeSignature(ClassSignature classSignature) {
        this.signature.merge(classSignature);
    }

    void addMixinMethod(MethodNode methodNode) {
        this.mixinMethods.add(methodNode);
        "".length();
    }

    void methodMerged(MethodNode methodNode) {
        if (TargetClassContext.lIIlIllI(this.mixinMethods.remove(methodNode) ? 1 : 0)) {
            logger.debug("Unexpected: Merged unregistered method {}{} in {}", new Object[]{methodNode.name, methodNode.desc, this});
        }
    }

    MethodNode findMethod(Deque<String> deque, String string) {
        return this.findAliasedMethod(deque, string, true);
    }

    MethodNode findAliasedMethod(Deque<String> deque, String string) {
        return this.findAliasedMethod(deque, string, false);
    }

    private MethodNode findAliasedMethod(Deque<String> deque, String string, boolean bl) {
        MethodNode methodNode;
        String string2 = deque.poll();
        if (TargetClassContext.lIIlIlll(string2)) {
            return null;
        }
        Iterator<MethodNode> iterator = this.classNode.methods.iterator();
        while (TargetClassContext.lIIllIII(iterator.hasNext() ? 1 : 0)) {
            methodNode = iterator.next();
            if (TargetClassContext.lIIllIII(methodNode.name.equals(string2) ? 1 : 0) && TargetClassContext.lIIllIII(methodNode.desc.equals(string) ? 1 : 0)) {
                return methodNode;
            }
            "".length();
            if (-" ".length() <= "   ".length()) continue;
            return null;
        }
        if (TargetClassContext.lIIllIII(bl ? 1 : 0)) {
            iterator = this.mixinMethods.iterator();
            while (TargetClassContext.lIIllIII(iterator.hasNext() ? 1 : 0)) {
                methodNode = iterator.next();
                if (TargetClassContext.lIIllIII(methodNode.name.equals(string2) ? 1 : 0) && TargetClassContext.lIIllIII(methodNode.desc.equals(string) ? 1 : 0)) {
                    return methodNode;
                }
                "".length();
                if ("  ".length() < (0x82 ^ 0x86)) continue;
                return null;
            }
        }
        return this.findAliasedMethod(deque, string);
    }

    FieldNode findAliasedField(Deque<String> deque, String string) {
        String string2 = deque.poll();
        if (TargetClassContext.lIIlIlll(string2)) {
            return null;
        }
        Iterator<FieldNode> iterator = this.classNode.fields.iterator();
        while (TargetClassContext.lIIllIII(iterator.hasNext() ? 1 : 0)) {
            FieldNode fieldNode = iterator.next();
            if (TargetClassContext.lIIllIII(fieldNode.name.equals(string2) ? 1 : 0) && TargetClassContext.lIIllIII(fieldNode.desc.equals(string) ? 1 : 0)) {
                return fieldNode;
            }
            "".length();
            if (-"  ".length() < 0) continue;
            return null;
        }
        return this.findAliasedField(deque, string);
    }

    Target getTargetMethod(MethodNode methodNode) {
        if (TargetClassContext.lIIlIllI(this.classNode.methods.contains(methodNode) ? 1 : 0)) {
            throw new IllegalArgumentException("Invalid target method supplied to getTargetMethod()");
        }
        String string = String.valueOf(new StringBuilder().append(methodNode.name).append(methodNode.desc));
        Target target = this.targetMethods.get(string);
        if (TargetClassContext.lIIlIlll(target)) {
            target = new Target(this.classNode, methodNode);
            this.targetMethods.put(string, target);
            "".length();
        }
        return target;
    }

    String getUniqueName(MethodNode methodNode, boolean bl) {
        String string;
        String string2 = Integer.toHexString(this.nextUniqueMethodIndex++);
        if (TargetClassContext.lIIllIII(bl ? 1 : 0)) {
            string = "%2$s_$md$%1$s$%3$s";
            "".length();
            if (" ".length() < 0) {
                return null;
            }
        } else {
            string = "md%s$%s$%s";
        }
        String string3 = string;
        return String.format(string3, this.sessionId.substring(30), methodNode.name, string2);
    }

    String getUniqueName(FieldNode fieldNode) {
        String string = Integer.toHexString(this.nextUniqueFieldIndex++);
        return String.format("fd%s$%s$%s", this.sessionId.substring(30), fieldNode.name, string);
    }

    void applyMixins() {
        if (TargetClassContext.lIIllIII(this.applied ? 1 : 0)) {
            throw new IllegalStateException(String.valueOf(new StringBuilder().append("Mixins already applied to target class ").append(this.className)));
        }
        this.applied = true;
        MixinApplicatorStandard mixinApplicatorStandard = this.createApplicator();
        mixinApplicatorStandard.apply(this.mixins);
        this.applySignature();
        this.upgradeMethods();
        this.checkMerges();
    }

    private MixinApplicatorStandard createApplicator() {
        if (TargetClassContext.lIIllIII(this.classInfo.isInterface() ? 1 : 0)) {
            return new MixinApplicatorInterface(this);
        }
        return new MixinApplicatorStandard(this);
    }

    private void applySignature() {
        this.getClassNode().signature = this.signature.toString();
    }

    private void checkMerges() {
        Iterator<MethodNode> iterator = this.mixinMethods.iterator();
        while (TargetClassContext.lIIllIII(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            if (TargetClassContext.lIIlIllI(methodNode.name.startsWith("<") ? 1 : 0)) {
                logger.debug("Unexpected: Registered method {}{} in {} was not merged", new Object[]{methodNode.name, methodNode.desc, this});
            }
            "".length();
            if ((0x2B ^ 0x2F) >= ((0x40 ^ 0x1A) & ~(0x36 ^ 0x6C))) continue;
            return;
        }
    }

    void processDebugTasks() {
        if (TargetClassContext.lIIlIllI(this.env.getOption(MixinEnvironment$Option.DEBUG_VERBOSE) ? 1 : 0)) {
            return;
        }
        AnnotationNode annotationNode = Annotations.getVisible(this.classNode, Debug.class);
        if (TargetClassContext.lIIllIIl(annotationNode)) {
            this.forceExport = Boolean.TRUE.equals(Annotations.getValue(annotationNode, "export"));
            if (TargetClassContext.lIIllIII(Boolean.TRUE.equals(Annotations.getValue(annotationNode, "print")) ? 1 : 0)) {
                Bytecode.textify(this.classNode, (OutputStream)System.err);
            }
        }
        Iterator<MethodNode> iterator = this.classNode.methods.iterator();
        while (TargetClassContext.lIIllIII(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            AnnotationNode annotationNode2 = Annotations.getVisible(methodNode, Debug.class);
            if (TargetClassContext.lIIllIIl(annotationNode2) && TargetClassContext.lIIllIII(Boolean.TRUE.equals(Annotations.getValue(annotationNode2, "print")) ? 1 : 0)) {
                Bytecode.textify(methodNode, (OutputStream)System.err);
            }
            "".length();
            if (-" ".length() <= 0) continue;
            return;
        }
    }

    private static boolean lIIllIIl(Object object) {
        return object != null;
    }

    private static boolean lIIlIlll(Object object) {
        return object == null;
    }

    private static boolean lIIllIII(int n) {
        return n != 0;
    }

    private static boolean lIIlIllI(int n) {
        return n == 0;
    }
}

