/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.java.decompiler.main.extern.IBytecodeProvider
 *  org.jetbrains.java.decompiler.util.InterpreterUtil
 */
package org.spongepowered.asm.mixin.transformer.debug;

import java.io.File;
import org.jetbrains.java.decompiler.main.extern.IBytecodeProvider;
import org.jetbrains.java.decompiler.util.InterpreterUtil;
import org.spongepowered.asm.mixin.transformer.debug.RuntimeDecompiler;

class RuntimeDecompiler$1
implements IBytecodeProvider {
    private byte[] byteCode;
    final /* synthetic */ RuntimeDecompiler this$0;

    RuntimeDecompiler$1(RuntimeDecompiler runtimeDecompiler) {
        this.this$0 = runtimeDecompiler;
    }

    public byte[] getBytecode(String string, String string2) {
        if (RuntimeDecompiler$1.lIIIIlIl(this.byteCode)) {
            this.byteCode = InterpreterUtil.getBytes((File)new File(string));
        }
        return this.byteCode;
    }

    private static boolean lIIIIlIl(Object object) {
        return object == null;
    }
}

