/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 */
package org.spongepowered.asm.mixin.transformer.ext;

import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.transformer.MixinTransformer;
import org.spongepowered.asm.mixin.transformer.ext.IClassGenerator;
import org.spongepowered.asm.mixin.transformer.ext.IExtension;
import org.spongepowered.asm.mixin.transformer.ext.ITargetClassContext;

public final class Extensions {
    private final MixinTransformer transformer;
    private final List<IExtension> extensions = new ArrayList<IExtension>();
    private final Map<Class<? extends IExtension>, IExtension> extensionMap = new HashMap<Class<? extends IExtension>, IExtension>();
    private final List<IClassGenerator> generators = new ArrayList<IClassGenerator>();
    private final List<IClassGenerator> generatorsView = Collections.unmodifiableList(this.generators);
    private final Map<Class<? extends IClassGenerator>, IClassGenerator> generatorMap = new HashMap<Class<? extends IClassGenerator>, IClassGenerator>();
    private List<IExtension> activeExtensions = Collections.emptyList();

    public Extensions(MixinTransformer mixinTransformer) {
        this.transformer = mixinTransformer;
    }

    public MixinTransformer getTransformer() {
        return this.transformer;
    }

    public void add(IExtension iExtension) {
        this.extensions.add(iExtension);
        "".length();
        this.extensionMap.put(iExtension.getClass(), iExtension);
        "".length();
    }

    public List<IExtension> getExtensions() {
        return Collections.unmodifiableList(this.extensions);
    }

    public List<IExtension> getActiveExtensions() {
        return this.activeExtensions;
    }

    public <T extends IExtension> T getExtension(Class<? extends IExtension> clazz) {
        return (T)Extensions.lookup(clazz, this.extensionMap, this.extensions);
    }

    public void select(MixinEnvironment mixinEnvironment) {
        ImmutableList.Builder builder = ImmutableList.builder();
        Iterator<IExtension> iterator = this.extensions.iterator();
        while (Extensions.lllIlIlllII(iterator.hasNext() ? 1 : 0)) {
            IExtension iExtension = iterator.next();
            if (Extensions.lllIlIlllII(iExtension.checkActive(mixinEnvironment) ? 1 : 0)) {
                builder.add((Object)iExtension);
                "".length();
            }
            "".length();
            if (-" ".length() < "  ".length()) continue;
            return;
        }
        this.activeExtensions = builder.build();
    }

    public void preApply(ITargetClassContext iTargetClassContext) {
        Iterator<IExtension> iterator = this.activeExtensions.iterator();
        while (Extensions.lllIlIlllII(iterator.hasNext() ? 1 : 0)) {
            IExtension iExtension = iterator.next();
            iExtension.preApply(iTargetClassContext);
            "".length();
            if (((0xB3 ^ 0xB9) & ~(0x37 ^ 0x3D)) <= "  ".length()) continue;
            return;
        }
    }

    public void postApply(ITargetClassContext iTargetClassContext) {
        Iterator<IExtension> iterator = this.activeExtensions.iterator();
        while (Extensions.lllIlIlllII(iterator.hasNext() ? 1 : 0)) {
            IExtension iExtension = iterator.next();
            iExtension.postApply(iTargetClassContext);
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
    }

    public void export(MixinEnvironment mixinEnvironment, String string, boolean bl, byte[] byArray) {
        Iterator<IExtension> iterator = this.activeExtensions.iterator();
        while (Extensions.lllIlIlllII(iterator.hasNext() ? 1 : 0)) {
            IExtension iExtension = iterator.next();
            iExtension.export(mixinEnvironment, string, bl, byArray);
            "".length();
            if (" ".length() < "   ".length()) continue;
            return;
        }
    }

    public void add(IClassGenerator iClassGenerator) {
        this.generators.add(iClassGenerator);
        "".length();
        this.generatorMap.put(iClassGenerator.getClass(), iClassGenerator);
        "".length();
    }

    public List<IClassGenerator> getGenerators() {
        return this.generatorsView;
    }

    public <T extends IClassGenerator> T getGenerator(Class<? extends IClassGenerator> clazz) {
        return (T)Extensions.lookup(clazz, this.generatorMap, this.generators);
    }

    private static <T> T lookup(Class<? extends T> clazz, Map<Class<? extends T>, T> map, List<T> list) {
        T t = map.get(clazz);
        if (Extensions.lllIlIllllI(t)) {
            Iterator<T> iterator = list.iterator();
            while (Extensions.lllIlIlllII(iterator.hasNext() ? 1 : 0)) {
                T t2 = iterator.next();
                if (Extensions.lllIlIlllII(clazz.isAssignableFrom(t2.getClass()) ? 1 : 0)) {
                    t = t2;
                    "".length();
                    if (null == null) break;
                    return null;
                }
                "".length();
                if ((0x75 ^ 0x70) > 0) continue;
                return null;
            }
            if (Extensions.lllIlIllllI(t)) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Extension for <").append(clazz.getName()).append("> could not be found")));
            }
            map.put(clazz, t);
            "".length();
        }
        return t;
    }

    private static boolean lllIlIllllI(Object object) {
        return object == null;
    }

    private static boolean lllIlIlllII(int n) {
        return n != 0;
    }
}

