/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer.ext.extensions;

import org.spongepowered.asm.mixin.throwables.MixinException;

public class ExtensionCheckClass$ValidationFailedException
extends MixinException {
    private static final long serialVersionUID = 1L;

    public ExtensionCheckClass$ValidationFailedException(String string, Throwable throwable) {
        super(string, throwable);
    }

    public ExtensionCheckClass$ValidationFailedException(String string) {
        super(string);
    }

    public ExtensionCheckClass$ValidationFailedException(Throwable throwable) {
        super(throwable);
    }
}

