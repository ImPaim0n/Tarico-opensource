/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.FileUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.mixin.transformer.ext.extensions;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.transformer.ext.IDecompiler;
import org.spongepowered.asm.mixin.transformer.ext.IExtension;
import org.spongepowered.asm.mixin.transformer.ext.ITargetClassContext;
import org.spongepowered.asm.util.Constants;
import org.spongepowered.asm.util.perf.Profiler$Section;

public class ExtensionClassExporter
implements IExtension {
    private static final String DECOMPILER_CLASS = "org.spongepowered.asm.mixin.transformer.debug.RuntimeDecompiler";
    private static final String EXPORT_CLASS_DIR;
    private static final String EXPORT_JAVA_DIR;
    private static final Logger logger;
    private final File classExportDir = new File(Constants.DEBUG_OUTPUT_DIR, "class");
    private final IDecompiler decompiler;

    public ExtensionClassExporter(MixinEnvironment mixinEnvironment) {
        this.decompiler = this.initDecompiler(mixinEnvironment, new File(Constants.DEBUG_OUTPUT_DIR, "java"));
        try {
            FileUtils.deleteDirectory((File)this.classExportDir);
            "".length();
        }
        catch (IOException iOException) {
            logger.warn("Error cleaning class output directory: {}", new Object[]{iOException.getMessage()});
        }
        if ((0xC9 ^ 0x84 ^ (0x57 ^ 0x1E)) < (0xD1 ^ 0xB5 ^ (0x21 ^ 0x41))) {
            throw null;
        }
    }

    private IDecompiler initDecompiler(MixinEnvironment mixinEnvironment, File file) {
        if (ExtensionClassExporter.lIIIIIlllI(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_EXPORT_DECOMPILE) ? 1 : 0)) {
            return null;
        }
        try {
            String string;
            String string2;
            String string3;
            int n = mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_EXPORT_DECOMPILE_THREADED);
            Object[] objectArray = new Object[1];
            if (ExtensionClassExporter.lIIIIIllll(n)) {
                string3 = " (Threaded mode)";
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                string3 = "";
            }
            objectArray[0] = string3;
            logger.info("Attempting to load Fernflower decompiler{}", objectArray);
            StringBuilder stringBuilder = new StringBuilder().append("org.spongepowered.asm.mixin.transformer.debug.RuntimeDecompiler");
            if (ExtensionClassExporter.lIIIIIllll(n)) {
                string2 = "Async";
                "".length();
                if (((0x71 ^ 0x2C) & ~(0xB ^ 0x56)) > 0) {
                    return null;
                }
            } else {
                string2 = "";
            }
            String string4 = String.valueOf(stringBuilder.append(string2));
            Class<?> clazz = Class.forName(string4);
            Constructor<?> constructor = clazz.getDeclaredConstructor(File.class);
            IDecompiler iDecompiler = (IDecompiler)constructor.newInstance(file);
            Object[] objectArray2 = new Object[1];
            if (ExtensionClassExporter.lIIIIIllll(n)) {
                string = " in a separate thread";
                "".length();
                if ((0x3B ^ 0x3F) < 0) {
                    return null;
                }
            } else {
                string = "";
            }
            objectArray2[0] = string;
            logger.info("Fernflower decompiler was successfully initialised, exported classes will be decompiled{}", objectArray2);
            return iDecompiler;
        }
        catch (Throwable throwable) {
            logger.info("Fernflower could not be loaded, exported classes will not be decompiled. {}: {}", new Object[]{throwable.getClass().getSimpleName(), throwable.getMessage()});
            return null;
        }
    }

    private String prepareFilter(String string) {
        string = String.valueOf(new StringBuilder().append("^\\Q").append(string.replace("**", "\u0081").replace("*", "\u0082").replace("?", "\u0083")).append("\\E$"));
        return string.replace("\u0081", "\\E.*\\Q").replace("\u0082", "\\E[^\\.]+\\Q").replace("\u0083", "\\E.\\Q").replace("\\Q\\E", "");
    }

    private boolean applyFilter(String string, String string2) {
        return Pattern.compile(this.prepareFilter(string), 2).matcher(string2).matches();
    }

    @Override
    public boolean checkActive(MixinEnvironment mixinEnvironment) {
        return true;
    }

    @Override
    public void preApply(ITargetClassContext iTargetClassContext) {
    }

    @Override
    public void postApply(ITargetClassContext iTargetClassContext) {
    }

    @Override
    public void export(MixinEnvironment mixinEnvironment, String string, boolean bl, byte[] byArray) {
        if (!ExtensionClassExporter.lIIIIIlllI(bl ? 1 : 0) || ExtensionClassExporter.lIIIIIllll(mixinEnvironment.getOption(MixinEnvironment$Option.DEBUG_EXPORT) ? 1 : 0)) {
            String string2 = mixinEnvironment.getOptionValue(MixinEnvironment$Option.DEBUG_EXPORT_FILTER);
            if (!ExtensionClassExporter.lIIIIIlllI(bl ? 1 : 0) || !ExtensionClassExporter.lIIIIlIIII(string2) || ExtensionClassExporter.lIIIIIllll(this.applyFilter(string2, string) ? 1 : 0)) {
                Profiler$Section profiler$Section = MixinEnvironment.getProfiler().begin("debug.export");
                File file = this.dumpClass(string.replace('.', '/'), byArray);
                if (ExtensionClassExporter.lIIIIlIIII(this.decompiler)) {
                    this.decompiler.decompile(file);
                }
                profiler$Section.end();
                "".length();
            }
        }
    }

    public File dumpClass(String string, byte[] byArray) {
        File file = new File(this.classExportDir, String.valueOf(new StringBuilder().append(string).append(".class")));
        try {
            FileUtils.writeByteArrayToFile((File)file, (byte[])byArray);
            "".length();
        }
        catch (IOException iOException) {
            // empty catch block
        }
        if (null != null) {
            return null;
        }
        return file;
    }

    static {
        EXPORT_JAVA_DIR = "java";
        EXPORT_CLASS_DIR = "class";
        logger = LogManager.getLogger((String)"mixin");
    }

    private static boolean lIIIIlIIII(Object object) {
        return object != null;
    }

    private static boolean lIIIIIllll(int n) {
        return n != 0;
    }

    private static boolean lIIIIIlllI(int n) {
        return n == 0;
    }
}

