/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.obfuscation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.mixin.extensibility.IRemapper;

public class RemapperChain
implements IRemapper {
    private final List<IRemapper> remappers = new ArrayList<IRemapper>();

    public String toString() {
        return String.format("RemapperChain[%d]", this.remappers.size());
    }

    public RemapperChain add(IRemapper iRemapper) {
        this.remappers.add(iRemapper);
        "".length();
        return this;
    }

    @Override
    public String mapMethodName(String string, String string2, String string3) {
        Iterator<IRemapper> iterator = this.remappers.iterator();
        while (RemapperChain.lIIIIIlIIlll(iterator.hasNext() ? 1 : 0)) {
            IRemapper iRemapper = iterator.next();
            String string4 = iRemapper.mapMethodName(string, string2, string3);
            if (RemapperChain.lIIIIIlIlIIl(string4) && RemapperChain.lIIIIIlIlIlI(string4.equals(string2) ? 1 : 0)) {
                string2 = string4;
            }
            "".length();
            if ((0x62 ^ 0x66) == (0x70 ^ 0x74)) continue;
            return null;
        }
        return string2;
    }

    @Override
    public String mapFieldName(String string, String string2, String string3) {
        Iterator<IRemapper> iterator = this.remappers.iterator();
        while (RemapperChain.lIIIIIlIIlll(iterator.hasNext() ? 1 : 0)) {
            IRemapper iRemapper = iterator.next();
            String string4 = iRemapper.mapFieldName(string, string2, string3);
            if (RemapperChain.lIIIIIlIlIIl(string4) && RemapperChain.lIIIIIlIlIlI(string4.equals(string2) ? 1 : 0)) {
                string2 = string4;
            }
            "".length();
            if ((0x84 ^ 0x8B ^ (0x45 ^ 0x4E)) != 0) continue;
            return null;
        }
        return string2;
    }

    @Override
    public String map(String string) {
        Iterator<IRemapper> iterator = this.remappers.iterator();
        while (RemapperChain.lIIIIIlIIlll(iterator.hasNext() ? 1 : 0)) {
            IRemapper iRemapper = iterator.next();
            String string2 = iRemapper.map(string);
            if (RemapperChain.lIIIIIlIlIIl(string2) && RemapperChain.lIIIIIlIlIlI(string2.equals(string) ? 1 : 0)) {
                string = string2;
            }
            "".length();
            if (" ".length() != 0) continue;
            return null;
        }
        return string;
    }

    @Override
    public String unmap(String string) {
        Iterator<IRemapper> iterator = this.remappers.iterator();
        while (RemapperChain.lIIIIIlIIlll(iterator.hasNext() ? 1 : 0)) {
            IRemapper iRemapper = iterator.next();
            String string2 = iRemapper.unmap(string);
            if (RemapperChain.lIIIIIlIlIIl(string2) && RemapperChain.lIIIIIlIlIlI(string2.equals(string) ? 1 : 0)) {
                string = string2;
            }
            "".length();
            if ((0x7A ^ 0x7E) >= 0) continue;
            return null;
        }
        return string;
    }

    @Override
    public String mapDesc(String string) {
        Iterator<IRemapper> iterator = this.remappers.iterator();
        while (RemapperChain.lIIIIIlIIlll(iterator.hasNext() ? 1 : 0)) {
            IRemapper iRemapper = iterator.next();
            String string2 = iRemapper.mapDesc(string);
            if (RemapperChain.lIIIIIlIlIIl(string2) && RemapperChain.lIIIIIlIlIlI(string2.equals(string) ? 1 : 0)) {
                string = string2;
            }
            "".length();
            if ("   ".length() <= "   ".length()) continue;
            return null;
        }
        return string;
    }

    @Override
    public String unmapDesc(String string) {
        Iterator<IRemapper> iterator = this.remappers.iterator();
        while (RemapperChain.lIIIIIlIIlll(iterator.hasNext() ? 1 : 0)) {
            IRemapper iRemapper = iterator.next();
            String string2 = iRemapper.unmapDesc(string);
            if (RemapperChain.lIIIIIlIlIIl(string2) && RemapperChain.lIIIIIlIlIlI(string2.equals(string) ? 1 : 0)) {
                string = string2;
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        return string;
    }

    private static boolean lIIIIIlIlIIl(Object object) {
        return object != null;
    }

    private static boolean lIIIIIlIIlll(int n) {
        return n != 0;
    }

    private static boolean lIIIIIlIlIlI(int n) {
        return n == 0;
    }
}

