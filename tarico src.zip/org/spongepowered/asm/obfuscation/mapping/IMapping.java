/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.obfuscation.mapping;

import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;

public interface IMapping<TMapping> {
    public IMapping$Type getType();

    public TMapping move(String var1);

    public TMapping remap(String var1);

    public TMapping transform(String var1);

    public TMapping copy();

    public String getName();

    public String getSimpleName();

    public String getOwner();

    public String getDesc();

    public TMapping getSuper();

    public String serialise();
}

