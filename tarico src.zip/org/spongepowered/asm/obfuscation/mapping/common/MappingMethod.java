/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Objects
 */
package org.spongepowered.asm.obfuscation.mapping.common;

import com.google.common.base.Objects;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;

public class MappingMethod
implements IMapping<MappingMethod> {
    private final String owner;
    private final String name;
    private final String desc;

    public MappingMethod(String string, String string2) {
        this(MappingMethod.getOwnerFromName(string), MappingMethod.getBaseName(string), string2);
    }

    public MappingMethod(String string, String string2, String string3) {
        this.owner = string;
        this.name = string2;
        this.desc = string3;
    }

    @Override
    public IMapping$Type getType() {
        return IMapping$Type.METHOD;
    }

    @Override
    public String getName() {
        String string;
        if (MappingMethod.llIIllIllll(this.name)) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (MappingMethod.llIIlllIIII(this.owner)) {
            string = String.valueOf(new StringBuilder().append(this.owner).append("/"));
            "".length();
            if (-" ".length() == "   ".length()) {
                return null;
            }
        } else {
            string = "";
        }
        return String.valueOf(stringBuilder.append(string).append(this.name));
    }

    @Override
    public String getSimpleName() {
        return this.name;
    }

    @Override
    public String getOwner() {
        return this.owner;
    }

    @Override
    public String getDesc() {
        return this.desc;
    }

    @Override
    public MappingMethod getSuper() {
        return null;
    }

    public boolean isConstructor() {
        return "<init>".equals(this.name);
    }

    @Override
    public MappingMethod move(String string) {
        return new MappingMethod(string, this.getSimpleName(), this.getDesc());
    }

    @Override
    public MappingMethod remap(String string) {
        return new MappingMethod(this.getOwner(), string, this.getDesc());
    }

    @Override
    public MappingMethod transform(String string) {
        return new MappingMethod(this.getOwner(), this.getSimpleName(), string);
    }

    @Override
    public MappingMethod copy() {
        return new MappingMethod(this.getOwner(), this.getSimpleName(), this.getDesc());
    }

    public MappingMethod addPrefix(String string) {
        String string2 = this.getSimpleName();
        if (!MappingMethod.llIIlllIIII(string2) || MappingMethod.llIIlllIIIl(string2.startsWith(string) ? 1 : 0)) {
            return this;
        }
        return new MappingMethod(this.getOwner(), String.valueOf(new StringBuilder().append(string).append(string2)), this.getDesc());
    }

    public int hashCode() {
        return Objects.hashCode((Object[])new Object[]{this.getName(), this.getDesc()});
    }

    public boolean equals(Object object) {
        if (MappingMethod.llIIlllIIlI(this, object)) {
            return true;
        }
        if (MappingMethod.llIIlllIIIl(object instanceof MappingMethod)) {
            boolean bl;
            if (MappingMethod.llIIlllIIIl(Objects.equal((Object)this.name, (Object)((MappingMethod)object).name) ? 1 : 0) && MappingMethod.llIIlllIIIl(Objects.equal((Object)this.desc, (Object)((MappingMethod)object).desc) ? 1 : 0)) {
                bl = true;
                "".length();
                if ("  ".length() <= ((0x1A ^ 0x32 ^ (0x53 ^ 0x32)) & (0x14 ^ 0x64 ^ (0xB3 ^ 0x8A) ^ -" ".length()))) {
                    return ((0x23 ^ 0x16 ^ (0x97 ^ 0xAA)) & (0xF8 ^ 0xC4 ^ (0x3B ^ 0xF) ^ -" ".length())) != 0;
                }
            } else {
                bl = false;
            }
            return bl;
        }
        return false;
    }

    @Override
    public String serialise() {
        return this.toString();
    }

    public String toString() {
        String string;
        Object object;
        String string2 = this.getDesc();
        Object[] objectArray = new Object[3];
        objectArray[0] = this.getName();
        if (MappingMethod.llIIlllIIII(string2)) {
            object = " ";
            "".length();
            if (" ".length() <= ((0x2A ^ 8) & ~(0x2F ^ 0xD))) {
                return null;
            }
        } else {
            object = objectArray[1] = "";
        }
        if (MappingMethod.llIIlllIIII(string2)) {
            string = string2;
            "".length();
            if (-" ".length() > 0) {
                return null;
            }
        } else {
            string = "";
        }
        objectArray[2] = string;
        return String.format("%s%s%s", objectArray);
    }

    private static String getBaseName(String string) {
        String string2;
        if (MappingMethod.llIIllIllll(string)) {
            return null;
        }
        int n = string.lastIndexOf(47);
        if (MappingMethod.llIIlllIIll(n, -1)) {
            string2 = string.substring(n + 1);
            "".length();
            if ("  ".length() == 0) {
                return null;
            }
        } else {
            string2 = string;
        }
        return string2;
    }

    private static String getOwnerFromName(String string) {
        String string2;
        if (MappingMethod.llIIllIllll(string)) {
            return null;
        }
        int n = string.lastIndexOf(47);
        if (MappingMethod.llIIlllIIll(n, -1)) {
            string2 = string.substring(0, n);
            "".length();
            if (((0x67 ^ 0x37 ^ (0x1C ^ 0x51)) & (0x17 ^ 0x73 ^ (0xF7 ^ 0x8E) ^ -" ".length())) >= (0x50 ^ 0x54 ^ (0xF1 ^ 0xC5) & ~(0xBA ^ 0x8E))) {
                return null;
            }
        } else {
            string2 = null;
        }
        return string2;
    }

    private static boolean llIIlllIIll(int n, int n2) {
        return n > n2;
    }

    private static boolean llIIlllIIII(Object object) {
        return object != null;
    }

    private static boolean llIIlllIIlI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIIllIllll(Object object) {
        return object == null;
    }

    private static boolean llIIlllIIIl(int n) {
        return n != 0;
    }
}

