/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.obfuscation.mapping.mcp;

import org.spongepowered.asm.obfuscation.mapping.common.MappingField;

public class MappingFieldSrg
extends MappingField {
    private final String srg;

    public MappingFieldSrg(String string) {
        super(MappingFieldSrg.getOwnerFromSrg(string), MappingFieldSrg.getNameFromSrg(string), null);
        this.srg = string;
    }

    public MappingFieldSrg(MappingField mappingField) {
        super(mappingField.getOwner(), mappingField.getName(), null);
        this.srg = String.valueOf(new StringBuilder().append(mappingField.getOwner()).append("/").append(mappingField.getName()));
    }

    @Override
    public String serialise() {
        return this.srg;
    }

    private static String getNameFromSrg(String string) {
        String string2;
        if (MappingFieldSrg.llIllIllIlI(string)) {
            return null;
        }
        int n = string.lastIndexOf(47);
        if (MappingFieldSrg.llIllIllIll(n, -1)) {
            string2 = string.substring(n + 1);
            "".length();
            if ((0x80 ^ 0xC1 ^ (0x1B ^ 0x5E)) <= ((0xA8 ^ 0x91 ^ (0x57 ^ 0x62)) & (154 + 146 - 200 + 62 ^ 35 + 104 - 131 + 166 ^ -" ".length()))) {
                return null;
            }
        } else {
            string2 = string;
        }
        return string2;
    }

    private static String getOwnerFromSrg(String string) {
        String string2;
        if (MappingFieldSrg.llIllIllIlI(string)) {
            return null;
        }
        int n = string.lastIndexOf(47);
        if (MappingFieldSrg.llIllIllIll(n, -1)) {
            string2 = string.substring(0, n);
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string2 = null;
        }
        return string2;
    }

    private static boolean llIllIllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean llIllIllIlI(Object object) {
        return object == null;
    }
}

