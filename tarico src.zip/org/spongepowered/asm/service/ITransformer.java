/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.service;

public interface ITransformer {
}

