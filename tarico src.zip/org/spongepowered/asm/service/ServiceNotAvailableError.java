/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.service;

public class ServiceNotAvailableError
extends Error {
    private static final long serialVersionUID = 1L;

    public ServiceNotAvailableError(String string) {
        super(string);
    }
}

