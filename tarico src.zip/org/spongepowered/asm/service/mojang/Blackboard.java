/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.launchwrapper.Launch
 */
package org.spongepowered.asm.service.mojang;

import net.minecraft.launchwrapper.Launch;
import org.spongepowered.asm.service.IGlobalPropertyService;

public class Blackboard
implements IGlobalPropertyService {
    @Override
    public final <T> T getProperty(String string) {
        return (T)Launch.blackboard.get(string);
    }

    @Override
    public final void setProperty(String string, Object object) {
        Launch.blackboard.put(string, object);
        "".length();
    }

    @Override
    public final <T> T getProperty(String string, T t) {
        Object object;
        Object v = Launch.blackboard.get(string);
        if (Blackboard.llIlIllllI(v)) {
            object = v;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            object = t;
        }
        return (T)object;
    }

    @Override
    public final String getPropertyString(String string, String string2) {
        String string3;
        Object v = Launch.blackboard.get(string);
        if (Blackboard.llIlIllllI(v)) {
            string3 = v.toString();
            "".length();
            if (-" ".length() > "  ".length()) {
                return null;
            }
        } else {
            string3 = string2;
        }
        return string3;
    }

    private static boolean llIlIllllI(Object object) {
        return object != null;
    }
}

