/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.launchwrapper.LaunchClassLoader
 */
package org.spongepowered.asm.service.mojang;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.launchwrapper.LaunchClassLoader;

final class LaunchClassLoaderUtil {
    private static final String CACHED_CLASSES_FIELD;
    private static final String INVALID_CLASSES_FIELD;
    private static final String CLASS_LOADER_EXCEPTIONS_FIELD;
    private static final String TRANSFORMER_EXCEPTIONS_FIELD;
    private final LaunchClassLoader classLoader;
    private final Map<String, Class<?>> cachedClasses;
    private final Set<String> invalidClasses;
    private final Set<String> classLoaderExceptions;
    private final Set<String> transformerExceptions;

    LaunchClassLoaderUtil(LaunchClassLoader launchClassLoader) {
        this.classLoader = launchClassLoader;
        this.cachedClasses = (Map)LaunchClassLoaderUtil.getField(launchClassLoader, "cachedClasses");
        this.invalidClasses = (Set)LaunchClassLoaderUtil.getField(launchClassLoader, "invalidClasses");
        this.classLoaderExceptions = (Set)LaunchClassLoaderUtil.getField(launchClassLoader, "classLoaderExceptions");
        this.transformerExceptions = (Set)LaunchClassLoaderUtil.getField(launchClassLoader, "transformerExceptions");
    }

    LaunchClassLoader getClassLoader() {
        return this.classLoader;
    }

    boolean isClassLoaded(String string) {
        return this.cachedClasses.containsKey(string);
    }

    boolean isClassExcluded(String string, String string2) {
        boolean bl;
        if (!LaunchClassLoaderUtil.lIIllIlIIl(this.isClassClassLoaderExcluded(string, string2) ? 1 : 0) || LaunchClassLoaderUtil.lIIllIlIlI(this.isClassTransformerExcluded(string, string2) ? 1 : 0)) {
            bl = true;
            "".length();
            if ("  ".length() < 0) {
                return ((" ".length() ^ (6 ^ 0x45)) & (0xD3 ^ 0x8B ^ (0x21 ^ 0x3B) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    boolean isClassClassLoaderExcluded(String string, String string2) {
        Iterator<String> iterator = this.getClassLoaderExceptions().iterator();
        while (LaunchClassLoaderUtil.lIIllIlIlI(iterator.hasNext() ? 1 : 0)) {
            String string3 = iterator.next();
            if (LaunchClassLoaderUtil.lIIllIlIll(string2) && !LaunchClassLoaderUtil.lIIllIlIIl(string2.startsWith(string3) ? 1 : 0) || LaunchClassLoaderUtil.lIIllIlIlI(string.startsWith(string3) ? 1 : 0)) {
                return true;
            }
            "".length();
            if (-("   ".length() ^ (0x34 ^ 0x32)) < 0) continue;
            return ((0x51 ^ 0x23 ^ (0x6A ^ 0x3D)) & (0xEA ^ 0x9D ^ (7 ^ 0x55) ^ -" ".length())) != 0;
        }
        return false;
    }

    boolean isClassTransformerExcluded(String string, String string2) {
        Iterator<String> iterator = this.getTransformerExceptions().iterator();
        while (LaunchClassLoaderUtil.lIIllIlIlI(iterator.hasNext() ? 1 : 0)) {
            String string3 = iterator.next();
            if (LaunchClassLoaderUtil.lIIllIlIll(string2) && !LaunchClassLoaderUtil.lIIllIlIIl(string2.startsWith(string3) ? 1 : 0) || LaunchClassLoaderUtil.lIIllIlIlI(string.startsWith(string3) ? 1 : 0)) {
                return true;
            }
            "".length();
            if (((0x75 ^ 0x2D) & ~(0xFF ^ 0xA7)) == 0) continue;
            return ((0x58 ^ 0x70) & ~(0x87 ^ 0xAF)) != 0;
        }
        return false;
    }

    void registerInvalidClass(String string) {
        if (LaunchClassLoaderUtil.lIIllIlIll(this.invalidClasses)) {
            this.invalidClasses.add(string);
            "".length();
        }
    }

    Set<String> getClassLoaderExceptions() {
        if (LaunchClassLoaderUtil.lIIllIlIll(this.classLoaderExceptions)) {
            return this.classLoaderExceptions;
        }
        return Collections.emptySet();
    }

    Set<String> getTransformerExceptions() {
        if (LaunchClassLoaderUtil.lIIllIlIll(this.transformerExceptions)) {
            return this.transformerExceptions;
        }
        return Collections.emptySet();
    }

    private static <T> T getField(LaunchClassLoader launchClassLoader, String string) {
        try {
            Field field = LaunchClassLoader.class.getDeclaredField(string);
            field.setAccessible(true);
            return (T)field.get(launchClassLoader);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    static {
        TRANSFORMER_EXCEPTIONS_FIELD = "transformerExceptions";
        CLASS_LOADER_EXCEPTIONS_FIELD = "classLoaderExceptions";
        INVALID_CLASSES_FIELD = "invalidClasses";
        CACHED_CLASSES_FIELD = "cachedClasses";
    }

    private static boolean lIIllIlIll(Object object) {
        return object != null;
    }

    private static boolean lIIllIlIlI(int n) {
        return n != 0;
    }

    private static boolean lIIllIlIIl(int n) {
        return n == 0;
    }
}

