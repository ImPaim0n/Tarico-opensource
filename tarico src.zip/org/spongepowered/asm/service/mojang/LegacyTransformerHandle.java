/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Resource
 *  net.minecraft.launchwrapper.IClassTransformer
 */
package org.spongepowered.asm.service.mojang;

import javax.annotation.Resource;
import net.minecraft.launchwrapper.IClassTransformer;
import org.spongepowered.asm.service.ILegacyClassTransformer;

class LegacyTransformerHandle
implements ILegacyClassTransformer {
    private final IClassTransformer transformer;

    LegacyTransformerHandle(IClassTransformer iClassTransformer) {
        this.transformer = iClassTransformer;
    }

    @Override
    public String getName() {
        return this.transformer.getClass().getName();
    }

    @Override
    public boolean isDelegationExcluded() {
        boolean bl;
        if (LegacyTransformerHandle.lIIIIlllIllI(this.transformer.getClass().getAnnotation(Resource.class))) {
            bl = true;
            "".length();
            if ("  ".length() >= (0x42 ^ 0x46)) {
                return ((0x63 ^ 0x64) & ~(0xBB ^ 0xBC)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public byte[] transformClassBytes(String string, String string2, byte[] byArray) {
        return this.transformer.transform(string, string2, byArray);
    }

    private static boolean lIIIIlllIllI(Object object) {
        return object != null;
    }
}

