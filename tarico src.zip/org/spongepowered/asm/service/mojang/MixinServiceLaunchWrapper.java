/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  net.minecraft.launchwrapper.IClassNameTransformer
 *  net.minecraft.launchwrapper.IClassTransformer
 *  net.minecraft.launchwrapper.ITweaker
 *  net.minecraft.launchwrapper.Launch
 *  org.apache.commons.io.IOUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.service.mojang;

import com.google.common.collect.ImmutableList;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.minecraft.launchwrapper.IClassNameTransformer;
import net.minecraft.launchwrapper.IClassTransformer;
import net.minecraft.launchwrapper.ITweaker;
import net.minecraft.launchwrapper.Launch;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.launch.GlobalProperties;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.MixinEnvironment$Phase;
import org.spongepowered.asm.mixin.throwables.MixinException;
import org.spongepowered.asm.service.IClassBytecodeProvider;
import org.spongepowered.asm.service.IClassProvider;
import org.spongepowered.asm.service.ILegacyClassTransformer;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.ITransformer;
import org.spongepowered.asm.service.mojang.LaunchClassLoaderUtil;
import org.spongepowered.asm.service.mojang.LegacyTransformerHandle;
import org.spongepowered.asm.util.ReEntranceLock;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;

public class MixinServiceLaunchWrapper
implements IClassBytecodeProvider,
IClassProvider,
IMixinService {
    public static final String BLACKBOARD_KEY_TWEAKCLASSES;
    public static final String BLACKBOARD_KEY_TWEAKS;
    private static final String LAUNCH_PACKAGE;
    private static final String MIXIN_PACKAGE;
    private static final String STATE_TWEAKER;
    private static final String TRANSFORMER_PROXY_CLASS;
    private static final Logger logger;
    private final LaunchClassLoaderUtil classLoaderUtil = new LaunchClassLoaderUtil(Launch.classLoader);
    private final ReEntranceLock lock = new ReEntranceLock(1);
    private IClassNameTransformer nameTransformer;

    @Override
    public String getName() {
        return "LaunchWrapper";
    }

    @Override
    public boolean isValid() {
        try {
            Launch.classLoader.hashCode();
            "".length();
            "".length();
        }
        catch (Throwable throwable) {
            return false;
        }
        if ("   ".length() < ((0x97 ^ 0x91 ^ (0xB2 ^ 0x88)) & (130 + 144 - 241 + 146 ^ 73 + 121 - 174 + 123 ^ -" ".length()))) {
            return ((0x8E ^ 0x85 ^ "  ".length()) & (0x48 ^ 8 ^ (0x78 ^ 0x31) ^ -" ".length())) != 0;
        }
        return true;
    }

    @Override
    public void prepare() {
        Launch.classLoader.addClassLoaderExclusion("org.spongepowered.asm.launch.");
    }

    @Override
    public MixinEnvironment$Phase getInitialPhase() {
        if (MixinServiceLaunchWrapper.lIlIIllIIlI(MixinServiceLaunchWrapper.findInStackTrace("net.minecraft.launchwrapper.Launch", "launch"), 132)) {
            return MixinEnvironment$Phase.DEFAULT;
        }
        return MixinEnvironment$Phase.PREINIT;
    }

    @Override
    public void init() {
        List list;
        if (MixinServiceLaunchWrapper.lIlIIllIIll(MixinServiceLaunchWrapper.findInStackTrace("net.minecraft.launchwrapper.Launch", "launch"), 4)) {
            logger.error("MixinBootstrap.doInit() called during a tweak constructor!");
        }
        if (MixinServiceLaunchWrapper.lIlIIllIlII(list = (List)GlobalProperties.get("TweakClasses"))) {
            list.add("org.spongepowered.asm.mixin.EnvironmentStateTweaker");
            "".length();
        }
    }

    @Override
    public ReEntranceLock getReEntranceLock() {
        return this.lock;
    }

    @Override
    public Collection<String> getPlatformAgents() {
        return ImmutableList.of((Object)"org.spongepowered.asm.launch.platform.MixinPlatformAgentFML");
    }

    @Override
    public IClassProvider getClassProvider() {
        return this;
    }

    @Override
    public IClassBytecodeProvider getBytecodeProvider() {
        return this;
    }

    @Override
    public Class<?> findClass(String string) {
        return Launch.classLoader.findClass(string);
    }

    @Override
    public Class<?> findClass(String string, boolean bl) {
        return Class.forName(string, bl, (ClassLoader)Launch.classLoader);
    }

    @Override
    public Class<?> findAgentClass(String string, boolean bl) {
        return Class.forName(string, bl, Launch.class.getClassLoader());
    }

    @Override
    public void beginPhase() {
        Launch.classLoader.registerTransformer("org.spongepowered.asm.mixin.transformer.Proxy");
    }

    @Override
    public void checkEnv(Object object) {
        if (MixinServiceLaunchWrapper.lIlIIllIlIl(object.getClass().getClassLoader(), Launch.class.getClassLoader())) {
            throw new MixinException("Attempted to init the mixin environment in the wrong classloader");
        }
    }

    @Override
    public InputStream getResourceAsStream(String string) {
        return Launch.classLoader.getResourceAsStream(string);
    }

    @Override
    public void registerInvalidClass(String string) {
        this.classLoaderUtil.registerInvalidClass(string);
    }

    @Override
    public boolean isClassLoaded(String string) {
        return this.classLoaderUtil.isClassLoaded(string);
    }

    @Override
    public String getClassRestrictions(String string) {
        String string2 = "";
        if (MixinServiceLaunchWrapper.lIlIIllIllI(this.classLoaderUtil.isClassClassLoaderExcluded(string, null) ? 1 : 0)) {
            string2 = "PACKAGE_CLASSLOADER_EXCLUSION";
        }
        if (MixinServiceLaunchWrapper.lIlIIllIllI(this.classLoaderUtil.isClassTransformerExcluded(string, null) ? 1 : 0)) {
            String string3;
            StringBuilder stringBuilder = new StringBuilder();
            if (MixinServiceLaunchWrapper.lIlIIllIlll(string2.length())) {
                string3 = String.valueOf(new StringBuilder().append(string2).append(","));
                "".length();
                if (-" ".length() >= 0) {
                    return null;
                }
            } else {
                string3 = "";
            }
            string2 = String.valueOf(stringBuilder.append(string3).append("PACKAGE_TRANSFORMER_EXCLUSION"));
        }
        return string2;
    }

    @Override
    public URL[] getClassPath() {
        return Launch.classLoader.getSources().toArray(new URL[0]);
    }

    @Override
    public Collection<ITransformer> getTransformers() {
        List list = Launch.classLoader.getTransformers();
        ArrayList<ITransformer> arrayList = new ArrayList<ITransformer>(list.size());
        Iterator iterator = list.iterator();
        while (MixinServiceLaunchWrapper.lIlIIllIllI(iterator.hasNext() ? 1 : 0)) {
            IClassTransformer iClassTransformer = (IClassTransformer)iterator.next();
            if (MixinServiceLaunchWrapper.lIlIIllIllI(iClassTransformer instanceof ITransformer)) {
                arrayList.add((ITransformer)iClassTransformer);
                "".length();
                "".length();
                if ("  ".length() == 0) {
                    return null;
                }
            } else {
                arrayList.add(new LegacyTransformerHandle(iClassTransformer));
                "".length();
            }
            if (MixinServiceLaunchWrapper.lIlIIllIllI(iClassTransformer instanceof IClassNameTransformer)) {
                logger.debug("Found name transformer: {}", new Object[]{iClassTransformer.getClass().getName()});
                this.nameTransformer = (IClassNameTransformer)iClassTransformer;
            }
            "".length();
            if (" ".length() > 0) continue;
            return null;
        }
        return arrayList;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public byte[] getClassBytes(String string, String string2) {
        byte[] byArray = Launch.classLoader.getClassBytes(string);
        if (MixinServiceLaunchWrapper.lIlIIllIlII(byArray)) {
            return byArray;
        }
        URLClassLoader uRLClassLoader = (URLClassLoader)Launch.class.getClassLoader();
        InputStream inputStream = null;
        try {
            String string3 = string2.replace('.', '/').concat(".class");
            inputStream = uRLClassLoader.getResourceAsStream(string3);
            byte[] byArray2 = IOUtils.toByteArray((InputStream)inputStream);
            IOUtils.closeQuietly((InputStream)inputStream);
            return byArray2;
        }
        catch (Exception exception) {
            byte[] byArray3 = null;
            return byArray3;
        }
        finally {
            IOUtils.closeQuietly(inputStream);
        }
    }

    @Override
    public byte[] getClassBytes(String string, boolean bl) {
        String string2 = string.replace('/', '.');
        String string3 = this.unmapClassName(string2);
        Profiler profiler = MixinEnvironment.getProfiler();
        Profiler$Section profiler$Section = profiler.begin(1, "class.load");
        byte[] byArray = this.getClassBytes(string3, string2);
        profiler$Section.end();
        "".length();
        if (MixinServiceLaunchWrapper.lIlIIllIllI(bl ? 1 : 0)) {
            Profiler$Section profiler$Section2 = profiler.begin(1, "class.transform");
            byArray = this.applyTransformers(string3, string2, byArray, profiler);
            profiler$Section2.end();
            "".length();
        }
        if (MixinServiceLaunchWrapper.lIlIIlllIII(byArray)) {
            throw new ClassNotFoundException(String.format("The specified class '%s' was not found", string2));
        }
        return byArray;
    }

    private byte[] applyTransformers(String string, String string2, byte[] byArray, Profiler profiler) {
        if (MixinServiceLaunchWrapper.lIlIIllIllI(this.classLoaderUtil.isClassExcluded(string, string2) ? 1 : 0)) {
            return byArray;
        }
        MixinEnvironment mixinEnvironment = MixinEnvironment.getCurrentEnvironment();
        Iterator<ILegacyClassTransformer> iterator = mixinEnvironment.getTransformers().iterator();
        while (MixinServiceLaunchWrapper.lIlIIllIllI(iterator.hasNext() ? 1 : 0)) {
            ILegacyClassTransformer iLegacyClassTransformer = iterator.next();
            this.lock.clear();
            "".length();
            int n = iLegacyClassTransformer.getName().lastIndexOf(46);
            String string3 = iLegacyClassTransformer.getName().substring(n + 1);
            Profiler$Section profiler$Section = profiler.begin(2, string3.toLowerCase());
            profiler$Section.setInfo(iLegacyClassTransformer.getName());
            byArray = iLegacyClassTransformer.transformClassBytes(string, string2, byArray);
            profiler$Section.end();
            "".length();
            if (MixinServiceLaunchWrapper.lIlIIllIllI(this.lock.isSet() ? 1 : 0)) {
                mixinEnvironment.addTransformerExclusion(iLegacyClassTransformer.getName());
                this.lock.clear();
                "".length();
                logger.info("A re-entrant transformer '{}' was detected and will no longer process meta class data", new Object[]{iLegacyClassTransformer.getName()});
            }
            "".length();
            if (-"   ".length() < 0) continue;
            return null;
        }
        return byArray;
    }

    private String unmapClassName(String string) {
        if (MixinServiceLaunchWrapper.lIlIIlllIII(this.nameTransformer)) {
            this.findNameTransformer();
        }
        if (MixinServiceLaunchWrapper.lIlIIllIlII(this.nameTransformer)) {
            return this.nameTransformer.unmapClassName(string);
        }
        return string;
    }

    private void findNameTransformer() {
        List list = Launch.classLoader.getTransformers();
        Iterator iterator = list.iterator();
        while (MixinServiceLaunchWrapper.lIlIIllIllI(iterator.hasNext() ? 1 : 0)) {
            IClassTransformer iClassTransformer = (IClassTransformer)iterator.next();
            if (MixinServiceLaunchWrapper.lIlIIllIllI(iClassTransformer instanceof IClassNameTransformer)) {
                logger.debug("Found name transformer: {}", new Object[]{iClassTransformer.getClass().getName()});
                this.nameTransformer = (IClassNameTransformer)iClassTransformer;
            }
            "".length();
            if ("  ".length() < "   ".length()) continue;
            return;
        }
    }

    @Override
    public ClassNode getClassNode(String string) {
        return this.getClassNode(this.getClassBytes(string, true), 0);
    }

    private ClassNode getClassNode(byte[] byArray, int n) {
        ClassNode classNode = new ClassNode();
        ClassReader classReader = new ClassReader(byArray);
        classReader.accept(classNode, n);
        return classNode;
    }

    @Override
    public final String getSideName() {
        Object object = ((List)GlobalProperties.get("Tweaks")).iterator();
        while (MixinServiceLaunchWrapper.lIlIIllIllI(object.hasNext() ? 1 : 0)) {
            ITweaker iTweaker = (ITweaker)object.next();
            if (MixinServiceLaunchWrapper.lIlIIllIllI(iTweaker.getClass().getName().endsWith(".common.launcher.FMLServerTweaker") ? 1 : 0)) {
                return "SERVER";
            }
            if (MixinServiceLaunchWrapper.lIlIIllIllI(iTweaker.getClass().getName().endsWith(".common.launcher.FMLTweaker") ? 1 : 0)) {
                return "CLIENT";
            }
            "".length();
            if (((0x23 ^ 0x2D) & ~(0x89 ^ 0x87)) == 0) continue;
            return null;
        }
        object = this.getSideName("net.minecraftforge.fml.relauncher.FMLLaunchHandler", "side");
        if (MixinServiceLaunchWrapper.lIlIIllIlII(object)) {
            return object;
        }
        object = this.getSideName("cpw.mods.fml.relauncher.FMLLaunchHandler", "side");
        if (MixinServiceLaunchWrapper.lIlIIllIlII(object)) {
            return object;
        }
        object = this.getSideName("com.mumfrey.liteloader.launch.LiteLoaderTweaker", "getEnvironmentType");
        if (MixinServiceLaunchWrapper.lIlIIllIlII(object)) {
            return object;
        }
        return "UNKNOWN";
    }

    private String getSideName(String string, String string2) {
        try {
            Class<?> clazz = Class.forName(string, false, (ClassLoader)Launch.classLoader);
            Method method = clazz.getDeclaredMethod(string2, new Class[0]);
            return ((Enum)method.invoke(null, new Object[0])).name();
        }
        catch (Exception exception) {
            return null;
        }
    }

    private static int findInStackTrace(String string, String string2) {
        StackTraceElement[] stackTraceElementArray;
        Thread thread = Thread.currentThread();
        if (MixinServiceLaunchWrapper.lIlIIlllIIl("main".equals(thread.getName()) ? 1 : 0)) {
            return 0;
        }
        StackTraceElement[] stackTraceElementArray2 = stackTraceElementArray = thread.getStackTrace();
        int n = stackTraceElementArray2.length;
        int n2 = 0;
        while (MixinServiceLaunchWrapper.lIlIIllIIll(n2, n)) {
            StackTraceElement stackTraceElement = stackTraceElementArray2[n2];
            if (MixinServiceLaunchWrapper.lIlIIllIllI(string.equals(stackTraceElement.getClassName()) ? 1 : 0) && MixinServiceLaunchWrapper.lIlIIllIllI(string2.equals(stackTraceElement.getMethodName()) ? 1 : 0)) {
                return stackTraceElement.getLineNumber();
            }
            ++n2;
            "".length();
            if (" ".length() < "  ".length()) continue;
            return (0x95 ^ 0xA7) & ~(0x25 ^ 0x17);
        }
        return 0;
    }

    static {
        LAUNCH_PACKAGE = "org.spongepowered.asm.launch.";
        TRANSFORMER_PROXY_CLASS = "org.spongepowered.asm.mixin.transformer.Proxy";
        MIXIN_PACKAGE = "org.spongepowered.asm.mixin.";
        BLACKBOARD_KEY_TWEAKCLASSES = "TweakClasses";
        STATE_TWEAKER = "org.spongepowered.asm.mixin.EnvironmentStateTweaker";
        BLACKBOARD_KEY_TWEAKS = "Tweaks";
        logger = LogManager.getLogger((String)"mixin");
    }

    private static boolean lIlIIllIIll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIIllIIlI(int n, int n2) {
        return n > n2;
    }

    private static boolean lIlIIllIlIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIlIIllIlII(Object object) {
        return object != null;
    }

    private static boolean lIlIIlllIII(Object object) {
        return object == null;
    }

    private static boolean lIlIIllIllI(int n) {
        return n != 0;
    }

    private static boolean lIlIIlllIIl(int n) {
        return n == 0;
    }

    private static boolean lIlIIllIlll(int n) {
        return n > 0;
    }
}

