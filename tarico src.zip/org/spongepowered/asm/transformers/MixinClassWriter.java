/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.transformers;

import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.mixin.transformer.ClassInfo;

public class MixinClassWriter
extends ClassWriter {
    public MixinClassWriter(int n) {
        super(n);
    }

    public MixinClassWriter(ClassReader classReader, int n) {
        super(classReader, n);
    }

    @Override
    protected String getCommonSuperClass(String string, String string2) {
        return ClassInfo.getCommonSuperClass(string, string2).getName();
    }
}

