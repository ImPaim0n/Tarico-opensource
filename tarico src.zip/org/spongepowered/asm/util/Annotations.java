/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Function
 *  com.google.common.base.Preconditions
 *  com.google.common.collect.Lists
 */
package org.spongepowered.asm.util;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.util.Annotations$1;

public final class Annotations {
    private Annotations() {
    }

    public static void setVisible(FieldNode fieldNode, Class<? extends Annotation> clazz, Object ... objectArray) {
        AnnotationNode annotationNode = Annotations.createNode(Type.getDescriptor(clazz), objectArray);
        fieldNode.visibleAnnotations = Annotations.add(fieldNode.visibleAnnotations, annotationNode);
    }

    public static void setInvisible(FieldNode fieldNode, Class<? extends Annotation> clazz, Object ... objectArray) {
        AnnotationNode annotationNode = Annotations.createNode(Type.getDescriptor(clazz), objectArray);
        fieldNode.invisibleAnnotations = Annotations.add(fieldNode.invisibleAnnotations, annotationNode);
    }

    public static void setVisible(MethodNode methodNode, Class<? extends Annotation> clazz, Object ... objectArray) {
        AnnotationNode annotationNode = Annotations.createNode(Type.getDescriptor(clazz), objectArray);
        methodNode.visibleAnnotations = Annotations.add(methodNode.visibleAnnotations, annotationNode);
    }

    public static void setInvisible(MethodNode methodNode, Class<? extends Annotation> clazz, Object ... objectArray) {
        AnnotationNode annotationNode = Annotations.createNode(Type.getDescriptor(clazz), objectArray);
        methodNode.invisibleAnnotations = Annotations.add(methodNode.invisibleAnnotations, annotationNode);
    }

    private static AnnotationNode createNode(String string, Object ... objectArray) {
        AnnotationNode annotationNode = new AnnotationNode(string);
        int n = 0;
        while (Annotations.llIllllIlII(n, objectArray.length - 1)) {
            if (Annotations.llIllllIlIl(objectArray[n] instanceof String)) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Annotation keys must be strings, found ").append(objectArray[n].getClass().getSimpleName()).append(" with ").append(objectArray[n].toString()).append(" at index ").append(n).append(" creating ").append(string)));
            }
            annotationNode.visit((String)objectArray[n], objectArray[n + 1]);
            n += 2;
            "".length();
            if ("  ".length() != 0) continue;
            return null;
        }
        return annotationNode;
    }

    private static List<AnnotationNode> add(List<AnnotationNode> list, AnnotationNode annotationNode) {
        if (Annotations.llIllllIllI(list)) {
            list = new ArrayList<AnnotationNode>(1);
            "".length();
            if ("   ".length() == 0) {
                return null;
            }
        } else {
            list.remove(Annotations.get(list, annotationNode.desc));
            "".length();
        }
        list.add(annotationNode);
        "".length();
        return list;
    }

    public static AnnotationNode getVisible(FieldNode fieldNode, Class<? extends Annotation> clazz) {
        return Annotations.get(fieldNode.visibleAnnotations, Type.getDescriptor(clazz));
    }

    public static AnnotationNode getInvisible(FieldNode fieldNode, Class<? extends Annotation> clazz) {
        return Annotations.get(fieldNode.invisibleAnnotations, Type.getDescriptor(clazz));
    }

    public static AnnotationNode getVisible(MethodNode methodNode, Class<? extends Annotation> clazz) {
        return Annotations.get(methodNode.visibleAnnotations, Type.getDescriptor(clazz));
    }

    public static AnnotationNode getInvisible(MethodNode methodNode, Class<? extends Annotation> clazz) {
        return Annotations.get(methodNode.invisibleAnnotations, Type.getDescriptor(clazz));
    }

    public static AnnotationNode getSingleVisible(MethodNode methodNode, Class<? extends Annotation> ... classArray) {
        return Annotations.getSingle(methodNode.visibleAnnotations, classArray);
    }

    public static AnnotationNode getSingleInvisible(MethodNode methodNode, Class<? extends Annotation> ... classArray) {
        return Annotations.getSingle(methodNode.invisibleAnnotations, classArray);
    }

    public static AnnotationNode getVisible(ClassNode classNode, Class<? extends Annotation> clazz) {
        return Annotations.get(classNode.visibleAnnotations, Type.getDescriptor(clazz));
    }

    public static AnnotationNode getInvisible(ClassNode classNode, Class<? extends Annotation> clazz) {
        return Annotations.get(classNode.invisibleAnnotations, Type.getDescriptor(clazz));
    }

    public static AnnotationNode getVisibleParameter(MethodNode methodNode, Class<? extends Annotation> clazz, int n) {
        return Annotations.getParameter(methodNode.visibleParameterAnnotations, Type.getDescriptor(clazz), n);
    }

    public static AnnotationNode getInvisibleParameter(MethodNode methodNode, Class<? extends Annotation> clazz, int n) {
        return Annotations.getParameter(methodNode.invisibleParameterAnnotations, Type.getDescriptor(clazz), n);
    }

    public static AnnotationNode getParameter(List<AnnotationNode>[] listArray, String string, int n) {
        if (!Annotations.llIllllIlll(listArray) || !Annotations.llIlllllIII(n) || Annotations.llIlllllIIl(n, listArray.length)) {
            return null;
        }
        return Annotations.get(listArray[n], string);
    }

    public static AnnotationNode get(List<AnnotationNode> list, String string) {
        if (Annotations.llIllllIllI(list)) {
            return null;
        }
        Iterator<AnnotationNode> iterator = list.iterator();
        while (Annotations.llIlllllIlI(iterator.hasNext() ? 1 : 0)) {
            AnnotationNode annotationNode = iterator.next();
            if (Annotations.llIlllllIlI(string.equals(annotationNode.desc) ? 1 : 0)) {
                return annotationNode;
            }
            "".length();
            if (((0xFF ^ 0x98 ^ (0x1C ^ 0x42)) & (0xD9 ^ 0xA9 ^ (0xD ^ 0x44) ^ -" ".length())) == ((123 + 87 - 64 + 36 ^ 31 + 80 - 72 + 138) & (100 + 48 - 123 + 145 ^ 9 + 124 - 50 + 90 ^ -" ".length()))) continue;
            return null;
        }
        return null;
    }

    private static AnnotationNode getSingle(List<AnnotationNode> list, Class<? extends Annotation>[] classArray) {
        AnnotationNode annotationNode;
        ArrayList<AnnotationNode> arrayList = new ArrayList<AnnotationNode>();
        Class<? extends Annotation>[] classArray2 = classArray;
        int n = classArray2.length;
        int n2 = 0;
        while (Annotations.llIllllIlII(n2, n)) {
            Class<? extends Annotation> clazz = classArray2[n2];
            AnnotationNode annotationNode2 = Annotations.get(list, Type.getDescriptor(clazz));
            if (Annotations.llIllllIlll(annotationNode2)) {
                arrayList.add(annotationNode2);
                "".length();
            }
            ++n2;
            "".length();
            if (-" ".length() < "   ".length()) continue;
            return null;
        }
        int n3 = arrayList.size();
        if (Annotations.llIlllllIll(n3, 1)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Conflicting annotations found: ").append(Lists.transform(arrayList, (Function)new Annotations$1()))));
        }
        if (Annotations.llIllllIlIl(n3)) {
            annotationNode = null;
            "".length();
            if (" ".length() >= "   ".length()) {
                return null;
            }
        } else {
            annotationNode = (AnnotationNode)arrayList.get(0);
        }
        return annotationNode;
    }

    public static <T> T getValue(AnnotationNode annotationNode) {
        return Annotations.getValue(annotationNode, "value");
    }

    public static <T> T getValue(AnnotationNode annotationNode, String string, T t) {
        T t2;
        T t3 = Annotations.getValue(annotationNode, string);
        if (Annotations.llIllllIlll(t3)) {
            t2 = t3;
            "".length();
            if (((0x1B ^ 0x52) & ~(0x7B ^ 0x32)) > "  ".length()) {
                return null;
            }
        } else {
            t2 = t;
        }
        return t2;
    }

    public static <T> T getValue(AnnotationNode annotationNode, String string, Class<?> clazz) {
        Preconditions.checkNotNull(clazz, (Object)"annotationClass cannot be null");
        "".length();
        Object object = Annotations.getValue(annotationNode, string);
        if (Annotations.llIllllIllI(object)) {
            try {
                object = clazz.getDeclaredMethod(string, new Class[0]).getDefaultValue();
                "".length();
            }
            catch (NoSuchMethodException noSuchMethodException) {
                // empty catch block
            }
            if (null != null) {
                return null;
            }
        }
        return object;
    }

    public static <T> T getValue(AnnotationNode annotationNode, String string) {
        int n = 0;
        if (!Annotations.llIllllIlll(annotationNode) || Annotations.llIllllIllI(annotationNode.values)) {
            return null;
        }
        Iterator<Object> iterator = annotationNode.values.iterator();
        while (Annotations.llIlllllIlI(iterator.hasNext() ? 1 : 0)) {
            Object object = iterator.next();
            if (Annotations.llIlllllIlI(n)) {
                return (T)object;
            }
            if (Annotations.llIlllllIlI(object.equals(string) ? 1 : 0)) {
                n = 1;
            }
            "".length();
            if ("  ".length() > " ".length()) continue;
            return null;
        }
        return null;
    }

    public static <T extends Enum<T>> T getValue(AnnotationNode annotationNode, String string, Class<T> clazz, T t) {
        String[] stringArray = (String[])Annotations.getValue(annotationNode, string);
        if (Annotations.llIllllIllI(stringArray)) {
            return t;
        }
        return Annotations.toEnumValue(clazz, stringArray);
    }

    public static <T> List<T> getValue(AnnotationNode annotationNode, String string, boolean bl) {
        T t = Annotations.getValue(annotationNode, string);
        if (Annotations.llIlllllIlI(t instanceof List)) {
            return (List)t;
        }
        if (Annotations.llIllllIlll(t)) {
            ArrayList<T> arrayList = new ArrayList<T>();
            arrayList.add(t);
            "".length();
            return arrayList;
        }
        return Collections.emptyList();
    }

    public static <T extends Enum<T>> List<T> getValue(AnnotationNode annotationNode, String string, boolean bl, Class<T> clazz) {
        T t = Annotations.getValue(annotationNode, string);
        if (Annotations.llIlllllIlI(t instanceof List)) {
            ListIterator<T> listIterator = ((List)t).listIterator();
            while (Annotations.llIlllllIlI(listIterator.hasNext() ? 1 : 0)) {
                listIterator.set(Annotations.toEnumValue(clazz, (String[])listIterator.next()));
                "".length();
                if (-" ".length() <= (0x84 ^ 0x80)) continue;
                return null;
            }
            return (List)t;
        }
        if (Annotations.llIlllllIlI(t instanceof String[])) {
            ArrayList<T> arrayList = new ArrayList<T>();
            arrayList.add(Annotations.toEnumValue(clazz, (String[])t));
            "".length();
            return arrayList;
        }
        return Collections.emptyList();
    }

    private static <T extends Enum<T>> T toEnumValue(Class<T> clazz, String[] stringArray) {
        if (Annotations.llIllllIlIl(clazz.getName().equals(Type.getType(stringArray[0]).getClassName()) ? 1 : 0)) {
            throw new IllegalArgumentException("The supplied enum class does not match the stored enum value");
        }
        return Enum.valueOf(clazz, stringArray[1]);
    }

    private static boolean llIlllllIIl(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIllllIlII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlllllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean llIllllIlll(Object object) {
        return object != null;
    }

    private static boolean llIllllIllI(Object object) {
        return object == null;
    }

    private static boolean llIlllllIlI(int n) {
        return n != 0;
    }

    private static boolean llIllllIlIl(int n) {
        return n == 0;
    }

    private static boolean llIlllllIII(int n) {
        return n >= 0;
    }
}

