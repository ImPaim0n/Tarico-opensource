/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

public final class Bytecode$Visibility
extends Enum<Bytecode$Visibility> {
    public static final /* enum */ Bytecode$Visibility PRIVATE;
    public static final /* enum */ Bytecode$Visibility PROTECTED;
    public static final /* enum */ Bytecode$Visibility PACKAGE;
    public static final /* enum */ Bytecode$Visibility PUBLIC;
    static final int MASK;
    final int access;
    private static final /* synthetic */ Bytecode$Visibility[] $VALUES;

    public static Bytecode$Visibility[] values() {
        return (Bytecode$Visibility[])$VALUES.clone();
    }

    public static Bytecode$Visibility valueOf(String string) {
        return Enum.valueOf(Bytecode$Visibility.class, string);
    }

    private Bytecode$Visibility(int n2) {
        this.access = n2;
    }

    static {
        MASK = 7;
        PRIVATE = new Bytecode$Visibility(2);
        PROTECTED = new Bytecode$Visibility(4);
        PACKAGE = new Bytecode$Visibility(0);
        PUBLIC = new Bytecode$Visibility(1);
        $VALUES = new Bytecode$Visibility[]{PRIVATE, PROTECTED, PACKAGE, PUBLIC};
    }
}

