/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Joiner
 *  com.google.common.primitives.Ints
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.util;

import com.google.common.base.Joiner;
import com.google.common.primitives.Ints;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.lib.ClassReader;
import org.spongepowered.asm.lib.ClassWriter;
import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.FieldInsnNode;
import org.spongepowered.asm.lib.tree.FieldNode;
import org.spongepowered.asm.lib.tree.FrameNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.IntInsnNode;
import org.spongepowered.asm.lib.tree.JumpInsnNode;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.LdcInsnNode;
import org.spongepowered.asm.lib.tree.LineNumberNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.lib.util.CheckClassAdapter;
import org.spongepowered.asm.lib.util.TraceClassVisitor;
import org.spongepowered.asm.mixin.Debug;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Intrinsic;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.util.Bytecode$Visibility;
import org.spongepowered.asm.util.Constants;
import org.spongepowered.asm.util.throwables.SyntheticBridgeException;
import org.spongepowered.asm.util.throwables.SyntheticBridgeException$Problem;

public final class Bytecode {
    public static final int[] CONSTANTS_INT = new int[]{2, 3, 4, 5, 6, 7, 8};
    public static final int[] CONSTANTS_FLOAT = new int[]{11, 12, 13};
    public static final int[] CONSTANTS_DOUBLE = new int[]{14, 15};
    public static final int[] CONSTANTS_LONG = new int[]{9, 10};
    public static final int[] CONSTANTS_ALL = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
    private static final Object[] CONSTANTS_VALUES = new Object[]{null, -1, 0, 1, 2, 3, 4, 5, 0L, 1L, Float.valueOf(0.0f), Float.valueOf(1.0f), Float.valueOf(2.0f), 0.0, 1.0};
    private static final String[] CONSTANTS_TYPES = new String[]{null, "I", "I", "I", "I", "I", "I", "I", "J", "J", "F", "F", "F", "D", "D", "I", "I"};
    private static final String[] BOXING_TYPES = new String[]{null, "java/lang/Boolean", "java/lang/Character", "java/lang/Byte", "java/lang/Short", "java/lang/Integer", "java/lang/Float", "java/lang/Long", "java/lang/Double", null, null, null};
    private static final String[] UNBOXING_METHODS = new String[]{null, "booleanValue", "charValue", "byteValue", "shortValue", "intValue", "floatValue", "longValue", "doubleValue", null, null, null};
    private static final Class<?>[] MERGEABLE_MIXIN_ANNOTATIONS = new Class[]{Overwrite.class, Intrinsic.class, Final.class, Debug.class};
    private static Pattern mergeableAnnotationPattern = Bytecode.getMergeableAnnotationPattern();
    private static final Logger logger = LogManager.getLogger((String)"mixin");

    private Bytecode() {
    }

    public static MethodNode findMethod(ClassNode classNode, String string, String string2) {
        Iterator<MethodNode> iterator = classNode.methods.iterator();
        while (Bytecode.lllllIII(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            if (Bytecode.lllllIII(methodNode.name.equals(string) ? 1 : 0) && Bytecode.lllllIII(methodNode.desc.equals(string2) ? 1 : 0)) {
                return methodNode;
            }
            "".length();
            if ((0x1E ^ 0x1A) >= 0) continue;
            return null;
        }
        return null;
    }

    public static AbstractInsnNode findInsn(MethodNode methodNode, int n) {
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (Bytecode.lllllIIl(abstractInsnNode.getOpcode(), n)) {
                return abstractInsnNode;
            }
            "".length();
            if (-(0x36 ^ 0x3A ^ (0x18 ^ 0x10)) <= 0) continue;
            return null;
        }
        return null;
    }

    public static MethodInsnNode findSuperInit(MethodNode methodNode, String string) {
        if (Bytecode.lllllIlI("<init>".equals(methodNode.name) ? 1 : 0)) {
            return null;
        }
        int n = 0;
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (Bytecode.lllllIII(abstractInsnNode instanceof TypeInsnNode) && Bytecode.lllllIIl(abstractInsnNode.getOpcode(), 187)) {
                ++n;
                "".length();
                if ("  ".length() == 0) {
                    return null;
                }
            } else if (Bytecode.lllllIII(abstractInsnNode instanceof MethodInsnNode) && Bytecode.lllllIIl(abstractInsnNode.getOpcode(), 183)) {
                MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
                if (Bytecode.lllllIII("<init>".equals(methodInsnNode.name) ? 1 : 0)) {
                    if (Bytecode.lllllIll(n)) {
                        --n;
                        "".length();
                        if (-"   ".length() > 0) {
                            return null;
                        }
                    } else if (Bytecode.lllllIII(methodInsnNode.owner.equals(string) ? 1 : 0)) {
                        return methodInsnNode;
                    }
                }
            }
            "".length();
            if ("  ".length() > ((0x49 ^ 0x1B) & ~(0x70 ^ 0x22))) continue;
            return null;
        }
        return null;
    }

    public static void textify(ClassNode classNode, OutputStream outputStream) {
        classNode.accept(new TraceClassVisitor(new PrintWriter(outputStream)));
    }

    public static void textify(MethodNode methodNode, OutputStream outputStream) {
        TraceClassVisitor traceClassVisitor = new TraceClassVisitor(new PrintWriter(outputStream));
        MethodVisitor methodVisitor = traceClassVisitor.visitMethod(methodNode.access, methodNode.name, methodNode.desc, methodNode.signature, methodNode.exceptions.toArray(new String[0]));
        methodNode.accept(methodVisitor);
        traceClassVisitor.visitEnd();
    }

    public static void dumpClass(ClassNode classNode) {
        ClassWriter classWriter = new ClassWriter(3);
        classNode.accept(classWriter);
        Bytecode.dumpClass(classWriter.toByteArray());
    }

    public static void dumpClass(byte[] byArray) {
        ClassReader classReader = new ClassReader(byArray);
        CheckClassAdapter.verify(classReader, true, new PrintWriter(System.out));
    }

    public static void printMethodWithOpcodeIndices(MethodNode methodNode) {
        System.err.printf("%s%s\n", methodNode.name, methodNode.desc);
        "".length();
        int n = 0;
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
            System.err.printf("[%4d] %s\n", n++, Bytecode.describeNode((AbstractInsnNode)listIterator.next()));
            "".length();
            "".length();
            if ("  ".length() >= -" ".length()) continue;
            return;
        }
    }

    public static void printMethod(MethodNode methodNode) {
        System.err.printf("%s%s\n", methodNode.name, methodNode.desc);
        "".length();
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
            System.err.print("  ");
            Bytecode.printNode((AbstractInsnNode)listIterator.next());
            "".length();
            if ("   ".length() >= -" ".length()) continue;
            return;
        }
    }

    public static void printNode(AbstractInsnNode abstractInsnNode) {
        System.err.printf("%s\n", Bytecode.describeNode(abstractInsnNode));
        "".length();
    }

    public static String describeNode(AbstractInsnNode abstractInsnNode) {
        if (Bytecode.llllllII(abstractInsnNode)) {
            return String.format("   %-14s ", "null");
        }
        if (Bytecode.lllllIII(abstractInsnNode instanceof LabelNode)) {
            return String.format("[%s]", ((LabelNode)abstractInsnNode).getLabel());
        }
        String string = String.format("   %-14s ", abstractInsnNode.getClass().getSimpleName().replace("Node", ""));
        if (Bytecode.lllllIII(abstractInsnNode instanceof JumpInsnNode)) {
            string = String.valueOf(new StringBuilder().append(string).append(String.format("[%s] [%s]", Bytecode.getOpcodeName(abstractInsnNode), ((JumpInsnNode)abstractInsnNode).label.getLabel())));
            "".length();
            if (-"   ".length() >= 0) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof VarInsnNode)) {
            string = String.valueOf(new StringBuilder().append(string).append(String.format("[%s] %d", Bytecode.getOpcodeName(abstractInsnNode), ((VarInsnNode)abstractInsnNode).var)));
            "".length();
            if ("  ".length() < ((0x36 ^ 0x24) & ~(0x4C ^ 0x5E))) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof MethodInsnNode)) {
            MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
            string = String.valueOf(new StringBuilder().append(string).append(String.format("[%s] %s %s %s", Bytecode.getOpcodeName(abstractInsnNode), methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc)));
            "".length();
            if (-"   ".length() > 0) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof FieldInsnNode)) {
            FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
            string = String.valueOf(new StringBuilder().append(string).append(String.format("[%s] %s %s %s", Bytecode.getOpcodeName(abstractInsnNode), fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc)));
            "".length();
            if (-"   ".length() >= 0) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof LineNumberNode)) {
            LineNumberNode lineNumberNode = (LineNumberNode)abstractInsnNode;
            string = String.valueOf(new StringBuilder().append(string).append(String.format("LINE=[%d] LABEL=[%s]", lineNumberNode.line, lineNumberNode.start.getLabel())));
            "".length();
            if ("   ".length() >= (129 + 13 - 87 + 89 ^ 40 + 34 - -13 + 61)) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof LdcInsnNode)) {
            string = String.valueOf(new StringBuilder().append(string).append(((LdcInsnNode)abstractInsnNode).cst));
            "".length();
            if (-"  ".length() >= 0) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof IntInsnNode)) {
            string = String.valueOf(new StringBuilder().append(string).append(((IntInsnNode)abstractInsnNode).operand));
            "".length();
            if (null != null) {
                return null;
            }
        } else if (Bytecode.lllllIII(abstractInsnNode instanceof FrameNode)) {
            string = String.valueOf(new StringBuilder().append(string).append(String.format("[%s] ", Bytecode.getOpcodeName(((FrameNode)abstractInsnNode).type, "H_INVOKEINTERFACE", -1))));
            "".length();
            if (-" ".length() > "  ".length()) {
                return null;
            }
        } else {
            string = String.valueOf(new StringBuilder().append(string).append(String.format("[%s] ", Bytecode.getOpcodeName(abstractInsnNode))));
        }
        return string;
    }

    public static String getOpcodeName(AbstractInsnNode abstractInsnNode) {
        String string;
        if (Bytecode.llllllIl(abstractInsnNode)) {
            string = Bytecode.getOpcodeName(abstractInsnNode.getOpcode());
            "".length();
            if (((0x59 ^ 0x3F ^ (5 ^ 2)) & (0x5C ^ 0x3E ^ "   ".length() ^ -" ".length())) != ((0x12 ^ 0x16 ^ (0x5E ^ 0x1B)) & (0x71 ^ 0x6B ^ (0x47 ^ 0x1C) ^ -" ".length()))) {
                return null;
            }
        } else {
            string = "";
        }
        return string;
    }

    public static String getOpcodeName(int n) {
        return Bytecode.getOpcodeName(n, "UNINITIALIZED_THIS", 1);
    }

    private static String getOpcodeName(int n, String string, int n2) {
        String string2;
        if (Bytecode.lllllllI(n, n2)) {
            int n3 = 0;
            try {
                Field[] fieldArray = Opcodes.class.getDeclaredFields();
                int n4 = fieldArray.length;
                int n5 = 0;
                while (Bytecode.llllllll(n5, n4)) {
                    Field field = fieldArray[n5];
                    if (Bytecode.lllllIlI(n3) && Bytecode.lllllIlI(field.getName().equals(string) ? 1 : 0)) {
                        "".length();
                        if ("  ".length() <= ((0xB7 ^ 0xBE) & ~(0x42 ^ 0x4B))) {
                            return null;
                        }
                    } else {
                        n3 = 1;
                        if (Bytecode.lIIIIIIII(field.getType(), Integer.TYPE) && Bytecode.lllllIIl(field.getInt(null), n)) {
                            return field.getName();
                        }
                    }
                    ++n5;
                    "".length();
                    if (((0xF7 ^ 0xAD ^ (0xF8 ^ 0xA6)) & (3 ^ 0x72 ^ (0x11 ^ 0x64) ^ -" ".length())) == 0) continue;
                    return null;
                }
                "".length();
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (((0x21 ^ 0x62) & ~(0xC ^ 0x4F)) != 0) {
                return null;
            }
        }
        if (Bytecode.lIIIIIIIl(n)) {
            string2 = String.valueOf(n);
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string2 = "UNKNOWN";
        }
        return string2;
    }

    public static boolean methodHasLineNumbers(MethodNode methodNode) {
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
            if (!Bytecode.lllllIII(listIterator.next() instanceof LineNumberNode)) continue;
            return true;
        }
        return false;
    }

    public static boolean methodIsStatic(MethodNode methodNode) {
        boolean bl;
        if (Bytecode.lllllIIl(methodNode.access & 8, 8)) {
            bl = true;
            "".length();
            if (-"  ".length() >= 0) {
                return ((0xD7 ^ 0x89 ^ (0xD6 ^ 0xB1)) & (3 + 145 - 113 + 126 ^ 116 + 40 - 66 + 62 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static boolean fieldIsStatic(FieldNode fieldNode) {
        boolean bl;
        if (Bytecode.lllllIIl(fieldNode.access & 8, 8)) {
            bl = true;
            "".length();
            if (-"   ".length() >= 0) {
                return ((190 + 205 - 379 + 200 ^ 18 + 107 - 120 + 143) & (0xCE ^ 0x87 ^ (0x46 ^ 0x43) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static int getFirstNonArgLocalIndex(MethodNode methodNode) {
        boolean bl;
        Type[] typeArray = Type.getArgumentTypes(methodNode.desc);
        if (Bytecode.lllllIlI(methodNode.access & 8)) {
            bl = true;
            "".length();
            if ("   ".length() <= 0) {
                return (0x7D ^ 0x6F ^ (0x2F ^ 0x79)) & (0x3A ^ 0x76 ^ (0xBD ^ 0xB5) ^ -" ".length());
            }
        } else {
            bl = false;
        }
        return Bytecode.getFirstNonArgLocalIndex(typeArray, bl);
    }

    public static int getFirstNonArgLocalIndex(Type[] typeArray, boolean bl) {
        int n;
        int n2 = Bytecode.getArgsSize(typeArray);
        if (Bytecode.lllllIII(bl ? 1 : 0)) {
            n = 1;
            "".length();
            if (" ".length() <= 0) {
                return (75 + 33 - 43 + 100 ^ 98 + 128 - 160 + 110) & (0xD9 ^ 0x9D ^ (0xF6 ^ 0xA7) ^ -" ".length());
            }
        } else {
            n = 0;
        }
        return n2 + n;
    }

    public static int getArgsSize(Type[] typeArray) {
        int n = 0;
        Type[] typeArray2 = typeArray;
        int n2 = typeArray2.length;
        int n3 = 0;
        while (Bytecode.llllllll(n3, n2)) {
            Type type = typeArray2[n3];
            n += type.getSize();
            ++n3;
            "".length();
            if ("   ".length() < (0x88 ^ 0x8C)) continue;
            return (0x42 ^ 0x48) & ~(0x4A ^ 0x40);
        }
        return n;
    }

    public static void loadArgs(Type[] typeArray, InsnList insnList, int n) {
        Bytecode.loadArgs(typeArray, insnList, n, -1);
    }

    public static void loadArgs(Type[] typeArray, InsnList insnList, int n, int n2) {
        Bytecode.loadArgs(typeArray, insnList, n, n2, null);
    }

    public static void loadArgs(Type[] typeArray, InsnList insnList, int n, int n2, Type[] typeArray2) {
        int n3 = n;
        int n4 = 0;
        Type[] typeArray3 = typeArray;
        int n5 = typeArray3.length;
        int n6 = 0;
        while (Bytecode.llllllll(n6, n5)) {
            Type type = typeArray3[n6];
            insnList.add(new VarInsnNode(type.getOpcode(21), n3));
            if (Bytecode.llllllIl(typeArray2) && Bytecode.llllllll(n4, typeArray2.length) && Bytecode.llllllIl(typeArray2[n4])) {
                insnList.add(new TypeInsnNode(192, typeArray2[n4].getInternalName()));
            }
            if (Bytecode.lllllllI(n2, n) && Bytecode.lllllllI(n3 += type.getSize(), n2)) {
                return;
            }
            ++n4;
            ++n6;
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
    }

    public static Map<LabelNode, LabelNode> cloneLabels(InsnList insnList) {
        HashMap<LabelNode, LabelNode> hashMap = new HashMap<LabelNode, LabelNode>();
        ListIterator<AbstractInsnNode> listIterator = insnList.iterator();
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
            if (Bytecode.lllllIII(abstractInsnNode instanceof LabelNode)) {
                hashMap.put((LabelNode)abstractInsnNode, new LabelNode(((LabelNode)abstractInsnNode).getLabel()));
                "".length();
            }
            "".length();
            if ("  ".length() < (0xA1 ^ 0xA5)) continue;
            return null;
        }
        return hashMap;
    }

    public static String generateDescriptor(Object object, Object ... objectArray) {
        String string;
        StringBuilder stringBuilder = new StringBuilder().append('(');
        Object[] objectArray2 = objectArray;
        int n = objectArray2.length;
        int n2 = 0;
        while (Bytecode.llllllll(n2, n)) {
            Object object2 = objectArray2[n2];
            stringBuilder.append(Bytecode.toDescriptor(object2));
            "".length();
            ++n2;
            "".length();
            if (((203 + 8 - 172 + 187 ^ 92 + 122 - 176 + 135) & (" ".length() ^ (0x11 ^ 0x5F) ^ -" ".length())) == 0) continue;
            return null;
        }
        StringBuilder stringBuilder2 = stringBuilder.append(')');
        if (Bytecode.llllllIl(object)) {
            string = Bytecode.toDescriptor(object);
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string = "V";
        }
        return String.valueOf(stringBuilder2.append(string));
    }

    private static String toDescriptor(Object object) {
        String string;
        if (Bytecode.lllllIII(object instanceof String)) {
            return (String)object;
        }
        if (Bytecode.lllllIII(object instanceof Type)) {
            return object.toString();
        }
        if (Bytecode.lllllIII(object instanceof Class)) {
            return Type.getDescriptor((Class)object);
        }
        if (Bytecode.llllllII(object)) {
            string = "";
            "".length();
            if (-" ".length() >= (0xB1 ^ 0xB5)) {
                return null;
            }
        } else {
            string = object.toString();
        }
        return string;
    }

    public static String getDescriptor(Type[] typeArray) {
        return String.valueOf(new StringBuilder().append("(").append(Joiner.on((String)"").join((Object[])typeArray)).append(")"));
    }

    public static String getDescriptor(Type[] typeArray, Type type) {
        return String.valueOf(new StringBuilder().append(Bytecode.getDescriptor(typeArray)).append(type.toString()));
    }

    public static String changeDescriptorReturnType(String string, String string2) {
        if (Bytecode.llllllII(string)) {
            return null;
        }
        if (Bytecode.llllllII(string2)) {
            return string;
        }
        return String.valueOf(new StringBuilder().append(string.substring(0, string.lastIndexOf(41) + 1)).append(string2));
    }

    public static String getSimpleName(Class<? extends Annotation> clazz) {
        return clazz.getSimpleName();
    }

    public static String getSimpleName(AnnotationNode annotationNode) {
        return Bytecode.getSimpleName(annotationNode.desc);
    }

    public static String getSimpleName(String string) {
        int n = Math.max(string.lastIndexOf(47), 0);
        return string.substring(n + 1).replace(";", "");
    }

    public static boolean isConstant(AbstractInsnNode abstractInsnNode) {
        if (Bytecode.llllllII(abstractInsnNode)) {
            return false;
        }
        return Ints.contains((int[])CONSTANTS_ALL, (int)abstractInsnNode.getOpcode());
    }

    public static Object getConstant(AbstractInsnNode abstractInsnNode) {
        Object object;
        if (Bytecode.llllllII(abstractInsnNode)) {
            return null;
        }
        if (Bytecode.lllllIII(abstractInsnNode instanceof LdcInsnNode)) {
            return ((LdcInsnNode)abstractInsnNode).cst;
        }
        if (Bytecode.lllllIII(abstractInsnNode instanceof IntInsnNode)) {
            int n = ((IntInsnNode)abstractInsnNode).operand;
            if (!Bytecode.lIIIIIIlI(abstractInsnNode.getOpcode(), 16) || Bytecode.lllllIIl(abstractInsnNode.getOpcode(), 17)) {
                return n;
            }
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("IntInsnNode with invalid opcode ").append(abstractInsnNode.getOpcode()).append(" in getConstant")));
        }
        int n = Ints.indexOf((int[])CONSTANTS_ALL, (int)abstractInsnNode.getOpcode());
        if (Bytecode.lIIIIIIll(n)) {
            object = null;
            "".length();
            if ((0xA5 ^ 0x87 ^ (0x10 ^ 0x36)) == " ".length()) {
                return null;
            }
        } else {
            object = CONSTANTS_VALUES[n];
        }
        return object;
    }

    public static Type getConstantType(AbstractInsnNode abstractInsnNode) {
        Type type;
        if (Bytecode.llllllII(abstractInsnNode)) {
            return null;
        }
        if (Bytecode.lllllIII(abstractInsnNode instanceof LdcInsnNode)) {
            Object object = ((LdcInsnNode)abstractInsnNode).cst;
            if (Bytecode.lllllIII(object instanceof Integer)) {
                return Type.getType("I");
            }
            if (Bytecode.lllllIII(object instanceof Float)) {
                return Type.getType("F");
            }
            if (Bytecode.lllllIII(object instanceof Long)) {
                return Type.getType("J");
            }
            if (Bytecode.lllllIII(object instanceof Double)) {
                return Type.getType("D");
            }
            if (Bytecode.lllllIII(object instanceof String)) {
                return Type.getType("Ljava/lang/String;");
            }
            if (Bytecode.lllllIII(object instanceof Type)) {
                return Type.getType("Ljava/lang/Class;");
            }
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("LdcInsnNode with invalid payload type ").append(object.getClass()).append(" in getConstant")));
        }
        int n = Ints.indexOf((int[])CONSTANTS_ALL, (int)abstractInsnNode.getOpcode());
        if (Bytecode.lIIIIIIll(n)) {
            type = null;
            "".length();
            if ((" ".length() ^ (0xC ^ 9)) < 0) {
                return null;
            }
        } else {
            type = Type.getType(CONSTANTS_TYPES[n]);
        }
        return type;
    }

    public static boolean hasFlag(ClassNode classNode, int n) {
        boolean bl;
        if (Bytecode.lllllIIl(classNode.access & n, n)) {
            bl = true;
            "".length();
            if ("   ".length() == " ".length()) {
                return ((0xFB ^ 0x8C ^ (0x56 ^ 9)) & (99 + 74 - 99 + 74 ^ 60 + 77 - 40 + 91 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static boolean hasFlag(MethodNode methodNode, int n) {
        boolean bl;
        if (Bytecode.lllllIIl(methodNode.access & n, n)) {
            bl = true;
            "".length();
            if (-(0x60 ^ 0x65) >= 0) {
                return ((0x11 ^ 0x35) & ~(0x68 ^ 0x4C)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static boolean hasFlag(FieldNode fieldNode, int n) {
        boolean bl;
        if (Bytecode.lllllIIl(fieldNode.access & n, n)) {
            bl = true;
            "".length();
            if (((35 + 1 - -178 + 9 ^ 5 + 25 - -96 + 26) & (0xA2 ^ 0xB2 ^ (0x1C ^ 0x4B) ^ -" ".length())) >= " ".length()) {
                return ((143 + 89 - 30 + 40 ^ 150 + 157 - 259 + 135) & (150 + 52 - 166 + 189 ^ 79 + 96 - 171 + 160 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static boolean compareFlags(MethodNode methodNode, MethodNode methodNode2, int n) {
        boolean bl;
        if (Bytecode.lllllIIl(Bytecode.hasFlag(methodNode, n) ? 1 : 0, Bytecode.hasFlag(methodNode2, n) ? 1 : 0)) {
            bl = true;
            "".length();
            if ("   ".length() == "  ".length()) {
                return ((15 + 104 - 44 + 93 ^ 105 + 65 - 156 + 122) & (0x5A ^ 0x71 ^ (6 ^ 0xD) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static boolean compareFlags(FieldNode fieldNode, FieldNode fieldNode2, int n) {
        boolean bl;
        if (Bytecode.lllllIIl(Bytecode.hasFlag(fieldNode, n) ? 1 : 0, Bytecode.hasFlag(fieldNode2, n) ? 1 : 0)) {
            bl = true;
            "".length();
            if ("   ".length() >= (0xC ^ 6 ^ (0x4C ^ 0x42))) {
                return ((0x2D ^ 0x5E ^ (0x7B ^ 0x3A)) & (0xE3 ^ 0xA5 ^ (0x32 ^ 0x46) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static Bytecode$Visibility getVisibility(MethodNode methodNode) {
        return Bytecode.getVisibility(methodNode.access & 7);
    }

    public static Bytecode$Visibility getVisibility(FieldNode fieldNode) {
        return Bytecode.getVisibility(fieldNode.access & 7);
    }

    private static Bytecode$Visibility getVisibility(int n) {
        if (Bytecode.lllllIII(n & 4)) {
            return Bytecode$Visibility.PROTECTED;
        }
        if (Bytecode.lllllIII(n & 2)) {
            return Bytecode$Visibility.PRIVATE;
        }
        if (Bytecode.lllllIII(n & 1)) {
            return Bytecode$Visibility.PUBLIC;
        }
        return Bytecode$Visibility.PACKAGE;
    }

    public static void setVisibility(MethodNode methodNode, Bytecode$Visibility bytecode$Visibility) {
        methodNode.access = Bytecode.setVisibility(methodNode.access, bytecode$Visibility.access);
    }

    public static void setVisibility(FieldNode fieldNode, Bytecode$Visibility bytecode$Visibility) {
        fieldNode.access = Bytecode.setVisibility(fieldNode.access, bytecode$Visibility.access);
    }

    public static void setVisibility(MethodNode methodNode, int n) {
        methodNode.access = Bytecode.setVisibility(methodNode.access, n);
    }

    public static void setVisibility(FieldNode fieldNode, int n) {
        fieldNode.access = Bytecode.setVisibility(fieldNode.access, n);
    }

    private static int setVisibility(int n, int n2) {
        return n & 0xFFFFFFF8 | n2 & 7;
    }

    public static int getMaxLineNumber(ClassNode classNode, int n, int n2) {
        int n3 = 0;
        Iterator<MethodNode> iterator = classNode.methods.iterator();
        while (Bytecode.lllllIII(iterator.hasNext() ? 1 : 0)) {
            MethodNode methodNode = iterator.next();
            ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
            while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0)) {
                AbstractInsnNode abstractInsnNode = (AbstractInsnNode)listIterator.next();
                if (Bytecode.lllllIII(abstractInsnNode instanceof LineNumberNode)) {
                    n3 = Math.max(n3, ((LineNumberNode)abstractInsnNode).line);
                }
                "".length();
                if ((0x99 ^ 0x9D) >= 0) continue;
                return (0x7F ^ 0x51) & ~(0x54 ^ 0x7A);
            }
            "".length();
            if ("  ".length() > 0) continue;
            return (0x9D ^ 0x85) & ~(0x56 ^ 0x4E);
        }
        return Math.max(n, n3 + n2);
    }

    public static String getBoxingType(Type type) {
        String string;
        if (Bytecode.llllllII(type)) {
            string = null;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string = BOXING_TYPES[type.getSort()];
        }
        return string;
    }

    public static String getUnboxingMethod(Type type) {
        String string;
        if (Bytecode.llllllII(type)) {
            string = null;
            "".length();
            if ("   ".length() < "   ".length()) {
                return null;
            }
        } else {
            string = UNBOXING_METHODS[type.getSort()];
        }
        return string;
    }

    public static void mergeAnnotations(ClassNode classNode, ClassNode classNode2) {
        classNode2.visibleAnnotations = Bytecode.mergeAnnotations(classNode.visibleAnnotations, classNode2.visibleAnnotations, "class", classNode.name);
        classNode2.invisibleAnnotations = Bytecode.mergeAnnotations(classNode.invisibleAnnotations, classNode2.invisibleAnnotations, "class", classNode.name);
    }

    public static void mergeAnnotations(MethodNode methodNode, MethodNode methodNode2) {
        methodNode2.visibleAnnotations = Bytecode.mergeAnnotations(methodNode.visibleAnnotations, methodNode2.visibleAnnotations, "method", methodNode.name);
        methodNode2.invisibleAnnotations = Bytecode.mergeAnnotations(methodNode.invisibleAnnotations, methodNode2.invisibleAnnotations, "method", methodNode.name);
    }

    public static void mergeAnnotations(FieldNode fieldNode, FieldNode fieldNode2) {
        fieldNode2.visibleAnnotations = Bytecode.mergeAnnotations(fieldNode.visibleAnnotations, fieldNode2.visibleAnnotations, "field", fieldNode.name);
        fieldNode2.invisibleAnnotations = Bytecode.mergeAnnotations(fieldNode.invisibleAnnotations, fieldNode2.invisibleAnnotations, "field", fieldNode.name);
    }

    private static List<AnnotationNode> mergeAnnotations(List<AnnotationNode> list, List<AnnotationNode> list2, String string, String string2) {
        try {
            if (Bytecode.llllllII(list)) {
                return list2;
            }
            if (Bytecode.llllllII(list2)) {
                list2 = new ArrayList<AnnotationNode>();
            }
            Iterator<AnnotationNode> iterator = list.iterator();
            while (Bytecode.lllllIII(iterator.hasNext() ? 1 : 0)) {
                AnnotationNode annotationNode = iterator.next();
                if (Bytecode.lllllIlI(Bytecode.isMergeableAnnotation(annotationNode) ? 1 : 0)) {
                    "".length();
                    if (" ".length() != 0) continue;
                    return null;
                }
                Iterator<AnnotationNode> iterator2 = list2.iterator();
                while (Bytecode.lllllIII(iterator2.hasNext() ? 1 : 0)) {
                    if (!Bytecode.lllllIII(iterator2.next().desc.equals(annotationNode.desc) ? 1 : 0)) continue;
                    iterator2.remove();
                    "".length();
                    if (" ".length() != 0) break;
                    return null;
                }
                list2.add(annotationNode);
                "".length();
                "".length();
                if (((0x1C ^ 0x7D ^ (0xF2 ^ 0xBD)) & (41 + 114 - 11 + 12 ^ 101 + 89 - 94 + 82 ^ -" ".length())) == 0) continue;
                return null;
            }
            "".length();
        }
        catch (Exception exception) {
            logger.warn("Exception encountered whilst merging annotations for {} {}", new Object[]{string, string2});
        }
        if (null != null) {
            return null;
        }
        return list2;
    }

    private static boolean isMergeableAnnotation(AnnotationNode annotationNode) {
        if (Bytecode.lllllIII(annotationNode.desc.startsWith(String.valueOf(new StringBuilder().append("L").append(Constants.MIXIN_PACKAGE_REF))) ? 1 : 0)) {
            return mergeableAnnotationPattern.matcher(annotationNode.desc).matches();
        }
        return true;
    }

    private static Pattern getMergeableAnnotationPattern() {
        StringBuilder stringBuilder = new StringBuilder("^L(");
        int n = 0;
        while (Bytecode.llllllll(n, MERGEABLE_MIXIN_ANNOTATIONS.length)) {
            if (Bytecode.lllllIll(n)) {
                stringBuilder.append('|');
                "".length();
            }
            stringBuilder.append(MERGEABLE_MIXIN_ANNOTATIONS[n].getName().replace('.', '/'));
            "".length();
            ++n;
            "".length();
            if (((134 + 54 - 42 + 30 ^ 31 + 38 - -24 + 50) & (44 + 38 - 7 + 87 ^ 138 + 84 - 77 + 12 ^ -" ".length())) < " ".length()) continue;
            return null;
        }
        return Pattern.compile(String.valueOf(stringBuilder.append(");$")));
    }

    public static void compareBridgeMethods(MethodNode methodNode, MethodNode methodNode2) {
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        ListIterator<AbstractInsnNode> listIterator2 = methodNode2.instructions.iterator();
        int n = 0;
        while (Bytecode.lllllIII(listIterator.hasNext() ? 1 : 0) && Bytecode.lllllIII(listIterator2.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode;
            AbstractInsnNode abstractInsnNode2;
            AbstractInsnNode abstractInsnNode3 = listIterator.next();
            AbstractInsnNode abstractInsnNode4 = listIterator2.next();
            if (Bytecode.lllllIII(abstractInsnNode3 instanceof LabelNode)) {
                "".length();
                if (" ".length() < ((0xE ^ 0x37 ^ (0x15 ^ 0x6B)) & (30 + 93 - 83 + 184 ^ 18 + 96 - -36 + 17 ^ -" ".length()))) {
                    return;
                }
            } else if (Bytecode.lllllIII(abstractInsnNode3 instanceof MethodInsnNode)) {
                abstractInsnNode2 = (MethodInsnNode)abstractInsnNode3;
                abstractInsnNode = (MethodInsnNode)abstractInsnNode4;
                if (Bytecode.lllllIlI(((MethodInsnNode)abstractInsnNode2).name.equals(abstractInsnNode.name) ? 1 : 0)) {
                    throw new SyntheticBridgeException(SyntheticBridgeException$Problem.BAD_INVOKE_NAME, methodNode.name, methodNode.desc, n, abstractInsnNode3, abstractInsnNode4);
                }
                if (Bytecode.lllllIlI(((MethodInsnNode)abstractInsnNode2).desc.equals(abstractInsnNode.desc) ? 1 : 0)) {
                    throw new SyntheticBridgeException(SyntheticBridgeException$Problem.BAD_INVOKE_DESC, methodNode.name, methodNode.desc, n, abstractInsnNode3, abstractInsnNode4);
                }
                "".length();
                if (((0x2E ^ 0x27 ^ (0x7E ^ 0x68)) & (0x63 ^ 0x1E ^ (0x5E ^ 0x3C) ^ -" ".length())) != ((131 + 36 - 26 + 29 ^ 149 + 70 - 163 + 109) & (4 ^ 0x44 ^ (0x27 ^ 0x68) ^ -" ".length()))) {
                    return;
                }
            } else {
                if (Bytecode.lIIIIIIlI(abstractInsnNode3.getOpcode(), abstractInsnNode4.getOpcode())) {
                    throw new SyntheticBridgeException(SyntheticBridgeException$Problem.BAD_INSN, methodNode.name, methodNode.desc, n, abstractInsnNode3, abstractInsnNode4);
                }
                if (Bytecode.lllllIII(abstractInsnNode3 instanceof VarInsnNode)) {
                    abstractInsnNode2 = (VarInsnNode)abstractInsnNode3;
                    abstractInsnNode = (VarInsnNode)abstractInsnNode4;
                    if (Bytecode.lIIIIIIlI(((VarInsnNode)abstractInsnNode2).var, ((VarInsnNode)abstractInsnNode).var)) {
                        throw new SyntheticBridgeException(SyntheticBridgeException$Problem.BAD_LOAD, methodNode.name, methodNode.desc, n, abstractInsnNode3, abstractInsnNode4);
                    }
                    "".length();
                    if ((0x5D ^ 0x29 ^ (0xF0 ^ 0x80)) <= " ".length()) {
                        return;
                    }
                } else if (Bytecode.lllllIII(abstractInsnNode3 instanceof TypeInsnNode)) {
                    abstractInsnNode2 = (TypeInsnNode)abstractInsnNode3;
                    abstractInsnNode = (TypeInsnNode)abstractInsnNode4;
                    if (Bytecode.lllllIIl(abstractInsnNode2.getOpcode(), 192) && Bytecode.lllllIlI(((TypeInsnNode)abstractInsnNode2).desc.equals(((TypeInsnNode)abstractInsnNode).desc) ? 1 : 0)) {
                        throw new SyntheticBridgeException(SyntheticBridgeException$Problem.BAD_CAST, methodNode.name, methodNode.desc, n, abstractInsnNode3, abstractInsnNode4);
                    }
                }
            }
            ++n;
            "".length();
            if (((0xBB ^ 0xAD ^ "   ".length()) & (0x33 ^ 0x54 ^ (0xF ^ 0x7D) ^ -" ".length())) == 0) continue;
            return;
        }
        if (!Bytecode.lllllIlI(listIterator.hasNext() ? 1 : 0) || Bytecode.lllllIII(listIterator2.hasNext() ? 1 : 0)) {
            throw new SyntheticBridgeException(SyntheticBridgeException$Problem.BAD_LENGTH, methodNode.name, methodNode.desc, n, null, null);
        }
    }

    private static boolean lllllIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lllllllI(int n, int n2) {
        return n >= n2;
    }

    private static boolean llllllll(int n, int n2) {
        return n < n2;
    }

    private static boolean llllllIl(Object object) {
        return object != null;
    }

    private static boolean lIIIIIIII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llllllII(Object object) {
        return object == null;
    }

    private static boolean lllllIII(int n) {
        return n != 0;
    }

    private static boolean lllllIlI(int n) {
        return n == 0;
    }

    private static boolean lIIIIIIIl(int n) {
        return n >= 0;
    }

    private static boolean lIIIIIIll(int n) {
        return n < 0;
    }

    private static boolean lllllIll(int n) {
        return n > 0;
    }

    private static boolean lIIIIIIlI(int n, int n2) {
        return n != n2;
    }
}

