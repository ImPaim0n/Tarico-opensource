/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.ClassSignature;

class ClassSignature$Lazy
extends ClassSignature {
    private final String sig;
    private ClassSignature generated;

    ClassSignature$Lazy(String string) {
        this.sig = string;
    }

    @Override
    public ClassSignature wake() {
        if (ClassSignature$Lazy.llIIIlIIl(this.generated)) {
            this.generated = ClassSignature.of(this.sig);
        }
        return this.generated;
    }

    private static boolean llIIIlIIl(Object object) {
        return object == null;
    }
}

