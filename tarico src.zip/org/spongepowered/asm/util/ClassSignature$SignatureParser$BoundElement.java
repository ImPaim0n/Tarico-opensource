/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.util.ClassSignature$SignatureParser;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$TokenElement;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$TypeArgElement;

class ClassSignature$SignatureParser$BoundElement
extends ClassSignature$SignatureParser$TokenElement {
    private final ClassSignature$SignatureParser$TokenElement type;
    private final boolean classBound;
    final /* synthetic */ ClassSignature$SignatureParser this$1;

    ClassSignature$SignatureParser$BoundElement(ClassSignature$SignatureParser classSignature$SignatureParser, ClassSignature$SignatureParser$TokenElement classSignature$SignatureParser$TokenElement, boolean bl) {
        this.this$1 = classSignature$SignatureParser;
        super(classSignature$SignatureParser);
        this.type = classSignature$SignatureParser$TokenElement;
        this.classBound = bl;
    }

    @Override
    public void visitClassType(String string) {
        this.token = this.type.token.addBound(string, this.classBound);
    }

    @Override
    public void visitTypeArgument() {
        this.token.addTypeArgument('*');
        "".length();
    }

    @Override
    public SignatureVisitor visitTypeArgument(char c) {
        return new ClassSignature$SignatureParser$TypeArgElement(this.this$1, this, c);
    }
}

