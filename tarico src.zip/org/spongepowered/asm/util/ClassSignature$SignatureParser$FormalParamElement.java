/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.ClassSignature$SignatureParser;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$TokenElement;
import org.spongepowered.asm.util.ClassSignature$TokenHandle;

class ClassSignature$SignatureParser$FormalParamElement
extends ClassSignature$SignatureParser$TokenElement {
    private final ClassSignature$TokenHandle handle;
    final /* synthetic */ ClassSignature$SignatureParser this$1;

    ClassSignature$SignatureParser$FormalParamElement(ClassSignature$SignatureParser classSignature$SignatureParser, String string) {
        this.this$1 = classSignature$SignatureParser;
        super(classSignature$SignatureParser);
        this.handle = classSignature$SignatureParser.this$0.getType(string);
        this.token = this.handle.asToken();
    }
}

