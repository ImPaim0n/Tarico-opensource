/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.ClassSignature$SignatureParser;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$TokenElement;

class ClassSignature$SignatureParser$InterfaceElement
extends ClassSignature$SignatureParser$TokenElement {
    final /* synthetic */ ClassSignature$SignatureParser this$1;

    ClassSignature$SignatureParser$InterfaceElement(ClassSignature$SignatureParser classSignature$SignatureParser) {
        this.this$1 = classSignature$SignatureParser;
        super(classSignature$SignatureParser);
    }

    @Override
    public void visitEnd() {
        this.this$1.this$0.addInterface(this.token);
    }
}

