/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.util.ClassSignature$SignatureParser;

abstract class ClassSignature$SignatureParser$SignatureElement
extends SignatureVisitor {
    final /* synthetic */ ClassSignature$SignatureParser this$1;

    public ClassSignature$SignatureParser$SignatureElement(ClassSignature$SignatureParser classSignature$SignatureParser) {
        this.this$1 = classSignature$SignatureParser;
        super(327680);
    }
}

