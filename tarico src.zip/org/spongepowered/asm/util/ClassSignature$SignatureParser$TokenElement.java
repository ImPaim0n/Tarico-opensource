/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.util.ClassSignature$IToken;
import org.spongepowered.asm.util.ClassSignature$SignatureParser;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$BoundElement;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$SignatureElement;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$TypeArgElement;
import org.spongepowered.asm.util.ClassSignature$Token;
import org.spongepowered.asm.util.ClassSignature$TokenHandle;

abstract class ClassSignature$SignatureParser$TokenElement
extends ClassSignature$SignatureParser$SignatureElement {
    protected ClassSignature$Token token;
    private boolean array;
    final /* synthetic */ ClassSignature$SignatureParser this$1;

    ClassSignature$SignatureParser$TokenElement(ClassSignature$SignatureParser classSignature$SignatureParser) {
        this.this$1 = classSignature$SignatureParser;
        super(classSignature$SignatureParser);
    }

    public ClassSignature$Token getToken() {
        if (ClassSignature$SignatureParser$TokenElement.lIIIllllII(this.token)) {
            this.token = new ClassSignature$Token();
        }
        return this.token;
    }

    protected void setArray() {
        this.array = true;
    }

    private boolean getArray() {
        boolean bl = this.array;
        this.array = false;
        return bl;
    }

    @Override
    public void visitClassType(String string) {
        this.getToken().setType(string);
        "".length();
    }

    @Override
    public SignatureVisitor visitClassBound() {
        this.getToken();
        "".length();
        return new ClassSignature$SignatureParser$BoundElement(this.this$1, this, true);
    }

    @Override
    public SignatureVisitor visitInterfaceBound() {
        this.getToken();
        "".length();
        return new ClassSignature$SignatureParser$BoundElement(this.this$1, this, false);
    }

    @Override
    public void visitInnerClassType(String string) {
        this.token.addInnerClass(string);
        "".length();
    }

    @Override
    public SignatureVisitor visitArrayType() {
        this.setArray();
        return this;
    }

    @Override
    public SignatureVisitor visitTypeArgument(char c) {
        return new ClassSignature$SignatureParser$TypeArgElement(this.this$1, this, c);
    }

    ClassSignature$Token addTypeArgument() {
        return this.token.addTypeArgument('*').asToken();
    }

    ClassSignature$IToken addTypeArgument(char c) {
        return this.token.addTypeArgument(c).setArray(this.getArray());
    }

    ClassSignature$IToken addTypeArgument(String string) {
        return this.token.addTypeArgument(string).setArray(this.getArray());
    }

    ClassSignature$IToken addTypeArgument(ClassSignature$Token classSignature$Token) {
        return this.token.addTypeArgument(classSignature$Token).setArray(this.getArray());
    }

    ClassSignature$IToken addTypeArgument(ClassSignature$TokenHandle classSignature$TokenHandle) {
        return this.token.addTypeArgument(classSignature$TokenHandle).setArray(this.getArray());
    }

    private static boolean lIIIllllII(Object object) {
        return object == null;
    }
}

