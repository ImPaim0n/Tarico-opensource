/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.util.ClassSignature$SignatureParser;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$TokenElement;
import org.spongepowered.asm.util.ClassSignature$TokenHandle;

class ClassSignature$SignatureParser$TypeArgElement
extends ClassSignature$SignatureParser$TokenElement {
    private final ClassSignature$SignatureParser$TokenElement type;
    private final char wildcard;
    final /* synthetic */ ClassSignature$SignatureParser this$1;

    ClassSignature$SignatureParser$TypeArgElement(ClassSignature$SignatureParser classSignature$SignatureParser, ClassSignature$SignatureParser$TokenElement classSignature$SignatureParser$TokenElement, char c) {
        this.this$1 = classSignature$SignatureParser;
        super(classSignature$SignatureParser);
        this.type = classSignature$SignatureParser$TokenElement;
        this.wildcard = c;
    }

    @Override
    public SignatureVisitor visitArrayType() {
        this.type.setArray();
        return this;
    }

    @Override
    public void visitBaseType(char c) {
        this.token = this.type.addTypeArgument(c).asToken();
    }

    @Override
    public void visitTypeVariable(String string) {
        ClassSignature$TokenHandle classSignature$TokenHandle = this.this$1.this$0.getType(string);
        this.token = this.type.addTypeArgument(classSignature$TokenHandle).setWildcard(this.wildcard).asToken();
    }

    @Override
    public void visitClassType(String string) {
        this.token = this.type.addTypeArgument(string).setWildcard(this.wildcard).asToken();
    }

    @Override
    public void visitTypeArgument() {
        this.token.addTypeArgument('*');
        "".length();
    }

    @Override
    public SignatureVisitor visitTypeArgument(char c) {
        return new ClassSignature$SignatureParser$TypeArgElement(this.this$1, this, c);
    }

    @Override
    public void visitEnd() {
    }
}

