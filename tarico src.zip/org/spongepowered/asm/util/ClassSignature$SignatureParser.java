/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.util.ClassSignature;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$FormalParamElement;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$InterfaceElement;
import org.spongepowered.asm.util.ClassSignature$SignatureParser$SuperClassElement;

class ClassSignature$SignatureParser
extends SignatureVisitor {
    private ClassSignature$SignatureParser$FormalParamElement param;
    final /* synthetic */ ClassSignature this$0;

    ClassSignature$SignatureParser(ClassSignature classSignature) {
        this.this$0 = classSignature;
        super(327680);
    }

    @Override
    public void visitFormalTypeParameter(String string) {
        this.param = new ClassSignature$SignatureParser$FormalParamElement(this, string);
    }

    @Override
    public SignatureVisitor visitClassBound() {
        return this.param.visitClassBound();
    }

    @Override
    public SignatureVisitor visitInterfaceBound() {
        return this.param.visitInterfaceBound();
    }

    @Override
    public SignatureVisitor visitSuperclass() {
        return new ClassSignature$SignatureParser$SuperClassElement(this);
    }

    @Override
    public SignatureVisitor visitInterface() {
        return new ClassSignature$SignatureParser$InterfaceElement(this);
    }
}

