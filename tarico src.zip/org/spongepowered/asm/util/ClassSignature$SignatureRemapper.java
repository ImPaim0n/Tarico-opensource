/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.util.HashSet;
import java.util.Set;
import org.spongepowered.asm.lib.signature.SignatureWriter;
import org.spongepowered.asm.util.ClassSignature;
import org.spongepowered.asm.util.ClassSignature$TypeVar;

class ClassSignature$SignatureRemapper
extends SignatureWriter {
    private final Set<String> localTypeVars = new HashSet<String>();
    final /* synthetic */ ClassSignature this$0;

    ClassSignature$SignatureRemapper(ClassSignature classSignature) {
        this.this$0 = classSignature;
    }

    @Override
    public void visitFormalTypeParameter(String string) {
        this.localTypeVars.add(string);
        "".length();
        super.visitFormalTypeParameter(string);
    }

    @Override
    public void visitTypeVariable(String string) {
        ClassSignature$TypeVar classSignature$TypeVar;
        if (ClassSignature$SignatureRemapper.llIllIll(this.localTypeVars.contains(string) ? 1 : 0) && ClassSignature$SignatureRemapper.llIlllII(classSignature$TypeVar = this.this$0.getTypeVar(string))) {
            super.visitTypeVariable(classSignature$TypeVar.toString());
            return;
        }
        super.visitTypeVariable(string);
    }

    private static boolean llIlllII(Object object) {
        return object != null;
    }

    private static boolean llIllIll(int n) {
        return n == 0;
    }
}

