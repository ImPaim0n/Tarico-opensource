/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.util.ClassSignature$IToken;
import org.spongepowered.asm.util.ClassSignature$TokenHandle;

class ClassSignature$Token
implements ClassSignature$IToken {
    static final String SYMBOLS = "+-*";
    private final boolean inner;
    private boolean array;
    private char symbol = '\u0000';
    private String type;
    private List<ClassSignature$Token> classBound;
    private List<ClassSignature$Token> ifaceBound;
    private List<ClassSignature$IToken> signature;
    private List<ClassSignature$IToken> suffix;
    private ClassSignature$Token tail;

    ClassSignature$Token() {
        this(false);
    }

    ClassSignature$Token(String string) {
        this(string, false);
    }

    ClassSignature$Token(char c) {
        this();
        this.symbol = c;
    }

    ClassSignature$Token(boolean bl) {
        this(null, bl);
    }

    ClassSignature$Token(String string, boolean bl) {
        this.inner = bl;
        this.type = string;
    }

    ClassSignature$Token setSymbol(char c) {
        if (ClassSignature$Token.lIIIllIlIll(this.symbol) && ClassSignature$Token.lIIIllIllII("+-*".indexOf(c), -1)) {
            this.symbol = c;
        }
        return this;
    }

    ClassSignature$Token setType(String string) {
        if (ClassSignature$Token.lIIIllIllIl(this.type)) {
            this.type = string;
        }
        return this;
    }

    boolean hasClassBound() {
        boolean bl;
        if (ClassSignature$Token.lIIIllIlllI(this.classBound)) {
            bl = true;
            "".length();
            if (((0xE ^ 0x1B) & ~(0x77 ^ 0x62)) != ((0x32 ^ 0x12) & ~(0xBE ^ 0x9E))) {
                return ((0x37 ^ 0x12) & ~(0xB1 ^ 0x94)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    boolean hasInterfaceBound() {
        boolean bl;
        if (ClassSignature$Token.lIIIllIlllI(this.ifaceBound)) {
            bl = true;
            "".length();
            if ("   ".length() != "   ".length()) {
                return ((0x63 ^ 0xA ^ (0x21 ^ 0x12)) & (180 + 164 - 295 + 196 ^ 173 + 29 - 181 + 154 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public ClassSignature$IToken setArray(boolean bl) {
        this.array |= bl;
        return this;
    }

    @Override
    public ClassSignature$IToken setWildcard(char c) {
        if (ClassSignature$Token.lIIIllIllll("+-".indexOf(c), -1)) {
            return this;
        }
        return this.setSymbol(c);
    }

    private List<ClassSignature$Token> getClassBound() {
        if (ClassSignature$Token.lIIIllIllIl(this.classBound)) {
            this.classBound = new ArrayList<ClassSignature$Token>();
        }
        return this.classBound;
    }

    private List<ClassSignature$Token> getIfaceBound() {
        if (ClassSignature$Token.lIIIllIllIl(this.ifaceBound)) {
            this.ifaceBound = new ArrayList<ClassSignature$Token>();
        }
        return this.ifaceBound;
    }

    private List<ClassSignature$IToken> getSignature() {
        if (ClassSignature$Token.lIIIllIllIl(this.signature)) {
            this.signature = new ArrayList<ClassSignature$IToken>();
        }
        return this.signature;
    }

    private List<ClassSignature$IToken> getSuffix() {
        if (ClassSignature$Token.lIIIllIllIl(this.suffix)) {
            this.suffix = new ArrayList<ClassSignature$IToken>();
        }
        return this.suffix;
    }

    ClassSignature$IToken addTypeArgument(char c) {
        if (ClassSignature$Token.lIIIllIlllI(this.tail)) {
            return this.tail.addTypeArgument(c);
        }
        ClassSignature$Token classSignature$Token = new ClassSignature$Token(c);
        this.getSignature().add(classSignature$Token);
        "".length();
        return classSignature$Token;
    }

    ClassSignature$IToken addTypeArgument(String string) {
        if (ClassSignature$Token.lIIIllIlllI(this.tail)) {
            return this.tail.addTypeArgument(string);
        }
        ClassSignature$Token classSignature$Token = new ClassSignature$Token(string);
        this.getSignature().add(classSignature$Token);
        "".length();
        return classSignature$Token;
    }

    ClassSignature$IToken addTypeArgument(ClassSignature$Token classSignature$Token) {
        if (ClassSignature$Token.lIIIllIlllI(this.tail)) {
            return this.tail.addTypeArgument(classSignature$Token);
        }
        this.getSignature().add(classSignature$Token);
        "".length();
        return classSignature$Token;
    }

    ClassSignature$IToken addTypeArgument(ClassSignature$TokenHandle classSignature$TokenHandle) {
        if (ClassSignature$Token.lIIIllIlllI(this.tail)) {
            return this.tail.addTypeArgument(classSignature$TokenHandle);
        }
        ClassSignature$TokenHandle classSignature$TokenHandle2 = classSignature$TokenHandle.clone();
        this.getSignature().add(classSignature$TokenHandle2);
        "".length();
        return classSignature$TokenHandle2;
    }

    ClassSignature$Token addBound(String string, boolean bl) {
        if (ClassSignature$Token.lIIIlllIIII(bl ? 1 : 0)) {
            return this.addClassBound(string);
        }
        return this.addInterfaceBound(string);
    }

    ClassSignature$Token addClassBound(String string) {
        ClassSignature$Token classSignature$Token = new ClassSignature$Token(string);
        this.getClassBound().add(classSignature$Token);
        "".length();
        return classSignature$Token;
    }

    ClassSignature$Token addInterfaceBound(String string) {
        ClassSignature$Token classSignature$Token = new ClassSignature$Token(string);
        this.getIfaceBound().add(classSignature$Token);
        "".length();
        return classSignature$Token;
    }

    ClassSignature$Token addInnerClass(String string) {
        this.tail = new ClassSignature$Token(string, true);
        this.getSuffix().add(this.tail);
        "".length();
        return this.tail;
    }

    public String toString() {
        return this.asType();
    }

    @Override
    public String asBound() {
        ClassSignature$Token classSignature$Token;
        Iterator<ClassSignature$Token> iterator;
        StringBuilder stringBuilder = new StringBuilder();
        if (ClassSignature$Token.lIIIllIlllI(this.type)) {
            stringBuilder.append(this.type);
            "".length();
        }
        if (ClassSignature$Token.lIIIllIlllI(this.classBound)) {
            iterator = this.classBound.iterator();
            while (ClassSignature$Token.lIIIlllIIII(iterator.hasNext() ? 1 : 0)) {
                classSignature$Token = iterator.next();
                stringBuilder.append(classSignature$Token.asType());
                "".length();
                "".length();
                if ("  ".length() != "   ".length()) continue;
                return null;
            }
        }
        if (ClassSignature$Token.lIIIllIlllI(this.ifaceBound)) {
            iterator = this.ifaceBound.iterator();
            while (ClassSignature$Token.lIIIlllIIII(iterator.hasNext() ? 1 : 0)) {
                classSignature$Token = iterator.next();
                stringBuilder.append(':').append(classSignature$Token.asType());
                "".length();
                "".length();
                if ("  ".length() != "   ".length()) continue;
                return null;
            }
        }
        return String.valueOf(stringBuilder);
    }

    @Override
    public String asType() {
        return this.asType(false);
    }

    public String asType(boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        if (ClassSignature$Token.lIIIlllIIII(this.array ? 1 : 0)) {
            stringBuilder.append('[');
            "".length();
        }
        if (ClassSignature$Token.lIIIlllIIII(this.symbol)) {
            stringBuilder.append(this.symbol);
            "".length();
        }
        if (ClassSignature$Token.lIIIllIllIl(this.type)) {
            return String.valueOf(stringBuilder);
        }
        if (ClassSignature$Token.lIIIllIlIll(this.inner ? 1 : 0)) {
            stringBuilder.append('L');
            "".length();
        }
        stringBuilder.append(this.type);
        "".length();
        if (ClassSignature$Token.lIIIllIlIll(bl ? 1 : 0)) {
            ClassSignature$IToken classSignature$IToken;
            Iterator<ClassSignature$IToken> iterator;
            if (ClassSignature$Token.lIIIllIlllI(this.signature)) {
                stringBuilder.append('<');
                "".length();
                iterator = this.signature.iterator();
                while (ClassSignature$Token.lIIIlllIIII(iterator.hasNext() ? 1 : 0)) {
                    classSignature$IToken = iterator.next();
                    stringBuilder.append(classSignature$IToken.asType());
                    "".length();
                    "".length();
                    if ((" ".length() & ~" ".length()) != -" ".length()) continue;
                    return null;
                }
                stringBuilder.append('>');
                "".length();
            }
            if (ClassSignature$Token.lIIIllIlllI(this.suffix)) {
                iterator = this.suffix.iterator();
                while (ClassSignature$Token.lIIIlllIIII(iterator.hasNext() ? 1 : 0)) {
                    classSignature$IToken = iterator.next();
                    stringBuilder.append('.').append(classSignature$IToken.asType());
                    "".length();
                    "".length();
                    if (null == null) continue;
                    return null;
                }
            }
        }
        if (ClassSignature$Token.lIIIllIlIll(this.inner ? 1 : 0)) {
            stringBuilder.append(';');
            "".length();
        }
        return String.valueOf(stringBuilder);
    }

    boolean isRaw() {
        boolean bl;
        if (ClassSignature$Token.lIIIllIllIl(this.signature)) {
            bl = true;
            "".length();
            if (" ".length() == 0) {
                return ((0x28 ^ 0x15) & ~(0x41 ^ 0x7C)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    String getClassType() {
        String string;
        if (ClassSignature$Token.lIIIllIlllI(this.type)) {
            string = this.type;
            "".length();
            if ((0x45 ^ 0x41) <= 0) {
                return null;
            }
        } else {
            string = "java/lang/Object";
        }
        return string;
    }

    @Override
    public ClassSignature$Token asToken() {
        return this;
    }

    private static boolean lIIIllIllll(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIllIllII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIIllIlllI(Object object) {
        return object != null;
    }

    private static boolean lIIIllIllIl(Object object) {
        return object == null;
    }

    private static boolean lIIIlllIIII(int n) {
        return n != 0;
    }

    private static boolean lIIIllIlIll(int n) {
        return n == 0;
    }
}

