/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.ClassSignature;
import org.spongepowered.asm.util.ClassSignature$IToken;
import org.spongepowered.asm.util.ClassSignature$Token;

class ClassSignature$TokenHandle
implements ClassSignature$IToken {
    final ClassSignature$Token token;
    boolean array;
    char wildcard;
    final /* synthetic */ ClassSignature this$0;

    ClassSignature$TokenHandle(ClassSignature classSignature) {
        this(classSignature, new ClassSignature$Token());
    }

    ClassSignature$TokenHandle(ClassSignature classSignature, ClassSignature$Token classSignature$Token) {
        this.this$0 = classSignature;
        this.token = classSignature$Token;
    }

    @Override
    public ClassSignature$IToken setArray(boolean bl) {
        this.array |= bl;
        return this;
    }

    @Override
    public ClassSignature$IToken setWildcard(char c) {
        if (ClassSignature$TokenHandle.lIIllIIlIII("+-".indexOf(c), -1)) {
            this.wildcard = c;
        }
        return this;
    }

    @Override
    public String asBound() {
        return this.token.asBound();
    }

    @Override
    public String asType() {
        StringBuilder stringBuilder = new StringBuilder();
        if (ClassSignature$TokenHandle.lIIllIIlIIl(this.wildcard)) {
            stringBuilder.append(this.wildcard);
            "".length();
        }
        if (ClassSignature$TokenHandle.lIIllIIlIlI(this.array ? 1 : 0)) {
            stringBuilder.append('[');
            "".length();
        }
        return String.valueOf(stringBuilder.append(this.this$0.getTypeVar(this)));
    }

    @Override
    public ClassSignature$Token asToken() {
        return this.token;
    }

    public String toString() {
        return this.token.toString();
    }

    public ClassSignature$TokenHandle clone() {
        return new ClassSignature$TokenHandle(this.this$0, this.token);
    }

    private static boolean lIIllIIlIII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIllIIlIlI(int n) {
        return n != 0;
    }

    private static boolean lIIllIIlIIl(int n) {
        return n > 0;
    }
}

