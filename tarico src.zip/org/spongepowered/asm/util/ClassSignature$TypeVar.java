/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

class ClassSignature$TypeVar
implements Comparable<ClassSignature$TypeVar> {
    private final String originalName;
    private String currentName;

    ClassSignature$TypeVar(String string) {
        this.currentName = this.originalName = string;
    }

    @Override
    public int compareTo(ClassSignature$TypeVar classSignature$TypeVar) {
        return this.currentName.compareTo(classSignature$TypeVar.currentName);
    }

    public String toString() {
        return this.currentName;
    }

    String getOriginalName() {
        return this.originalName;
    }

    void rename(String string) {
        this.currentName = string;
    }

    public boolean matches(String string) {
        return this.originalName.equals(string);
    }

    public boolean equals(Object object) {
        return this.currentName.equals(object);
    }

    public int hashCode() {
        return this.currentName.hashCode();
    }
}

