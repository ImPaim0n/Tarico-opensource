/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import org.spongepowered.asm.lib.signature.SignatureReader;
import org.spongepowered.asm.lib.signature.SignatureVisitor;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.util.ClassSignature$Lazy;
import org.spongepowered.asm.util.ClassSignature$SignatureParser;
import org.spongepowered.asm.util.ClassSignature$SignatureRemapper;
import org.spongepowered.asm.util.ClassSignature$Token;
import org.spongepowered.asm.util.ClassSignature$TokenHandle;
import org.spongepowered.asm.util.ClassSignature$TypeVar;

public class ClassSignature {
    protected static final String OBJECT = "java/lang/Object";
    private final Map<ClassSignature$TypeVar, ClassSignature$TokenHandle> types = new LinkedHashMap<ClassSignature$TypeVar, ClassSignature$TokenHandle>();
    private ClassSignature$Token superClass = new ClassSignature$Token("java/lang/Object");
    private final List<ClassSignature$Token> interfaces = new ArrayList<ClassSignature$Token>();
    private final Deque<String> rawInterfaces = new LinkedList<String>();

    ClassSignature() {
    }

    private ClassSignature read(String string) {
        if (ClassSignature.lllIIIIIl(string)) {
            try {
                new SignatureReader(string).accept(new ClassSignature$SignatureParser(this));
                "".length();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            if (null != null) {
                return null;
            }
        }
        return this;
    }

    protected ClassSignature$TypeVar getTypeVar(String string) {
        Iterator<ClassSignature$TypeVar> iterator = this.types.keySet().iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            ClassSignature$TypeVar classSignature$TypeVar = iterator.next();
            if (ClassSignature.lllIIIIlI(classSignature$TypeVar.matches(string) ? 1 : 0)) {
                return classSignature$TypeVar;
            }
            "".length();
            if (-" ".length() < ((0x11 ^ 0x59 ^ (0x88 ^ 0x83)) & (0xA1 ^ 0xBD ^ (0x33 ^ 0x6C) ^ -" ".length()))) continue;
            return null;
        }
        return null;
    }

    protected ClassSignature$TokenHandle getType(String string) {
        Object object = this.types.keySet().iterator();
        while (ClassSignature.lllIIIIlI(object.hasNext() ? 1 : 0)) {
            ClassSignature$TypeVar classSignature$TypeVar = object.next();
            if (ClassSignature.lllIIIIlI(classSignature$TypeVar.matches(string) ? 1 : 0)) {
                return this.types.get(classSignature$TypeVar);
            }
            "".length();
            if (((0x85 ^ 0x9C ^ (1 ^ 0x3D)) & (1 + 78 - 67 + 116 ^ 25 + 8 - -23 + 109 ^ -" ".length())) == 0) continue;
            return null;
        }
        object = new ClassSignature$TokenHandle(this);
        this.types.put(new ClassSignature$TypeVar(string), (ClassSignature$TokenHandle)object);
        "".length();
        return object;
    }

    protected String getTypeVar(ClassSignature$TokenHandle classSignature$TokenHandle) {
        Iterator<Map.Entry<ClassSignature$TypeVar, ClassSignature$TokenHandle>> iterator = this.types.entrySet().iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            Map.Entry<ClassSignature$TypeVar, ClassSignature$TokenHandle> entry = iterator.next();
            ClassSignature$TypeVar classSignature$TypeVar = entry.getKey();
            ClassSignature$TokenHandle classSignature$TokenHandle2 = entry.getValue();
            if (!ClassSignature.lllIIIIll(classSignature$TokenHandle, classSignature$TokenHandle2) || ClassSignature.lllIIIlII(classSignature$TokenHandle.asToken(), classSignature$TokenHandle2.asToken())) {
                return String.valueOf(new StringBuilder().append("T").append(classSignature$TypeVar).append(";"));
            }
            "".length();
            if ((0x15 ^ 0x1E ^ (0x6A ^ 0x64)) > 0) continue;
            return null;
        }
        return classSignature$TokenHandle.token.asType();
    }

    protected void addTypeVar(ClassSignature$TypeVar classSignature$TypeVar, ClassSignature$TokenHandle classSignature$TokenHandle) {
        if (ClassSignature.lllIIIIlI(this.types.containsKey(classSignature$TypeVar) ? 1 : 0)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("TypeVar ").append(classSignature$TypeVar).append(" is already present on ").append(this)));
        }
        this.types.put(classSignature$TypeVar, classSignature$TokenHandle);
        "".length();
    }

    protected void setSuperClass(ClassSignature$Token classSignature$Token) {
        this.superClass = classSignature$Token;
    }

    public String getSuperClass() {
        return this.superClass.asType(true);
    }

    protected void addInterface(ClassSignature$Token classSignature$Token) {
        if (ClassSignature.lllIIIlIl(classSignature$Token.isRaw() ? 1 : 0)) {
            String string = classSignature$Token.asType(true);
            ListIterator<ClassSignature$Token> listIterator = this.interfaces.listIterator();
            while (ClassSignature.lllIIIIlI(listIterator.hasNext() ? 1 : 0)) {
                ClassSignature$Token classSignature$Token2 = listIterator.next();
                if (ClassSignature.lllIIIIlI(classSignature$Token2.isRaw() ? 1 : 0) && ClassSignature.lllIIIIlI(classSignature$Token2.asType(true).equals(string) ? 1 : 0)) {
                    listIterator.set(classSignature$Token);
                    return;
                }
                "".length();
                if ("  ".length() <= "   ".length()) continue;
                return;
            }
        }
        this.interfaces.add(classSignature$Token);
        "".length();
    }

    public void addInterface(String string) {
        this.rawInterfaces.add(string);
        "".length();
    }

    protected void addRawInterface(String string) {
        ClassSignature$Token classSignature$Token = new ClassSignature$Token(string);
        String string2 = classSignature$Token.asType(true);
        Iterator<ClassSignature$Token> iterator = this.interfaces.iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            ClassSignature$Token classSignature$Token2 = iterator.next();
            if (ClassSignature.lllIIIIlI(classSignature$Token2.asType(true).equals(string2) ? 1 : 0)) {
                return;
            }
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
        this.interfaces.add(classSignature$Token);
        "".length();
    }

    public void merge(ClassSignature classSignature) {
        Object object;
        Iterator<ClassSignature$Token> iterator;
        try {
            iterator = new HashSet<String>();
            object = this.types.keySet().iterator();
            while (ClassSignature.lllIIIIlI(object.hasNext() ? 1 : 0)) {
                ClassSignature$TypeVar classSignature$TypeVar = object.next();
                iterator.add((ClassSignature$Token)((Object)classSignature$TypeVar.toString()));
                "".length();
                "".length();
                if (((14 + 119 - 122 + 123 ^ 49 + 109 - -9 + 30) & (0xAC ^ 0xB2 ^ (0xC4 ^ 0x99) ^ -" ".length())) < " ".length()) continue;
                return;
            }
            classSignature.conform((Set<String>)((Object)iterator));
        }
        catch (IllegalStateException illegalStateException) {
            illegalStateException.printStackTrace();
            return;
        }
        "".length();
        if ("  ".length() < "  ".length()) {
            return;
        }
        iterator = classSignature.types.entrySet().iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            object = (Map.Entry)iterator.next();
            this.addTypeVar((ClassSignature$TypeVar)object.getKey(), (ClassSignature$TokenHandle)object.getValue());
            "".length();
            if (null == null) continue;
            return;
        }
        iterator = classSignature.interfaces.iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            object = iterator.next();
            this.addInterface((ClassSignature$Token)object);
            "".length();
            if ("  ".length() >= "  ".length()) continue;
            return;
        }
    }

    private void conform(Set<String> set) {
        Iterator<ClassSignature$TypeVar> iterator = this.types.keySet().iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            ClassSignature$TypeVar classSignature$TypeVar = iterator.next();
            String string = this.findUniqueName(classSignature$TypeVar.getOriginalName(), set);
            classSignature$TypeVar.rename(string);
            set.add(string);
            "".length();
            "".length();
            if (null == null) continue;
            return;
        }
    }

    private String findUniqueName(String string, Set<String> set) {
        String string2;
        if (ClassSignature.lllIIIlIl(set.contains(string) ? 1 : 0)) {
            return string;
        }
        if (ClassSignature.lllIIIlll(string.length(), 1) && ClassSignature.lllIIIIIl(string2 = this.findOffsetName(string.charAt(0), set))) {
            return string2;
        }
        string2 = this.findOffsetName('T', set, "", string);
        if (ClassSignature.lllIIIIIl(string2)) {
            return string2;
        }
        string2 = this.findOffsetName('T', set, string, "");
        if (ClassSignature.lllIIIIIl(string2)) {
            return string2;
        }
        string2 = this.findOffsetName('T', set, "T", string);
        if (ClassSignature.lllIIIIIl(string2)) {
            return string2;
        }
        string2 = this.findOffsetName('T', set, "", String.valueOf(new StringBuilder().append(string).append("Type")));
        if (ClassSignature.lllIIIIIl(string2)) {
            return string2;
        }
        throw new IllegalStateException(String.valueOf(new StringBuilder().append("Failed to conform type var: ").append(string)));
    }

    private String findOffsetName(char c, Set<String> set) {
        return this.findOffsetName(c, set, "", "");
    }

    private String findOffsetName(char c, Set<String> set, String string, String string2) {
        String string3 = String.format("%s%s%s", string, Character.valueOf(c), string2);
        if (ClassSignature.lllIIIlIl(set.contains(string3) ? 1 : 0)) {
            return string3;
        }
        if (ClassSignature.lllIIlIIl(c, 64) && ClassSignature.lllIIlIlI(c, 91)) {
            int n = c - 64;
            while (ClassSignature.lllIIlIll(n + 65, c)) {
                string3 = String.format("%s%s%s", string, Character.valueOf((char)(n + 65)), string2);
                if (ClassSignature.lllIIIlIl(set.contains(string3) ? 1 : 0)) {
                    return string3;
                }
                ++n;
                n %= 26;
                "".length();
                if (null == null) continue;
                return null;
            }
        }
        return null;
    }

    public SignatureVisitor getRemapper() {
        return new ClassSignature$SignatureRemapper(this);
    }

    public String toString() {
        Object object;
        while (ClassSignature.lllIIllII(this.rawInterfaces.size())) {
            this.addRawInterface(this.rawInterfaces.remove());
            "".length();
            if (-" ".length() != ((0x6B ^ 0x65) & ~(0x2A ^ 0x24))) continue;
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (ClassSignature.lllIIllII(this.types.size())) {
            int n = 0;
            object = new StringBuilder();
            Iterator<Map.Entry<ClassSignature$TypeVar, ClassSignature$TokenHandle>> iterator = this.types.entrySet().iterator();
            while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
                Map.Entry<ClassSignature$TypeVar, ClassSignature$TokenHandle> entry = iterator.next();
                String string = entry.getValue().asBound();
                if (ClassSignature.lllIIIlIl(string.isEmpty() ? 1 : 0)) {
                    ((StringBuilder)object).append(entry.getKey()).append(':').append(string);
                    "".length();
                    n = 1;
                }
                "".length();
                if ((0x31 ^ 0x35) <= (0x1D ^ 0x19)) continue;
                return null;
            }
            if (ClassSignature.lllIIIIlI(n)) {
                stringBuilder.append('<').append((CharSequence)object).append('>');
                "".length();
            }
        }
        stringBuilder.append(this.superClass.asType());
        "".length();
        Iterator<ClassSignature$Token> iterator = this.interfaces.iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            object = iterator.next();
            stringBuilder.append(((ClassSignature$Token)object).asType());
            "".length();
            "".length();
            if ((" ".length() & (" ".length() ^ -" ".length())) == 0) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    public ClassSignature wake() {
        return this;
    }

    public static ClassSignature of(String string) {
        return new ClassSignature().read(string);
    }

    public static ClassSignature of(ClassNode classNode) {
        if (ClassSignature.lllIIIIIl(classNode.signature)) {
            return ClassSignature.of(classNode.signature);
        }
        return ClassSignature.generate(classNode);
    }

    public static ClassSignature ofLazy(ClassNode classNode) {
        if (ClassSignature.lllIIIIIl(classNode.signature)) {
            return new ClassSignature$Lazy(classNode.signature);
        }
        return ClassSignature.generate(classNode);
    }

    private static ClassSignature generate(ClassNode classNode) {
        String string;
        ClassSignature classSignature = new ClassSignature();
        if (ClassSignature.lllIIIIIl(classNode.superName)) {
            string = classNode.superName;
            "".length();
            if ("   ".length() == ((0xE2 ^ 0xB3 ^ (0x6F ^ 0x2E)) & (0x5B ^ 0x4D ^ (0x70 ^ 0x76) ^ -" ".length()))) {
                return null;
            }
        } else {
            string = "java/lang/Object";
        }
        classSignature.setSuperClass(new ClassSignature$Token(string));
        Iterator<String> iterator = classNode.interfaces.iterator();
        while (ClassSignature.lllIIIIlI(iterator.hasNext() ? 1 : 0)) {
            String string2 = iterator.next();
            classSignature.addInterface(new ClassSignature$Token(string2));
            "".length();
            if ((" ".length() & ~" ".length()) >= 0) continue;
            return null;
        }
        return classSignature;
    }

    private static boolean lllIIIlll(int n, int n2) {
        return n == n2;
    }

    private static boolean lllIIlIlI(int n, int n2) {
        return n < n2;
    }

    private static boolean lllIIlIIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIIIIll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lllIIIIIl(Object object) {
        return object != null;
    }

    private static boolean lllIIIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIIIIlI(int n) {
        return n != 0;
    }

    private static boolean lllIIIlIl(int n) {
        return n == 0;
    }

    private static boolean lllIIllII(int n) {
        return n > 0;
    }

    private static boolean lllIIlIll(int n, int n2) {
        return n != n2;
    }
}

