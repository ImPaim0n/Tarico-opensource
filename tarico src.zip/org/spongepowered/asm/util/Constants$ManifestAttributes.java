/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

public abstract class Constants$ManifestAttributes {
    public static final String TWEAKER;
    public static final String MAINCLASS;
    public static final String MIXINCONFIGS;
    public static final String TOKENPROVIDERS;
    @Deprecated
    public static final String COMPATIBILITY;

    private Constants$ManifestAttributes() {
    }

    static {
        MIXINCONFIGS = "MixinConfigs";
        TOKENPROVIDERS = "MixinTokenProviders";
        TWEAKER = "TweakClass";
        COMPATIBILITY = "MixinCompatibilityLevel";
        MAINCLASS = "Main-Class";
    }
}

