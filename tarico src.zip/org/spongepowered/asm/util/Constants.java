/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.io.File;
import org.spongepowered.asm.mixin.Mixin;

public abstract class Constants {
    public static final String CTOR;
    public static final String CLINIT;
    public static final String IMAGINARY_SUPER;
    public static final String DEBUG_OUTPUT_PATH;
    public static final String MIXIN_PACKAGE;
    public static final String MIXIN_PACKAGE_REF;
    public static final String STRING;
    public static final String OBJECT;
    public static final String CLASS;
    public static final String SYNTHETIC_PACKAGE;
    public static final char UNICODE_SNOWMAN;
    public static final File DEBUG_OUTPUT_DIR;

    private Constants() {
    }

    static {
        STRING = "Ljava/lang/String;";
        DEBUG_OUTPUT_PATH = ".mixin.out";
        OBJECT = "Ljava/lang/Object;";
        UNICODE_SNOWMAN = (char)9731;
        CLINIT = "<clinit>";
        CTOR = "<init>";
        SYNTHETIC_PACKAGE = "org.spongepowered.asm.synthetic";
        CLASS = "Ljava/lang/Class;";
        IMAGINARY_SUPER = "super$";
        MIXIN_PACKAGE = Mixin.class.getPackage().getName();
        MIXIN_PACKAGE_REF = MIXIN_PACKAGE.replace('.', '/');
        DEBUG_OUTPUT_DIR = new File(".mixin.out");
    }
}

