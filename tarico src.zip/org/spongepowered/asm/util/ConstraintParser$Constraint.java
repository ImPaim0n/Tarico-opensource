/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.spongepowered.asm.util.ITokenProvider;
import org.spongepowered.asm.util.throwables.ConstraintViolationException;
import org.spongepowered.asm.util.throwables.InvalidConstraintException;

public class ConstraintParser$Constraint {
    public static final ConstraintParser$Constraint NONE = new ConstraintParser$Constraint();
    private static final Pattern pattern = Pattern.compile("^([A-Z0-9\\-_\\.]+)\\((?:(<|<=|>|>=|=)?([0-9]+)(<|(-)([0-9]+)?|>|(\\+)([0-9]+)?)?)?\\)$");
    private final String expr;
    private String token;
    private String[] constraint;
    private int min = Integer.MIN_VALUE;
    private int max = Integer.MAX_VALUE;
    private ConstraintParser$Constraint next;

    ConstraintParser$Constraint(String string) {
        this.expr = string;
        Matcher matcher = pattern.matcher(string);
        if (ConstraintParser$Constraint.llIlIIIlIl(matcher.matches() ? 1 : 0)) {
            throw new InvalidConstraintException(String.valueOf(new StringBuilder().append("Constraint syntax was invalid parsing: ").append(this.expr)));
        }
        this.token = matcher.group(1);
        this.constraint = new String[]{matcher.group(2), matcher.group(3), matcher.group(4), matcher.group(5), matcher.group(6), matcher.group(7), matcher.group(8)};
        this.parse();
    }

    private ConstraintParser$Constraint() {
        this.expr = null;
        this.token = "*";
        this.constraint = new String[0];
    }

    private void parse() {
        if (ConstraintParser$Constraint.llIlIIIlIl(this.has(1) ? 1 : 0)) {
            return;
        }
        this.min = this.val(1);
        this.max = this.min++;
        int n = this.has(0);
        if (ConstraintParser$Constraint.llIlIIIllI(this.has(4) ? 1 : 0)) {
            if (ConstraintParser$Constraint.llIlIIIllI(n)) {
                throw new InvalidConstraintException(String.valueOf(new StringBuilder().append("Unexpected modifier '").append(this.elem(0)).append("' in ").append(this.expr).append(" parsing range")));
            }
            this.max = this.val(4);
            if (ConstraintParser$Constraint.llIlIIIlll(this.max, this.min)) {
                throw new InvalidConstraintException(String.valueOf(new StringBuilder().append("Invalid range specified '").append(this.max).append("' is less than ").append(this.min).append(" in ").append(this.expr)));
            }
            return;
        }
        if (ConstraintParser$Constraint.llIlIIIllI(this.has(6) ? 1 : 0)) {
            if (ConstraintParser$Constraint.llIlIIIllI(n)) {
                throw new InvalidConstraintException(String.valueOf(new StringBuilder().append("Unexpected modifier '").append(this.elem(0)).append("' in ").append(this.expr).append(" parsing range")));
            }
            this.max = this.min + this.val(6);
            return;
        }
        if (ConstraintParser$Constraint.llIlIIIllI(n)) {
            if (ConstraintParser$Constraint.llIlIIIllI(this.has(3) ? 1 : 0)) {
                throw new InvalidConstraintException(String.valueOf(new StringBuilder().append("Unexpected trailing modifier '").append(this.elem(3)).append("' in ").append(this.expr)));
            }
            String string = this.elem(0);
            if (ConstraintParser$Constraint.llIlIIIllI(">".equals(string) ? 1 : 0)) {
                this.max = Integer.MAX_VALUE;
                "".length();
                if (((0x2F ^ 0x7F ^ (0x16 ^ 0x57)) & (46 + 33 - 0 + 51 ^ 44 + 95 - 57 + 65 ^ -" ".length())) != 0) {
                    return;
                }
            } else if (ConstraintParser$Constraint.llIlIIIllI(">=".equals(string) ? 1 : 0)) {
                this.max = Integer.MAX_VALUE;
                "".length();
                if (-" ".length() == "   ".length()) {
                    return;
                }
            } else if (ConstraintParser$Constraint.llIlIIIllI("<".equals(string) ? 1 : 0)) {
                this.max = --this.min;
                this.min = Integer.MIN_VALUE;
                "".length();
                if (" ".length() == 0) {
                    return;
                }
            } else if (ConstraintParser$Constraint.llIlIIIllI("<=".equals(string) ? 1 : 0)) {
                this.max = this.min;
                this.min = Integer.MIN_VALUE;
            }
            "".length();
            if ("   ".length() <= 0) {
                return;
            }
        } else if (ConstraintParser$Constraint.llIlIIIllI(this.has(2) ? 1 : 0)) {
            String string = this.elem(2);
            if (ConstraintParser$Constraint.llIlIIIllI("<".equals(string) ? 1 : 0)) {
                this.max = this.min;
                this.min = Integer.MIN_VALUE;
                "".length();
                if (-" ".length() > ((0x59 ^ 0x13 ^ (0xEA ^ 0xC3)) & (0xE3 ^ 0x99 ^ (0x78 ^ 0x61) ^ -" ".length()))) {
                    return;
                }
            } else {
                this.max = Integer.MAX_VALUE;
            }
        }
    }

    private boolean has(int n) {
        boolean bl;
        if (ConstraintParser$Constraint.llIlIIlIII(this.constraint[n])) {
            bl = true;
            "".length();
            if ("  ".length() < ((0xB7 ^ 0xA5) & ~(0x54 ^ 0x46))) {
                return ((0xA8 ^ 0x95) & ~(0x72 ^ 0x4F)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    private String elem(int n) {
        return this.constraint[n];
    }

    private int val(int n) {
        int n2;
        if (ConstraintParser$Constraint.llIlIIlIII(this.constraint[n])) {
            n2 = Integer.parseInt(this.constraint[n]);
            "".length();
            if ("   ".length() >= (129 + 84 - 120 + 84 ^ 99 + 12 - 1 + 71)) {
                return (0x41 ^ 0x7F ^ (0x2E ^ 0x4B)) & (56 + 83 - -23 + 82 ^ 95 + 20 - 105 + 165 ^ -" ".length());
            }
        } else {
            n2 = 0;
        }
        return n2;
    }

    void append(ConstraintParser$Constraint constraintParser$Constraint) {
        if (ConstraintParser$Constraint.llIlIIlIII(this.next)) {
            this.next.append(constraintParser$Constraint);
            return;
        }
        this.next = constraintParser$Constraint;
    }

    public String getToken() {
        return this.token;
    }

    public int getMin() {
        return this.min;
    }

    public int getMax() {
        return this.max;
    }

    public void check(ITokenProvider iTokenProvider) {
        if (ConstraintParser$Constraint.llIlIIlIIl(this, NONE)) {
            Integer n = iTokenProvider.getToken(this.token);
            if (ConstraintParser$Constraint.llIlIIlIlI(n)) {
                throw new ConstraintViolationException(String.valueOf(new StringBuilder().append("The token '").append(this.token).append("' could not be resolved in ").append(iTokenProvider)), this);
            }
            if (ConstraintParser$Constraint.llIlIIIlll(n, this.min)) {
                throw new ConstraintViolationException(String.valueOf(new StringBuilder().append("Token '").append(this.token).append("' has a value (").append(n).append(") which is less than the minimum value ").append(this.min).append(" in ").append(iTokenProvider)), this, (int)n);
            }
            if (ConstraintParser$Constraint.llIlIIlIll(n, this.max)) {
                throw new ConstraintViolationException(String.valueOf(new StringBuilder().append("Token '").append(this.token).append("' has a value (").append(n).append(") which is greater than the maximum value ").append(this.max).append(" in ").append(iTokenProvider)), this, (int)n);
            }
        }
        if (ConstraintParser$Constraint.llIlIIlIII(this.next)) {
            this.next.check(iTokenProvider);
        }
    }

    public String getRangeHumanReadable() {
        if (ConstraintParser$Constraint.llIlIIllII(this.min, Integer.MIN_VALUE) && ConstraintParser$Constraint.llIlIIllII(this.max, Integer.MAX_VALUE)) {
            return "ANY VALUE";
        }
        if (ConstraintParser$Constraint.llIlIIllII(this.min, Integer.MIN_VALUE)) {
            return String.format("less than or equal to %d", this.max);
        }
        if (ConstraintParser$Constraint.llIlIIllII(this.max, Integer.MAX_VALUE)) {
            return String.format("greater than or equal to %d", this.min);
        }
        if (ConstraintParser$Constraint.llIlIIllII(this.min, this.max)) {
            return String.format("%d", this.min);
        }
        return String.format("between %d and %d", this.min, this.max);
    }

    public String toString() {
        return String.format("Constraint(%s [%d-%d])", this.token, this.min, this.max);
    }

    private static boolean llIlIIllII(int n, int n2) {
        return n == n2;
    }

    private static boolean llIlIIIlll(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIIlIll(int n, int n2) {
        return n > n2;
    }

    private static boolean llIlIIlIIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlIIlIII(Object object) {
        return object != null;
    }

    private static boolean llIlIIlIlI(Object object) {
        return object == null;
    }

    private static boolean llIlIIIllI(int n) {
        return n != 0;
    }

    private static boolean llIlIIIlIl(int n) {
        return n == 0;
    }
}

