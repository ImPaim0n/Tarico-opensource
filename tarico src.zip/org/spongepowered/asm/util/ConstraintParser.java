/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.lib.tree.AnnotationNode;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.ConstraintParser$Constraint;

public final class ConstraintParser {
    private ConstraintParser() {
    }

    public static ConstraintParser$Constraint parse(String string) {
        ConstraintParser$Constraint constraintParser$Constraint;
        if (!ConstraintParser.llllllllll(string) || ConstraintParser.lIIIIIIIIII(string.length())) {
            return ConstraintParser$Constraint.NONE;
        }
        String[] stringArray = string.replaceAll("\\s", "").toUpperCase().split(";");
        ConstraintParser$Constraint constraintParser$Constraint2 = null;
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        int n2 = 0;
        while (ConstraintParser.lIIIIIIIIIl(n2, n)) {
            String string2 = stringArray2[n2];
            ConstraintParser$Constraint constraintParser$Constraint3 = new ConstraintParser$Constraint(string2);
            if (ConstraintParser.lIIIIIIIIlI(constraintParser$Constraint2)) {
                constraintParser$Constraint2 = constraintParser$Constraint3;
                "".length();
                if ("  ".length() <= 0) {
                    return null;
                }
            } else {
                constraintParser$Constraint2.append(constraintParser$Constraint3);
            }
            ++n2;
            "".length();
            if (null == null) continue;
            return null;
        }
        if (ConstraintParser.llllllllll(constraintParser$Constraint2)) {
            constraintParser$Constraint = constraintParser$Constraint2;
            "".length();
            if (("   ".length() & ~"   ".length()) > 0) {
                return null;
            }
        } else {
            constraintParser$Constraint = ConstraintParser$Constraint.NONE;
        }
        return constraintParser$Constraint;
    }

    public static ConstraintParser$Constraint parse(AnnotationNode annotationNode) {
        String string = Annotations.getValue(annotationNode, "constraints", "");
        return ConstraintParser.parse(string);
    }

    private static boolean lIIIIIIIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llllllllll(Object object) {
        return object != null;
    }

    private static boolean lIIIIIIIIlI(Object object) {
        return object == null;
    }

    private static boolean lIIIIIIIIII(int n) {
        return n == 0;
    }
}

