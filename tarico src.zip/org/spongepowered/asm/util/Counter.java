/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

public final class Counter {
    public int value;

    public boolean equals(Object object) {
        boolean bl;
        if (Counter.lIlIlllllll(object) && Counter.lIllIIIIIII(object.getClass(), Counter.class) && Counter.lIllIIIIIIl(((Counter)object).value, this.value)) {
            bl = true;
            "".length();
            if ("  ".length() <= " ".length()) {
                return ((0x78 ^ 0x66) & ~(0x78 ^ 0x66)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.value;
    }

    private static boolean lIllIIIIIIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIlIlllllll(Object object) {
        return object != null;
    }

    private static boolean lIllIIIIIII(Object object, Object object2) {
        return object == object2;
    }
}

