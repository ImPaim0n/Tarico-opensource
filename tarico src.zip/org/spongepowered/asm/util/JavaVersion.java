/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class JavaVersion {
    private static double current = 0.0;

    private JavaVersion() {
    }

    public static double current() {
        if (JavaVersion.lllllIIlllI(JavaVersion.lllllIIllIl(current, 0.0))) {
            current = JavaVersion.resolveCurrentVersion();
        }
        return current;
    }

    private static double resolveCurrentVersion() {
        String string = System.getProperty("java.version");
        Matcher matcher = Pattern.compile("[0-9]+\\.[0-9]+").matcher(string);
        if (JavaVersion.lllllIIllll(matcher.find() ? 1 : 0)) {
            return Double.parseDouble(matcher.group());
        }
        return 1.6;
    }

    private static boolean lllllIIllll(int n) {
        return n != 0;
    }

    private static boolean lllllIIlllI(int n) {
        return n == 0;
    }

    private static int lllllIIllIl(double d, double d2) {
        return d == d2 ? 0 : (d > d2 ? 1 : -1);
    }
}

