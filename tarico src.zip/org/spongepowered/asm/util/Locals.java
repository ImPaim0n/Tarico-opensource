/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.spongepowered.asm.lib.Opcodes;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.lib.tree.FrameNode;
import org.spongepowered.asm.lib.tree.InsnList;
import org.spongepowered.asm.lib.tree.LabelNode;
import org.spongepowered.asm.lib.tree.LineNumberNode;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.lib.tree.analysis.Analyzer;
import org.spongepowered.asm.lib.tree.analysis.AnalyzerException;
import org.spongepowered.asm.lib.tree.analysis.BasicValue;
import org.spongepowered.asm.lib.tree.analysis.Frame;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.ClassInfo$FrameData;
import org.spongepowered.asm.mixin.transformer.ClassInfo$Method;
import org.spongepowered.asm.util.asm.MixinVerifier;
import org.spongepowered.asm.util.throwables.LVTGeneratorException;

public final class Locals {
    private static final Map<String, List<LocalVariableNode>> calculatedLocalVariables = new HashMap<String, List<LocalVariableNode>>();

    private Locals() {
    }

    public static void loadLocals(Type[] typeArray, InsnList insnList, int n, int n2) {
        while (Locals.llIlIlIllII(n, typeArray.length) && Locals.llIlIlIllIl(n2)) {
            if (Locals.llIlIlIlllI(typeArray[n])) {
                insnList.add(new VarInsnNode(typeArray[n].getOpcode(21), n));
                --n2;
            }
            ++n;
            "".length();
            if (((0xEF ^ 0x9F ^ (0xDF ^ 0xA6)) & (0x6D ^ 0x56 ^ (0xB3 ^ 0x81) ^ -" ".length())) <= 0) continue;
            return;
        }
    }

    public static LocalVariableNode[] getLocalsAt(ClassNode classNode, MethodNode methodNode, AbstractInsnNode abstractInsnNode) {
        Object object;
        int n = 0;
        while (Locals.llIlIlIllII(n, 3) && (!Locals.llIlIlIllll(abstractInsnNode instanceof LabelNode) || Locals.llIlIllIIII(abstractInsnNode instanceof LineNumberNode))) {
            abstractInsnNode = Locals.nextNode(methodNode.instructions, abstractInsnNode);
            ++n;
            "".length();
            if (" ".length() != 0) continue;
            return null;
        }
        ClassInfo classInfo = ClassInfo.forName(classNode.name);
        if (Locals.llIlIllIIIl(classInfo)) {
            throw new LVTGeneratorException(String.valueOf(new StringBuilder().append("Could not load class metadata for ").append(classNode.name).append(" generating LVT for ").append(methodNode.name)));
        }
        ClassInfo$Method classInfo$Method = classInfo.findMethod(methodNode);
        if (Locals.llIlIllIIIl(classInfo$Method)) {
            throw new LVTGeneratorException(String.valueOf(new StringBuilder().append("Could not locate method metadata for ").append(methodNode.name).append(" generating LVT in ").append(classNode.name)));
        }
        List<ClassInfo$FrameData> list = classInfo$Method.getFrames();
        LocalVariableNode[] localVariableNodeArray = new LocalVariableNode[methodNode.maxLocals];
        int n2 = 0;
        int n3 = 0;
        if (Locals.llIlIlIllll(methodNode.access & 8)) {
            localVariableNodeArray[n2++] = new LocalVariableNode("this", classNode.name, null, null, null, 0);
        }
        Type[] typeArray = Type.getArgumentTypes(methodNode.desc);
        int n4 = typeArray.length;
        int n5 = 0;
        while (Locals.llIlIlIllII(n5, n4)) {
            object = typeArray[n5];
            localVariableNodeArray[n2] = new LocalVariableNode(String.valueOf(new StringBuilder().append("arg").append(n3++)), ((Type)object).toString(), null, null, null, n2);
            n2 += ((Type)object).getSize();
            ++n5;
            "".length();
            if (" ".length() <= "   ".length()) continue;
            return null;
        }
        int n6 = n2;
        n4 = -1;
        n5 = 0;
        object = methodNode.instructions.iterator();
        while (Locals.llIlIllIIII(object.hasNext() ? 1 : 0)) {
            AbstractInsnNode abstractInsnNode2;
            AbstractInsnNode abstractInsnNode3 = (AbstractInsnNode)object.next();
            if (Locals.llIlIllIIII(abstractInsnNode3 instanceof FrameNode)) {
                int n7;
                ClassInfo$FrameData classInfo$FrameData;
                ClassInfo$FrameData classInfo$FrameData2;
                abstractInsnNode2 = (FrameNode)abstractInsnNode3;
                if (Locals.llIlIlIllII(++n4, list.size())) {
                    classInfo$FrameData2 = list.get(n4);
                    "".length();
                    if (((0x28 ^ 1) & ~(0x42 ^ 0x6B)) == (0xA0 ^ 0xA4)) {
                        return null;
                    }
                } else {
                    classInfo$FrameData2 = null;
                }
                if (Locals.llIlIlIlllI(classInfo$FrameData = classInfo$FrameData2) && Locals.llIlIlIllll(classInfo$FrameData.type)) {
                    n7 = Math.min(n5, classInfo$FrameData.locals);
                    "".length();
                    if (" ".length() > (0x37 ^ 0x33)) {
                        return null;
                    }
                } else {
                    n7 = abstractInsnNode2.local.size();
                }
                n5 = n7;
                int n8 = 0;
                int n9 = 0;
                while (Locals.llIlIlIllII(n9, localVariableNodeArray.length)) {
                    Object object2;
                    Object object3;
                    if (Locals.llIlIlIllII(n8, abstractInsnNode2.local.size())) {
                        object3 = abstractInsnNode2.local.get(n8);
                        "".length();
                        if ("   ".length() == 0) {
                            return null;
                        }
                    } else {
                        object3 = null;
                    }
                    if (Locals.llIlIllIIII((object2 = object3) instanceof String)) {
                        localVariableNodeArray[n9] = Locals.getLocalVariableAt(classNode, methodNode, abstractInsnNode, n9);
                        "".length();
                        if (null != null) {
                            return null;
                        }
                    } else if (Locals.llIlIllIIII(object2 instanceof Integer)) {
                        int n10;
                        int n11;
                        int n12;
                        int n13;
                        int n14;
                        int n15;
                        if (!Locals.llIlIllIIlI(object2, Opcodes.UNINITIALIZED_THIS) || Locals.llIlIllIIll(object2, Opcodes.NULL)) {
                            n15 = 1;
                            "".length();
                            if ((0x33 ^ 0xA ^ (0x93 ^ 0xAE)) == 0) {
                                return null;
                            }
                        } else {
                            n15 = n14 = 0;
                        }
                        if (!Locals.llIlIllIIlI(object2, Opcodes.INTEGER) || Locals.llIlIllIIll(object2, Opcodes.FLOAT)) {
                            n13 = 1;
                            "".length();
                            if ((0xB2 ^ 0xB6) <= "   ".length()) {
                                return null;
                            }
                        } else {
                            n13 = n12 = 0;
                        }
                        if (!Locals.llIlIllIIlI(object2, Opcodes.DOUBLE) || Locals.llIlIllIIll(object2, Opcodes.LONG)) {
                            n11 = 1;
                            "".length();
                            if ((0x20 ^ 0x31 ^ (0x49 ^ 0x5C)) <= 0) {
                                return null;
                            }
                        } else {
                            n11 = n10 = 0;
                        }
                        if (Locals.llIlIllIIll(object2, Opcodes.TOP)) {
                            "".length();
                            if (((0x6B ^ 0x24 ^ (0x5D ^ 0x27)) & (0xC8 ^ 0x9A ^ (7 ^ 0x60) ^ -" ".length())) < 0) {
                                return null;
                            }
                        } else if (Locals.llIlIllIIII(n14)) {
                            localVariableNodeArray[n9] = null;
                            "".length();
                            if (-"   ".length() >= 0) {
                                return null;
                            }
                        } else if (!Locals.llIlIlIllll(n12) || Locals.llIlIllIIII(n10)) {
                            localVariableNodeArray[n9] = Locals.getLocalVariableAt(classNode, methodNode, abstractInsnNode, n9);
                            if (Locals.llIlIllIIII(n10)) {
                                localVariableNodeArray[++n9] = null;
                                "".length();
                                if (-" ".length() != -" ".length()) {
                                    return null;
                                }
                            }
                        } else {
                            throw new LVTGeneratorException(String.valueOf(new StringBuilder().append("Unrecognised locals opcode ").append(object2).append(" in locals array at position ").append(n8).append(" in ").append(classNode.name).append(".").append(methodNode.name).append(methodNode.desc)));
                        }
                        "".length();
                        if (((0x85 ^ 0x98) & ~(0xA7 ^ 0xBA)) >= " ".length()) {
                            return null;
                        }
                    } else if (Locals.llIlIllIIIl(object2)) {
                        if (Locals.llIlIllIlII(n9, n6) && Locals.llIlIllIlII(n9, n5) && Locals.llIlIlIllIl(n5)) {
                            localVariableNodeArray[n9] = null;
                            "".length();
                            if (((0xA9 ^ 0xB7 ^ (0xF ^ 0x1E)) & (54 + 75 - 94 + 152 ^ 38 + 0 - 23 + 165 ^ -" ".length())) > ((185 + 111 - 128 + 74 ^ 7 + 41 - -71 + 25) & (169 + 103 - 270 + 195 ^ 100 + 147 - 176 + 96 ^ -" ".length()))) {
                                return null;
                            }
                        }
                    } else {
                        throw new LVTGeneratorException(String.valueOf(new StringBuilder().append("Invalid value ").append(object2).append(" in locals array at position ").append(n8).append(" in ").append(classNode.name).append(".").append(methodNode.name).append(methodNode.desc)));
                    }
                    ++n9;
                    ++n8;
                    "".length();
                    if (((0x1B ^ 0x33) & ~(0xA1 ^ 0x89)) == 0) continue;
                    return null;
                }
                "".length();
                if ((0x9F ^ 0x9A ^ (0xE4 ^ 0x86) & ~(0x74 ^ 0x16)) == 0) {
                    return null;
                }
            } else if (Locals.llIlIllIIII(abstractInsnNode3 instanceof VarInsnNode)) {
                abstractInsnNode2 = (VarInsnNode)abstractInsnNode3;
                localVariableNodeArray[((VarInsnNode)abstractInsnNode2).var] = Locals.getLocalVariableAt(classNode, methodNode, abstractInsnNode, ((VarInsnNode)abstractInsnNode2).var);
            }
            if (Locals.llIlIllIIll(abstractInsnNode3, abstractInsnNode)) {
                "".length();
                if (((151 + 25 - 41 + 56 ^ 8 + 71 - 65 + 117) & (0x78 ^ 0x71 ^ (0x69 ^ 0x5C) ^ -" ".length())) < (162 + 160 - 246 + 98 ^ 48 + 68 - 98 + 152)) break;
                return null;
            }
            "".length();
            if (-" ".length() < " ".length()) continue;
            return null;
        }
        int n16 = 0;
        while (Locals.llIlIlIllII(n16, localVariableNodeArray.length)) {
            if (Locals.llIlIlIlllI(localVariableNodeArray[n16]) && Locals.llIlIllIIIl(localVariableNodeArray[n16].desc)) {
                localVariableNodeArray[n16] = null;
            }
            ++n16;
            "".length();
            if ((0x2C ^ 0x28) >= -" ".length()) continue;
            return null;
        }
        return localVariableNodeArray;
    }

    public static LocalVariableNode getLocalVariableAt(ClassNode classNode, MethodNode methodNode, AbstractInsnNode abstractInsnNode, int n) {
        return Locals.getLocalVariableAt(classNode, methodNode, methodNode.instructions.indexOf(abstractInsnNode), n);
    }

    private static LocalVariableNode getLocalVariableAt(ClassNode classNode, MethodNode methodNode, int n, int n2) {
        LocalVariableNode localVariableNode;
        LocalVariableNode localVariableNode2;
        LocalVariableNode localVariableNode3 = null;
        LocalVariableNode localVariableNode4 = null;
        Iterator<LocalVariableNode> iterator = Locals.getLocalVariableTable(classNode, methodNode).iterator();
        while (Locals.llIlIllIIII(iterator.hasNext() ? 1 : 0)) {
            localVariableNode2 = iterator.next();
            if (Locals.llIlIllIlIl(localVariableNode2.index, n2)) {
                "".length();
                if (" ".length() > 0) continue;
                return null;
            }
            if (Locals.llIlIllIIII(Locals.isOpcodeInRange(methodNode.instructions, localVariableNode2, n) ? 1 : 0)) {
                localVariableNode3 = localVariableNode2;
                "".length();
                if (" ".length() <= 0) {
                    return null;
                }
            } else if (Locals.llIlIllIIIl(localVariableNode3)) {
                localVariableNode4 = localVariableNode2;
            }
            "".length();
            if (((0x52 ^ 0x58) & ~(0xAC ^ 0xA6)) == 0) continue;
            return null;
        }
        if (Locals.llIlIllIIIl(localVariableNode3) && Locals.llIlIlIllll(methodNode.localVariables.isEmpty() ? 1 : 0)) {
            iterator = Locals.getGeneratedLocalVariableTable(classNode, methodNode).iterator();
            while (Locals.llIlIllIIII(iterator.hasNext() ? 1 : 0)) {
                localVariableNode2 = iterator.next();
                if (Locals.llIlIllIllI(localVariableNode2.index, n2) && Locals.llIlIllIIII(Locals.isOpcodeInRange(methodNode.instructions, localVariableNode2, n) ? 1 : 0)) {
                    localVariableNode3 = localVariableNode2;
                }
                "".length();
                if (null == null) continue;
                return null;
            }
        }
        if (Locals.llIlIlIlllI(localVariableNode3)) {
            localVariableNode = localVariableNode3;
            "".length();
            if ((171 + 16 - 36 + 28 ^ 164 + 55 - 46 + 10) == " ".length()) {
                return null;
            }
        } else {
            localVariableNode = localVariableNode4;
        }
        return localVariableNode;
    }

    private static boolean isOpcodeInRange(InsnList insnList, LocalVariableNode localVariableNode, int n) {
        boolean bl;
        if (Locals.llIlIlIllII(insnList.indexOf(localVariableNode.start), n) && Locals.llIlIllIlll(insnList.indexOf(localVariableNode.end), n)) {
            bl = true;
            "".length();
            if ("   ".length() <= 0) {
                return ((0xC8 ^ 0xC4 ^ (0x34 ^ 0x19)) & (0x67 ^ 0x55 ^ (0x6D ^ 0x7E) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public static List<LocalVariableNode> getLocalVariableTable(ClassNode classNode, MethodNode methodNode) {
        if (Locals.llIlIllIIII(methodNode.localVariables.isEmpty() ? 1 : 0)) {
            return Locals.getGeneratedLocalVariableTable(classNode, methodNode);
        }
        return methodNode.localVariables;
    }

    public static List<LocalVariableNode> getGeneratedLocalVariableTable(ClassNode classNode, MethodNode methodNode) {
        String string = String.format("%s.%s%s", classNode.name, methodNode.name, methodNode.desc);
        List<LocalVariableNode> list = calculatedLocalVariables.get(string);
        if (Locals.llIlIlIlllI(list)) {
            return list;
        }
        list = Locals.generateLocalVariableTable(classNode, methodNode);
        calculatedLocalVariables.put(string, list);
        "".length();
        return list;
    }

    public static List<LocalVariableNode> generateLocalVariableTable(ClassNode classNode, MethodNode methodNode) {
        Object object;
        Object object2;
        ArrayList<Type> arrayList = null;
        if (Locals.llIlIlIlllI(classNode.interfaces)) {
            arrayList = new ArrayList<Type>();
            object2 = classNode.interfaces.iterator();
            while (Locals.llIlIllIIII(object2.hasNext() ? 1 : 0)) {
                object = (String)object2.next();
                arrayList.add(Type.getObjectType((String)object));
                "".length();
                "".length();
                if (((0xE3 ^ 0xB1 ^ (0xEB ^ 0xB1)) & (0xF7 ^ 0x8F ^ (0xE2 ^ 0x92) ^ -" ".length())) <= 0) continue;
                return null;
            }
        }
        object2 = null;
        if (Locals.llIlIlIlllI(classNode.superName)) {
            object2 = Type.getObjectType(classNode.superName);
        }
        object = new Analyzer<BasicValue>(new MixinVerifier(Type.getObjectType(classNode.name), (Type)object2, arrayList, false));
        try {
            ((Analyzer)object).analyze(classNode.name, methodNode);
            "".length();
            "".length();
        }
        catch (AnalyzerException analyzerException) {
            analyzerException.printStackTrace();
        }
        if ("  ".length() <= 0) {
            return null;
        }
        Frame<V>[] frameArray = ((Analyzer)object).getFrames();
        int n = methodNode.instructions.size();
        ArrayList<LocalVariableNode> arrayList2 = new ArrayList<LocalVariableNode>();
        LocalVariableNode[] localVariableNodeArray = new LocalVariableNode[methodNode.maxLocals];
        BasicValue[] basicValueArray = new BasicValue[methodNode.maxLocals];
        LabelNode[] labelNodeArray = new LabelNode[n];
        String[] stringArray = new String[methodNode.maxLocals];
        int n2 = 0;
        while (Locals.llIlIlIllII(n2, n)) {
            Frame frame = frameArray[n2];
            if (Locals.llIlIllIIIl(frame)) {
                "".length();
                if ("  ".length() >= "   ".length()) {
                    return null;
                }
            } else {
                LabelNode labelNode = null;
                int n3 = 0;
                while (Locals.llIlIlIllII(n3, frame.getLocals())) {
                    BasicValue basicValue = (BasicValue)frame.getLocal(n3);
                    if (Locals.llIlIllIIIl(basicValue) && Locals.llIlIllIIIl(basicValueArray[n3])) {
                        "".length();
                        if (" ".length() > " ".length()) {
                            return null;
                        }
                    } else if (Locals.llIlIlIlllI(basicValue) && Locals.llIlIllIIII(basicValue.equals(basicValueArray[n3]) ? 1 : 0)) {
                        "".length();
                        if ((0xAE ^ 0xAA) == ((6 ^ 0x13) & ~(0x7B ^ 0x6E))) {
                            return null;
                        }
                    } else {
                        Object object3;
                        if (Locals.llIlIllIIIl(labelNode)) {
                            object3 = methodNode.instructions.get(n2);
                            if (Locals.llIlIllIIII(object3 instanceof LabelNode)) {
                                labelNode = (LabelNode)object3;
                                "".length();
                                if (" ".length() <= 0) {
                                    return null;
                                }
                            } else {
                                labelNodeArray[n2] = labelNode = new LabelNode();
                            }
                        }
                        if (Locals.llIlIllIIIl(basicValue) && Locals.llIlIlIlllI(basicValueArray[n3])) {
                            arrayList2.add(localVariableNodeArray[n3]);
                            "".length();
                            localVariableNodeArray[n3].end = labelNode;
                            localVariableNodeArray[n3] = null;
                            "".length();
                            if (null != null) {
                                return null;
                            }
                        } else if (Locals.llIlIlIlllI(basicValue)) {
                            String string;
                            if (Locals.llIlIlIlllI(basicValueArray[n3])) {
                                arrayList2.add(localVariableNodeArray[n3]);
                                "".length();
                                localVariableNodeArray[n3].end = labelNode;
                                localVariableNodeArray[n3] = null;
                            }
                            if (Locals.llIlIlIlllI(basicValue.getType())) {
                                string = basicValue.getType().getDescriptor();
                                "".length();
                                if (" ".length() <= 0) {
                                    return null;
                                }
                            } else {
                                string = stringArray[n3];
                            }
                            object3 = string;
                            localVariableNodeArray[n3] = new LocalVariableNode(String.valueOf(new StringBuilder().append("var").append(n3)), (String)object3, null, labelNode, null, n3);
                            if (Locals.llIlIlIlllI(object3)) {
                                stringArray[n3] = object3;
                            }
                        }
                        basicValueArray[n3] = basicValue;
                    }
                    ++n3;
                    "".length();
                    if ((0x46 ^ 0x5E ^ (0x11 ^ 0xD)) != 0) continue;
                    return null;
                }
            }
            ++n2;
            "".length();
            if ("  ".length() == "  ".length()) continue;
            return null;
        }
        LabelNode labelNode = null;
        int n4 = 0;
        while (Locals.llIlIlIllII(n4, localVariableNodeArray.length)) {
            if (Locals.llIlIlIlllI(localVariableNodeArray[n4])) {
                if (Locals.llIlIllIIIl(labelNode)) {
                    labelNode = new LabelNode();
                    methodNode.instructions.add(labelNode);
                }
                localVariableNodeArray[n4].end = labelNode;
                arrayList2.add(localVariableNodeArray[n4]);
                "".length();
            }
            ++n4;
            "".length();
            if (null == null) continue;
            return null;
        }
        n4 = n - 1;
        while (Locals.llIlIlllIII(n4)) {
            if (Locals.llIlIlIlllI(labelNodeArray[n4])) {
                methodNode.instructions.insert(methodNode.instructions.get(n4), labelNodeArray[n4]);
            }
            --n4;
            "".length();
            if ("  ".length() == "  ".length()) continue;
            return null;
        }
        return arrayList2;
    }

    private static AbstractInsnNode nextNode(InsnList insnList, AbstractInsnNode abstractInsnNode) {
        int n = insnList.indexOf(abstractInsnNode) + 1;
        if (Locals.llIlIlIllIl(n) && Locals.llIlIlIllII(n, insnList.size())) {
            return insnList.get(n);
        }
        return abstractInsnNode;
    }

    private static boolean llIlIllIllI(int n, int n2) {
        return n == n2;
    }

    private static boolean llIlIllIlII(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIlIlIllII(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIllIlll(int n, int n2) {
        return n > n2;
    }

    private static boolean llIlIllIIlI(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlIlIlllI(Object object) {
        return object != null;
    }

    private static boolean llIlIllIIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIlIllIIIl(Object object) {
        return object == null;
    }

    private static boolean llIlIllIIII(int n) {
        return n != 0;
    }

    private static boolean llIlIlIllll(int n) {
        return n == 0;
    }

    private static boolean llIlIlllIII(int n) {
        return n >= 0;
    }

    private static boolean llIlIlIllIl(int n) {
        return n > 0;
    }

    private static boolean llIlIllIlIl(int n, int n2) {
        return n != n2;
    }
}

