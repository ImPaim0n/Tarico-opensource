/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

public interface ObfuscationUtil$IClassRemapper {
    public String map(String var1);

    public String unmap(String var1);
}

