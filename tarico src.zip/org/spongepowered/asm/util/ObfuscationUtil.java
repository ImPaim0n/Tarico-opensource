/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.ObfuscationUtil$IClassRemapper;

public abstract class ObfuscationUtil {
    private ObfuscationUtil() {
    }

    public static String mapDescriptor(String string, ObfuscationUtil$IClassRemapper obfuscationUtil$IClassRemapper) {
        return ObfuscationUtil.remapDescriptor(string, obfuscationUtil$IClassRemapper, false);
    }

    public static String unmapDescriptor(String string, ObfuscationUtil$IClassRemapper obfuscationUtil$IClassRemapper) {
        return ObfuscationUtil.remapDescriptor(string, obfuscationUtil$IClassRemapper, true);
    }

    private static String remapDescriptor(String string, ObfuscationUtil$IClassRemapper obfuscationUtil$IClassRemapper, boolean bl) {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = null;
        int n = 0;
        while (ObfuscationUtil.lIIIlllIIllI(n, string.length())) {
            char c = string.charAt(n);
            if (ObfuscationUtil.lIIIlllIIlll(stringBuilder2)) {
                if (ObfuscationUtil.lIIIlllIlIII(c, 59)) {
                    stringBuilder.append('L').append(ObfuscationUtil.remap(String.valueOf(stringBuilder2), obfuscationUtil$IClassRemapper, bl)).append(';');
                    "".length();
                    stringBuilder2 = null;
                    "".length();
                    if (((124 + 150 - 130 + 92 ^ 107 + 66 - 113 + 105) & (0x70 ^ 0x60 ^ (0x9C ^ 0xC5) ^ -" ".length())) < -" ".length()) {
                        return null;
                    }
                } else {
                    stringBuilder2.append(c);
                    "".length();
                    "".length();
                    if (((0x69 ^ 0x77) & ~(0x94 ^ 0x8A)) > 0) {
                        return null;
                    }
                }
            } else if (ObfuscationUtil.lIIIlllIlIII(c, 76)) {
                stringBuilder2 = new StringBuilder();
                "".length();
                if (-" ".length() >= ((0xE4 ^ 0xB3) & ~(0x75 ^ 0x22))) {
                    return null;
                }
            } else {
                stringBuilder.append(c);
                "".length();
            }
            ++n;
            "".length();
            if (-"  ".length() < 0) continue;
            return null;
        }
        if (ObfuscationUtil.lIIIlllIIlll(stringBuilder2)) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Invalid descriptor '").append(string).append("', missing ';'")));
        }
        return String.valueOf(stringBuilder);
    }

    private static Object remap(String string, ObfuscationUtil$IClassRemapper obfuscationUtil$IClassRemapper, boolean bl) {
        String string2;
        String string3;
        String string4;
        if (ObfuscationUtil.lIIIlllIlIIl(bl ? 1 : 0)) {
            string4 = obfuscationUtil$IClassRemapper.unmap(string);
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string4 = obfuscationUtil$IClassRemapper.map(string);
        }
        if (ObfuscationUtil.lIIIlllIIlll(string3 = string4)) {
            string2 = string3;
            "".length();
            if (((0x26 ^ 8) & ~(0xA4 ^ 0x8A)) != ((0x69 ^ 0x7A) & ~(9 ^ 0x1A))) {
                return null;
            }
        } else {
            string2 = string;
        }
        return string2;
    }

    private static boolean lIIIlllIlIII(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIlllIIllI(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlllIIlll(Object object) {
        return object != null;
    }

    private static boolean lIIIlllIlIIl(int n) {
        return n != 0;
    }
}

