/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.PrettyPrinter;

class PrettyPrinter$CentredText {
    private final Object centred;
    final /* synthetic */ PrettyPrinter this$0;

    public PrettyPrinter$CentredText(PrettyPrinter prettyPrinter, Object object) {
        this.this$0 = prettyPrinter;
        this.centred = object;
    }

    public String toString() {
        String string = this.centred.toString();
        return String.format(String.valueOf(new StringBuilder().append("%").append((this.this$0.width - string.length()) / 2 + string.length()).append("s")), string);
    }
}

