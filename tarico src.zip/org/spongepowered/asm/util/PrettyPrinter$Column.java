/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.PrettyPrinter$Alignment;
import org.spongepowered.asm.util.PrettyPrinter$Table;

class PrettyPrinter$Column {
    private final PrettyPrinter$Table table;
    private PrettyPrinter$Alignment align = PrettyPrinter$Alignment.LEFT;
    private int minWidth = 1;
    private int maxWidth = Integer.MAX_VALUE;
    private int size = 0;
    private String title = "";
    private String format = "%s";

    PrettyPrinter$Column(PrettyPrinter$Table prettyPrinter$Table) {
        this.table = prettyPrinter$Table;
    }

    PrettyPrinter$Column(PrettyPrinter$Table prettyPrinter$Table, String string) {
        this(prettyPrinter$Table);
        this.title = string;
        this.minWidth = string.length();
        this.updateFormat();
    }

    PrettyPrinter$Column(PrettyPrinter$Table prettyPrinter$Table, PrettyPrinter$Alignment prettyPrinter$Alignment, int n, String string) {
        this(prettyPrinter$Table, string);
        this.align = prettyPrinter$Alignment;
        this.size = n;
    }

    void setAlignment(PrettyPrinter$Alignment prettyPrinter$Alignment) {
        this.align = prettyPrinter$Alignment;
        this.updateFormat();
    }

    void setWidth(int n) {
        if (PrettyPrinter$Column.lllIllIll(n, this.size)) {
            this.size = n;
            this.updateFormat();
        }
    }

    void setMinWidth(int n) {
        if (PrettyPrinter$Column.lllIllIll(n, this.minWidth)) {
            this.minWidth = n;
            this.updateFormat();
        }
    }

    void setMaxWidth(int n) {
        this.size = Math.min(this.size, this.maxWidth);
        this.maxWidth = Math.max(1, n);
        this.updateFormat();
    }

    void setTitle(String string) {
        this.title = string;
        this.setWidth(string.length());
    }

    private void updateFormat() {
        String string;
        int n;
        if (PrettyPrinter$Column.lllIlllII(this.size)) {
            n = this.minWidth;
            "".length();
            if ("   ".length() < 0) {
                return;
            }
        } else {
            n = this.size;
        }
        int n2 = Math.min(this.maxWidth, n);
        StringBuilder stringBuilder = new StringBuilder().append("%");
        if (PrettyPrinter$Column.lllIlllIl((Object)this.align, (Object)PrettyPrinter$Alignment.RIGHT)) {
            string = "";
            "".length();
            if (" ".length() <= 0) {
                return;
            }
        } else {
            string = "-";
        }
        this.format = String.valueOf(stringBuilder.append(string).append(n2).append("s"));
        this.table.updateFormat();
    }

    int getMaxWidth() {
        return this.maxWidth;
    }

    String getTitle() {
        return this.title;
    }

    String getFormat() {
        return this.format;
    }

    public String toString() {
        if (PrettyPrinter$Column.lllIllIll(this.title.length(), this.maxWidth)) {
            return this.title.substring(0, this.maxWidth);
        }
        return this.title;
    }

    private static boolean lllIllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lllIlllIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lllIlllII(int n) {
        return n == 0;
    }
}

