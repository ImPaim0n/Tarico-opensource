/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.util;

import com.google.common.base.Strings;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.PrettyPrinter$ISpecialEntry;

class PrettyPrinter$HorizontalRule
implements PrettyPrinter$ISpecialEntry {
    private final char[] hrChars;
    final /* synthetic */ PrettyPrinter this$0;

    public PrettyPrinter$HorizontalRule(PrettyPrinter prettyPrinter, char ... cArray) {
        this.this$0 = prettyPrinter;
        this.hrChars = cArray;
    }

    public String toString() {
        return Strings.repeat((String)new String(this.hrChars), (int)(this.this$0.width + 2));
    }
}

