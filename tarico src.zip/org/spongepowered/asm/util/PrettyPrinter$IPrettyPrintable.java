/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.PrettyPrinter;

public interface PrettyPrinter$IPrettyPrintable {
    public void print(PrettyPrinter var1);
}

