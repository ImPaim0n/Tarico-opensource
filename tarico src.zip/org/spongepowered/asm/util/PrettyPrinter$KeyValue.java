/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.PrettyPrinter$IVariableWidthEntry;

class PrettyPrinter$KeyValue
implements PrettyPrinter$IVariableWidthEntry {
    private final String key;
    private final Object value;
    final /* synthetic */ PrettyPrinter this$0;

    public PrettyPrinter$KeyValue(PrettyPrinter prettyPrinter, String string, Object object) {
        this.this$0 = prettyPrinter;
        this.key = string;
        this.value = object;
    }

    public String toString() {
        return String.format(this.this$0.kvFormat, this.key, this.value);
    }

    @Override
    public int getWidth() {
        return this.toString().length();
    }
}

