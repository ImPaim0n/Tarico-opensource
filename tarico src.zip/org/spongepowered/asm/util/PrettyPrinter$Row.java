/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import org.spongepowered.asm.util.PrettyPrinter$Column;
import org.spongepowered.asm.util.PrettyPrinter$IVariableWidthEntry;
import org.spongepowered.asm.util.PrettyPrinter$Table;

class PrettyPrinter$Row
implements PrettyPrinter$IVariableWidthEntry {
    final PrettyPrinter$Table table;
    final String[] args;

    public PrettyPrinter$Row(PrettyPrinter$Table prettyPrinter$Table, Object ... objectArray) {
        this.table = prettyPrinter$Table.grow(objectArray.length);
        this.args = new String[objectArray.length];
        int n = 0;
        while (PrettyPrinter$Row.lllllIlIlll(n, objectArray.length)) {
            this.args[n] = objectArray[n].toString();
            this.table.columns.get(n).setMinWidth(this.args[n].length());
            ++n;
            "".length();
            if ((20 + 141 - 71 + 80 ^ 111 + 42 - 17 + 38) != 0) continue;
            throw null;
        }
    }

    public String toString() {
        Object[] objectArray = new Object[this.table.columns.size()];
        int n = 0;
        while (PrettyPrinter$Row.lllllIlIlll(n, objectArray.length)) {
            PrettyPrinter$Column prettyPrinter$Column = this.table.columns.get(n);
            if (PrettyPrinter$Row.lllllIllIII(n, this.args.length)) {
                objectArray[n] = "";
                "".length();
                if (" ".length() <= 0) {
                    return null;
                }
            } else {
                String string;
                if (PrettyPrinter$Row.lllllIllIIl(this.args[n].length(), prettyPrinter$Column.getMaxWidth())) {
                    string = this.args[n].substring(0, prettyPrinter$Column.getMaxWidth());
                    "".length();
                    if (null != null) {
                        return null;
                    }
                } else {
                    string = this.args[n];
                }
                objectArray[n] = string;
            }
            ++n;
            "".length();
            if (null == null) continue;
            return null;
        }
        return String.format(this.table.format, objectArray);
    }

    @Override
    public int getWidth() {
        return this.toString().length();
    }

    private static boolean lllllIllIII(int n, int n2) {
        return n >= n2;
    }

    private static boolean lllllIlIlll(int n, int n2) {
        return n < n2;
    }

    private static boolean lllllIllIIl(int n, int n2) {
        return n > n2;
    }
}

