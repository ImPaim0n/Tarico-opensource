/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.util;

import com.google.common.base.Strings;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.util.PrettyPrinter$Alignment;
import org.spongepowered.asm.util.PrettyPrinter$Column;
import org.spongepowered.asm.util.PrettyPrinter$IVariableWidthEntry;
import org.spongepowered.asm.util.PrettyPrinter$Row;

class PrettyPrinter$Table
implements PrettyPrinter$IVariableWidthEntry {
    final List<PrettyPrinter$Column> columns = new ArrayList<PrettyPrinter$Column>();
    final List<PrettyPrinter$Row> rows = new ArrayList<PrettyPrinter$Row>();
    String format = "%s";
    int colSpacing = 2;
    boolean addHeader = true;

    PrettyPrinter$Table() {
    }

    void headerAdded() {
        this.addHeader = false;
    }

    void setColSpacing(int n) {
        this.colSpacing = Math.max(0, n);
        this.updateFormat();
    }

    PrettyPrinter$Table grow(int n) {
        while (PrettyPrinter$Table.lIlIIllll(this.columns.size(), n)) {
            this.columns.add(new PrettyPrinter$Column(this));
            "".length();
            "".length();
            if (" ".length() == " ".length()) continue;
            return null;
        }
        this.updateFormat();
        return this;
    }

    PrettyPrinter$Column add(PrettyPrinter$Column prettyPrinter$Column) {
        this.columns.add(prettyPrinter$Column);
        "".length();
        return prettyPrinter$Column;
    }

    PrettyPrinter$Row add(PrettyPrinter$Row row) {
        this.rows.add(row);
        "".length();
        return row;
    }

    PrettyPrinter$Column addColumn(String string) {
        return this.add(new PrettyPrinter$Column(this, string));
    }

    PrettyPrinter$Column addColumn(PrettyPrinter.Alignment alignment, int n, String string) {
        return this.add(new PrettyPrinter$Column(this, alignment, n, string));
    }

    PrettyPrinter$Row addRow(Object ... objectArray) {
        return this.add(new PrettyPrinter$Row(this, objectArray));
    }

    void updateFormat() {
        String string = Strings.repeat((String)" ", (int)this.colSpacing);
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        Iterator<PrettyPrinter$Column> iterator = this.columns.iterator();
        while (PrettyPrinter$Table.lIlIlIIII(iterator.hasNext() ? 1 : 0)) {
            PrettyPrinter$Column prettyPrinter$Column = iterator.next();
            if (PrettyPrinter$Table.lIlIlIIII(n)) {
                stringBuilder.append(string);
                "".length();
            }
            n = 1;
            stringBuilder.append(prettyPrinter$Column.getFormat());
            "".length();
            "".length();
            if (-" ".length() != ((145 + 44 - 38 + 47 ^ 102 + 25 - 35 + 52) & (0x69 ^ 0x74 ^ (0x3D ^ 0x76) ^ -" ".length()))) continue;
            return;
        }
        this.format = String.valueOf(stringBuilder);
    }

    String getFormat() {
        return this.format;
    }

    Object[] getTitles() {
        ArrayList<String> arrayList = new ArrayList<String>();
        Iterator<PrettyPrinter$Column> iterator = this.columns.iterator();
        while (PrettyPrinter$Table.lIlIlIIII(iterator.hasNext() ? 1 : 0)) {
            PrettyPrinter$Column prettyPrinter$Column = iterator.next();
            arrayList.add(prettyPrinter$Column.getTitle());
            "".length();
            "".length();
            if ("  ".length() > -" ".length()) continue;
            return null;
        }
        return arrayList.toArray();
    }

    public String toString() {
        String string;
        int n = 0;
        String[] stringArray = new String[this.columns.size()];
        int n2 = 0;
        while (PrettyPrinter$Table.lIlIIllll(n2, this.columns.size())) {
            int n3;
            stringArray[n2] = this.columns.get(n2).toString();
            if (PrettyPrinter$Table.lIlIlIIIl(stringArray[n2].isEmpty() ? 1 : 0)) {
                n3 = 1;
                "".length();
                if (-" ".length() > 0) {
                    return null;
                }
            } else {
                n3 = 0;
            }
            n |= n3;
            ++n2;
            "".length();
            if (-(0xCA ^ 0x9F ^ (0xFA ^ 0xAB)) <= 0) continue;
            return null;
        }
        if (PrettyPrinter$Table.lIlIlIIII(n)) {
            string = String.format(this.format, stringArray);
            "".length();
            if (-(0x7D ^ 0x58 ^ (0xB6 ^ 0x96)) >= 0) {
                return null;
            }
        } else {
            string = null;
        }
        return string;
    }

    @Override
    public int getWidth() {
        int n;
        String string = this.toString();
        if (PrettyPrinter$Table.lIlIlIIlI(string)) {
            n = string.length();
            "".length();
            if (-"  ".length() >= 0) {
                return (0x78 ^ 0x7E) & ~(0x3B ^ 0x3D);
            }
        } else {
            n = 0;
        }
        return n;
    }

    private static boolean lIlIIllll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIlIlIIlI(Object object) {
        return object != null;
    }

    private static boolean lIlIlIIII(int n) {
        return n != 0;
    }

    private static boolean lIlIlIIIl(int n) {
        return n == 0;
    }
}

