/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  org.apache.logging.log4j.Level
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.asm.util;

import com.google.common.base.Strings;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.util.PrettyPrinter$Alignment;
import org.spongepowered.asm.util.PrettyPrinter$CentredText;
import org.spongepowered.asm.util.PrettyPrinter$Column;
import org.spongepowered.asm.util.PrettyPrinter$HorizontalRule;
import org.spongepowered.asm.util.PrettyPrinter$IPrettyPrintable;
import org.spongepowered.asm.util.PrettyPrinter$ISpecialEntry;
import org.spongepowered.asm.util.PrettyPrinter$IVariableWidthEntry;
import org.spongepowered.asm.util.PrettyPrinter$KeyValue;
import org.spongepowered.asm.util.PrettyPrinter$Table;

public class PrettyPrinter {
    private final PrettyPrinter$HorizontalRule horizontalRule = new PrettyPrinter$HorizontalRule(this, '*');
    private final List<Object> lines = new ArrayList<Object>();
    private PrettyPrinter$Table table;
    private boolean recalcWidth = false;
    protected int width = 100;
    protected int wrapWidth = 80;
    protected int kvKeyWidth = 10;
    protected String kvFormat = PrettyPrinter.makeKvFormat(this.kvKeyWidth);

    public PrettyPrinter() {
        this(100);
    }

    public PrettyPrinter(int n) {
        this.width = n;
    }

    public PrettyPrinter wrapTo(int n) {
        this.wrapWidth = n;
        return this;
    }

    public int wrapTo() {
        return this.wrapWidth;
    }

    public PrettyPrinter table() {
        this.table = new PrettyPrinter$Table();
        return this;
    }

    public PrettyPrinter table(String ... stringArray) {
        this.table = new PrettyPrinter$Table();
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        int n2 = 0;
        while (PrettyPrinter.lIIllllIlIl(n2, n)) {
            String string = stringArray2[n2];
            this.table.addColumn(string);
            "".length();
            ++n2;
            "".length();
            if (-" ".length() <= 0) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter table(Object ... objectArray) {
        this.table = new PrettyPrinter$Table();
        PrettyPrinter$Column prettyPrinter$Column = null;
        Object[] objectArray2 = objectArray;
        int n = objectArray2.length;
        int n2 = 0;
        while (PrettyPrinter.lIIllllIlIl(n2, n)) {
            Object object = objectArray2[n2];
            if (PrettyPrinter.lIIllllIllI(object instanceof String)) {
                prettyPrinter$Column = this.table.addColumn((String)object);
                "".length();
                if (" ".length() != " ".length()) {
                    return null;
                }
            } else if (PrettyPrinter.lIIllllIllI(object instanceof Integer) && PrettyPrinter.lIIllllIlll(prettyPrinter$Column)) {
                int n3 = (Integer)object;
                if (PrettyPrinter.lIIlllllIII(n3)) {
                    prettyPrinter$Column.setWidth(n3);
                    "".length();
                    if ((0x29 ^ 0x2D) == 0) {
                        return null;
                    }
                } else if (PrettyPrinter.lIIlllllIIl(n3)) {
                    prettyPrinter$Column.setMaxWidth(-n3);
                }
                "".length();
                if (((171 + 82 - 103 + 90 ^ 149 + 93 - 161 + 82) & (0 + 7 - -95 + 44 ^ 20 + 76 - 77 + 174 ^ -" ".length())) != 0) {
                    return null;
                }
            } else if (PrettyPrinter.lIIllllIllI(object instanceof PrettyPrinter$Alignment) && PrettyPrinter.lIIllllIlll(prettyPrinter$Column)) {
                prettyPrinter$Column.setAlignment((PrettyPrinter$Alignment)((Object)object));
                "".length();
                if (-" ".length() >= 0) {
                    return null;
                }
            } else if (PrettyPrinter.lIIllllIlll(object)) {
                prettyPrinter$Column = this.table.addColumn(object.toString());
            }
            ++n2;
            "".length();
            if (-"  ".length() <= 0) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter spacing(int n) {
        if (PrettyPrinter.lIIlllllIlI(this.table)) {
            this.table = new PrettyPrinter$Table();
        }
        this.table.setColSpacing(n);
        return this;
    }

    public PrettyPrinter th() {
        return this.th(false);
    }

    private PrettyPrinter th(boolean bl) {
        if (PrettyPrinter.lIIlllllIlI(this.table)) {
            this.table = new PrettyPrinter$Table();
        }
        if (!PrettyPrinter.lIIllllIllI(bl ? 1 : 0) || PrettyPrinter.lIIllllIllI(this.table.addHeader ? 1 : 0)) {
            this.table.headerAdded();
            this.addLine(this.table);
        }
        return this;
    }

    public PrettyPrinter tr(Object ... objectArray) {
        this.th(true);
        "".length();
        this.addLine(this.table.addRow(objectArray));
        this.recalcWidth = true;
        return this;
    }

    public PrettyPrinter add() {
        this.addLine("");
        return this;
    }

    public PrettyPrinter add(String string) {
        this.addLine(string);
        this.width = Math.max(this.width, string.length());
        return this;
    }

    public PrettyPrinter add(String string, Object ... objectArray) {
        String string2 = String.format(string, objectArray);
        this.addLine(string2);
        this.width = Math.max(this.width, string2.length());
        return this;
    }

    public PrettyPrinter add(Object[] objectArray) {
        return this.add(objectArray, "%s");
    }

    public PrettyPrinter add(Object[] objectArray, String string) {
        Object[] objectArray2 = objectArray;
        int n = objectArray2.length;
        int n2 = 0;
        while (PrettyPrinter.lIIllllIlIl(n2, n)) {
            Object object = objectArray2[n2];
            this.add(string, object);
            "".length();
            ++n2;
            "".length();
            if (null == null) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter addIndexed(Object[] objectArray) {
        int n = String.valueOf(objectArray.length - 1).length();
        String string = String.valueOf(new StringBuilder().append("[%").append(n).append("d] %s"));
        int n2 = 0;
        while (PrettyPrinter.lIIllllIlIl(n2, objectArray.length)) {
            this.add(string, n2, objectArray[n2]);
            "".length();
            ++n2;
            "".length();
            if (-"  ".length() <= 0) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter addWithIndices(Collection<?> collection) {
        return this.addIndexed(collection.toArray());
    }

    public PrettyPrinter add(PrettyPrinter$IPrettyPrintable prettyPrinter$IPrettyPrintable) {
        if (PrettyPrinter.lIIllllIlll(prettyPrinter$IPrettyPrintable)) {
            prettyPrinter$IPrettyPrintable.print(this);
        }
        return this;
    }

    public PrettyPrinter add(Throwable throwable) {
        return this.add(throwable, 4);
    }

    public PrettyPrinter add(Throwable throwable, int n) {
        while (PrettyPrinter.lIIllllIlll(throwable)) {
            this.add("%s: %s", throwable.getClass().getName(), throwable.getMessage());
            "".length();
            this.add(throwable.getStackTrace(), n);
            "".length();
            throwable = throwable.getCause();
            "".length();
            if (((0x68 ^ 0x2D) & ~(0xE7 ^ 0xA2)) <= 0) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter add(StackTraceElement[] stackTraceElementArray, int n) {
        String string = Strings.repeat((String)" ", (int)n);
        StackTraceElement[] stackTraceElementArray2 = stackTraceElementArray;
        int n2 = stackTraceElementArray2.length;
        int n3 = 0;
        while (PrettyPrinter.lIIllllIlIl(n3, n2)) {
            StackTraceElement stackTraceElement = stackTraceElementArray2[n3];
            this.add("%s%s", string, stackTraceElement);
            "".length();
            ++n3;
            "".length();
            if ("  ".length() > 0) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter add(Object object) {
        return this.add(object, 0);
    }

    public PrettyPrinter add(Object object, int n) {
        String string = Strings.repeat((String)" ", (int)n);
        return this.append(object, n, string);
    }

    private PrettyPrinter append(Object object, int n, String string) {
        if (PrettyPrinter.lIIllllIllI(object instanceof String)) {
            return this.add("%s%s", string, object);
        }
        if (PrettyPrinter.lIIllllIllI(object instanceof Iterable)) {
            Iterator iterator = ((Iterable)object).iterator();
            while (PrettyPrinter.lIIllllIllI(iterator.hasNext() ? 1 : 0)) {
                Object t = iterator.next();
                this.append(t, n, string);
                "".length();
                "".length();
                if ((0xB ^ 0xF) > 0) continue;
                return null;
            }
            return this;
        }
        if (PrettyPrinter.lIIllllIllI(object instanceof Map)) {
            this.kvWidth(n);
            "".length();
            return this.add((Map)object);
        }
        if (PrettyPrinter.lIIllllIllI(object instanceof PrettyPrinter$IPrettyPrintable)) {
            return this.add((PrettyPrinter$IPrettyPrintable)object);
        }
        if (PrettyPrinter.lIIllllIllI(object instanceof Throwable)) {
            return this.add((Throwable)object, n);
        }
        if (PrettyPrinter.lIIllllIllI(object.getClass().isArray() ? 1 : 0)) {
            return this.add((Object[])object, String.valueOf(new StringBuilder().append(n).append("%s")));
        }
        return this.add("%s%s", string, object);
    }

    public PrettyPrinter addWrapped(String string, Object ... objectArray) {
        return this.addWrapped(this.wrapWidth, string, objectArray);
    }

    public PrettyPrinter addWrapped(int n, String string, Object ... objectArray) {
        String string2 = "";
        String string3 = String.format(string, objectArray).replace("\t", "    ");
        Matcher matcher = Pattern.compile("^(\\s+)(.*)$").matcher(string3);
        if (PrettyPrinter.lIIllllIllI(matcher.matches() ? 1 : 0)) {
            string2 = matcher.group(1);
        }
        try {
            Iterator<String> iterator = this.getWrapped(n, string3, string2).iterator();
            while (PrettyPrinter.lIIllllIllI(iterator.hasNext() ? 1 : 0)) {
                String string4 = iterator.next();
                this.addLine(string4);
                "".length();
                if (" ".length() > 0) continue;
                return null;
            }
            "".length();
        }
        catch (Exception exception) {
            this.add(string3);
            "".length();
        }
        if (((0x3C ^ 0xC) & ~(0x7A ^ 0x4A)) != 0) {
            return null;
        }
        return this;
    }

    private List<String> getWrapped(int n, String string, String string2) {
        ArrayList<String> arrayList = new ArrayList<String>();
        while (PrettyPrinter.lIIlllllIll(string.length(), n)) {
            int n2 = string.lastIndexOf(32, n);
            if (PrettyPrinter.lIIllllIlIl(n2, 10)) {
                n2 = n;
            }
            String string3 = string.substring(0, n2);
            arrayList.add(string3);
            "".length();
            string = String.valueOf(new StringBuilder().append(string2).append(string.substring(n2 + 1)));
            "".length();
            if ("   ".length() >= -" ".length()) continue;
            return null;
        }
        if (PrettyPrinter.lIIlllllIII(string.length())) {
            arrayList.add(string);
            "".length();
        }
        return arrayList;
    }

    public PrettyPrinter kv(String string, String string2, Object ... objectArray) {
        return this.kv(string, String.format(string2, objectArray));
    }

    public PrettyPrinter kv(String string, Object object) {
        this.addLine(new PrettyPrinter$KeyValue(this, string, object));
        return this.kvWidth(string.length());
    }

    public PrettyPrinter kvWidth(int n) {
        if (PrettyPrinter.lIIlllllIll(n, this.kvKeyWidth)) {
            this.kvKeyWidth = n;
            this.kvFormat = PrettyPrinter.makeKvFormat(n);
        }
        this.recalcWidth = true;
        return this;
    }

    public PrettyPrinter add(Map<?, ?> map) {
        Iterator<Map.Entry<?, ?>> iterator = map.entrySet().iterator();
        while (PrettyPrinter.lIIllllIllI(iterator.hasNext() ? 1 : 0)) {
            String string;
            Map.Entry<?, ?> entry = iterator.next();
            if (PrettyPrinter.lIIlllllIlI(entry.getKey())) {
                string = "null";
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                string = entry.getKey().toString();
            }
            String string2 = string;
            this.kv(string2, entry.getValue());
            "".length();
            "".length();
            if (null == null) continue;
            return null;
        }
        return this;
    }

    public PrettyPrinter hr() {
        return this.hr('*');
    }

    public PrettyPrinter hr(char c) {
        this.addLine(new PrettyPrinter$HorizontalRule(this, c));
        return this;
    }

    public PrettyPrinter centre() {
        Object object;
        if (PrettyPrinter.lIIllllllII(this.lines.isEmpty() ? 1 : 0) && PrettyPrinter.lIIllllIllI((object = this.lines.get(this.lines.size() - 1)) instanceof String)) {
            this.addLine(new PrettyPrinter$CentredText(this, this.lines.remove(this.lines.size() - 1)));
        }
        return this;
    }

    private void addLine(Object object) {
        if (PrettyPrinter.lIIlllllIlI(object)) {
            return;
        }
        this.lines.add(object);
        "".length();
        this.recalcWidth |= object instanceof PrettyPrinter$IVariableWidthEntry;
    }

    public PrettyPrinter trace() {
        return this.trace(PrettyPrinter.getDefaultLoggerName());
    }

    public PrettyPrinter trace(Level level) {
        return this.trace(PrettyPrinter.getDefaultLoggerName(), level);
    }

    public PrettyPrinter trace(String string) {
        return this.trace(System.err, LogManager.getLogger((String)string));
    }

    public PrettyPrinter trace(String string, Level level) {
        return this.trace(System.err, LogManager.getLogger((String)string), level);
    }

    public PrettyPrinter trace(Logger logger) {
        return this.trace(System.err, logger);
    }

    public PrettyPrinter trace(Logger logger, Level level) {
        return this.trace(System.err, logger, level);
    }

    public PrettyPrinter trace(PrintStream printStream) {
        return this.trace(printStream, PrettyPrinter.getDefaultLoggerName());
    }

    public PrettyPrinter trace(PrintStream printStream, Level level) {
        return this.trace(printStream, PrettyPrinter.getDefaultLoggerName(), level);
    }

    public PrettyPrinter trace(PrintStream printStream, String string) {
        return this.trace(printStream, LogManager.getLogger((String)string));
    }

    public PrettyPrinter trace(PrintStream printStream, String string, Level level) {
        return this.trace(printStream, LogManager.getLogger((String)string), level);
    }

    public PrettyPrinter trace(PrintStream printStream, Logger logger) {
        return this.trace(printStream, logger, Level.DEBUG);
    }

    public PrettyPrinter trace(PrintStream printStream, Logger logger, Level level) {
        this.log(logger, level);
        "".length();
        this.print(printStream);
        "".length();
        return this;
    }

    public PrettyPrinter print() {
        return this.print(System.err);
    }

    public PrettyPrinter print(PrintStream printStream) {
        this.updateWidth();
        this.printSpecial(printStream, this.horizontalRule);
        Iterator<Object> iterator = this.lines.iterator();
        while (PrettyPrinter.lIIllllIllI(iterator.hasNext() ? 1 : 0)) {
            Object object = iterator.next();
            if (PrettyPrinter.lIIllllIllI(object instanceof PrettyPrinter$ISpecialEntry)) {
                this.printSpecial(printStream, (PrettyPrinter$ISpecialEntry)object);
                "".length();
                if (((0x77 ^ 0x6F ^ (0x17 ^ 0x47)) & (0xAC ^ 0x88 ^ (0x4A ^ 0x26) ^ -" ".length())) != 0) {
                    return null;
                }
            } else {
                this.printString(printStream, object.toString());
            }
            "".length();
            if ((0x69 ^ 0x6D) != 0) continue;
            return null;
        }
        this.printSpecial(printStream, this.horizontalRule);
        return this;
    }

    private void printSpecial(PrintStream printStream, PrettyPrinter$ISpecialEntry prettyPrinter$ISpecialEntry) {
        printStream.printf("/*%s*/\n", prettyPrinter$ISpecialEntry.toString());
        "".length();
    }

    private void printString(PrintStream printStream, String string) {
        if (PrettyPrinter.lIIllllIlll(string)) {
            printStream.printf(String.valueOf(new StringBuilder().append("/* %-").append(this.width).append("s */\n")), string);
            "".length();
        }
    }

    public PrettyPrinter log(Logger logger) {
        return this.log(logger, Level.INFO);
    }

    public PrettyPrinter log(Logger logger, Level level) {
        this.updateWidth();
        this.logSpecial(logger, level, this.horizontalRule);
        Iterator<Object> iterator = this.lines.iterator();
        while (PrettyPrinter.lIIllllIllI(iterator.hasNext() ? 1 : 0)) {
            Object object = iterator.next();
            if (PrettyPrinter.lIIllllIllI(object instanceof PrettyPrinter$ISpecialEntry)) {
                this.logSpecial(logger, level, (PrettyPrinter$ISpecialEntry)object);
                "".length();
                if ("  ".length() > "  ".length()) {
                    return null;
                }
            } else {
                this.logString(logger, level, object.toString());
            }
            "".length();
            if ((0x22 ^ 0x27) != 0) continue;
            return null;
        }
        this.logSpecial(logger, level, this.horizontalRule);
        return this;
    }

    private void logSpecial(Logger logger, Level level, PrettyPrinter$ISpecialEntry prettyPrinter$ISpecialEntry) {
        logger.log(level, "/*{}*/", new Object[]{prettyPrinter$ISpecialEntry.toString()});
    }

    private void logString(Logger logger, Level level, String string) {
        if (PrettyPrinter.lIIllllIlll(string)) {
            logger.log(level, String.format(String.valueOf(new StringBuilder().append("/* %-").append(this.width).append("s */")), string));
        }
    }

    private void updateWidth() {
        if (PrettyPrinter.lIIllllIllI(this.recalcWidth ? 1 : 0)) {
            this.recalcWidth = false;
            Iterator<Object> iterator = this.lines.iterator();
            while (PrettyPrinter.lIIllllIllI(iterator.hasNext() ? 1 : 0)) {
                Object object = iterator.next();
                if (PrettyPrinter.lIIllllIllI(object instanceof PrettyPrinter$IVariableWidthEntry)) {
                    this.width = Math.min(4096, Math.max(this.width, ((PrettyPrinter$IVariableWidthEntry)object).getWidth()));
                }
                "".length();
                if ((0x56 ^ 0x19 ^ (0x1D ^ 0x57)) != 0) continue;
                return;
            }
        }
    }

    private static String makeKvFormat(int n) {
        return String.format("%%%ds : %%s", n);
    }

    private static String getDefaultLoggerName() {
        String string;
        String string2 = new Throwable().getStackTrace()[2].getClassName();
        int n = string2.lastIndexOf(46);
        if (PrettyPrinter.lIIllllllIl(n, -1)) {
            string = string2;
            "".length();
            if (" ".length() == 0) {
                return null;
            }
        } else {
            string = string2.substring(n + 1);
        }
        return string;
    }

    public static void dumpStack() {
        new PrettyPrinter().add(new Exception("Stack trace")).print(System.err);
        "".length();
    }

    public static void print(Throwable throwable) {
        new PrettyPrinter().add(throwable).print(System.err);
        "".length();
    }

    private static boolean lIIllllllIl(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIllllIlIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIlllllIll(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIllllIlll(Object object) {
        return object != null;
    }

    private static boolean lIIlllllIlI(Object object) {
        return object == null;
    }

    private static boolean lIIllllIllI(int n) {
        return n != 0;
    }

    private static boolean lIIllllllII(int n) {
        return n == 0;
    }

    private static boolean lIIlllllIIl(int n) {
        return n < 0;
    }

    private static boolean lIIlllllIII(int n) {
        return n > 0;
    }
}

