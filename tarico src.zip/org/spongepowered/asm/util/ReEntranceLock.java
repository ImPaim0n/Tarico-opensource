/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

public class ReEntranceLock {
    private final int maxDepth;
    private int depth = 0;
    private boolean semaphore = false;

    public ReEntranceLock(int n) {
        this.maxDepth = n;
    }

    public int getMaxDepth() {
        return this.maxDepth;
    }

    public int getDepth() {
        return this.depth;
    }

    public ReEntranceLock push() {
        ++this.depth;
        this.checkAndSet();
        "".length();
        return this;
    }

    public ReEntranceLock pop() {
        if (ReEntranceLock.lIIlIllll(this.depth)) {
            throw new IllegalStateException("ReEntranceLock pop() with zero depth");
        }
        --this.depth;
        return this;
    }

    public boolean check() {
        boolean bl;
        if (ReEntranceLock.lIIllIIII(this.depth, this.maxDepth)) {
            bl = true;
            "".length();
            if ("  ".length() <= 0) {
                return ((0x65 ^ 0x68) & ~(4 ^ 9)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean checkAndSet() {
        return this.semaphore |= this.check();
    }

    public ReEntranceLock set() {
        this.semaphore = true;
        return this;
    }

    public boolean isSet() {
        return this.semaphore;
    }

    public ReEntranceLock clear() {
        this.semaphore = false;
        return this;
    }

    private static boolean lIIllIIII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIlIllll(int n) {
        return n == 0;
    }
}

