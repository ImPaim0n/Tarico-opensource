/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.asm.util;

import com.google.common.base.Strings;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.LocalVariableNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;

public class SignaturePrinter {
    private final String name;
    private final Type returnType;
    private final Type[] argTypes;
    private final String[] argNames;
    private String modifiers = "private void";
    private boolean fullyQualified;

    public SignaturePrinter(MethodNode methodNode) {
        this(methodNode.name, Type.VOID_TYPE, Type.getArgumentTypes(methodNode.desc));
        this.setModifiers(methodNode);
    }

    public SignaturePrinter(MethodNode methodNode, String[] stringArray) {
        this(methodNode.name, Type.VOID_TYPE, Type.getArgumentTypes(methodNode.desc), stringArray);
        this.setModifiers(methodNode);
    }

    public SignaturePrinter(MemberInfo memberInfo) {
        this(memberInfo.name, memberInfo.desc);
    }

    public SignaturePrinter(String string, String string2) {
        this(string, Type.getReturnType(string2), Type.getArgumentTypes(string2));
    }

    public SignaturePrinter(String string, Type type, Type[] typeArray) {
        this.name = string;
        this.returnType = type;
        this.argTypes = new Type[typeArray.length];
        this.argNames = new String[typeArray.length];
        int n = 0;
        int n2 = 0;
        while (SignaturePrinter.llIIIlIll(n, typeArray.length)) {
            if (SignaturePrinter.llIIIllII(typeArray[n])) {
                this.argTypes[n] = typeArray[n];
                this.argNames[n] = String.valueOf(new StringBuilder().append("var").append(n2++));
            }
            ++n;
            "".length();
            if (-(36 + 89 - 101 + 171 ^ 121 + 187 - 285 + 175) < 0) continue;
            throw null;
        }
    }

    public SignaturePrinter(String string, Type type, LocalVariableNode[] localVariableNodeArray) {
        this.name = string;
        this.returnType = type;
        this.argTypes = new Type[localVariableNodeArray.length];
        this.argNames = new String[localVariableNodeArray.length];
        int n = 0;
        while (SignaturePrinter.llIIIlIll(n, localVariableNodeArray.length)) {
            if (SignaturePrinter.llIIIllII(localVariableNodeArray[n])) {
                this.argTypes[n] = Type.getType(localVariableNodeArray[n].desc);
                this.argNames[n] = localVariableNodeArray[n].name;
            }
            ++n;
            "".length();
            if (((0x73 ^ 0x2A) & ~(0x72 ^ 0x2B)) != -" ".length()) continue;
            throw null;
        }
    }

    public SignaturePrinter(String string, Type type, Type[] typeArray, String[] stringArray) {
        this.name = string;
        this.returnType = type;
        this.argTypes = typeArray;
        this.argNames = stringArray;
        if (SignaturePrinter.llIIIllIl(this.argTypes.length, this.argNames.length)) {
            throw new IllegalArgumentException(String.format("Types array length must not exceed names array length! (names=%d, types=%d)", this.argNames.length, this.argTypes.length));
        }
    }

    public String getFormattedArgs() {
        return String.valueOf(this.appendArgs(new StringBuilder(), true, true));
    }

    public String getReturnType() {
        return SignaturePrinter.getTypeName(this.returnType, false, this.fullyQualified);
    }

    public void setModifiers(MethodNode methodNode) {
        String string = SignaturePrinter.getTypeName(Type.getReturnType(methodNode.desc), false, this.fullyQualified);
        if (SignaturePrinter.llIIIlllI(methodNode.access & 1)) {
            this.setModifiers(String.valueOf(new StringBuilder().append("public ").append(string)));
            "".length();
            "".length();
            if ((0xF6 ^ 0x8D ^ 63 + 32 - -2 + 30) <= " ".length()) {
                return;
            }
        } else if (SignaturePrinter.llIIIlllI(methodNode.access & 4)) {
            this.setModifiers(String.valueOf(new StringBuilder().append("protected ").append(string)));
            "".length();
            "".length();
            if (" ".length() <= ((23 + 63 - 77 + 124 ^ 173 + 104 - 191 + 95) & (0xAF ^ 0xA1 ^ (0x4A ^ 0x74) ^ -" ".length()))) {
                return;
            }
        } else if (SignaturePrinter.llIIIlllI(methodNode.access & 2)) {
            this.setModifiers(String.valueOf(new StringBuilder().append("private ").append(string)));
            "".length();
            "".length();
            if ((0xB2 ^ 0xB6) != (0xAE ^ 0xAA)) {
                return;
            }
        } else {
            this.setModifiers(string);
            "".length();
        }
    }

    public SignaturePrinter setModifiers(String string) {
        this.modifiers = string.replace("${returnType}", this.getReturnType());
        return this;
    }

    public SignaturePrinter setFullyQualified(boolean bl) {
        this.fullyQualified = bl;
        return this;
    }

    public boolean isFullyQualified() {
        return this.fullyQualified;
    }

    public String toString() {
        return String.valueOf(this.appendArgs(new StringBuilder().append(this.modifiers).append(" ").append(this.name), false, true));
    }

    public String toDescriptor() {
        StringBuilder stringBuilder = this.appendArgs(new StringBuilder(), true, false);
        return String.valueOf(stringBuilder.append(SignaturePrinter.getTypeName(this.returnType, false, this.fullyQualified)));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private StringBuilder appendArgs(StringBuilder stringBuilder, boolean bl, boolean bl2) {
        stringBuilder.append('(');
        "".length();
        int n = 0;
        do {
            if (!SignaturePrinter.llIIIlIll(n, this.argTypes.length)) {
                return stringBuilder.append(")");
            }
            if (SignaturePrinter.llIIIllll(this.argTypes[n])) {
                "".length();
                if (" ".length() <= 0) {
                    return null;
                }
            } else {
                if (SignaturePrinter.llIIlIIII(n)) {
                    stringBuilder.append(',');
                    "".length();
                    if (SignaturePrinter.llIIIlllI(bl2 ? 1 : 0)) {
                        stringBuilder.append(' ');
                        "".length();
                    }
                }
                try {
                    String string;
                    if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                        string = null;
                        "".length();
                    } else if (SignaturePrinter.llIIIlllI(Strings.isNullOrEmpty((String)this.argNames[n]) ? 1 : 0)) {
                        string = String.valueOf(new StringBuilder().append("unnamed").append(n));
                        "".length();
                        if ("   ".length() != "   ".length()) {
                            return null;
                        }
                    } else {
                        string = this.argNames[n];
                    }
                    String string2 = string;
                    this.appendType(stringBuilder, this.argTypes[n], string2);
                    "".length();
                    "".length();
                }
                catch (Exception exception) {
                    throw new RuntimeException(exception);
                }
            }
            ++n;
            "".length();
        } while ("  ".length() >= " ".length());
        return null;
    }

    private StringBuilder appendType(StringBuilder stringBuilder, Type type, String string) {
        switch (type.getSort()) {
            case 9: {
                return SignaturePrinter.appendArraySuffix(this.appendType(stringBuilder, type.getElementType(), string), type);
            }
            case 10: {
                return this.appendType(stringBuilder, type.getClassName(), string);
            }
        }
        stringBuilder.append(SignaturePrinter.getTypeName(type, false, this.fullyQualified));
        "".length();
        if (SignaturePrinter.llIIIllII(string)) {
            stringBuilder.append(' ').append(string);
            "".length();
        }
        return stringBuilder;
    }

    private StringBuilder appendType(StringBuilder stringBuilder, String string, String string2) {
        if (SignaturePrinter.llIIlIIlI(this.fullyQualified ? 1 : 0)) {
            string = string.substring(string.lastIndexOf(46) + 1);
        }
        stringBuilder.append(string);
        "".length();
        if (SignaturePrinter.llIIIlllI(string.endsWith("CallbackInfoReturnable") ? 1 : 0)) {
            stringBuilder.append('<').append(SignaturePrinter.getTypeName(this.returnType, true, this.fullyQualified)).append('>');
            "".length();
        }
        if (SignaturePrinter.llIIIllII(string2)) {
            stringBuilder.append(' ').append(string2);
            "".length();
        }
        return stringBuilder;
    }

    public static String getTypeName(Type type, boolean bl) {
        return SignaturePrinter.getTypeName(type, bl, false);
    }

    public static String getTypeName(Type type, boolean bl, boolean bl2) {
        switch (type.getSort()) {
            case 0: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Void";
                    "".length();
                    if (" ".length() >= (0 ^ 4)) {
                        return null;
                    }
                } else {
                    string = "void";
                }
                return string;
            }
            case 1: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Boolean";
                    "".length();
                    if (((0x6A ^ 0x20) & ~(0x3F ^ 0x75)) != 0) {
                        return null;
                    }
                } else {
                    string = "boolean";
                }
                return string;
            }
            case 2: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Character";
                    "".length();
                    if (-(2 ^ 6) >= 0) {
                        return null;
                    }
                } else {
                    string = "char";
                }
                return string;
            }
            case 3: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Byte";
                    "".length();
                    if (" ".length() <= -" ".length()) {
                        return null;
                    }
                } else {
                    string = "byte";
                }
                return string;
            }
            case 4: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Short";
                    "".length();
                    if (-" ".length() > 0) {
                        return null;
                    }
                } else {
                    string = "short";
                }
                return string;
            }
            case 5: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Integer";
                    "".length();
                    if ((0xF5 ^ 0xB9 ^ (0x71 ^ 0x38)) <= 0) {
                        return null;
                    }
                } else {
                    string = "int";
                }
                return string;
            }
            case 6: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Float";
                    "".length();
                    if (-" ".length() > 0) {
                        return null;
                    }
                } else {
                    string = "float";
                }
                return string;
            }
            case 7: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Long";
                    "".length();
                    if ("   ".length() < "  ".length()) {
                        return null;
                    }
                } else {
                    string = "long";
                }
                return string;
            }
            case 8: {
                String string;
                if (SignaturePrinter.llIIIlllI(bl ? 1 : 0)) {
                    string = "Double";
                    "".length();
                    if (" ".length() != " ".length()) {
                        return null;
                    }
                } else {
                    string = "double";
                }
                return string;
            }
            case 9: {
                return String.valueOf(new StringBuilder().append(SignaturePrinter.getTypeName(type.getElementType(), bl, bl2)).append(SignaturePrinter.arraySuffix(type)));
            }
            case 10: {
                String string = type.getClassName();
                if (SignaturePrinter.llIIlIIlI(bl2 ? 1 : 0)) {
                    string = string.substring(string.lastIndexOf(46) + 1);
                }
                return string;
            }
        }
        return "Object";
    }

    private static String arraySuffix(Type type) {
        return Strings.repeat((String)"[]", (int)type.getDimensions());
    }

    private static StringBuilder appendArraySuffix(StringBuilder stringBuilder, Type type) {
        int n = 0;
        while (SignaturePrinter.llIIIlIll(n, type.getDimensions())) {
            stringBuilder.append("[]");
            "".length();
            ++n;
            "".length();
            if (((0x45 ^ 0x78) & ~(0x54 ^ 0x69)) == 0) continue;
            return null;
        }
        return stringBuilder;
    }

    private static boolean llIIIlIll(int n, int n2) {
        return n < n2;
    }

    private static boolean llIIIllIl(int n, int n2) {
        return n > n2;
    }

    private static boolean llIIIllII(Object object) {
        return object != null;
    }

    private static boolean llIIIllll(Object object) {
        return object == null;
    }

    private static boolean llIIIlllI(int n) {
        return n != 0;
    }

    private static boolean llIIlIIlI(int n) {
        return n == 0;
    }

    private static boolean llIIlIIII(int n) {
        return n > 0;
    }
}

