/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class VersionNumber
implements Serializable,
Comparable<VersionNumber> {
    private static final long serialVersionUID = 1L;
    public static final VersionNumber NONE = new VersionNumber();
    private static final Pattern PATTERN = Pattern.compile("^(\\d{1,5})(?:\\.(\\d{1,5})(?:\\.(\\d{1,5})(?:\\.(\\d{1,5}))?)?)?(-[a-zA-Z0-9_\\-]+)?$");
    private final long value;
    private final String suffix;

    private VersionNumber() {
        this.value = 0L;
        this.suffix = "";
    }

    private VersionNumber(short[] sArray) {
        this(sArray, null);
    }

    private VersionNumber(short[] sArray, String string) {
        String string2;
        this.value = VersionNumber.pack(sArray);
        if (VersionNumber.lllllIlIl(string)) {
            string2 = string;
            "".length();
            if (-" ".length() < -" ".length()) {
                throw null;
            }
        } else {
            string2 = "";
        }
        this.suffix = string2;
    }

    private VersionNumber(short s, short s2, short s3, short s4) {
        this(s, s2, s3, s4, null);
    }

    private VersionNumber(short s, short s2, short s3, short s4, String string) {
        String string2;
        this.value = VersionNumber.pack(s, s2, s3, s4);
        if (VersionNumber.lllllIlIl(string)) {
            string2 = string;
            "".length();
            if (null != null) {
                throw null;
            }
        } else {
            string2 = "";
        }
        this.suffix = string2;
    }

    public String toString() {
        String string;
        Object object;
        short[] sArray = VersionNumber.unpack(this.value);
        Object[] objectArray = new Object[5];
        objectArray[0] = sArray[0];
        objectArray[1] = sArray[1];
        if (VersionNumber.lllllIlll(VersionNumber.lllllIllI(this.value & Integer.MAX_VALUE, 0L))) {
            object = String.format(".%d", sArray[2]);
            "".length();
            if (" ".length() < ((201 + 4 - 130 + 127 ^ 104 + 8 - 2 + 19) & (0xA8 ^ 0xC5 ^ (0x24 ^ 2) ^ -" ".length()))) {
                return null;
            }
        } else {
            object = objectArray[2] = "";
        }
        if (VersionNumber.lllllIlll(VersionNumber.lllllIllI(this.value & 0x7FFFL, 0L))) {
            string = String.format(".%d", sArray[3]);
            "".length();
            if ("   ".length() < " ".length()) {
                return null;
            }
        } else {
            string = "";
        }
        objectArray[3] = string;
        objectArray[4] = this.suffix;
        return String.format("%d.%d%3$s%4$s%5$s", objectArray);
    }

    @Override
    public int compareTo(VersionNumber versionNumber) {
        int n;
        if (VersionNumber.llllllIIl(versionNumber)) {
            return 1;
        }
        long l = this.value - versionNumber.value;
        if (VersionNumber.lllllIlll(VersionNumber.llllllIII(l, 0L))) {
            n = 1;
            "".length();
            if ("  ".length() == 0) {
                return (0xDC ^ 0x92) & ~(0x26 ^ 0x68);
            }
        } else if (VersionNumber.llllllIlI(VersionNumber.llllllIII(l, 0L))) {
            n = -1;
            "".length();
            if ("   ".length() != "   ".length()) {
                return (46 + 91 - 10 + 6 ^ 159 + 31 - 155 + 158) & (110 + 166 - 274 + 230 ^ 54 + 149 - 197 + 166 ^ -" ".length());
            }
        } else {
            n = 0;
        }
        return n;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (VersionNumber.lllllllII(object instanceof VersionNumber)) {
            return false;
        }
        if (VersionNumber.lllllllII(VersionNumber.llllllIll(((VersionNumber)object).value, this.value))) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x6A ^ 0x3E) & ~(0xDA ^ 0x8E)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return (int)(this.value >> 32) ^ (int)(this.value & 0xFFFFFFFFL);
    }

    private static long pack(short ... sArray) {
        return (long)sArray[0] << 48 | (long)sArray[1] << 32 | (long)(sArray[2] << 16) | (long)sArray[3];
    }

    private static short[] unpack(long l) {
        return new short[]{(short)(l >> 48), (short)(l >> 32 & 0x7FFFL), (short)(l >> 16 & 0x7FFFL), (short)(l & 0x7FFFL)};
    }

    public static VersionNumber parse(String string) {
        return VersionNumber.parse(string, NONE);
    }

    public static VersionNumber parse(String string, String string2) {
        return VersionNumber.parse(string, VersionNumber.parse(string2));
    }

    private static VersionNumber parse(String string, VersionNumber versionNumber) {
        if (VersionNumber.llllllIIl(string)) {
            return versionNumber;
        }
        Matcher matcher = PATTERN.matcher(string);
        if (VersionNumber.lllllllII(matcher.matches() ? 1 : 0)) {
            return versionNumber;
        }
        short[] sArray = new short[4];
        int n = 0;
        while (VersionNumber.lllllllll(n, 4)) {
            String string2 = matcher.group(n + 1);
            if (VersionNumber.lllllIlIl(string2)) {
                int n2 = Integer.parseInt(string2);
                if (VersionNumber.lIIIIIIIII(n2, Short.MAX_VALUE)) {
                    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Version parts cannot exceed 32767, found ").append(n2)));
                }
                sArray[n] = (short)n2;
            }
            ++n;
            "".length();
            if (null == null) continue;
            return null;
        }
        return new VersionNumber(sArray, matcher.group(5));
    }

    private static boolean lllllllll(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIIIIII(int n, int n2) {
        return n > n2;
    }

    private static boolean lllllIlIl(Object object) {
        return object != null;
    }

    private static boolean llllllIIl(Object object) {
        return object == null;
    }

    private static boolean lllllllII(int n) {
        return n == 0;
    }

    private static boolean llllllIlI(int n) {
        return n < 0;
    }

    private static boolean lllllIlll(int n) {
        return n > 0;
    }

    private static int lllllIllI(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }

    private static int llllllIII(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }

    private static int llllllIll(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }
}

