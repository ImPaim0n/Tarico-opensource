/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.asm;

import org.spongepowered.asm.lib.MethodVisitor;
import org.spongepowered.asm.util.Bytecode;

public class MethodVisitorEx
extends MethodVisitor {
    public MethodVisitorEx(MethodVisitor methodVisitor) {
        super(327680, methodVisitor);
    }

    public void visitConstant(byte by) {
        if (MethodVisitorEx.llIlllIllII(by, -2) && MethodVisitorEx.llIlllIllIl(by, 6)) {
            this.visitInsn(Bytecode.CONSTANTS_INT[by + 1]);
            return;
        }
        this.visitIntInsn(16, by);
    }

    private static boolean llIlllIllIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlllIllII(int n, int n2) {
        return n > n2;
    }
}

