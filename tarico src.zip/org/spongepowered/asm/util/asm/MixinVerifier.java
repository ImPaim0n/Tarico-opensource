/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.asm;

import java.util.List;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.analysis.SimpleVerifier;
import org.spongepowered.asm.mixin.transformer.ClassInfo;

public class MixinVerifier
extends SimpleVerifier {
    private Type currentClass;
    private Type currentSuperClass;
    private List<Type> currentClassInterfaces;
    private boolean isInterface;

    public MixinVerifier(Type type, Type type2, List<Type> list, boolean bl) {
        super(type, type2, list, bl);
        this.currentClass = type;
        this.currentSuperClass = type2;
        this.currentClassInterfaces = list;
        this.isInterface = bl;
    }

    @Override
    protected boolean isInterface(Type type) {
        if (MixinVerifier.llIllIlIII(this.currentClass) && MixinVerifier.llIllIlIIl(type.equals(this.currentClass) ? 1 : 0)) {
            return this.isInterface;
        }
        return ClassInfo.forType(type).isInterface();
    }

    @Override
    protected Type getSuperClass(Type type) {
        Type type2;
        if (MixinVerifier.llIllIlIII(this.currentClass) && MixinVerifier.llIllIlIIl(type.equals(this.currentClass) ? 1 : 0)) {
            return this.currentSuperClass;
        }
        ClassInfo classInfo = ClassInfo.forType(type).getSuperClass();
        if (MixinVerifier.llIllIlIlI(classInfo)) {
            type2 = null;
            "".length();
            if ("   ".length() <= 0) {
                return null;
            }
        } else {
            type2 = Type.getType(String.valueOf(new StringBuilder().append("L").append(classInfo.getName()).append(";")));
        }
        return type2;
    }

    @Override
    protected boolean isAssignableFrom(Type type, Type type2) {
        if (MixinVerifier.llIllIlIIl(type.equals(type2) ? 1 : 0)) {
            return true;
        }
        if (MixinVerifier.llIllIlIII(this.currentClass) && MixinVerifier.llIllIlIIl(type.equals(this.currentClass) ? 1 : 0)) {
            if (MixinVerifier.llIllIlIlI(this.getSuperClass(type2))) {
                return false;
            }
            if (MixinVerifier.llIllIlIIl(this.isInterface ? 1 : 0)) {
                boolean bl;
                if (!MixinVerifier.llIllIlIll(type2.getSort(), 10) || MixinVerifier.llIllIllII(type2.getSort(), 9)) {
                    bl = true;
                    "".length();
                    if ("  ".length() <= " ".length()) {
                        return ((0x63 ^ 0x30 ^ (0x28 ^ 0x3D)) & (0x4B ^ 0x13 ^ (0xAB ^ 0xB5) ^ -" ".length())) != 0;
                    }
                } else {
                    bl = false;
                }
                return bl;
            }
            return this.isAssignableFrom(type, this.getSuperClass(type2));
        }
        if (MixinVerifier.llIllIlIII(this.currentClass) && MixinVerifier.llIllIlIIl(type2.equals(this.currentClass) ? 1 : 0)) {
            if (MixinVerifier.llIllIlIIl(this.isAssignableFrom(type, this.currentSuperClass) ? 1 : 0)) {
                return true;
            }
            if (MixinVerifier.llIllIlIII(this.currentClassInterfaces)) {
                int n = 0;
                while (MixinVerifier.llIllIllIl(n, this.currentClassInterfaces.size())) {
                    Type type3 = this.currentClassInterfaces.get(n);
                    if (MixinVerifier.llIllIlIIl(this.isAssignableFrom(type, type3) ? 1 : 0)) {
                        return true;
                    }
                    ++n;
                    "".length();
                    if (" ".length() >= 0) continue;
                    return ((0x65 ^ 4 ^ (0x68 ^ 0x52)) & (70 + 2 - -74 + 10 ^ 54 + 87 - 33 + 91 ^ -" ".length())) != 0;
                }
            }
            return false;
        }
        ClassInfo classInfo = ClassInfo.forType(type);
        if (MixinVerifier.llIllIlIlI(classInfo)) {
            return false;
        }
        if (MixinVerifier.llIllIlIIl(classInfo.isInterface() ? 1 : 0)) {
            classInfo = ClassInfo.forName("java/lang/Object");
        }
        return ClassInfo.forType(type2).hasSuperClass(classInfo);
    }

    private static boolean llIllIllII(int n, int n2) {
        return n == n2;
    }

    private static boolean llIllIllIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIllIlIII(Object object) {
        return object != null;
    }

    private static boolean llIllIlIlI(Object object) {
        return object == null;
    }

    private static boolean llIllIlIIl(int n) {
        return n != 0;
    }

    private static boolean llIllIlIll(int n, int n2) {
        return n != n2;
    }
}

