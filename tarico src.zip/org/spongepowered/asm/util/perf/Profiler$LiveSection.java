/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.perf;

import java.util.Arrays;
import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$Section;

class Profiler$LiveSection
extends Profiler$Section {
    private int cursor;
    private long[] times;
    private long start;
    private long time;
    private long markedTime;
    private int count;
    private int markedCount;
    final /* synthetic */ Profiler this$0;

    Profiler$LiveSection(Profiler profiler, String string, int n) {
        this.this$0 = profiler;
        super(profiler, string);
        this.cursor = 0;
        this.times = new long[0];
        this.start = 0L;
        this.cursor = n;
    }

    @Override
    Profiler$Section start() {
        this.start = System.currentTimeMillis();
        return this;
    }

    @Override
    protected Profiler$Section stop() {
        if (Profiler$LiveSection.llIllIIIl(Profiler$LiveSection.llIllIIII(this.start, 0L))) {
            this.time += System.currentTimeMillis() - this.start;
        }
        this.start = 0L;
        ++this.count;
        return this;
    }

    @Override
    public Profiler$Section end() {
        this.stop();
        "".length();
        if (Profiler$LiveSection.llIllIIlI(this.invalidated ? 1 : 0)) {
            this.this$0.end(this);
        }
        return this;
    }

    @Override
    void mark() {
        if (Profiler$LiveSection.llIllIIll(this.cursor, this.times.length)) {
            this.times = Arrays.copyOf(this.times, this.cursor + 4);
        }
        this.times[this.cursor] = this.time;
        this.markedTime += this.time;
        this.markedCount += this.count;
        this.time = 0L;
        this.count = 0;
        ++this.cursor;
    }

    @Override
    public long getTime() {
        return this.time;
    }

    @Override
    public long getTotalTime() {
        return this.time + this.markedTime;
    }

    @Override
    public double getSeconds() {
        return (double)this.time * 0.001;
    }

    @Override
    public double getTotalSeconds() {
        return (double)(this.time + this.markedTime) * 0.001;
    }

    @Override
    public long[] getTimes() {
        long[] lArray = new long[this.cursor + 1];
        System.arraycopy(this.times, 0, lArray, 0, Math.min(this.times.length, this.cursor));
        lArray[this.cursor] = this.time;
        return lArray;
    }

    @Override
    public int getCount() {
        return this.count;
    }

    @Override
    public int getTotalCount() {
        return this.count + this.markedCount;
    }

    @Override
    public double getAverageTime() {
        double d;
        if (Profiler$LiveSection.llIllIIIl(this.count)) {
            d = (double)this.time / (double)this.count;
            "".length();
            if ("  ".length() < 0) {
                return 0.0;
            }
        } else {
            d = 0.0;
        }
        return d;
    }

    @Override
    public double getTotalAverageTime() {
        double d;
        if (Profiler$LiveSection.llIllIIIl(this.count)) {
            d = (double)(this.time + this.markedTime) / (double)(this.count + this.markedCount);
            "".length();
            if (-" ".length() > "   ".length()) {
                return 0.0;
            }
        } else {
            d = 0.0;
        }
        return d;
    }

    private static boolean llIllIIll(int n, int n2) {
        return n >= n2;
    }

    private static boolean llIllIIlI(int n) {
        return n == 0;
    }

    private static boolean llIllIIIl(int n) {
        return n > 0;
    }

    private static int llIllIIII(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }
}

