/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.perf;

import org.spongepowered.asm.util.perf.Profiler;

public class Profiler$Section {
    static final String SEPARATOR_ROOT = " -> ";
    static final String SEPARATOR_CHILD = ".";
    private final String name;
    private boolean root;
    private boolean fine;
    protected boolean invalidated;
    private String info;
    final /* synthetic */ Profiler this$0;

    Profiler$Section(Profiler profiler, String string) {
        this.this$0 = profiler;
        this.name = string;
        this.info = string;
    }

    Profiler$Section getDelegate() {
        return this;
    }

    Profiler$Section invalidate() {
        this.invalidated = true;
        return this;
    }

    Profiler$Section setRoot(boolean bl) {
        this.root = bl;
        return this;
    }

    public boolean isRoot() {
        return this.root;
    }

    Profiler$Section setFine(boolean bl) {
        this.fine = bl;
        return this;
    }

    public boolean isFine() {
        return this.fine;
    }

    public String getName() {
        return this.name;
    }

    public String getBaseName() {
        return this.name;
    }

    public void setInfo(String string) {
        this.info = string;
    }

    public String getInfo() {
        return this.info;
    }

    Profiler$Section start() {
        return this;
    }

    protected Profiler$Section stop() {
        return this;
    }

    public Profiler$Section end() {
        if (Profiler$Section.lIIlIIlIIII(this.invalidated ? 1 : 0)) {
            this.this$0.end(this);
        }
        return this;
    }

    public Profiler$Section next(String string) {
        this.end();
        "".length();
        return this.this$0.begin(string);
    }

    void mark() {
    }

    public long getTime() {
        return 0L;
    }

    public long getTotalTime() {
        return 0L;
    }

    public double getSeconds() {
        return 0.0;
    }

    public double getTotalSeconds() {
        return 0.0;
    }

    public long[] getTimes() {
        return new long[1];
    }

    public int getCount() {
        return 0;
    }

    public int getTotalCount() {
        return 0;
    }

    public double getAverageTime() {
        return 0.0;
    }

    public double getTotalAverageTime() {
        return 0.0;
    }

    public final String toString() {
        return this.name;
    }

    private static boolean lIIlIIlIIII(int n) {
        return n == 0;
    }
}

