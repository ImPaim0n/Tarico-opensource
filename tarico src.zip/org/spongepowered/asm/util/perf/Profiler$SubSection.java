/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.perf;

import org.spongepowered.asm.util.perf.Profiler;
import org.spongepowered.asm.util.perf.Profiler$LiveSection;
import org.spongepowered.asm.util.perf.Profiler$Section;

class Profiler$SubSection
extends Profiler$LiveSection {
    private final String baseName;
    private final Profiler$Section root;
    final /* synthetic */ Profiler this$0;

    Profiler$SubSection(Profiler profiler, String string, int n, String string2, Profiler$Section profiler$Section) {
        this.this$0 = profiler;
        super(profiler, string, n);
        this.baseName = string2;
        this.root = profiler$Section;
    }

    @Override
    Profiler$Section invalidate() {
        this.root.invalidate();
        "".length();
        return super.invalidate();
    }

    @Override
    public String getBaseName() {
        return this.baseName;
    }

    @Override
    public void setInfo(String string) {
        this.root.setInfo(string);
        super.setInfo(string);
    }

    @Override
    Profiler$Section getDelegate() {
        return this.root;
    }

    @Override
    Profiler$Section start() {
        this.root.start();
        "".length();
        return super.start();
    }

    @Override
    public Profiler$Section end() {
        this.root.stop();
        "".length();
        return super.end();
    }

    @Override
    public Profiler$Section next(String string) {
        super.stop();
        "".length();
        return this.root.next(string);
    }
}

