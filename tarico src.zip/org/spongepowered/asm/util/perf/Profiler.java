/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Joiner
 */
package org.spongepowered.asm.util.perf;

import com.google.common.base.Joiner;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.TreeMap;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.PrettyPrinter$Alignment;
import org.spongepowered.asm.util.perf.Profiler$LiveSection;
import org.spongepowered.asm.util.perf.Profiler$Section;
import org.spongepowered.asm.util.perf.Profiler$SubSection;

public final class Profiler {
    public static final int ROOT;
    public static final int FINE;
    private final Map<String, Profiler$Section> sections = new TreeMap<String, Profiler$Section>();
    private final List<String> phases = new ArrayList<String>();
    private final Deque<Profiler$Section> stack = new LinkedList<Profiler$Section>();
    private boolean active;

    public Profiler() {
        this.phases.add("Initial");
        "".length();
    }

    public void setActive(boolean bl) {
        if (Profiler.llllIIIIIIl(this.active ? 1 : 0) && !Profiler.llllIIIIIIl(bl ? 1 : 0) || Profiler.llllIIIIIIl(bl ? 1 : 0)) {
            this.reset();
        }
        this.active = bl;
    }

    public void reset() {
        Iterator<Profiler$Section> iterator = this.sections.values().iterator();
        while (Profiler.llllIIIIIlI(iterator.hasNext() ? 1 : 0)) {
            Profiler$Section profiler$Section = iterator.next();
            profiler$Section.invalidate();
            "".length();
            "".length();
            if (null == null) continue;
            return;
        }
        this.sections.clear();
        this.phases.clear();
        this.phases.add("Initial");
        "".length();
        this.stack.clear();
    }

    public Profiler$Section get(String string) {
        Profiler$Section profiler$Section = this.sections.get(string);
        if (Profiler.llllIIIIIll(profiler$Section)) {
            Profiler$Section profiler$Section2;
            if (Profiler.llllIIIIIlI(this.active ? 1 : 0)) {
                profiler$Section2 = new Profiler$LiveSection(this, string, this.phases.size() - 1);
                "".length();
                if (null != null) {
                    return null;
                }
            } else {
                profiler$Section2 = new Profiler$Section(this, string);
            }
            profiler$Section = profiler$Section2;
            this.sections.put(string, profiler$Section);
            "".length();
        }
        return profiler$Section;
    }

    private Profiler$Section getSubSection(String string, String string2, Profiler$Section profiler$Section) {
        Profiler$Section profiler$Section2 = this.sections.get(string);
        if (Profiler.llllIIIIIll(profiler$Section2)) {
            profiler$Section2 = new Profiler$SubSection(this, string, this.phases.size() - 1, string2, profiler$Section);
            this.sections.put(string, profiler$Section2);
            "".length();
        }
        return profiler$Section2;
    }

    boolean isHead(Profiler$Section profiler$Section) {
        boolean bl;
        if (Profiler.llllIIIIlII(this.stack.peek(), profiler$Section)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((0x48 ^ 0x79) & ~(0xB0 ^ 0x81)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public Profiler$Section begin(String ... stringArray) {
        return this.begin(0, stringArray);
    }

    public Profiler$Section begin(int n, String ... stringArray) {
        return this.begin(n, Joiner.on((char)'.').join((Object[])stringArray));
    }

    public Profiler$Section begin(String string) {
        return this.begin(0, string);
    }

    public Profiler$Section begin(int n, String string) {
        String string2;
        boolean bl;
        int n2;
        int n3;
        if (Profiler.llllIIIIIlI(n & 1)) {
            n3 = 1;
            "".length();
            if ("   ".length() <= "  ".length()) {
                return null;
            }
        } else {
            n3 = n2 = 0;
        }
        if (Profiler.llllIIIIIlI(n & 2)) {
            bl = true;
            "".length();
            if ((10 + 33 - -9 + 114 ^ 149 + 128 - 269 + 154) != (43 + 13 - -41 + 41 ^ 69 + 61 - 22 + 34)) {
                return null;
            }
        } else {
            bl = false;
        }
        boolean bl2 = bl;
        String string3 = string;
        Profiler$Section profiler$Section = this.stack.peek();
        if (Profiler.llllIIIIlIl(profiler$Section)) {
            String string4;
            StringBuilder stringBuilder = new StringBuilder().append(profiler$Section.getName());
            if (Profiler.llllIIIIIlI(n2)) {
                string4 = " -> ";
                "".length();
                if (-(0x1F ^ 0x1A) >= 0) {
                    return null;
                }
            } else {
                string4 = ".";
            }
            string3 = String.valueOf(stringBuilder.append(string4).append(string3));
            if (Profiler.llllIIIIIlI(profiler$Section.isRoot() ? 1 : 0) && Profiler.llllIIIIIIl(n2)) {
                String string5;
                int n4 = profiler$Section.getName().lastIndexOf(" -> ");
                StringBuilder stringBuilder2 = new StringBuilder();
                if (Profiler.llllIIIIllI(n4, -1)) {
                    string5 = profiler$Section.getName().substring(n4 + 4);
                    "".length();
                    if (((0x7C ^ 0x61) & ~(0x43 ^ 0x5E)) != 0) {
                        return null;
                    }
                } else {
                    string5 = profiler$Section.getName();
                }
                string = String.valueOf(stringBuilder2.append(string5).append(".").append(string));
                n2 = 1;
            }
        }
        if (Profiler.llllIIIIIlI(n2)) {
            string2 = string;
            "".length();
            if (((0x69 ^ 0x60 ^ (0xC2 ^ 0x99)) & (0xDF ^ 0xC7 ^ (0x61 ^ 0x2B) ^ -" ".length())) != ((26 + 89 - -30 + 5 ^ 166 + 18 - 86 + 89) & (1 + 99 - 24 + 55 ^ 13 + 171 - 170 + 160 ^ -" ".length()))) {
                return null;
            }
        } else {
            string2 = string3;
        }
        Profiler$Section profiler$Section2 = this.get(string2);
        if (Profiler.llllIIIIIlI(n2) && Profiler.llllIIIIlIl(profiler$Section) && Profiler.llllIIIIIlI(this.active ? 1 : 0)) {
            profiler$Section2 = this.getSubSection(string3, profiler$Section.getName(), profiler$Section2);
        }
        profiler$Section2.setFine(bl2).setRoot(n2 != 0);
        "".length();
        this.stack.push(profiler$Section2);
        return profiler$Section2.start();
    }

    void end(Profiler$Section profiler$Section) {
        block6: {
            try {
                Profiler$Section profiler$Section2;
                Profiler$Section profiler$Section3 = profiler$Section2 = this.stack.pop();
                while (Profiler.llllIIIIlll(profiler$Section3, profiler$Section)) {
                    if (Profiler.llllIIIIIll(profiler$Section3) && Profiler.llllIIIIIlI(this.active ? 1 : 0)) {
                        if (Profiler.llllIIIIIll(profiler$Section2)) {
                            throw new IllegalStateException(String.valueOf(new StringBuilder().append("Attempted to pop ").append(profiler$Section).append(" but the stack is empty")));
                        }
                        throw new IllegalStateException(String.valueOf(new StringBuilder().append("Attempted to pop ").append(profiler$Section).append(" which was not in the stack, head was ").append(profiler$Section2)));
                    }
                    profiler$Section3 = this.stack.pop();
                    "".length();
                    if ((0x58 ^ 0x5C) >= (0x81 ^ 0x85)) continue;
                    return;
                }
            }
            catch (NoSuchElementException noSuchElementException) {
                if (!Profiler.llllIIIIIlI(this.active ? 1 : 0)) break block6;
                throw new IllegalStateException(String.valueOf(new StringBuilder().append("Attempted to pop ").append(profiler$Section).append(" but the stack is empty")));
            }
            "".length();
            if ("   ".length() < ((103 + 108 - 174 + 172 ^ 105 + 63 - 96 + 74) & (0x15 ^ 0x4E ^ (0x91 ^ 0x89) ^ -" ".length()))) {
                return;
            }
        }
    }

    public void mark(String string) {
        Profiler$Section profiler$Section;
        long l = 0L;
        Iterator<Profiler$Section> iterator = this.sections.values().iterator();
        while (Profiler.llllIIIIIlI(iterator.hasNext() ? 1 : 0)) {
            profiler$Section = iterator.next();
            l += profiler$Section.getTime();
            "".length();
            if (-"  ".length() <= 0) continue;
            return;
        }
        if (Profiler.llllIIIIIIl(Profiler.llllIIIlIII(l, 0L))) {
            int n = this.phases.size();
            this.phases.set(n - 1, string);
            "".length();
            return;
        }
        this.phases.add(string);
        "".length();
        iterator = this.sections.values().iterator();
        while (Profiler.llllIIIIIlI(iterator.hasNext() ? 1 : 0)) {
            profiler$Section = iterator.next();
            profiler$Section.mark();
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
    }

    public Collection<Profiler$Section> getSections() {
        return Collections.unmodifiableCollection(this.sections.values());
    }

    public PrettyPrinter printer(boolean bl, boolean bl2) {
        PrettyPrinter prettyPrinter = new PrettyPrinter();
        int n = this.phases.size() + 4;
        int[] nArray = new int[]{0, 1, 2, n - 2, n - 1};
        Object[] objectArray = new Object[n * 2];
        int n2 = 0;
        int n3 = 0;
        while (Profiler.llllIIIlIIl(n2, n)) {
            objectArray[n3 + 1] = PrettyPrinter$Alignment.RIGHT;
            if (Profiler.llllIIIlIlI(n2, nArray[0])) {
                String string;
                StringBuilder stringBuilder = new StringBuilder();
                if (Profiler.llllIIIIIlI(bl2 ? 1 : 0)) {
                    string = "";
                    "".length();
                    if (" ".length() <= 0) {
                        return null;
                    }
                } else {
                    string = "  ";
                }
                objectArray[n3] = String.valueOf(stringBuilder.append(string).append("Section"));
                objectArray[n3 + 1] = PrettyPrinter$Alignment.LEFT;
                "".length();
                if ("   ".length() != "   ".length()) {
                    return null;
                }
            } else if (Profiler.llllIIIlIlI(n2, nArray[1])) {
                objectArray[n3] = "    TOTAL";
                "".length();
                if (((87 + 146 - 147 + 84 ^ 86 + 143 - 105 + 52) & (0x7A ^ 0x20 ^ (0x19 ^ 0x59) ^ -" ".length())) != 0) {
                    return null;
                }
            } else if (Profiler.llllIIIlIlI(n2, nArray[3])) {
                objectArray[n3] = "    Count";
                "".length();
                if (null != null) {
                    return null;
                }
            } else if (Profiler.llllIIIlIlI(n2, nArray[4])) {
                objectArray[n3] = "Avg. ";
                "".length();
                if (-" ".length() > (0x2F ^ 0x2B)) {
                    return null;
                }
            } else if (Profiler.llllIIIlIIl(n2 - nArray[2], this.phases.size())) {
                objectArray[n3] = this.phases.get(n2 - nArray[2]);
                "".length();
                if (((0x83 ^ 0x8F ^ (0xE0 ^ 0xAD)) & (0x25 ^ 0x28 ^ (0xE2 ^ 0xAE) ^ -" ".length())) >= " ".length()) {
                    return null;
                }
            } else {
                objectArray[n3] = "";
            }
            n3 = ++n2 * 2;
            "".length();
            if ("   ".length() > ((0xB7 ^ 0xA3) & ~(0x5A ^ 0x4E))) continue;
            return null;
        }
        prettyPrinter.table(objectArray).th().hr().add();
        "".length();
        Iterator<Profiler$Section> iterator = this.sections.values().iterator();
        while (Profiler.llllIIIIIlI(iterator.hasNext() ? 1 : 0)) {
            Profiler$Section profiler$Section = iterator.next();
            if (Profiler.llllIIIIIlI(profiler$Section.isFine() ? 1 : 0) && !Profiler.llllIIIIIlI(bl ? 1 : 0)) continue;
            if (Profiler.llllIIIIIlI(bl2 ? 1 : 0) && Profiler.llllIIIIlll(profiler$Section.getDelegate(), profiler$Section)) {
                "".length();
                if ((0x10 ^ 0x14) > -" ".length()) continue;
                return null;
            }
            this.printSectionRow(prettyPrinter, n, nArray, profiler$Section, bl2);
            if (Profiler.llllIIIIIlI(bl2 ? 1 : 0)) {
                Iterator<Profiler$Section> iterator2 = this.sections.values().iterator();
                while (Profiler.llllIIIIIlI(iterator2.hasNext() ? 1 : 0)) {
                    Profiler$Section profiler$Section2 = iterator2.next();
                    Profiler$Section profiler$Section3 = profiler$Section2.getDelegate();
                    if (Profiler.llllIIIIIlI(profiler$Section2.isFine() ? 1 : 0) && !Profiler.llllIIIIIlI(bl ? 1 : 0) || !Profiler.llllIIIIlII(profiler$Section3, profiler$Section)) continue;
                    if (Profiler.llllIIIIlII(profiler$Section3, profiler$Section2)) {
                        "".length();
                        if (null == null) continue;
                        return null;
                    }
                    this.printSectionRow(prettyPrinter, n, nArray, profiler$Section2, bl2);
                    "".length();
                    if (null == null) continue;
                    return null;
                }
            }
            "".length();
            if (-(0x27 ^ 0x23) < 0) continue;
            return null;
        }
        return prettyPrinter.add();
    }

    private void printSectionRow(PrettyPrinter prettyPrinter, int n, int[] nArray, Profiler$Section profiler$Section, boolean bl) {
        long[] lArray;
        int n2;
        if (Profiler.llllIIIIlll(profiler$Section.getDelegate(), profiler$Section)) {
            n2 = 1;
            "".length();
            if (((0xB ^ 0x42 ^ (0xB4 ^ 0xBB)) & (112 + 154 - 120 + 86 ^ 11 + 27 - -103 + 33 ^ -" ".length())) != 0) {
                return;
            }
        } else {
            n2 = 0;
        }
        int n3 = n2;
        Object[] objectArray = new Object[n];
        int n4 = 1;
        if (Profiler.llllIIIIIlI(bl ? 1 : 0)) {
            String string;
            if (Profiler.llllIIIIIlI(n3)) {
                string = String.valueOf(new StringBuilder().append("  > ").append(profiler$Section.getBaseName()));
                "".length();
                if (((9 + 127 - 93 + 197 ^ 20 + 145 - 99 + 114) & (49 + 56 - 14 + 133 ^ 54 + 141 - 98 + 67 ^ -" ".length())) == "  ".length()) {
                    return;
                }
            } else {
                string = profiler$Section.getName();
            }
            objectArray[0] = string;
            "".length();
            if ((0x8A ^ 0xA0 ^ (0x57 ^ 0x79)) <= -" ".length()) {
                return;
            }
        } else {
            String string;
            StringBuilder stringBuilder = new StringBuilder();
            if (Profiler.llllIIIIIlI(n3)) {
                string = "+ ";
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                string = "  ";
            }
            objectArray[0] = String.valueOf(stringBuilder.append(string).append(profiler$Section.getName()));
        }
        long[] lArray2 = lArray = profiler$Section.getTimes();
        int n5 = lArray2.length;
        int n6 = 0;
        while (Profiler.llllIIIlIIl(n6, n5)) {
            long l = lArray2[n6];
            if (Profiler.llllIIIlIlI(n4, nArray[1])) {
                objectArray[n4++] = String.valueOf(new StringBuilder().append(profiler$Section.getTotalTime()).append(" ms"));
            }
            if (Profiler.llllIIIlIll(n4, nArray[2]) && Profiler.llllIIIlIIl(n4, objectArray.length)) {
                objectArray[n4++] = String.valueOf(new StringBuilder().append(l).append(" ms"));
            }
            ++n6;
            "".length();
            if ("  ".length() >= ((39 + 195 - 194 + 206 ^ 140 + 109 - 150 + 62) & (0x3B ^ 0x36 ^ (0xEB ^ 0xB1) ^ -" ".length()))) continue;
            return;
        }
        objectArray[nArray[3]] = profiler$Section.getTotalCount();
        objectArray[nArray[4]] = new DecimalFormat("   ###0.000 ms").format(profiler$Section.getTotalAverageTime());
        int n7 = 0;
        while (Profiler.llllIIIlIIl(n7, objectArray.length)) {
            if (Profiler.llllIIIIIll(objectArray[n7])) {
                objectArray[n7] = "-";
            }
            ++n7;
            "".length();
            if (null == null) continue;
            return;
        }
        prettyPrinter.tr(objectArray);
        "".length();
    }

    static {
        FINE = 2;
        ROOT = 1;
    }

    private static boolean llllIIIlIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean llllIIIlIll(int n, int n2) {
        return n >= n2;
    }

    private static boolean llllIIIlIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llllIIIIllI(int n, int n2) {
        return n > n2;
    }

    private static boolean llllIIIIlll(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llllIIIIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llllIIIIlIl(Object object) {
        return object != null;
    }

    private static boolean llllIIIIIll(Object object) {
        return object == null;
    }

    private static boolean llllIIIIIlI(int n) {
        return n != 0;
    }

    private static boolean llllIIIIIIl(int n) {
        return n == 0;
    }

    private static int llllIIIlIII(long l, long l2) {
        return l == l2 ? 0 : (l < l2 ? -1 : 1);
    }
}

