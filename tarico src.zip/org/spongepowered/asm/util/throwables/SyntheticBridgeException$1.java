/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.throwables;

import org.spongepowered.asm.util.throwables.SyntheticBridgeException$Problem;

class SyntheticBridgeException$1 {
    static final /* synthetic */ int[] $SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem;

    static {
        block14: {
            block18: {
                block17: {
                    block16: {
                        block15: {
                            block13: {
                                $SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem = new int[SyntheticBridgeException$Problem.values().length];
                                try {
                                    SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException$Problem.BAD_INSN.ordinal()] = 1;
                                    "".length();
                                }
                                catch (NoSuchFieldError noSuchFieldError) {
                                    // empty catch block
                                }
                                if ("   ".length() != -" ".length()) break block13;
                                break block14;
                            }
                            try {
                                SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException$Problem.BAD_LOAD.ordinal()] = 2;
                                "".length();
                            }
                            catch (NoSuchFieldError noSuchFieldError) {
                                // empty catch block
                            }
                            if (null == null) break block15;
                            break block14;
                        }
                        try {
                            SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException$Problem.BAD_CAST.ordinal()] = 3;
                            "".length();
                        }
                        catch (NoSuchFieldError noSuchFieldError) {
                            // empty catch block
                        }
                        if (-(3 ^ 0x72 ^ (0xCB ^ 0xBF)) < 0) break block16;
                        break block14;
                    }
                    try {
                        SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException$Problem.BAD_INVOKE_NAME.ordinal()] = 4;
                        "".length();
                    }
                    catch (NoSuchFieldError noSuchFieldError) {
                        // empty catch block
                    }
                    if (null == null) break block17;
                    break block14;
                }
                try {
                    SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException$Problem.BAD_INVOKE_DESC.ordinal()] = 5;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if (null == null) break block18;
                break block14;
            }
            try {
                SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[SyntheticBridgeException$Problem.BAD_LENGTH.ordinal()] = 6;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if (((0x2F ^ 3 ^ (0x80 ^ 0xA5)) & (0x32 ^ 0x57 ^ (0xD ^ 0x61) ^ -" ".length())) < ("  ".length() & ("  ".length() ^ -" ".length()))) {
                // empty if block
            }
        }
    }
}

