/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.throwables;

import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.util.Bytecode;

public enum SyntheticBridgeException$Problem {
    BAD_INSN("Conflicting opcodes %4$s and %5$s at offset %3$d in synthetic bridge method %1$s%2$s"),
    BAD_LOAD("Conflicting variable access at offset %3$d in synthetic bridge method %1$s%2$s"),
    BAD_CAST("Conflicting type cast at offset %3$d in synthetic bridge method %1$s%2$s"),
    BAD_INVOKE_NAME("Conflicting synthetic bridge target method name in synthetic bridge method %1$s%2$s Existing:%6$s Incoming:%7$s"),
    BAD_INVOKE_DESC("Conflicting synthetic bridge target method descriptor in synthetic bridge method %1$s%2$s Existing:%8$s Incoming:%9$s"),
    BAD_LENGTH("Mismatched bridge method length for synthetic bridge method %1$s%2$s unexpected extra opcode at offset %3$d");

    private final String message;

    private SyntheticBridgeException$Problem(String string2) {
        this.message = string2;
    }

    String getMessage(String string, String string2, int n, AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        return String.format(this.message, string, string2, n, Bytecode.getOpcodeName(abstractInsnNode), Bytecode.getOpcodeName(abstractInsnNode), SyntheticBridgeException$Problem.getInsnName(abstractInsnNode), SyntheticBridgeException$Problem.getInsnName(abstractInsnNode2), SyntheticBridgeException$Problem.getInsnDesc(abstractInsnNode), SyntheticBridgeException$Problem.getInsnDesc(abstractInsnNode2));
    }

    private static String getInsnName(AbstractInsnNode abstractInsnNode) {
        String string;
        if (SyntheticBridgeException$Problem.llllIIllI(abstractInsnNode instanceof MethodInsnNode)) {
            string = ((MethodInsnNode)abstractInsnNode).name;
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string = "";
        }
        return string;
    }

    private static String getInsnDesc(AbstractInsnNode abstractInsnNode) {
        String string;
        if (SyntheticBridgeException$Problem.llllIIllI(abstractInsnNode instanceof MethodInsnNode)) {
            string = ((MethodInsnNode)abstractInsnNode).desc;
            "".length();
            if ((2 + 3 - -43 + 134 ^ 1 + 127 - -39 + 11) == 0) {
                return null;
            }
        } else {
            string = "";
        }
        return string;
    }

    private static boolean llllIIllI(int n) {
        return n != 0;
    }
}

