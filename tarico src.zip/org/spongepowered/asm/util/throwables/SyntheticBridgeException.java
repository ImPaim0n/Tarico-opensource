/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.util.throwables;

import java.util.ListIterator;
import org.spongepowered.asm.lib.Type;
import org.spongepowered.asm.lib.tree.AbstractInsnNode;
import org.spongepowered.asm.lib.tree.MethodInsnNode;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.lib.tree.TypeInsnNode;
import org.spongepowered.asm.lib.tree.VarInsnNode;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.throwables.MixinException;
import org.spongepowered.asm.mixin.transformer.ClassInfo;
import org.spongepowered.asm.mixin.transformer.meta.MixinMerged;
import org.spongepowered.asm.util.Annotations;
import org.spongepowered.asm.util.Bytecode;
import org.spongepowered.asm.util.PrettyPrinter;
import org.spongepowered.asm.util.throwables.SyntheticBridgeException$1;
import org.spongepowered.asm.util.throwables.SyntheticBridgeException$Problem;

public class SyntheticBridgeException
extends MixinException {
    private static final long serialVersionUID = 1L;
    private final SyntheticBridgeException$Problem problem;
    private final String name;
    private final String desc;
    private final int index;
    private final AbstractInsnNode a;
    private final AbstractInsnNode b;

    public SyntheticBridgeException(SyntheticBridgeException$Problem syntheticBridgeException$Problem, String string, String string2, int n, AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        super(syntheticBridgeException$Problem.getMessage(string, string2, n, abstractInsnNode, abstractInsnNode2));
        this.problem = syntheticBridgeException$Problem;
        this.name = string;
        this.desc = string2;
        this.index = n;
        this.a = abstractInsnNode;
        this.b = abstractInsnNode2;
    }

    public void printAnalysis(IMixinContext iMixinContext, MethodNode methodNode, MethodNode methodNode2) {
        String string;
        PrettyPrinter prettyPrinter = new PrettyPrinter();
        prettyPrinter.addWrapped(100, this.getMessage(), new Object[0]).hr();
        "".length();
        prettyPrinter.add().kv("Method", String.valueOf(new StringBuilder().append(this.name).append(this.desc))).kv("Problem Type", (Object)this.problem).add().hr();
        "".length();
        String string2 = (String)Annotations.getValue(Annotations.getVisible(methodNode, MixinMerged.class), "mixin");
        if (SyntheticBridgeException.lIIIIIIlIlII(string2)) {
            string = string2;
            "".length();
            if (" ".length() < 0) {
                return;
            }
        } else {
            string = iMixinContext.getTargetClassRef().replace('/', '.');
        }
        String string3 = string;
        this.printMethod(prettyPrinter.add("Existing method").add().kv("Owner", string3).add(), methodNode).hr();
        "".length();
        this.printMethod(prettyPrinter.add("Incoming method").add().kv("Owner", iMixinContext.getClassRef().replace('/', '.')).add(), methodNode2).hr();
        "".length();
        this.printProblem(prettyPrinter, iMixinContext, methodNode, methodNode2).print(System.err);
        "".length();
    }

    private PrettyPrinter printMethod(PrettyPrinter prettyPrinter, MethodNode methodNode) {
        int n = 0;
        ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
        while (SyntheticBridgeException.lIIIIIIlIlIl(listIterator.hasNext() ? 1 : 0)) {
            String string;
            if (SyntheticBridgeException.lIIIIIIlIllI(n, this.index)) {
                string = ">>>>";
                "".length();
                if ("   ".length() < "   ".length()) {
                    return null;
                }
            } else {
                string = "";
            }
            prettyPrinter.kv(string, Bytecode.describeNode((AbstractInsnNode)listIterator.next()));
            "".length();
            ++n;
            "".length();
            if (-(0x52 ^ 0x56) <= 0) continue;
            return null;
        }
        return prettyPrinter.add();
    }

    private PrettyPrinter printProblem(PrettyPrinter prettyPrinter, IMixinContext iMixinContext, MethodNode methodNode, MethodNode methodNode2) {
        Type type = Type.getObjectType(iMixinContext.getTargetClassRef());
        prettyPrinter.add("Analysis").add();
        "".length();
        switch (SyntheticBridgeException$1.$SwitchMap$org$spongepowered$asm$util$throwables$SyntheticBridgeException$Problem[this.problem.ordinal()]) {
            case 1: {
                prettyPrinter.add("The bridge methods are not compatible because they contain incompatible opcodes");
                "".length();
                prettyPrinter.add(String.valueOf(new StringBuilder().append("at index ").append(this.index).append(":"))).add();
                "".length();
                prettyPrinter.kv("Existing opcode: %s", Bytecode.getOpcodeName(this.a));
                "".length();
                prettyPrinter.kv("Incoming opcode: %s", Bytecode.getOpcodeName(this.b)).add();
                "".length();
                prettyPrinter.add("This implies that the bridge methods are from different interfaces. This problem");
                "".length();
                prettyPrinter.add("may not be resolvable without changing the base interfaces.").add();
                "".length();
                "".length();
                if ((0xAD ^ 0xA9) > ((0x50 ^ 0x44) & ~(0xBC ^ 0xA8))) break;
                return null;
            }
            case 2: {
                prettyPrinter.add("The bridge methods are not compatible because they contain different variables at");
                "".length();
                prettyPrinter.add(String.valueOf(new StringBuilder().append("opcode index ").append(this.index).append("."))).add();
                "".length();
                ListIterator<AbstractInsnNode> listIterator = methodNode.instructions.iterator();
                ListIterator<AbstractInsnNode> listIterator2 = methodNode2.instructions.iterator();
                Type[] typeArray = Type.getArgumentTypes(methodNode.desc);
                Type[] typeArray2 = Type.getArgumentTypes(methodNode2.desc);
                int n = 0;
                while (SyntheticBridgeException.lIIIIIIlIlIl(listIterator.hasNext() ? 1 : 0) && SyntheticBridgeException.lIIIIIIlIlIl(listIterator2.hasNext() ? 1 : 0)) {
                    AbstractInsnNode abstractInsnNode = listIterator.next();
                    AbstractInsnNode abstractInsnNode2 = listIterator2.next();
                    if (SyntheticBridgeException.lIIIIIIlIlIl(abstractInsnNode instanceof VarInsnNode) && SyntheticBridgeException.lIIIIIIlIlIl(abstractInsnNode2 instanceof VarInsnNode)) {
                        Type type2;
                        Type type3;
                        Type type4;
                        VarInsnNode varInsnNode = (VarInsnNode)abstractInsnNode;
                        VarInsnNode varInsnNode2 = (VarInsnNode)abstractInsnNode2;
                        if (SyntheticBridgeException.lIIIIIIlIlll(varInsnNode.var)) {
                            type4 = typeArray[varInsnNode.var - 1];
                            "".length();
                            if ("   ".length() <= -" ".length()) {
                                return null;
                            }
                        } else {
                            type4 = type3 = type;
                        }
                        if (SyntheticBridgeException.lIIIIIIlIlll(varInsnNode2.var)) {
                            type2 = typeArray2[varInsnNode2.var - 1];
                            "".length();
                            if (-"  ".length() >= 0) {
                                return null;
                            }
                        } else {
                            type2 = type;
                        }
                        Type type5 = type2;
                        prettyPrinter.kv(String.valueOf(new StringBuilder().append("Target ").append(n)), "%8s %-2d %s", Bytecode.getOpcodeName(varInsnNode), varInsnNode.var, type3);
                        "".length();
                        prettyPrinter.kv(String.valueOf(new StringBuilder().append("Incoming ").append(n)), "%8s %-2d %s", Bytecode.getOpcodeName(varInsnNode2), varInsnNode2.var, type5);
                        "".length();
                        if (SyntheticBridgeException.lIIIIIIlIlIl(type3.equals(type5) ? 1 : 0)) {
                            prettyPrinter.kv("", "Types match: %s", type3);
                            "".length();
                            "".length();
                            if (((0x29 ^ 0x1F) & ~(0xAC ^ 0x9A)) <= -" ".length()) {
                                return null;
                            }
                        } else if (SyntheticBridgeException.lIIIIIIllIII(type3.getSort(), type5.getSort())) {
                            prettyPrinter.kv("", "Types are incompatible");
                            "".length();
                            "".length();
                            if ((0x3F ^ 0x49 ^ (0x36 ^ 0x44)) == 0) {
                                return null;
                            }
                        } else if (SyntheticBridgeException.lIIIIIIlIllI(type3.getSort(), 10)) {
                            ClassInfo classInfo = ClassInfo.getCommonSuperClassOrInterface(type3, type5);
                            prettyPrinter.kv("", "Common supertype: %s", classInfo);
                            "".length();
                        }
                        prettyPrinter.add();
                        "".length();
                    }
                    ++n;
                    "".length();
                    if (-(0x92 ^ 0x97) < 0) continue;
                    return null;
                }
                prettyPrinter.add("Since this probably means that the methods come from different interfaces, you");
                "".length();
                prettyPrinter.add("may have a \"multiple inheritance\" problem, it may not be possible to implement");
                "".length();
                prettyPrinter.add("both root interfaces");
                "".length();
                "".length();
                if (" ".length() == " ".length()) break;
                return null;
            }
            case 3: {
                prettyPrinter.add(String.valueOf(new StringBuilder().append("Incompatible CHECKCAST encountered at opcode ").append(this.index).append(", this could indicate that the bridge")));
                "".length();
                prettyPrinter.add("is casting down for contravariant generic types. It may be possible to coalesce the");
                "".length();
                prettyPrinter.add("bridges by adjusting the types in the target method.").add();
                "".length();
                Type type6 = Type.getObjectType(((TypeInsnNode)this.a).desc);
                Type type7 = Type.getObjectType(((TypeInsnNode)this.b).desc);
                prettyPrinter.kv("Target type", type6);
                "".length();
                prettyPrinter.kv("Incoming type", type7);
                "".length();
                prettyPrinter.kv("Common supertype", ClassInfo.getCommonSuperClassOrInterface(type6, type7)).add();
                "".length();
                "".length();
                if ((8 ^ 0x47 ^ (0x5B ^ 0x10)) > ((0x7F ^ 0x59 ^ (0x54 ^ 0x6F)) & (29 + 131 - 82 + 87 ^ 101 + 161 - 87 + 9 ^ -" ".length()))) break;
                return null;
            }
            case 4: {
                prettyPrinter.add("Incompatible invocation targets in synthetic bridge. This is extremely unusual");
                "".length();
                prettyPrinter.add("and implies that a remapping transformer has incorrectly remapped a method. This");
                "".length();
                prettyPrinter.add("is an unrecoverable error.");
                "".length();
                "".length();
                if ("   ".length() <= "   ".length()) break;
                return null;
            }
            case 5: {
                MethodInsnNode methodInsnNode = (MethodInsnNode)this.a;
                MethodInsnNode methodInsnNode2 = (MethodInsnNode)this.b;
                Type[] typeArray = Type.getArgumentTypes(methodInsnNode.desc);
                Type[] typeArray3 = Type.getArgumentTypes(methodInsnNode2.desc);
                if (SyntheticBridgeException.lIIIIIIllIII(typeArray.length, typeArray3.length)) {
                    String string;
                    int n = Type.getArgumentTypes(methodNode.desc).length;
                    if (SyntheticBridgeException.lIIIIIIlIllI(typeArray.length, n)) {
                        string = "The TARGET";
                        "".length();
                        if (-" ".length() >= 0) {
                            return null;
                        }
                    } else if (SyntheticBridgeException.lIIIIIIlIllI(typeArray3.length, n)) {
                        string = " The INCOMING";
                        "".length();
                        if (-" ".length() < -" ".length()) {
                            return null;
                        }
                    } else {
                        string = "NEITHER";
                    }
                    String string2 = string;
                    prettyPrinter.add("Mismatched invocation descriptors in synthetic bridge implies that a remapping");
                    "".length();
                    prettyPrinter.add("transformer has incorrectly coalesced a bridge method with a conflicting name.");
                    "".length();
                    prettyPrinter.add("Overlapping bridge methods should always have the same number of arguments, yet");
                    "".length();
                    prettyPrinter.add("the target method has %d arguments, the incoming method has %d. This is an", typeArray.length, typeArray3.length);
                    "".length();
                    prettyPrinter.add("unrecoverable error. %s method has the expected arg count of %d", string2, n);
                    "".length();
                    "".length();
                    if (" ".length() == " ".length()) break;
                    return null;
                }
                Type type8 = Type.getReturnType(methodInsnNode.desc);
                Type type9 = Type.getReturnType(methodInsnNode2.desc);
                prettyPrinter.add("Incompatible invocation descriptors in synthetic bridge implies that generified");
                "".length();
                prettyPrinter.add("types are incompatible over one or more generic superclasses or interfaces. It may");
                "".length();
                prettyPrinter.add("be possible to adjust the generic types on implemented members to rectify this");
                "".length();
                prettyPrinter.add("problem by coalescing the appropriate generic types.").add();
                "".length();
                this.printTypeComparison(prettyPrinter, "return type", type8, type9);
                "".length();
                int n = 0;
                while (SyntheticBridgeException.lIIIIIIllIIl(n, typeArray.length)) {
                    this.printTypeComparison(prettyPrinter, String.valueOf(new StringBuilder().append("arg ").append(n)), typeArray[n], typeArray3[n]);
                    "".length();
                    ++n;
                    "".length();
                    if (null == null) continue;
                    return null;
                }
                "".length();
                if (-"  ".length() <= 0) break;
                return null;
            }
            case 6: {
                prettyPrinter.add("Mismatched bridge method length implies the bridge methods are incompatible");
                "".length();
                prettyPrinter.add("and may originate from different superinterfaces. This is an unrecoverable");
                "".length();
                prettyPrinter.add("error.").add();
                "".length();
                "".length();
                if (((156 + 32 - 174 + 152 ^ 44 + 168 - 132 + 116) & (131 + 184 - 127 + 22 ^ 147 + 31 - 134 + 132 ^ -" ".length())) < "  ".length()) break;
                return null;
            }
        }
        return prettyPrinter;
    }

    private PrettyPrinter printTypeComparison(PrettyPrinter prettyPrinter, String string, Type type, Type type2) {
        prettyPrinter.kv(String.valueOf(new StringBuilder().append("Target ").append(string)), "%s", type);
        "".length();
        prettyPrinter.kv(String.valueOf(new StringBuilder().append("Incoming ").append(string)), "%s", type2);
        "".length();
        if (SyntheticBridgeException.lIIIIIIlIlIl(type.equals(type2) ? 1 : 0)) {
            prettyPrinter.kv("Analysis", "Types match: %s", type);
            "".length();
            "".length();
            if ("   ".length() == 0) {
                return null;
            }
        } else if (SyntheticBridgeException.lIIIIIIllIII(type.getSort(), type2.getSort())) {
            prettyPrinter.kv("Analysis", "Types are incompatible");
            "".length();
            "".length();
            if (" ".length() == ((7 ^ 0x4A) & ~(0x16 ^ 0x5B))) {
                return null;
            }
        } else if (SyntheticBridgeException.lIIIIIIlIllI(type.getSort(), 10)) {
            ClassInfo classInfo = ClassInfo.getCommonSuperClassOrInterface(type, type2);
            prettyPrinter.kv("Analysis", "Common supertype: L%s;", classInfo);
            "".length();
        }
        return prettyPrinter.add();
    }

    private static boolean lIIIIIIlIllI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIIIIllIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIIIlIlII(Object object) {
        return object != null;
    }

    private static boolean lIIIIIIlIlIl(int n) {
        return n != 0;
    }

    private static boolean lIIIIIIlIlll(int n) {
        return n > 0;
    }

    private static boolean lIIIIIIllIII(int n, int n2) {
        return n != n2;
    }
}

