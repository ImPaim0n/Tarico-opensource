/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.agent;

import java.lang.instrument.ClassDefinition;
import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.mixin.transformer.throwables.MixinReloadException;
import org.spongepowered.asm.service.IMixinService;
import org.spongepowered.asm.service.MixinService;
import org.spongepowered.tools.agent.MixinAgent;

class MixinAgent$Transformer
implements ClassFileTransformer {
    final /* synthetic */ MixinAgent this$0;

    MixinAgent$Transformer(MixinAgent mixinAgent) {
        this.this$0 = mixinAgent;
    }

    @Override
    public byte[] transform(ClassLoader classLoader, String string, Class<?> clazz, ProtectionDomain protectionDomain, byte[] byArray) {
        if (MixinAgent$Transformer.lIIIIIlIlIl(clazz)) {
            return null;
        }
        byte[] byArray2 = MixinAgent.classLoader.getFakeMixinBytecode(clazz);
        if (MixinAgent$Transformer.lIIIIIlIllI(byArray2)) {
            List<String> list = this.reloadMixin(string, byArray);
            if (!MixinAgent$Transformer.lIIIIIlIllI(list) || MixinAgent$Transformer.lIIIIIlIlll(this.reApplyMixins(list) ? 1 : 0)) {
                return MixinAgent.ERROR_BYTECODE;
            }
            return byArray2;
        }
        try {
            MixinAgent.logger.info(String.valueOf(new StringBuilder().append("Redefining class ").append(string)));
            return this.this$0.classTransformer.transformClassBytes(null, string, byArray);
        }
        catch (Throwable throwable) {
            MixinAgent.logger.error(String.valueOf(new StringBuilder().append("Error while re-transforming class ").append(string)), throwable);
            return MixinAgent.ERROR_BYTECODE;
        }
    }

    private List<String> reloadMixin(String string, byte[] byArray) {
        MixinAgent.logger.info("Redefining mixin {}", new Object[]{string});
        try {
            return this.this$0.classTransformer.reload(string.replace('/', '.'), byArray);
        }
        catch (MixinReloadException mixinReloadException) {
            MixinAgent.logger.error("Mixin {} cannot be reloaded, needs a restart to be applied: {} ", new Object[]{mixinReloadException.getMixinInfo(), mixinReloadException.getMessage()});
            "".length();
            if ((0x4B ^ 0x4F) < 0) {
                return null;
            }
        }
        catch (Throwable throwable) {
            MixinAgent.logger.error(String.valueOf(new StringBuilder().append("Error while finding targets for mixin ").append(string)), throwable);
        }
        return null;
    }

    private boolean reApplyMixins(List<String> list) {
        IMixinService iMixinService = MixinService.getService();
        Iterator<String> iterator = list.iterator();
        while (MixinAgent$Transformer.lIIIIIllIII(iterator.hasNext() ? 1 : 0)) {
            String string = iterator.next();
            String string2 = string.replace('/', '.');
            MixinAgent.logger.debug("Re-transforming target class {}", new Object[]{string});
            try {
                Class<?> clazz = iMixinService.getClassProvider().findClass(string2);
                byte[] byArray = MixinAgent.classLoader.getOriginalTargetBytecode(string2);
                if (MixinAgent$Transformer.lIIIIIlIlIl(byArray)) {
                    MixinAgent.logger.error("Target class {} bytecode is not registered", new Object[]{string2});
                    return false;
                }
                byArray = this.this$0.classTransformer.transformClassBytes(null, string2, byArray);
                MixinAgent.instrumentation.redefineClasses(new ClassDefinition(clazz, byArray));
                "".length();
            }
            catch (Throwable throwable) {
                MixinAgent.logger.error(String.valueOf(new StringBuilder().append("Error while re-transforming target class ").append(string)), throwable);
                return false;
            }
            if ((118 + 96 - 122 + 88 ^ 121 + 173 - 203 + 85) != (78 + 33 - 103 + 186 ^ 163 + 13 - 78 + 100)) {
                return ((21 + 217 - 14 + 26 ^ 146 + 38 - 99 + 105) & (130 + 102 - 185 + 179 ^ 35 + 100 - 65 + 96 ^ -" ".length())) != 0;
            }
            "".length();
            if (null == null) continue;
            return ((7 ^ 0x36) & ~(0x2D ^ 0x1C)) != 0;
        }
        return true;
    }

    private static boolean lIIIIIlIllI(Object object) {
        return object != null;
    }

    private static boolean lIIIIIlIlIl(Object object) {
        return object == null;
    }

    private static boolean lIIIIIllIII(int n) {
        return n != 0;
    }

    private static boolean lIIIIIlIlll(int n) {
        return n == 0;
    }
}

