/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package org.spongepowered.tools.agent;

import java.lang.instrument.Instrumentation;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.transformer.MixinTransformer;
import org.spongepowered.asm.mixin.transformer.ext.IHotSwap;
import org.spongepowered.tools.agent.MixinAgent$Transformer;
import org.spongepowered.tools.agent.MixinAgentClassLoader;

public class MixinAgent
implements IHotSwap {
    public static final byte[] ERROR_BYTECODE = new byte[]{1};
    static final MixinAgentClassLoader classLoader = new MixinAgentClassLoader();
    static final Logger logger = LogManager.getLogger((String)"mixin.agent");
    static Instrumentation instrumentation = null;
    private static List<MixinAgent> agents = new ArrayList<MixinAgent>();
    final MixinTransformer classTransformer;

    public MixinAgent(MixinTransformer mixinTransformer) {
        this.classTransformer = mixinTransformer;
        agents.add(this);
        "".length();
        if (MixinAgent.lIIIIl(instrumentation)) {
            this.initTransformer();
        }
    }

    private void initTransformer() {
        instrumentation.addTransformer(new MixinAgent$Transformer(this), true);
    }

    @Override
    public void registerMixinClass(String string) {
        classLoader.addMixinClass(string);
    }

    @Override
    public void registerTargetClass(String string, byte[] byArray) {
        classLoader.addTargetClass(string, byArray);
    }

    public static void init(Instrumentation instrumentation) {
        MixinAgent.instrumentation = instrumentation;
        if (MixinAgent.lIIIlI(MixinAgent.instrumentation.isRedefineClassesSupported() ? 1 : 0)) {
            logger.error("The instrumentation doesn't support re-definition of classes");
        }
        Iterator<MixinAgent> iterator = agents.iterator();
        while (MixinAgent.lIIIll(iterator.hasNext() ? 1 : 0)) {
            MixinAgent mixinAgent = iterator.next();
            mixinAgent.initTransformer();
            "".length();
            if (((0x31 ^ 0x2B) & ~(0x70 ^ 0x6A)) == 0) continue;
            return;
        }
    }

    public static void premain(String string, Instrumentation instrumentation) {
        System.setProperty("mixin.hotSwap", "true");
        "".length();
        MixinAgent.init(instrumentation);
    }

    public static void agentmain(String string, Instrumentation instrumentation) {
        MixinAgent.init(instrumentation);
    }

    private static boolean lIIIIl(Object object) {
        return object != null;
    }

    private static boolean lIIIll(int n) {
        return n != 0;
    }

    private static boolean lIIIlI(int n) {
        return n == 0;
    }
}

