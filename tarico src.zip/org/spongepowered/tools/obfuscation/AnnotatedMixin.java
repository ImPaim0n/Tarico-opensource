/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.annotation.processing.Messager;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeMirror;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerAccessor;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerInjector;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerOverwrite;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerSoftImplements;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.interfaces.IMixinValidator;
import org.spongepowered.tools.obfuscation.interfaces.IMixinValidator$ValidationPass;
import org.spongepowered.tools.obfuscation.interfaces.IObfuscationManager;
import org.spongepowered.tools.obfuscation.interfaces.ITypeHandleProvider;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;
import org.spongepowered.tools.obfuscation.struct.InjectorRemap;

class AnnotatedMixin {
    private final AnnotationHandle annotation;
    private final Messager messager;
    private final ITypeHandleProvider typeProvider;
    private final IObfuscationManager obf;
    private final IMappingConsumer mappings;
    private final TypeElement mixin;
    private final List<ExecutableElement> methods;
    private final TypeHandle handle;
    private final List<TypeHandle> targets = new ArrayList<TypeHandle>();
    private final TypeHandle primaryTarget;
    private final String classRef;
    private final boolean remap;
    private final boolean virtual;
    private final AnnotatedMixinElementHandlerOverwrite overwrites;
    private final AnnotatedMixinElementHandlerShadow shadows;
    private final AnnotatedMixinElementHandlerInjector injectors;
    private final AnnotatedMixinElementHandlerAccessor accessors;
    private final AnnotatedMixinElementHandlerSoftImplements softImplements;
    private boolean validated = false;

    public AnnotatedMixin(IMixinAnnotationProcessor iMixinAnnotationProcessor, TypeElement typeElement) {
        boolean bl;
        this.typeProvider = iMixinAnnotationProcessor.getTypeProvider();
        this.obf = iMixinAnnotationProcessor.getObfuscationManager();
        this.mappings = this.obf.createMappingConsumer();
        this.messager = iMixinAnnotationProcessor;
        this.mixin = typeElement;
        this.handle = new TypeHandle(typeElement);
        this.methods = new ArrayList(this.handle.getEnclosedElements(ElementKind.METHOD));
        this.virtual = this.handle.getAnnotation(Pseudo.class).exists();
        this.annotation = this.handle.getAnnotation(Mixin.class);
        this.classRef = TypeUtils.getInternalName(typeElement);
        this.primaryTarget = this.initTargets();
        if (AnnotatedMixin.lIIllIIIII(this.annotation.getBoolean("remap", true) ? 1 : 0) && AnnotatedMixin.lIIllIIIIl(this.targets.size())) {
            bl = true;
            "".length();
            if (((0x13 ^ 0x77 ^ (0x46 ^ 0x10)) & (0x7C ^ 0x2C ^ (0x6F ^ 0xD) ^ -" ".length())) != 0) {
                throw null;
            }
        } else {
            bl = false;
        }
        this.remap = bl;
        this.overwrites = new AnnotatedMixinElementHandlerOverwrite(iMixinAnnotationProcessor, this);
        this.shadows = new AnnotatedMixinElementHandlerShadow(iMixinAnnotationProcessor, this);
        this.injectors = new AnnotatedMixinElementHandlerInjector(iMixinAnnotationProcessor, this);
        this.accessors = new AnnotatedMixinElementHandlerAccessor(iMixinAnnotationProcessor, this);
        this.softImplements = new AnnotatedMixinElementHandlerSoftImplements(iMixinAnnotationProcessor, this);
    }

    AnnotatedMixin runValidators(IMixinValidator$ValidationPass iMixinValidator$ValidationPass, Collection<IMixinValidator> collection) {
        Iterator<IMixinValidator> iterator = collection.iterator();
        while (AnnotatedMixin.lIIllIIIII(iterator.hasNext() ? 1 : 0)) {
            IMixinValidator iMixinValidator = iterator.next();
            if (AnnotatedMixin.lIIllIIIlI(iMixinValidator.validate(iMixinValidator$ValidationPass, this.mixin, this.annotation, this.targets) ? 1 : 0)) {
                "".length();
                if ("   ".length() != 0) break;
                return null;
            }
            "".length();
            if (" ".length() != 0) continue;
            return null;
        }
        if (AnnotatedMixin.lIIllIIIll((Object)iMixinValidator$ValidationPass, (Object)IMixinValidator$ValidationPass.FINAL) && AnnotatedMixin.lIIllIIIlI(this.validated ? 1 : 0)) {
            this.validated = true;
            this.runFinalValidation();
        }
        return this;
    }

    private TypeHandle initTargets() {
        TypeHandle typeHandle;
        Object object;
        Iterator iterator;
        TypeHandle typeHandle2 = null;
        try {
            iterator = this.annotation.getList().iterator();
            while (AnnotatedMixin.lIIllIIIII(iterator.hasNext() ? 1 : 0)) {
                object = (TypeMirror)iterator.next();
                typeHandle = new TypeHandle((DeclaredType)object);
                if (AnnotatedMixin.lIIllIIIII(this.targets.contains(typeHandle) ? 1 : 0)) {
                    "".length();
                    if (((54 + 99 - 98 + 92 ^ 4 + 3 - -42 + 143) & (0xC0 ^ 0x86 ^ (0xAD ^ 0xB8) ^ -" ".length())) == 0) continue;
                    return null;
                }
                this.addTarget(typeHandle);
                if (AnnotatedMixin.lIIllIIlII(typeHandle2)) {
                    typeHandle2 = typeHandle;
                }
                "".length();
                if ((0xB5 ^ 0xB0) != 0) continue;
                return null;
            }
            "".length();
        }
        catch (Exception exception) {
            this.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Error processing public targets: ").append(exception.getClass().getName()).append(": ").append(exception.getMessage())), this);
        }
        if (-(44 + 68 - -74 + 8 ^ 18 + 49 - 53 + 185) >= 0) {
            return null;
        }
        try {
            iterator = this.annotation.getList("targets").iterator();
            while (AnnotatedMixin.lIIllIIIII(iterator.hasNext() ? 1 : 0)) {
                object = (String)iterator.next();
                typeHandle = this.typeProvider.getTypeHandle((String)object);
                if (AnnotatedMixin.lIIllIIIII(this.targets.contains(typeHandle) ? 1 : 0)) {
                    "".length();
                    if ("   ".length() == "   ".length()) continue;
                    return null;
                }
                if (AnnotatedMixin.lIIllIIIII(this.virtual ? 1 : 0)) {
                    typeHandle = this.typeProvider.getSimulatedHandle((String)object, this.mixin.asType());
                    "".length();
                    if (" ".length() == "  ".length()) {
                        return null;
                    }
                } else {
                    if (AnnotatedMixin.lIIllIIlII(typeHandle)) {
                        this.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Mixin target ").append((String)object).append(" could not be found")), this);
                        return null;
                    }
                    if (AnnotatedMixin.lIIllIIIII(typeHandle.isPublic() ? 1 : 0)) {
                        this.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Mixin target ").append((String)object).append(" is public and must be specified in value")), this);
                        return null;
                    }
                }
                this.addSoftTarget(typeHandle, (String)object);
                if (AnnotatedMixin.lIIllIIlII(typeHandle2)) {
                    typeHandle2 = typeHandle;
                }
                "".length();
                if ("  ".length() >= "  ".length()) continue;
                return null;
            }
            "".length();
        }
        catch (Exception exception) {
            this.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Error processing private targets: ").append(exception.getClass().getName()).append(": ").append(exception.getMessage())), this);
        }
        if ((0x45 ^ 0x41) < ((0x82 ^ 0x96) & ~(0xF ^ 0x1B))) {
            return null;
        }
        if (AnnotatedMixin.lIIllIIlII(typeHandle2)) {
            this.printMessage(Diagnostic.Kind.ERROR, "Mixin has no targets", this);
        }
        return typeHandle2;
    }

    private void printMessage(Diagnostic.Kind kind, CharSequence charSequence, AnnotatedMixin annotatedMixin) {
        this.messager.printMessage(kind, charSequence, this.mixin, this.annotation.asMirror());
    }

    private void addSoftTarget(TypeHandle typeHandle, String string) {
        ObfuscationData<String> obfuscationData = this.obf.getDataProvider().getObfClass(typeHandle);
        if (AnnotatedMixin.lIIllIIIlI(obfuscationData.isEmpty() ? 1 : 0)) {
            this.obf.getReferenceManager().addClassMapping(this.classRef, string, obfuscationData);
        }
        this.addTarget(typeHandle);
    }

    private void addTarget(TypeHandle typeHandle) {
        this.targets.add(typeHandle);
        "".length();
    }

    public String toString() {
        return this.mixin.getSimpleName().toString();
    }

    public AnnotationHandle getAnnotation() {
        return this.annotation;
    }

    public TypeElement getMixin() {
        return this.mixin;
    }

    public TypeHandle getHandle() {
        return this.handle;
    }

    public String getClassRef() {
        return this.classRef;
    }

    public boolean isInterface() {
        boolean bl;
        if (AnnotatedMixin.lIIllIIIll((Object)this.mixin.getKind(), (Object)ElementKind.INTERFACE)) {
            bl = true;
            "".length();
            if (((0x75 ^ 0x6C) & ~(0x6A ^ 0x73)) <= -" ".length()) {
                return ((0x8B ^ 0x9D) & ~(0x65 ^ 0x73)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Deprecated
    public TypeHandle getPrimaryTarget() {
        return this.primaryTarget;
    }

    public List<TypeHandle> getTargets() {
        return this.targets;
    }

    public boolean isMultiTarget() {
        boolean bl;
        if (AnnotatedMixin.lIIllIIlIl(this.targets.size(), 1)) {
            bl = true;
            "".length();
            if ("   ".length() <= ((0x4F ^ 0x40) & ~(0xCB ^ 0xC4))) {
                return ((0x76 ^ 0x20) & ~(0x2F ^ 0x79)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean remap() {
        return this.remap;
    }

    public IMappingConsumer getMappings() {
        return this.mappings;
    }

    private void runFinalValidation() {
        Iterator<ExecutableElement> iterator = this.methods.iterator();
        while (AnnotatedMixin.lIIllIIIII(iterator.hasNext() ? 1 : 0)) {
            ExecutableElement executableElement = iterator.next();
            this.overwrites.registerMerge(executableElement);
            "".length();
            if ("   ".length() > 0) continue;
            return;
        }
    }

    public void registerOverwrite(ExecutableElement executableElement, AnnotationHandle annotationHandle, boolean bl) {
        this.methods.remove(executableElement);
        "".length();
        this.overwrites.registerOverwrite(new AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite(executableElement, annotationHandle, bl));
    }

    public void registerShadow(VariableElement variableElement, AnnotationHandle annotationHandle, boolean bl) {
        AnnotatedMixinElementHandlerShadow annotatedMixinElementHandlerShadow = this.shadows;
        annotatedMixinElementHandlerShadow.getClass();
        "".length();
        this.shadows.registerShadow(new AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField(annotatedMixinElementHandlerShadow, variableElement, annotationHandle, bl));
    }

    public void registerShadow(ExecutableElement executableElement, AnnotationHandle annotationHandle, boolean bl) {
        this.methods.remove(executableElement);
        "".length();
        AnnotatedMixinElementHandlerShadow annotatedMixinElementHandlerShadow = this.shadows;
        annotatedMixinElementHandlerShadow.getClass();
        "".length();
        this.shadows.registerShadow(new AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod(annotatedMixinElementHandlerShadow, executableElement, annotationHandle, bl));
    }

    public void registerInjector(ExecutableElement executableElement, AnnotationHandle annotationHandle, InjectorRemap injectorRemap) {
        Object object;
        this.methods.remove(executableElement);
        "".length();
        this.injectors.registerInjector(new AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector(executableElement, annotationHandle, injectorRemap));
        List<AnnotationHandle> list = annotationHandle.getAnnotationList("at");
        Object object2 = list.iterator();
        while (AnnotatedMixin.lIIllIIIII(object2.hasNext() ? 1 : 0)) {
            object = object2.next();
            this.registerInjectionPoint(executableElement, annotationHandle, (AnnotationHandle)object, injectorRemap, "@At(%s)");
            "".length();
            if (" ".length() != 0) continue;
            return;
        }
        object2 = annotationHandle.getAnnotationList("slice");
        object = object2.iterator();
        while (AnnotatedMixin.lIIllIIIII(object.hasNext() ? 1 : 0)) {
            AnnotationHandle annotationHandle2;
            AnnotationHandle annotationHandle3 = (AnnotationHandle)object.next();
            String string = annotationHandle3.getValue("id", "");
            AnnotationHandle annotationHandle4 = annotationHandle3.getAnnotation("from");
            if (AnnotatedMixin.lIIllIIllI(annotationHandle4)) {
                this.registerInjectionPoint(executableElement, annotationHandle, annotationHandle4, injectorRemap, String.valueOf(new StringBuilder().append("@Slice[").append(string).append("](from=@At(%s))")));
            }
            if (AnnotatedMixin.lIIllIIllI(annotationHandle2 = annotationHandle3.getAnnotation("to"))) {
                this.registerInjectionPoint(executableElement, annotationHandle, annotationHandle2, injectorRemap, String.valueOf(new StringBuilder().append("@Slice[").append(string).append("](to=@At(%s))")));
            }
            "".length();
            if (" ".length() != (146 + 99 - 199 + 133 ^ 22 + 11 - -122 + 28)) continue;
            return;
        }
    }

    public void registerInjectionPoint(ExecutableElement executableElement, AnnotationHandle annotationHandle, AnnotationHandle annotationHandle2, InjectorRemap injectorRemap, String string) {
        this.injectors.registerInjectionPoint(new AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint(executableElement, annotationHandle, annotationHandle2, injectorRemap), string);
    }

    public void registerAccessor(ExecutableElement executableElement, AnnotationHandle annotationHandle, boolean bl) {
        this.methods.remove(executableElement);
        "".length();
        this.accessors.registerAccessor(new AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor(executableElement, annotationHandle, bl));
    }

    public void registerInvoker(ExecutableElement executableElement, AnnotationHandle annotationHandle, boolean bl) {
        this.methods.remove(executableElement);
        "".length();
        this.accessors.registerAccessor(new AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker(executableElement, annotationHandle, bl));
    }

    public void registerSoftImplements(AnnotationHandle annotationHandle) {
        this.softImplements.process(annotationHandle);
    }

    private static boolean lIIllIIlIl(int n, int n2) {
        return n > n2;
    }

    private static boolean lIIllIIIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIllIIllI(Object object) {
        return object != null;
    }

    private static boolean lIIllIIlII(Object object) {
        return object == null;
    }

    private static boolean lIIllIIIII(int n) {
        return n != 0;
    }

    private static boolean lIIllIIIlI(int n) {
        return n == 0;
    }

    private static boolean lIIllIIIIl(int n) {
        return n > 0;
    }
}

