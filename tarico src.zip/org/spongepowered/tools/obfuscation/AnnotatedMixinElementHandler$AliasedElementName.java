/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.List;
import javax.lang.model.element.Element;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;

class AnnotatedMixinElementHandler$AliasedElementName {
    protected final String originalName;
    private final List<String> aliases;
    private boolean caseSensitive;

    public AnnotatedMixinElementHandler$AliasedElementName(Element element, AnnotationHandle annotationHandle) {
        this.originalName = element.getSimpleName().toString();
        this.aliases = annotationHandle.getList("aliases");
    }

    public AnnotatedMixinElementHandler$AliasedElementName setCaseSensitive(boolean bl) {
        this.caseSensitive = bl;
        return this;
    }

    public boolean isCaseSensitive() {
        return this.caseSensitive;
    }

    public boolean hasAliases() {
        boolean bl;
        if (AnnotatedMixinElementHandler$AliasedElementName.lllIIlll(this.aliases.size())) {
            bl = true;
            "".length();
            if (((0xAD ^ 0x9D) & ~(0x57 ^ 0x67)) > 0) {
                return ((0x2F ^ 0x16) & ~(0x9B ^ 0xA2)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public List<String> getAliases() {
        return this.aliases;
    }

    public String elementName() {
        return this.originalName;
    }

    public String baseName() {
        return this.originalName;
    }

    public boolean hasPrefix() {
        return false;
    }

    private static boolean lllIIlll(int n) {
        return n > 0;
    }
}

