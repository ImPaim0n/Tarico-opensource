/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import javax.annotation.processing.Messager;
import javax.lang.model.element.Element;
import javax.tools.Diagnostic;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;

abstract class AnnotatedMixinElementHandler$AnnotatedElement<E extends Element> {
    protected final E element;
    protected final AnnotationHandle annotation;
    private final String desc;

    public AnnotatedMixinElementHandler$AnnotatedElement(E e, AnnotationHandle annotationHandle) {
        this.element = e;
        this.annotation = annotationHandle;
        this.desc = TypeUtils.getDescriptor(e);
    }

    public E getElement() {
        return this.element;
    }

    public AnnotationHandle getAnnotation() {
        return this.annotation;
    }

    public String getSimpleName() {
        return this.getElement().getSimpleName().toString();
    }

    public String getDesc() {
        return this.desc;
    }

    public final void printMessage(Messager messager, Diagnostic.Kind kind, CharSequence charSequence) {
        messager.printMessage(kind, charSequence, (Element)this.element, this.annotation.asMirror());
    }
}

