/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import javax.lang.model.element.Element;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AliasedElementName;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;

class AnnotatedMixinElementHandler$ShadowElementName
extends AnnotatedMixinElementHandler$AliasedElementName {
    private final boolean hasPrefix;
    private final String prefix;
    private final String baseName;
    private String obfuscated;

    AnnotatedMixinElementHandler$ShadowElementName(Element element, AnnotationHandle annotationHandle) {
        super(element, annotationHandle);
        this.prefix = annotationHandle.getValue("prefix", "shadow$");
        boolean bl = false;
        String string = this.originalName;
        if (AnnotatedMixinElementHandler$ShadowElementName.lIIIlIIIIlIl(string.startsWith(this.prefix) ? 1 : 0)) {
            bl = true;
            string = string.substring(this.prefix.length());
        }
        this.hasPrefix = bl;
        this.obfuscated = this.baseName = string;
    }

    public String toString() {
        return this.baseName;
    }

    @Override
    public String baseName() {
        return this.baseName;
    }

    public AnnotatedMixinElementHandler$ShadowElementName setObfuscatedName(IMapping<?> iMapping) {
        this.obfuscated = iMapping.getName();
        return this;
    }

    public AnnotatedMixinElementHandler$ShadowElementName setObfuscatedName(String string) {
        this.obfuscated = string;
        return this;
    }

    @Override
    public boolean hasPrefix() {
        return this.hasPrefix;
    }

    public String prefix() {
        String string;
        if (AnnotatedMixinElementHandler$ShadowElementName.lIIIlIIIIlIl(this.hasPrefix ? 1 : 0)) {
            string = this.prefix;
            "".length();
            if (((20 + 90 - -14 + 27 ^ 54 + 70 - 58 + 112) & (26 + 93 - 17 + 57 ^ 74 + 33 - 30 + 109 ^ -" ".length())) != 0) {
                return null;
            }
        } else {
            string = "";
        }
        return string;
    }

    public String name() {
        return this.prefix(this.baseName);
    }

    public String obfuscated() {
        return this.prefix(this.obfuscated);
    }

    public String prefix(String string) {
        String string2;
        if (AnnotatedMixinElementHandler$ShadowElementName.lIIIlIIIIlIl(this.hasPrefix ? 1 : 0)) {
            string2 = String.valueOf(new StringBuilder().append(this.prefix).append(string));
            "".length();
            if (-"   ".length() >= 0) {
                return null;
            }
        } else {
            string2 = string;
        }
        return string2;
    }

    private static boolean lIIIlIIIIlIl(int n) {
        return n != 0;
    }
}

