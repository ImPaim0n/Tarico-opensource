/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import java.util.List;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.VariableElement;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.asm.util.ConstraintParser;
import org.spongepowered.asm.util.ConstraintParser$Constraint;
import org.spongepowered.asm.util.throwables.ConstraintViolationException;
import org.spongepowered.asm.util.throwables.InvalidConstraintException;
import org.spongepowered.tools.obfuscation.AnnotatedMixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AliasedElementName;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$ShadowElementName;
import org.spongepowered.tools.obfuscation.Mappings;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.interfaces.IObfuscationManager;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.FieldHandle;
import org.spongepowered.tools.obfuscation.mirror.MethodHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;
import org.spongepowered.tools.obfuscation.mirror.Visibility;

abstract class AnnotatedMixinElementHandler {
    protected final AnnotatedMixin mixin;
    protected final String classRef;
    protected final IMixinAnnotationProcessor ap;
    protected final IObfuscationManager obf;
    private IMappingConsumer mappings;

    AnnotatedMixinElementHandler(IMixinAnnotationProcessor iMixinAnnotationProcessor, AnnotatedMixin annotatedMixin) {
        this.ap = iMixinAnnotationProcessor;
        this.mixin = annotatedMixin;
        this.classRef = annotatedMixin.getClassRef();
        this.obf = iMixinAnnotationProcessor.getObfuscationManager();
    }

    private IMappingConsumer getMappings() {
        if (AnnotatedMixinElementHandler.llllIIIlll(this.mappings)) {
            IMappingConsumer iMappingConsumer = this.mixin.getMappings();
            if (AnnotatedMixinElementHandler.llllIIlIII(iMappingConsumer instanceof Mappings)) {
                this.mappings = ((Mappings)iMappingConsumer).asUnique();
                "".length();
                if (((0xC2 ^ 0x88) & ~(0x88 ^ 0xC2)) != 0) {
                    return null;
                }
            } else {
                this.mappings = iMappingConsumer;
            }
        }
        return this.mappings;
    }

    protected final void addFieldMappings(String string, String string2, ObfuscationData<MappingField> obfuscationData) {
        Iterator<ObfuscationType> iterator = obfuscationData.iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            MappingField mappingField = obfuscationData.get(obfuscationType);
            this.addFieldMapping(obfuscationType, string, mappingField.getSimpleName(), string2, mappingField.getDesc());
            "".length();
            if ("  ".length() != 0) continue;
            return;
        }
    }

    protected final void addFieldMapping(ObfuscationType obfuscationType, AnnotatedMixinElementHandler$ShadowElementName annotatedMixinElementHandler$ShadowElementName, String string, String string2) {
        this.addFieldMapping(obfuscationType, annotatedMixinElementHandler$ShadowElementName.name(), annotatedMixinElementHandler$ShadowElementName.obfuscated(), string, string2);
    }

    protected final void addFieldMapping(ObfuscationType obfuscationType, String string, String string2, String string3, String string4) {
        MappingField mappingField = new MappingField(this.classRef, string, string3);
        MappingField mappingField2 = new MappingField(this.classRef, string2, string4);
        this.getMappings().addFieldMapping(obfuscationType, mappingField, mappingField2);
    }

    protected final void addMethodMappings(String string, String string2, ObfuscationData<MappingMethod> obfuscationData) {
        Iterator<ObfuscationType> iterator = obfuscationData.iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            MappingMethod mappingMethod = obfuscationData.get(obfuscationType);
            this.addMethodMapping(obfuscationType, string, mappingMethod.getSimpleName(), string2, mappingMethod.getDesc());
            "".length();
            if ((0x7F ^ 0x7A) > 0) continue;
            return;
        }
    }

    protected final void addMethodMapping(ObfuscationType obfuscationType, AnnotatedMixinElementHandler$ShadowElementName annotatedMixinElementHandler$ShadowElementName, String string, String string2) {
        this.addMethodMapping(obfuscationType, annotatedMixinElementHandler$ShadowElementName.name(), annotatedMixinElementHandler$ShadowElementName.obfuscated(), string, string2);
    }

    protected final void addMethodMapping(ObfuscationType obfuscationType, String string, String string2, String string3, String string4) {
        MappingMethod mappingMethod = new MappingMethod(this.classRef, string, string3);
        MappingMethod mappingMethod2 = new MappingMethod(this.classRef, string2, string4);
        this.getMappings().addMethodMapping(obfuscationType, mappingMethod, mappingMethod2);
    }

    protected final void checkConstraints(ExecutableElement executableElement, AnnotationHandle annotationHandle) {
        try {
            ConstraintParser$Constraint constraintParser$Constraint = ConstraintParser.parse((String)annotationHandle.getValue("constraints"));
            try {
                constraintParser$Constraint.check(this.ap.getTokenProvider());
                "".length();
            }
            catch (ConstraintViolationException constraintViolationException) {
                this.ap.printMessage(Diagnostic.Kind.ERROR, constraintViolationException.getMessage(), executableElement, annotationHandle.asMirror());
            }
            if (" ".length() == ((0x99 ^ 0xB0) & ~(0x71 ^ 0x58))) {
                return;
            }
        }
        catch (InvalidConstraintException invalidConstraintException) {
            this.ap.printMessage(Diagnostic.Kind.WARNING, invalidConstraintException.getMessage(), executableElement, annotationHandle.asMirror());
        }
        "".length();
        if (-(0x76 ^ 0x72) >= 0) {
            return;
        }
    }

    protected final void validateTarget(Element element, AnnotationHandle annotationHandle, AnnotatedMixinElementHandler$AliasedElementName annotatedMixinElementHandler$AliasedElementName, String string) {
        if (AnnotatedMixinElementHandler.llllIIlIII(element instanceof ExecutableElement)) {
            this.validateTargetMethod((ExecutableElement)element, annotationHandle, annotatedMixinElementHandler$AliasedElementName, string, false, false);
            "".length();
            if (((0x6F ^ 0x31) & ~(0xF4 ^ 0xAA)) != 0) {
                return;
            }
        } else if (AnnotatedMixinElementHandler.llllIIlIII(element instanceof VariableElement)) {
            this.validateTargetField((VariableElement)element, annotationHandle, annotatedMixinElementHandler$AliasedElementName, string);
        }
    }

    protected final void validateTargetMethod(ExecutableElement executableElement, AnnotationHandle annotationHandle, AnnotatedMixinElementHandler$AliasedElementName annotatedMixinElementHandler$AliasedElementName, String string, boolean bl, boolean bl2) {
        String string2 = TypeUtils.getJavaSignature(executableElement);
        Iterator<TypeHandle> iterator = this.mixin.getTargets().iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            TypeHandle typeHandle = iterator.next();
            if (AnnotatedMixinElementHandler.llllIIlIII(typeHandle.isImaginary() ? 1 : 0)) {
                "".length();
                if (-" ".length() < (32 + 40 - 55 + 124 ^ 106 + 80 - 164 + 115)) continue;
                return;
            }
            MethodHandle methodHandle = typeHandle.findMethod(executableElement);
            if (AnnotatedMixinElementHandler.llllIIIlll(methodHandle) && AnnotatedMixinElementHandler.llllIIlIII(annotatedMixinElementHandler$AliasedElementName.hasPrefix() ? 1 : 0)) {
                methodHandle = typeHandle.findMethod(annotatedMixinElementHandler$AliasedElementName.baseName(), string2);
            }
            if (AnnotatedMixinElementHandler.llllIIIlll(methodHandle) && AnnotatedMixinElementHandler.llllIIlIII(annotatedMixinElementHandler$AliasedElementName.hasAliases() ? 1 : 0)) {
                Iterator<String> iterator2 = annotatedMixinElementHandler$AliasedElementName.getAliases().iterator();
                while (AnnotatedMixinElementHandler.llllIIlIII(iterator2.hasNext() ? 1 : 0)) {
                    String string3 = iterator2.next();
                    methodHandle = typeHandle.findMethod(string3, string2);
                    if (AnnotatedMixinElementHandler.llllIIlIll(methodHandle)) {
                        "".length();
                        if (null == null) break;
                        return;
                    }
                    "".length();
                    if ((0x27 ^ 0x28 ^ (0xBD ^ 0xB6)) > " ".length()) continue;
                    return;
                }
            }
            if (AnnotatedMixinElementHandler.llllIIlIll(methodHandle)) {
                if (AnnotatedMixinElementHandler.llllIIlIII(bl ? 1 : 0)) {
                    this.validateMethodVisibility(executableElement, annotationHandle, string, typeHandle, methodHandle);
                    "".length();
                    if (((0xA7 ^ 0x92) & ~(0x6A ^ 0x5F)) != 0) {
                        return;
                    }
                }
            } else if (AnnotatedMixinElementHandler.llllIIllII(bl2 ? 1 : 0)) {
                this.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Cannot find target for ").append(string).append(" method in ").append(typeHandle)), executableElement, annotationHandle);
            }
            "".length();
            if (-"   ".length() <= 0) continue;
            return;
        }
    }

    private void validateMethodVisibility(ExecutableElement executableElement, AnnotationHandle annotationHandle, String string, TypeHandle typeHandle, MethodHandle methodHandle) {
        Visibility visibility = methodHandle.getVisibility();
        if (AnnotatedMixinElementHandler.llllIIIlll((Object)visibility)) {
            return;
        }
        Visibility visibility2 = TypeUtils.getVisibility(executableElement);
        String string2 = String.valueOf(new StringBuilder().append("visibility of ").append((Object)visibility).append(" method in ").append(typeHandle));
        if (AnnotatedMixinElementHandler.llllIIlllI(visibility.ordinal(), visibility2.ordinal())) {
            this.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append((Object)visibility2).append(" ").append(string).append(" method cannot reduce ").append(string2)), executableElement, annotationHandle);
            "".length();
            if ("  ".length() == " ".length()) {
                return;
            }
        } else if (AnnotatedMixinElementHandler.llllIIllll((Object)visibility, (Object)Visibility.PRIVATE) && AnnotatedMixinElementHandler.llllIIlllI(visibility2.ordinal(), visibility.ordinal())) {
            this.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append((Object)visibility2).append(" ").append(string).append(" method will upgrade ").append(string2)), executableElement, annotationHandle);
        }
    }

    protected final void validateTargetField(VariableElement variableElement, AnnotationHandle annotationHandle, AnnotatedMixinElementHandler$AliasedElementName annotatedMixinElementHandler$AliasedElementName, String string) {
        String string2 = variableElement.asType().toString();
        Iterator<TypeHandle> iterator = this.mixin.getTargets().iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            TypeHandle typeHandle = iterator.next();
            if (AnnotatedMixinElementHandler.llllIIlIII(typeHandle.isImaginary() ? 1 : 0)) {
                "".length();
                if ((0x73 ^ 0x50 ^ (0x8B ^ 0xAD)) != 0) continue;
                return;
            }
            FieldHandle fieldHandle = typeHandle.findField(variableElement);
            if (AnnotatedMixinElementHandler.llllIIlIll(fieldHandle)) {
                "".length();
                if (-"   ".length() <= 0) continue;
                return;
            }
            List<String> list = annotatedMixinElementHandler$AliasedElementName.getAliases();
            Iterator<String> iterator2 = list.iterator();
            while (AnnotatedMixinElementHandler.llllIIlIII(iterator2.hasNext() ? 1 : 0)) {
                String string3 = iterator2.next();
                fieldHandle = typeHandle.findField(string3, string2);
                if (AnnotatedMixinElementHandler.llllIIlIll(fieldHandle)) {
                    "".length();
                    if (" ".length() < "  ".length()) break;
                    return;
                }
                "".length();
                if (((0x2D ^ 0x14 ^ (7 ^ 0x60)) & (91 + 110 - 50 + 93 ^ 4 + 163 - 98 + 101 ^ -" ".length())) == ((132 + 12 - 51 + 53 ^ 118 + 75 - 104 + 51) & (0xE3 ^ 0xB1 ^ (0x15 ^ 0x59) ^ -" ".length()))) continue;
                return;
            }
            if (AnnotatedMixinElementHandler.llllIIIlll(fieldHandle)) {
                this.ap.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Cannot find target for ").append(string).append(" field in ").append(typeHandle)), variableElement, annotationHandle.asMirror());
            }
            "".length();
            if ("  ".length() >= 0) continue;
            return;
        }
    }

    protected final void validateReferencedTarget(ExecutableElement executableElement, AnnotationHandle annotationHandle, MemberInfo memberInfo, String string) {
        String string2 = memberInfo.toDescriptor();
        Iterator<TypeHandle> iterator = this.mixin.getTargets().iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            TypeHandle typeHandle = iterator.next();
            if (AnnotatedMixinElementHandler.llllIIlIII(typeHandle.isImaginary() ? 1 : 0)) {
                "".length();
                if (" ".length() >= -" ".length()) continue;
                return;
            }
            MethodHandle methodHandle = typeHandle.findMethod(memberInfo.name, string2);
            if (AnnotatedMixinElementHandler.llllIIIlll(methodHandle)) {
                this.ap.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Cannot find target method for ").append(string).append(" in ").append(typeHandle)), executableElement, annotationHandle.asMirror());
            }
            "".length();
            if (-(0xC0 ^ 0xC4) < 0) continue;
            return;
        }
    }

    private void printMessage(Diagnostic.Kind kind, String string, Element element, AnnotationHandle annotationHandle) {
        if (AnnotatedMixinElementHandler.llllIIIlll(annotationHandle)) {
            this.ap.printMessage(kind, string, element);
            "".length();
            if (((0xED ^ 0xAF) & ~(0x7C ^ 0x3E)) != 0) {
                return;
            }
        } else {
            this.ap.printMessage(kind, string, element, annotationHandle.asMirror());
        }
    }

    protected static <T extends IMapping<T>> ObfuscationData<T> stripOwnerData(ObfuscationData<T> obfuscationData) {
        ObfuscationData obfuscationData2 = new ObfuscationData();
        Iterator<ObfuscationType> iterator = obfuscationData.iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            IMapping iMapping = (IMapping)obfuscationData.get(obfuscationType);
            obfuscationData2.put(obfuscationType, iMapping.move(null));
            "".length();
            if (-" ".length() < 0) continue;
            return null;
        }
        return obfuscationData2;
    }

    protected static <T extends IMapping<T>> ObfuscationData<T> stripDescriptors(ObfuscationData<T> obfuscationData) {
        ObfuscationData obfuscationData2 = new ObfuscationData();
        Iterator<ObfuscationType> iterator = obfuscationData.iterator();
        while (AnnotatedMixinElementHandler.llllIIlIII(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            IMapping iMapping = (IMapping)obfuscationData.get(obfuscationType);
            obfuscationData2.put(obfuscationType, iMapping.transform(null));
            "".length();
            if (((0x80 ^ 0xBB) & ~(0xF ^ 0x34)) != (0x20 ^ 0x24)) continue;
            return null;
        }
        return obfuscationData2;
    }

    private static boolean llllIIlllI(int n, int n2) {
        return n > n2;
    }

    private static boolean llllIIlIll(Object object) {
        return object != null;
    }

    private static boolean llllIIllll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llllIIIlll(Object object) {
        return object == null;
    }

    private static boolean llllIIlIII(int n) {
        return n != 0;
    }

    private static boolean llllIIllII(int n) {
        return n == 0;
    }
}

