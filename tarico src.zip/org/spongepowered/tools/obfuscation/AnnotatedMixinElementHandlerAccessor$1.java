/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType;

class AnnotatedMixinElementHandlerAccessor$1 {
    static final /* synthetic */ int[] $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType;

    static {
        block6: {
            block5: {
                $SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType = new int[AccessorInfo$AccessorType.values().length];
                try {
                    AnnotatedMixinElementHandlerAccessor$1.$SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[AccessorInfo$AccessorType.FIELD_GETTER.ordinal()] = 1;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if (-(0x84 ^ 0x80) <= 0) break block5;
                break block6;
            }
            try {
                AnnotatedMixinElementHandlerAccessor$1.$SwitchMap$org$spongepowered$asm$mixin$gen$AccessorInfo$AccessorType[AccessorInfo$AccessorType.FIELD_SETTER.ordinal()] = 2;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if (" ".length() <= 0) {
                // empty if block
            }
        }
    }
}

