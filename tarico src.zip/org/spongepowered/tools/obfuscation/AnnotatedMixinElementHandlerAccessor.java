/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.tools.obfuscation;

import com.google.common.base.Strings;
import java.util.Iterator;
import javax.tools.Diagnostic;
import org.spongepowered.asm.lib.tree.MethodNode;
import org.spongepowered.asm.mixin.MixinEnvironment$Option;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.mixin.gen.AccessorInfo;
import org.spongepowered.asm.mixin.gen.AccessorInfo$AccessorType;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.refmap.IMixinContext;
import org.spongepowered.asm.mixin.refmap.ReferenceMapper;
import org.spongepowered.asm.mixin.transformer.ext.Extensions;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.AnnotatedMixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ReferenceManager$ReferenceConflictException;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.mirror.FieldHandle;
import org.spongepowered.tools.obfuscation.mirror.MethodHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

public class AnnotatedMixinElementHandlerAccessor
extends AnnotatedMixinElementHandler
implements IMixinContext {
    public AnnotatedMixinElementHandlerAccessor(IMixinAnnotationProcessor iMixinAnnotationProcessor, AnnotatedMixin annotatedMixin) {
        super(iMixinAnnotationProcessor, annotatedMixin);
    }

    @Override
    public ReferenceMapper getReferenceMapper() {
        return null;
    }

    @Override
    public String getClassName() {
        return this.mixin.getClassRef().replace('/', '.');
    }

    @Override
    public String getClassRef() {
        return this.mixin.getClassRef();
    }

    @Override
    public String getTargetClassRef() {
        throw new UnsupportedOperationException("Target class not available at compile time");
    }

    @Override
    public IMixinInfo getMixin() {
        throw new UnsupportedOperationException("MixinInfo not available at compile time");
    }

    @Override
    public Extensions getExtensions() {
        throw new UnsupportedOperationException("Mixin Extensions not available at compile time");
    }

    @Override
    public boolean getOption(MixinEnvironment$Option mixinEnvironment$Option) {
        throw new UnsupportedOperationException("Options not available at compile time");
    }

    @Override
    public int getPriority() {
        throw new UnsupportedOperationException("Priority not available at compile time");
    }

    @Override
    public Target getTargetMethod(MethodNode methodNode) {
        throw new UnsupportedOperationException("Target not available at compile time");
    }

    public void registerAccessor(AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor) {
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIIl((Object)annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getAccessorType())) {
            annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.printMessage(this.ap, Diagnostic.Kind.WARNING, "Unsupported accessor type");
            return;
        }
        String string = this.getAccessorTargetName(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor);
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIIl(string)) {
            annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.printMessage(this.ap, Diagnostic.Kind.WARNING, "Cannot inflect accessor target name");
            return;
        }
        annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.setTargetName(string);
        Iterator<TypeHandle> iterator = this.mixin.getTargets().iterator();
        while (AnnotatedMixinElementHandlerAccessor.llIIlIIll(iterator.hasNext() ? 1 : 0)) {
            TypeHandle typeHandle = iterator.next();
            if (AnnotatedMixinElementHandlerAccessor.llIIlIlII((Object)annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getAccessorType(), (Object)AccessorInfo$AccessorType.METHOD_PROXY)) {
                this.registerInvokerForTarget((AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker)annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor, typeHandle);
                "".length();
                if (-" ".length() >= " ".length()) {
                    return;
                }
            } else {
                this.registerAccessorForTarget(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor, typeHandle);
            }
            "".length();
            if (-"  ".length() <= 0) continue;
            return;
        }
    }

    private void registerAccessorForTarget(AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor, TypeHandle typeHandle) {
        FieldHandle fieldHandle = typeHandle.findField(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getTargetName(), annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getTargetTypeName(), false);
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIIl(fieldHandle)) {
            if (AnnotatedMixinElementHandlerAccessor.llIIlIlIl(typeHandle.isImaginary() ? 1 : 0)) {
                annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Could not locate @Accessor target ").append(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor).append(" in target ").append(typeHandle)));
                return;
            }
            fieldHandle = new FieldHandle(typeHandle.getName(), annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getTargetName(), annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getDesc());
        }
        if (AnnotatedMixinElementHandlerAccessor.llIIlIlIl(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.shouldRemap() ? 1 : 0)) {
            return;
        }
        ObfuscationData<MappingField> obfuscationData = this.obf.getDataProvider().getObfField(fieldHandle.asMapping(false).move(typeHandle.getName()));
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIll(obfuscationData.isEmpty() ? 1 : 0)) {
            String string;
            if (AnnotatedMixinElementHandlerAccessor.llIIlIIll(this.mixin.isMultiTarget() ? 1 : 0)) {
                string = String.valueOf(new StringBuilder().append(" in target ").append(typeHandle));
                "".length();
                if ((71 + 0 - 30 + 153 ^ 37 + 56 - -95 + 10) < -" ".length()) {
                    return;
                }
            } else {
                string = "";
            }
            String string2 = string;
            annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.printMessage(this.ap, Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Unable to locate obfuscation mapping").append(string2).append(" for @Accessor target ").append(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor)));
            return;
        }
        obfuscationData = AnnotatedMixinElementHandler.stripOwnerData(obfuscationData);
        try {
            this.obf.getReferenceManager().addFieldMapping(this.mixin.getClassRef(), annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getTargetName(), annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getContext(), obfuscationData);
        }
        catch (ReferenceManager$ReferenceConflictException referenceManager$ReferenceConflictException) {
            annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Mapping conflict for @Accessor target ").append(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor).append(": ").append(referenceManager$ReferenceConflictException.getNew()).append(" for target ").append(typeHandle).append(" conflicts with existing mapping ").append(referenceManager$ReferenceConflictException.getOld())));
        }
        "".length();
        if ("  ".length() == 0) {
            return;
        }
    }

    private void registerInvokerForTarget(AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker, TypeHandle typeHandle) {
        MethodHandle methodHandle = typeHandle.findMethod(annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.getTargetName(), annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.getTargetTypeName(), false);
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIIl(methodHandle)) {
            if (AnnotatedMixinElementHandlerAccessor.llIIlIlIl(typeHandle.isImaginary() ? 1 : 0)) {
                annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Could not locate @Invoker target ").append(annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker).append(" in target ").append(typeHandle)));
                return;
            }
            methodHandle = new MethodHandle(typeHandle, annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.getTargetName(), annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.getDesc());
        }
        if (AnnotatedMixinElementHandlerAccessor.llIIlIlIl(annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.shouldRemap() ? 1 : 0)) {
            return;
        }
        ObfuscationData<MappingMethod> obfuscationData = this.obf.getDataProvider().getObfMethod(methodHandle.asMapping(false).move(typeHandle.getName()));
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIll(obfuscationData.isEmpty() ? 1 : 0)) {
            String string;
            if (AnnotatedMixinElementHandlerAccessor.llIIlIIll(this.mixin.isMultiTarget() ? 1 : 0)) {
                string = String.valueOf(new StringBuilder().append(" in target ").append(typeHandle));
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                string = "";
            }
            String string2 = string;
            annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.printMessage(this.ap, Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Unable to locate obfuscation mapping").append(string2).append(" for @Accessor target ").append(annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker)));
            return;
        }
        obfuscationData = AnnotatedMixinElementHandler.stripOwnerData(obfuscationData);
        try {
            this.obf.getReferenceManager().addMethodMapping(this.mixin.getClassRef(), annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.getTargetName(), annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.getContext(), obfuscationData);
        }
        catch (ReferenceManager$ReferenceConflictException referenceManager$ReferenceConflictException) {
            annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Mapping conflict for @Invoker target ").append(annotatedMixinElementHandlerAccessor$AnnotatedElementInvoker).append(": ").append(referenceManager$ReferenceConflictException.getNew()).append(" for target ").append(typeHandle).append(" conflicts with existing mapping ").append(referenceManager$ReferenceConflictException.getOld())));
        }
        "".length();
        if (null != null) {
            return;
        }
    }

    private String getAccessorTargetName(AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor) {
        String string = annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getAnnotationValue();
        if (AnnotatedMixinElementHandlerAccessor.llIIlIIll(Strings.isNullOrEmpty((String)string) ? 1 : 0)) {
            return this.inflectAccessorTarget(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor);
        }
        return string;
    }

    private String inflectAccessorTarget(AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor) {
        return AccessorInfo.inflectTarget(annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getSimpleName(), annotatedMixinElementHandlerAccessor$AnnotatedElementAccessor.getAccessorType(), "", this, false);
    }

    private static boolean llIIlIlII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIIlIIIl(Object object) {
        return object == null;
    }

    private static boolean llIIlIIll(int n) {
        return n != 0;
    }

    private static boolean llIIlIlIl(int n) {
        return n == 0;
    }
}

