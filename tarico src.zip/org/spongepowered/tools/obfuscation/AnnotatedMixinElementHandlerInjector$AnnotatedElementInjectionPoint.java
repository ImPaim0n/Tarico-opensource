/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.lang.model.element.ExecutableElement;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AnnotatedElement;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.struct.InjectorRemap;

class AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint
extends AnnotatedMixinElementHandler$AnnotatedElement<ExecutableElement> {
    private final AnnotationHandle at;
    private Map<String, String> args;
    private final InjectorRemap state;

    public AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint(ExecutableElement executableElement, AnnotationHandle annotationHandle, AnnotationHandle annotationHandle2, InjectorRemap injectorRemap) {
        super(executableElement, annotationHandle);
        this.at = annotationHandle2;
        this.state = injectorRemap;
    }

    public boolean shouldRemap() {
        return this.at.getBoolean("remap", this.state.shouldRemap());
    }

    public AnnotationHandle getAt() {
        return this.at;
    }

    public String getAtArg(String string) {
        if (AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.lIllIlIlIlI(this.args)) {
            this.args = new HashMap<String, String>();
            Iterator iterator = this.at.getList("args").iterator();
            while (AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.lIllIlIlIll(iterator.hasNext() ? 1 : 0)) {
                String string2 = (String)iterator.next();
                if (AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.lIllIlIlIlI(string2)) {
                    "".length();
                    if ("  ".length() < (0x54 ^ 4 ^ (0xF2 ^ 0xA6))) continue;
                    return null;
                }
                int n = string2.indexOf(61);
                if (AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.lIllIlIllII(n, -1)) {
                    this.args.put(string2.substring(0, n), string2.substring(n + 1));
                    "".length();
                    "".length();
                    if (-" ".length() >= 0) {
                        return null;
                    }
                } else {
                    this.args.put(string2, "");
                    "".length();
                }
                "".length();
                if (((0x3D ^ 0xC) & ~(0xAE ^ 0x9F)) == 0) continue;
                return null;
            }
        }
        return this.args.get(string);
    }

    public void notifyRemapped() {
        this.state.notifyRemapped();
    }

    private static boolean lIllIlIllII(int n, int n2) {
        return n > n2;
    }

    private static boolean lIllIlIlIlI(Object object) {
        return object == null;
    }

    private static boolean lIllIlIlIll(int n) {
        return n != 0;
    }
}

