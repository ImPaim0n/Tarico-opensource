/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.VariableElement;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AnnotatedElement;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.struct.InjectorRemap;

class AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector
extends AnnotatedMixinElementHandler$AnnotatedElement<ExecutableElement> {
    private final InjectorRemap state;

    public AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector(ExecutableElement executableElement, AnnotationHandle annotationHandle, InjectorRemap injectorRemap) {
        super(executableElement, annotationHandle);
        this.state = injectorRemap;
    }

    public boolean shouldRemap() {
        return this.state.shouldRemap();
    }

    public boolean hasCoerceArgument() {
        if (AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector.llIllllIIIl(this.annotation.toString().equals("@Inject") ? 1 : 0)) {
            return false;
        }
        Iterator<? extends VariableElement> iterator = ((ExecutableElement)this.element).getParameters().iterator();
        if (AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector.llIllllIIlI(iterator.hasNext() ? 1 : 0)) {
            VariableElement variableElement = iterator.next();
            return AnnotationHandle.of(variableElement, Coerce.class).exists();
        }
        return false;
    }

    public void addMessage(Diagnostic.Kind kind, CharSequence charSequence, Element element, AnnotationHandle annotationHandle) {
        this.state.addMessage(kind, charSequence, element, annotationHandle);
    }

    public String toString() {
        return this.getAnnotation().toString();
    }

    private static boolean llIllllIIlI(int n) {
        return n != 0;
    }

    private static boolean llIllllIIIl(int n) {
        return n == 0;
    }
}

