/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.injection.struct.InjectionPointData;
import org.spongepowered.asm.mixin.injection.struct.InvalidMemberDescriptorException;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.AnnotatedMixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.ReferenceManager$ReferenceConflictException;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor$CompilerEnvironment;
import org.spongepowered.tools.obfuscation.interfaces.IReferenceManager;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

class AnnotatedMixinElementHandlerInjector
extends AnnotatedMixinElementHandler {
    AnnotatedMixinElementHandlerInjector(IMixinAnnotationProcessor iMixinAnnotationProcessor, AnnotatedMixin annotatedMixin) {
        super(iMixinAnnotationProcessor, annotatedMixin);
    }

    public void registerInjector(AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector annotatedMixinElementHandlerInjector$AnnotatedElementInjector) {
        if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(this.mixin.isInterface() ? 1 : 0)) {
            this.ap.printMessage(Diagnostic.Kind.ERROR, "Injector in interface is unsupported", (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjector.getElement());
        }
        Iterator iterator = annotatedMixinElementHandlerInjector$AnnotatedElementInjector.getAnnotation().getList("method").iterator();
        while (AnnotatedMixinElementHandlerInjector.lIlIIllIll(iterator.hasNext() ? 1 : 0)) {
            String string = (String)iterator.next();
            MemberInfo memberInfo = MemberInfo.parse(string);
            if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(memberInfo.name)) {
                "".length();
                if (((0x58 ^ 0x3A ^ (0xBD ^ 0xC1)) & (112 + 81 - 75 + 47 ^ 4 + 125 - -11 + 47 ^ -" ".length())) <= ((166 + 17 - 111 + 115 ^ 137 + 0 - 36 + 67) & (140 + 124 - 118 + 11 ^ 137 + 20 - 93 + 78 ^ -" ".length()))) continue;
                return;
            }
            try {
                memberInfo.validate();
                "".length();
            }
            catch (InvalidMemberDescriptorException invalidMemberDescriptorException) {
                annotatedMixinElementHandlerInjector$AnnotatedElementInjector.printMessage(this.ap, Diagnostic.Kind.ERROR, invalidMemberDescriptorException.getMessage());
            }
            "".length();
            if ((0x37 ^ 0x6A ^ (0x28 ^ 0x70)) <= 0) {
                return;
            }
            if (AnnotatedMixinElementHandlerInjector.lIlIIlllIl(memberInfo.desc)) {
                this.validateReferencedTarget((ExecutableElement)annotatedMixinElementHandlerInjector$AnnotatedElementInjector.getElement(), annotatedMixinElementHandlerInjector$AnnotatedElementInjector.getAnnotation(), memberInfo, annotatedMixinElementHandlerInjector$AnnotatedElementInjector.toString());
            }
            if (AnnotatedMixinElementHandlerInjector.lIlIIllllI(annotatedMixinElementHandlerInjector$AnnotatedElementInjector.shouldRemap() ? 1 : 0)) {
                "".length();
                if (-" ".length() == -" ".length()) continue;
                return;
            }
            Iterator<TypeHandle> iterator2 = this.mixin.getTargets().iterator();
            while (AnnotatedMixinElementHandlerInjector.lIlIIllIll(iterator2.hasNext() ? 1 : 0)) {
                TypeHandle typeHandle = iterator2.next();
                if (AnnotatedMixinElementHandlerInjector.lIlIIllllI(this.registerInjector(annotatedMixinElementHandlerInjector$AnnotatedElementInjector, string, memberInfo, typeHandle) ? 1 : 0)) {
                    "".length();
                    if (-" ".length() <= (0xA3 ^ 0xA7)) break;
                    return;
                }
                "".length();
                if (null == null) continue;
                return;
            }
            "".length();
            if ((14 + 59 - -40 + 16 ^ 90 + 120 - 143 + 65) != 0) continue;
            return;
        }
    }

    private boolean registerInjector(AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector annotatedMixinElementHandlerInjector$AnnotatedElementInjector, String string, MemberInfo memberInfo, TypeHandle typeHandle) {
        String string2 = typeHandle.findDescriptor(memberInfo);
        if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(string2)) {
            Diagnostic.Kind kind;
            Diagnostic.Kind kind2;
            if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(this.mixin.isMultiTarget() ? 1 : 0)) {
                kind2 = Diagnostic.Kind.ERROR;
                "".length();
                if (null != null) {
                    return ((0xE3 ^ 0xBD) & ~(0xCB ^ 0x95)) != 0;
                }
            } else {
                kind2 = kind = Diagnostic.Kind.WARNING;
            }
            if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(typeHandle.isSimulated() ? 1 : 0)) {
                annotatedMixinElementHandlerInjector$AnnotatedElementInjector.printMessage(this.ap, Diagnostic.Kind.NOTE, String.valueOf(new StringBuilder().append(annotatedMixinElementHandlerInjector$AnnotatedElementInjector).append(" target '").append(string).append("' in @Pseudo mixin will not be obfuscated")));
                "".length();
                if (" ".length() == 0) {
                    return ((82 + 104 - 87 + 47 ^ 104 + 142 - 159 + 88) & (223 + 101 - 227 + 154 ^ 14 + 123 - -12 + 49 ^ -" ".length())) != 0;
                }
            } else if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(typeHandle.isImaginary() ? 1 : 0)) {
                annotatedMixinElementHandlerInjector$AnnotatedElementInjector.printMessage(this.ap, kind, String.valueOf(new StringBuilder().append(annotatedMixinElementHandlerInjector$AnnotatedElementInjector).append(" target requires method signature because enclosing type information for ").append(typeHandle).append(" is unavailable")));
                "".length();
                if (" ".length() > " ".length()) {
                    return ((0x7D ^ 0x59) & ~(0x9A ^ 0xBE)) != 0;
                }
            } else if (AnnotatedMixinElementHandlerInjector.lIlIIllllI(memberInfo.isInitialiser() ? 1 : 0)) {
                annotatedMixinElementHandlerInjector$AnnotatedElementInjector.printMessage(this.ap, kind, String.valueOf(new StringBuilder().append("Unable to determine signature for ").append(annotatedMixinElementHandlerInjector$AnnotatedElementInjector).append(" target method")));
            }
            return true;
        }
        String string3 = String.valueOf(new StringBuilder().append(annotatedMixinElementHandlerInjector$AnnotatedElementInjector).append(" target ").append(memberInfo.name));
        MappingMethod mappingMethod = typeHandle.getMappingMethod(memberInfo.name, string2);
        ObfuscationData<MappingMethod> obfuscationData = this.obf.getDataProvider().getObfMethod(mappingMethod);
        if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(obfuscationData.isEmpty() ? 1 : 0)) {
            if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(typeHandle.isSimulated() ? 1 : 0)) {
                obfuscationData = this.obf.getDataProvider().getRemappedMethod(mappingMethod);
                "".length();
                if ("  ".length() <= 0) {
                    return ((0xD2 ^ 0x85) & ~(0x34 ^ 0x63)) != 0;
                }
            } else {
                Diagnostic.Kind kind;
                if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(memberInfo.isClassInitialiser() ? 1 : 0)) {
                    return true;
                }
                if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(memberInfo.isConstructor() ? 1 : 0)) {
                    kind = Diagnostic.Kind.WARNING;
                    "".length();
                    if (-"   ".length() >= 0) {
                        return ((0x1B ^ 0x66 ^ (0xF0 ^ 0xB4)) & (0x2D ^ 0x4E ^ (0x7C ^ 0x26) ^ -" ".length())) != 0;
                    }
                } else {
                    kind = Diagnostic.Kind.ERROR;
                }
                Diagnostic.Kind kind3 = kind;
                annotatedMixinElementHandlerInjector$AnnotatedElementInjector.addMessage(kind3, String.valueOf(new StringBuilder().append("No obfuscation mapping for ").append(string3)), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjector.getElement(), annotatedMixinElementHandlerInjector$AnnotatedElementInjector.getAnnotation());
                return false;
            }
        }
        IReferenceManager iReferenceManager = this.obf.getReferenceManager();
        try {
            if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(memberInfo.owner) && !AnnotatedMixinElementHandlerInjector.lIlIIllllI(this.mixin.isMultiTarget() ? 1 : 0) || AnnotatedMixinElementHandlerInjector.lIlIIllIll(typeHandle.isSimulated() ? 1 : 0)) {
                obfuscationData = AnnotatedMixinElementHandler.stripOwnerData(obfuscationData);
            }
            iReferenceManager.addMethodMapping(this.classRef, string, obfuscationData);
        }
        catch (ReferenceManager$ReferenceConflictException referenceManager$ReferenceConflictException) {
            String string4;
            String string5;
            if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(this.mixin.isMultiTarget() ? 1 : 0)) {
                string5 = "Multi-target";
                "".length();
                if ("   ".length() <= 0) {
                    return ((0xC7 ^ 0xC3) & ~(0xA ^ 0xE)) != 0;
                }
            } else {
                string5 = string4 = "Target";
            }
            if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(annotatedMixinElementHandlerInjector$AnnotatedElementInjector.hasCoerceArgument() ? 1 : 0) && AnnotatedMixinElementHandlerInjector.lIlIIlllII(memberInfo.owner) && AnnotatedMixinElementHandlerInjector.lIlIIlllII(memberInfo.desc)) {
                MemberInfo memberInfo2 = MemberInfo.parse(referenceManager$ReferenceConflictException.getOld());
                MemberInfo memberInfo3 = MemberInfo.parse(referenceManager$ReferenceConflictException.getNew());
                if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(memberInfo2.name.equals(memberInfo3.name) ? 1 : 0)) {
                    obfuscationData = AnnotatedMixinElementHandler.stripDescriptors(obfuscationData);
                    iReferenceManager.setAllowConflicts(true);
                    iReferenceManager.addMethodMapping(this.classRef, string, obfuscationData);
                    iReferenceManager.setAllowConflicts(false);
                    annotatedMixinElementHandlerInjector$AnnotatedElementInjector.printMessage(this.ap, Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Coerced ").append(string4).append(" reference has conflicting descriptors for ").append(string3).append(": Storing bare references ").append(obfuscationData.values()).append(" in refMap")));
                    return true;
                }
            }
            annotatedMixinElementHandlerInjector$AnnotatedElementInjector.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append(string4).append(" reference conflict for ").append(string3).append(": ").append(string).append(" -> ").append(referenceManager$ReferenceConflictException.getNew()).append(" previously defined as ").append(referenceManager$ReferenceConflictException.getOld())));
        }
        "".length();
        if (null != null) {
            return ((0xAB ^ 0x90) & ~(0x2F ^ 0x14)) != 0;
        }
        return true;
    }

    public void registerInjectionPoint(AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint, String string) {
        if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(this.mixin.isInterface() ? 1 : 0)) {
            this.ap.printMessage(Diagnostic.Kind.ERROR, "Injector in interface is unsupported", (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement());
        }
        if (AnnotatedMixinElementHandlerInjector.lIlIIllllI(annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.shouldRemap() ? 1 : 0)) {
            return;
        }
        String string2 = InjectionPointData.parseType((String)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getAt().getValue("value"));
        String string3 = (String)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getAt().getValue("target");
        if (AnnotatedMixinElementHandlerInjector.lIlIIllIll("NEW".equals(string2) ? 1 : 0)) {
            this.remapNewTarget(String.format(string, String.valueOf(new StringBuilder().append(string2).append(".<target>"))), string3, annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint);
            this.remapNewTarget(String.format(string, String.valueOf(new StringBuilder().append(string2).append(".args[class]"))), annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getAtArg("class"), annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint);
            "".length();
            if ((0xBB ^ 0x9D ^ (0x32 ^ 0x10)) != (0x59 ^ 0x41 ^ (0x9C ^ 0x80))) {
                return;
            }
        } else {
            this.remapReference(String.format(string, String.valueOf(new StringBuilder().append(string2).append(".<target>"))), string3, annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint);
        }
    }

    protected final void remapNewTarget(String string, String string2, AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint) {
        if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(string2)) {
            return;
        }
        MemberInfo memberInfo = MemberInfo.parse(string2);
        String string3 = memberInfo.toCtorType();
        if (AnnotatedMixinElementHandlerInjector.lIlIIlllIl(string3)) {
            String string4;
            String string5 = memberInfo.toCtorDesc();
            if (AnnotatedMixinElementHandlerInjector.lIlIIlllIl(string5)) {
                string4 = string5;
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                string4 = "()V";
            }
            MappingMethod mappingMethod = new MappingMethod(string3, ".", string4);
            ObfuscationData<MappingMethod> obfuscationData = this.obf.getDataProvider().getRemappedMethod(mappingMethod);
            if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(obfuscationData.isEmpty() ? 1 : 0)) {
                this.ap.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Cannot find class mapping for ").append(string).append(" '").append(string3).append("'")), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement(), annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getAnnotation().asMirror());
                return;
            }
            ObfuscationData<String> obfuscationData2 = new ObfuscationData<String>();
            Iterator<ObfuscationType> iterator = obfuscationData.iterator();
            while (AnnotatedMixinElementHandlerInjector.lIlIIllIll(iterator.hasNext() ? 1 : 0)) {
                ObfuscationType obfuscationType = iterator.next();
                MappingMethod mappingMethod2 = obfuscationData.get(obfuscationType);
                if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(string5)) {
                    obfuscationData2.put(obfuscationType, mappingMethod2.getOwner());
                    "".length();
                    if (" ".length() == "  ".length()) {
                        return;
                    }
                } else {
                    obfuscationData2.put(obfuscationType, mappingMethod2.getDesc().replace(")V", String.valueOf(new StringBuilder().append(")L").append(mappingMethod2.getOwner()).append(";"))));
                }
                "".length();
                if (null == null) continue;
                return;
            }
            this.obf.getReferenceManager().addClassMapping(this.classRef, string2, obfuscationData2);
        }
        annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.notifyRemapped();
    }

    protected final void remapReference(String string, String string2, AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint) {
        block21: {
            AnnotationHandle annotationHandle;
            if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(string2)) {
                return;
            }
            if (AnnotatedMixinElementHandlerInjector.lIlIlIlIII((Object)this.ap.getCompilerEnvironment(), (Object)IMixinAnnotationProcessor$CompilerEnvironment.JDT)) {
                annotationHandle = annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getAt();
                "".length();
                if (((0x63 ^ 0x26) & ~(0xD1 ^ 0x94)) != 0) {
                    return;
                }
            } else {
                annotationHandle = annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getAnnotation();
            }
            AnnotationMirror annotationMirror = annotationHandle.asMirror();
            MemberInfo memberInfo = MemberInfo.parse(string2);
            if (AnnotatedMixinElementHandlerInjector.lIlIIllllI(memberInfo.isFullyQualified() ? 1 : 0)) {
                String string3;
                if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(memberInfo.owner)) {
                    if (AnnotatedMixinElementHandlerInjector.lIlIIlllII(memberInfo.desc)) {
                        string3 = "owner and signature";
                        "".length();
                        if (null != null) {
                            return;
                        }
                    } else {
                        string3 = "owner";
                        "".length();
                        if ("   ".length() == (0x52 ^ 1 ^ (0x1E ^ 0x49))) {
                            return;
                        }
                    }
                } else {
                    string3 = "signature";
                }
                String string4 = string3;
                this.ap.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append(string).append(" is not fully qualified, missing ").append(string4)), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement(), annotationMirror);
                return;
            }
            try {
                memberInfo.validate();
                "".length();
            }
            catch (InvalidMemberDescriptorException invalidMemberDescriptorException) {
                this.ap.printMessage(Diagnostic.Kind.ERROR, invalidMemberDescriptorException.getMessage(), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement(), annotationMirror);
            }
            "".length();
            if (" ".length() > "   ".length()) {
                return;
            }
            try {
                if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(memberInfo.isField() ? 1 : 0)) {
                    ObfuscationData<MappingField> obfuscationData = this.obf.getDataProvider().getObfFieldRecursive(memberInfo);
                    if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(obfuscationData.isEmpty() ? 1 : 0)) {
                        this.ap.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Cannot find field mapping for ").append(string).append(" '").append(string2).append("'")), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement(), annotationMirror);
                        return;
                    }
                    this.obf.getReferenceManager().addFieldMapping(this.classRef, string2, memberInfo, obfuscationData);
                    "".length();
                    if ("   ".length() <= 0) {
                        return;
                    }
                    break block21;
                }
                ObfuscationData<MappingMethod> obfuscationData = this.obf.getDataProvider().getObfMethodRecursive(memberInfo);
                if (AnnotatedMixinElementHandlerInjector.lIlIIllIll(obfuscationData.isEmpty() ? 1 : 0) && (!AnnotatedMixinElementHandlerInjector.lIlIIlllIl(memberInfo.owner) || AnnotatedMixinElementHandlerInjector.lIlIIllllI(memberInfo.owner.startsWith("java/lang/") ? 1 : 0))) {
                    this.ap.printMessage(Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Cannot find method mapping for ").append(string).append(" '").append(string2).append("'")), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement(), annotationMirror);
                    return;
                }
                this.obf.getReferenceManager().addMethodMapping(this.classRef, string2, memberInfo, obfuscationData);
            }
            catch (ReferenceManager$ReferenceConflictException referenceManager$ReferenceConflictException) {
                this.ap.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Unexpected reference conflict for ").append(string).append(": ").append(string2).append(" -> ").append(referenceManager$ReferenceConflictException.getNew()).append(" previously defined as ").append(referenceManager$ReferenceConflictException.getOld())), (Element)annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.getElement(), annotationMirror);
                return;
            }
        }
        "".length();
        if (null != null) {
            return;
        }
        annotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint.notifyRemapped();
    }

    private static boolean lIlIIlllIl(Object object) {
        return object != null;
    }

    private static boolean lIlIlIlIII(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIlIIlllII(Object object) {
        return object == null;
    }

    private static boolean lIlIIllIll(int n) {
        return n != 0;
    }

    private static boolean lIlIIllllI(int n) {
        return n == 0;
    }
}

