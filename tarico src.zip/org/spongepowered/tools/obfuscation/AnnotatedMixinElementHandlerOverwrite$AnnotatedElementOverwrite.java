/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import javax.lang.model.element.ExecutableElement;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AnnotatedElement;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;

class AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite
extends AnnotatedMixinElementHandler$AnnotatedElement<ExecutableElement> {
    private final boolean shouldRemap;

    public AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite(ExecutableElement executableElement, AnnotationHandle annotationHandle, boolean bl) {
        super(executableElement, annotationHandle);
        this.shouldRemap = bl;
    }

    public boolean shouldRemap() {
        return this.shouldRemap;
    }
}

