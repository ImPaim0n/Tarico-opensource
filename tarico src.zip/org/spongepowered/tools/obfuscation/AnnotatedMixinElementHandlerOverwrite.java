/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.lang.reflect.Method;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.tools.Diagnostic;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.AnnotatedMixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AliasedElementName;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite;
import org.spongepowered.tools.obfuscation.Mappings$MappingConflictException;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

class AnnotatedMixinElementHandlerOverwrite
extends AnnotatedMixinElementHandler {
    AnnotatedMixinElementHandlerOverwrite(IMixinAnnotationProcessor iMixinAnnotationProcessor, AnnotatedMixin annotatedMixin) {
        super(iMixinAnnotationProcessor, annotatedMixin);
    }

    public void registerMerge(ExecutableElement executableElement) {
        this.validateTargetMethod(executableElement, null, new AnnotatedMixinElementHandler$AliasedElementName(executableElement, AnnotationHandle.MISSING), "overwrite", true, true);
    }

    public void registerOverwrite(AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite) {
        Object object;
        Object object2;
        AnnotatedMixinElementHandler$AliasedElementName annotatedMixinElementHandler$AliasedElementName = new AnnotatedMixinElementHandler$AliasedElementName((Element)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement(), annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getAnnotation());
        this.validateTargetMethod((ExecutableElement)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement(), annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getAnnotation(), annotatedMixinElementHandler$AliasedElementName, "@Overwrite", true, false);
        this.checkConstraints((ExecutableElement)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement(), annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getAnnotation());
        if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIlIll(annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.shouldRemap() ? 1 : 0)) {
            object2 = this.mixin.getTargets().iterator();
            while (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIlIll(object2.hasNext() ? 1 : 0)) {
                object = object2.next();
                if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIllII(this.registerOverwriteForTarget(annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite, (TypeHandle)object) ? 1 : 0)) {
                    return;
                }
                "".length();
                if (((0x68 ^ 0x5B) & ~(0x89 ^ 0xBA)) == 0) continue;
                return;
            }
        }
        if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIllII("true".equalsIgnoreCase(this.ap.getOption("disableOverwriteChecker")) ? 1 : 0)) {
            Object object3;
            if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIlIll("error".equalsIgnoreCase(this.ap.getOption("overwriteErrorLevel")) ? 1 : 0)) {
                object3 = Diagnostic.Kind.ERROR;
                "".length();
                if (-"   ".length() >= 0) {
                    return;
                }
            } else {
                object3 = object2 = Diagnostic.Kind.WARNING;
            }
            if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIllIl(object = this.ap.getJavadocProvider().getJavadoc((Element)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement()))) {
                this.ap.printMessage((Diagnostic.Kind)((Object)object2), "@Overwrite is missing javadoc comment", (Element)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement());
                return;
            }
            if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIllII(((String)object).toLowerCase().contains("@author") ? 1 : 0)) {
                this.ap.printMessage((Diagnostic.Kind)((Object)object2), "@Overwrite is missing an @author tag", (Element)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement());
            }
            if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIllII(((String)object).toLowerCase().contains("@reason") ? 1 : 0)) {
                this.ap.printMessage((Diagnostic.Kind)((Object)object2), "@Overwrite is missing an @reason tag", (Element)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement());
            }
        }
    }

    private boolean registerOverwriteForTarget(AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite, TypeHandle typeHandle) {
        ObfuscationData<MappingMethod> obfuscationData;
        block7: {
            MappingMethod mappingMethod = typeHandle.getMappingMethod(annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getSimpleName(), annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getDesc());
            obfuscationData = this.obf.getDataProvider().getObfMethod(mappingMethod);
            if (!AnnotatedMixinElementHandlerOverwrite.lIIlIIIIlIll(obfuscationData.isEmpty() ? 1 : 0)) break block7;
            Diagnostic.Kind kind = Diagnostic.Kind.ERROR;
            try {
                Method method = ((ExecutableElement)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement()).getClass().getMethod("isStatic", new Class[0]);
                if (AnnotatedMixinElementHandlerOverwrite.lIIlIIIIlIll(((Boolean)method.invoke(annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement(), new Object[0])).booleanValue() ? 1 : 0)) {
                    kind = Diagnostic.Kind.WARNING;
                }
                "".length();
            }
            catch (Exception exception) {
                // empty catch block
            }
            if ("  ".length() <= " ".length()) {
                return ((0x52 ^ 4) & ~(0x2B ^ 0x7D)) != 0;
            }
            this.ap.printMessage(kind, "No obfuscation mapping for @Overwrite method", (Element)annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getElement());
            return false;
        }
        try {
            this.addMethodMappings(annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getSimpleName(), annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.getDesc(), obfuscationData);
        }
        catch (Mappings$MappingConflictException mappings$MappingConflictException) {
            annotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Mapping conflict for @Overwrite method: ").append(mappings$MappingConflictException.getNew().getSimpleName()).append(" for target ").append(typeHandle).append(" conflicts with existing mapping ").append(mappings$MappingConflictException.getOld().getSimpleName())));
            return false;
        }
        "".length();
        if (-(0x34 ^ 0x30) > 0) {
            return ((0xFB ^ 0xC1) & ~(0x26 ^ 0x1C)) != 0;
        }
        return true;
    }

    private static boolean lIIlIIIIllIl(Object object) {
        return object == null;
    }

    private static boolean lIIlIIIIlIll(int n) {
        return n != 0;
    }

    private static boolean lIIlIIIIllII(int n) {
        return n == 0;
    }
}

