/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import javax.lang.model.element.Element;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$AnnotatedElement;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler$ShadowElementName;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.interfaces.IObfuscationDataProvider;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

abstract class AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<E extends Element, M extends IMapping<M>>
extends AnnotatedMixinElementHandler$AnnotatedElement<E> {
    private final boolean shouldRemap;
    private final AnnotatedMixinElementHandler$ShadowElementName name;
    private final IMapping$Type type;

    protected AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow(E e, AnnotationHandle annotationHandle, boolean bl, IMapping$Type iMapping$Type) {
        super(e, annotationHandle);
        this.shouldRemap = bl;
        this.name = new AnnotatedMixinElementHandler$ShadowElementName((Element)e, annotationHandle);
        this.type = iMapping$Type;
    }

    public boolean shouldRemap() {
        return this.shouldRemap;
    }

    public AnnotatedMixinElementHandler$ShadowElementName getName() {
        return this.name;
    }

    public IMapping$Type getElementType() {
        return this.type;
    }

    public String toString() {
        return this.getElementType().name().toLowerCase();
    }

    public AnnotatedMixinElementHandler$ShadowElementName setObfuscatedName(IMapping<?> iMapping) {
        return this.setObfuscatedName(iMapping.getSimpleName());
    }

    public AnnotatedMixinElementHandler$ShadowElementName setObfuscatedName(String string) {
        return this.getName().setObfuscatedName(string);
    }

    public ObfuscationData<M> getObfuscationData(IObfuscationDataProvider iObfuscationDataProvider, TypeHandle typeHandle) {
        return iObfuscationDataProvider.getObfEntry(this.getMapping(typeHandle, this.getName().toString(), this.getDesc()));
    }

    public abstract M getMapping(TypeHandle var1, String var2, String var3);

    public abstract void addMapping(ObfuscationType var1, IMapping<?> var2);
}

