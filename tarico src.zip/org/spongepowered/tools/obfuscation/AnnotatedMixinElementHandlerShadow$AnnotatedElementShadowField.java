/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import javax.lang.model.element.VariableElement;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

class AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField
extends AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<VariableElement, MappingField> {
    final /* synthetic */ AnnotatedMixinElementHandlerShadow this$0;

    public AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField(AnnotatedMixinElementHandlerShadow annotatedMixinElementHandlerShadow, VariableElement variableElement, AnnotationHandle annotationHandle, boolean bl) {
        this.this$0 = annotatedMixinElementHandlerShadow;
        super(variableElement, annotationHandle, bl, IMapping$Type.FIELD);
    }

    @Override
    public MappingField getMapping(TypeHandle typeHandle, String string, String string2) {
        return new MappingField(typeHandle.getName(), string, string2);
    }

    @Override
    public void addMapping(ObfuscationType obfuscationType, IMapping<?> iMapping) {
        this.this$0.addFieldMapping(obfuscationType, this.setObfuscatedName(iMapping), this.getDesc(), iMapping.getDesc());
    }
}

