/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import javax.lang.model.element.ExecutableElement;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

class AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod
extends AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<ExecutableElement, MappingMethod> {
    final /* synthetic */ AnnotatedMixinElementHandlerShadow this$0;

    public AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod(AnnotatedMixinElementHandlerShadow annotatedMixinElementHandlerShadow, ExecutableElement executableElement, AnnotationHandle annotationHandle, boolean bl) {
        this.this$0 = annotatedMixinElementHandlerShadow;
        super(executableElement, annotationHandle, bl, IMapping$Type.METHOD);
    }

    @Override
    public MappingMethod getMapping(TypeHandle typeHandle, String string, String string2) {
        return typeHandle.getMappingMethod(string, string2);
    }

    @Override
    public void addMapping(ObfuscationType obfuscationType, IMapping<?> iMapping) {
        this.this$0.addMethodMapping(obfuscationType, this.setObfuscatedName(iMapping), this.getDesc(), iMapping.getDesc());
    }
}

