/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import javax.lang.model.element.Element;
import javax.tools.Diagnostic;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.tools.obfuscation.AnnotatedMixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow;
import org.spongepowered.tools.obfuscation.Mappings$MappingConflictException;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

class AnnotatedMixinElementHandlerShadow
extends AnnotatedMixinElementHandler {
    AnnotatedMixinElementHandlerShadow(IMixinAnnotationProcessor iMixinAnnotationProcessor, AnnotatedMixin annotatedMixin) {
        super(iMixinAnnotationProcessor, annotatedMixin);
    }

    public void registerShadow(AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<?, ?> annotatedMixinElementHandlerShadow$AnnotatedElementShadow) {
        this.validateTarget((Element)annotatedMixinElementHandlerShadow$AnnotatedElementShadow.getElement(), annotatedMixinElementHandlerShadow$AnnotatedElementShadow.getAnnotation(), annotatedMixinElementHandlerShadow$AnnotatedElementShadow.getName(), "@Shadow");
        if (AnnotatedMixinElementHandlerShadow.llIlIlllIIl(annotatedMixinElementHandlerShadow$AnnotatedElementShadow.shouldRemap() ? 1 : 0)) {
            return;
        }
        Iterator<TypeHandle> iterator = this.mixin.getTargets().iterator();
        while (AnnotatedMixinElementHandlerShadow.llIlIlllIlI(iterator.hasNext() ? 1 : 0)) {
            TypeHandle typeHandle = iterator.next();
            this.registerShadowForTarget(annotatedMixinElementHandlerShadow$AnnotatedElementShadow, typeHandle);
            "".length();
            if ((" ".length() & (" ".length() ^ -" ".length())) == 0) continue;
            return;
        }
    }

    private void registerShadowForTarget(AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<?, ?> annotatedMixinElementHandlerShadow$AnnotatedElementShadow, TypeHandle typeHandle) {
        ObfuscationData<?> obfuscationData = annotatedMixinElementHandlerShadow$AnnotatedElementShadow.getObfuscationData(this.obf.getDataProvider(), typeHandle);
        if (AnnotatedMixinElementHandlerShadow.llIlIlllIlI(obfuscationData.isEmpty() ? 1 : 0)) {
            String string;
            String string2;
            if (AnnotatedMixinElementHandlerShadow.llIlIlllIlI(this.mixin.isMultiTarget() ? 1 : 0)) {
                string2 = String.valueOf(new StringBuilder().append(" in target ").append(typeHandle));
                "".length();
                if ((0x64 ^ 0x60) != (0x6C ^ 0x68)) {
                    return;
                }
            } else {
                string2 = string = "";
            }
            if (AnnotatedMixinElementHandlerShadow.llIlIlllIlI(typeHandle.isSimulated() ? 1 : 0)) {
                annotatedMixinElementHandlerShadow$AnnotatedElementShadow.printMessage(this.ap, Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Unable to locate obfuscation mapping").append(string).append(" for @Shadow ").append(annotatedMixinElementHandlerShadow$AnnotatedElementShadow)));
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                annotatedMixinElementHandlerShadow$AnnotatedElementShadow.printMessage(this.ap, Diagnostic.Kind.WARNING, String.valueOf(new StringBuilder().append("Unable to locate obfuscation mapping").append(string).append(" for @Shadow ").append(annotatedMixinElementHandlerShadow$AnnotatedElementShadow)));
            }
            return;
        }
        Iterator<ObfuscationType> iterator = obfuscationData.iterator();
        while (AnnotatedMixinElementHandlerShadow.llIlIlllIlI(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            try {
                annotatedMixinElementHandlerShadow$AnnotatedElementShadow.addMapping(obfuscationType, (IMapping)obfuscationData.get(obfuscationType));
            }
            catch (Mappings$MappingConflictException mappings$MappingConflictException) {
                annotatedMixinElementHandlerShadow$AnnotatedElementShadow.printMessage(this.ap, Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Mapping conflict for @Shadow ").append(annotatedMixinElementHandlerShadow$AnnotatedElementShadow).append(": ").append(mappings$MappingConflictException.getNew().getSimpleName()).append(" for target ").append(typeHandle).append(" conflicts with existing mapping ").append(mappings$MappingConflictException.getOld().getSimpleName())));
            }
            "".length();
            if (-"   ".length() >= 0) {
                return;
            }
            "".length();
            if (-"   ".length() < 0) continue;
            return;
        }
    }

    private static boolean llIlIlllIlI(int n) {
        return n != 0;
    }

    private static boolean llIlIlllIIl(int n) {
        return n == 0;
    }
}

