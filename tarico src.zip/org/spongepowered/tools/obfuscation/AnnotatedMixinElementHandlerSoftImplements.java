/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import java.util.List;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.type.DeclaredType;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.Interface$Remap;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.AnnotatedMixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixinElementHandler;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.MethodHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;

public class AnnotatedMixinElementHandlerSoftImplements
extends AnnotatedMixinElementHandler {
    AnnotatedMixinElementHandlerSoftImplements(IMixinAnnotationProcessor iMixinAnnotationProcessor, AnnotatedMixin annotatedMixin) {
        super(iMixinAnnotationProcessor, annotatedMixin);
    }

    public void process(AnnotationHandle annotationHandle) {
        if (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIlII(this.mixin.remap() ? 1 : 0)) {
            return;
        }
        List<AnnotationHandle> list = annotationHandle.getAnnotationList("value");
        if (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIlIl(list.size(), 1)) {
            this.ap.printMessage(Diagnostic.Kind.WARNING, "Empty @Implements annotation", this.mixin.getMixin(), annotationHandle.asMirror());
            return;
        }
        Iterator<AnnotationHandle> iterator = list.iterator();
        while (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIllI(iterator.hasNext() ? 1 : 0)) {
            AnnotationHandle annotationHandle2 = iterator.next();
            Interface$Remap interface$Remap = annotationHandle2.getValue("remap", Interface$Remap.ALL);
            if (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIlll((Object)interface$Remap, (Object)Interface$Remap.NONE)) {
                "".length();
                if (((0xA9 ^ 0xB6) & ~(0xA9 ^ 0xB6)) <= 0) continue;
                return;
            }
            try {
                TypeHandle typeHandle = new TypeHandle((DeclaredType)annotationHandle2.getValue("iface"));
                String string = (String)annotationHandle2.getValue("prefix");
                this.processSoftImplements(interface$Remap, typeHandle, string);
                "".length();
            }
            catch (Exception exception) {
                this.ap.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Unexpected error: ").append(exception.getClass().getName()).append(": ").append(exception.getMessage())), this.mixin.getMixin(), annotationHandle2.asMirror());
            }
            if (" ".length() <= 0) {
                return;
            }
            "".length();
            if (-" ".length() >= -" ".length()) continue;
            return;
        }
    }

    private void processSoftImplements(Interface$Remap interface$Remap, TypeHandle typeHandle, String string) {
        Object object;
        Iterator<Object> iterator = typeHandle.getEnclosedElements(ElementKind.METHOD).iterator();
        while (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIllI(iterator.hasNext() ? 1 : 0)) {
            object = (ExecutableElement)iterator.next();
            this.processMethod(interface$Remap, typeHandle, string, (ExecutableElement)object);
            "".length();
            if (((0x50 ^ 0x7C) & ~(0x40 ^ 0x6C)) > -" ".length()) continue;
            return;
        }
        iterator = typeHandle.getInterfaces().iterator();
        while (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIllI(iterator.hasNext() ? 1 : 0)) {
            object = (TypeHandle)iterator.next();
            this.processSoftImplements(interface$Remap, (TypeHandle)object, string);
            "".length();
            if (" ".length() != (3 + 88 - 6 + 60 ^ 26 + 147 - 131 + 107)) continue;
            return;
        }
    }

    private void processMethod(Interface$Remap interface$Remap, TypeHandle typeHandle, String string, ExecutableElement executableElement) {
        MethodHandle methodHandle;
        String string2 = executableElement.getSimpleName().toString();
        String string3 = TypeUtils.getJavaSignature(executableElement);
        String string4 = TypeUtils.getDescriptor(executableElement);
        if (AnnotatedMixinElementHandlerSoftImplements.llIlIIllIIl((Object)interface$Remap, (Object)Interface$Remap.ONLY_PREFIXED) && AnnotatedMixinElementHandlerSoftImplements.llIlIIllIlI(methodHandle = this.mixin.getHandle().findMethod(string2, string3))) {
            this.addInterfaceMethodMapping(interface$Remap, typeHandle, null, methodHandle, string2, string4);
        }
        if (AnnotatedMixinElementHandlerSoftImplements.llIlIIllIlI(string) && AnnotatedMixinElementHandlerSoftImplements.llIlIIllIlI(methodHandle = this.mixin.getHandle().findMethod(String.valueOf(new StringBuilder().append(string).append(string2)), string3))) {
            this.addInterfaceMethodMapping(interface$Remap, typeHandle, string, methodHandle, string2, string4);
        }
    }

    private void addInterfaceMethodMapping(Interface$Remap interface$Remap, TypeHandle typeHandle, String string, MethodHandle methodHandle, String string2, String string3) {
        MappingMethod mappingMethod = new MappingMethod(typeHandle.getName(), string2, string3);
        ObfuscationData<MappingMethod> obfuscationData = this.obf.getDataProvider().getObfMethod(mappingMethod);
        if (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIllI(obfuscationData.isEmpty() ? 1 : 0)) {
            if (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIllI(interface$Remap.forceRemap() ? 1 : 0)) {
                this.ap.printMessage(Diagnostic.Kind.ERROR, "No obfuscation mapping for soft-implementing method", methodHandle.getElement());
            }
            return;
        }
        this.addMethodMappings(methodHandle.getName(), string3, this.applyPrefix(obfuscationData, string));
    }

    private ObfuscationData<MappingMethod> applyPrefix(ObfuscationData<MappingMethod> obfuscationData, String string) {
        if (AnnotatedMixinElementHandlerSoftImplements.llIlIIllIll(string)) {
            return obfuscationData;
        }
        ObfuscationData<MappingMethod> obfuscationData2 = new ObfuscationData<MappingMethod>();
        Iterator<ObfuscationType> iterator = obfuscationData.iterator();
        while (AnnotatedMixinElementHandlerSoftImplements.llIlIIlIllI(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            MappingMethod mappingMethod = obfuscationData.get(obfuscationType);
            obfuscationData2.put(obfuscationType, mappingMethod.addPrefix(string));
            "".length();
            if (-(0x69 ^ 0x6D) < 0) continue;
            return null;
        }
        return obfuscationData2;
    }

    private static boolean llIlIIlIlIl(int n, int n2) {
        return n < n2;
    }

    private static boolean llIlIIllIIl(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlIIlIlll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIlIIllIlI(Object object) {
        return object != null;
    }

    private static boolean llIlIIllIll(Object object) {
        return object == null;
    }

    private static boolean llIlIIlIllI(int n) {
        return n != 0;
    }

    private static boolean llIlIIlIlII(int n) {
        return n == 0;
    }
}

