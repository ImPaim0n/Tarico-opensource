/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.HashMap;
import java.util.Map;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.Mappings$MappingConflictException;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet;

class Mappings$UniqueMappings
implements IMappingConsumer {
    private final IMappingConsumer mappings;
    private final Map<ObfuscationType, Map<MappingField, MappingField>> fields = new HashMap<ObfuscationType, Map<MappingField, MappingField>>();
    private final Map<ObfuscationType, Map<MappingMethod, MappingMethod>> methods = new HashMap<ObfuscationType, Map<MappingMethod, MappingMethod>>();

    public Mappings$UniqueMappings(IMappingConsumer iMappingConsumer) {
        this.mappings = iMappingConsumer;
    }

    @Override
    public void clear() {
        this.clearMaps();
        this.mappings.clear();
    }

    protected void clearMaps() {
        this.fields.clear();
        this.methods.clear();
    }

    @Override
    public void addFieldMapping(ObfuscationType obfuscationType, MappingField mappingField, MappingField mappingField2) {
        if (Mappings$UniqueMappings.lIlIIIllIII(this.checkForExistingMapping(obfuscationType, mappingField, mappingField2, this.fields) ? 1 : 0)) {
            this.mappings.addFieldMapping(obfuscationType, mappingField, mappingField2);
        }
    }

    @Override
    public void addMethodMapping(ObfuscationType obfuscationType, MappingMethod mappingMethod, MappingMethod mappingMethod2) {
        if (Mappings$UniqueMappings.lIlIIIllIII(this.checkForExistingMapping(obfuscationType, mappingMethod, mappingMethod2, this.methods) ? 1 : 0)) {
            this.mappings.addMethodMapping(obfuscationType, mappingMethod, mappingMethod2);
        }
    }

    private <TMapping extends IMapping<TMapping>> boolean checkForExistingMapping(ObfuscationType obfuscationType, TMapping TMapping, TMapping TMapping2, Map<ObfuscationType, Map<TMapping, TMapping>> map) {
        IMapping iMapping;
        Map<TMapping, TMapping> map2 = map.get(obfuscationType);
        if (Mappings$UniqueMappings.lIlIIIllIIl(map2)) {
            map2 = new HashMap<TMapping, TMapping>();
            map.put(obfuscationType, map2);
            "".length();
        }
        if (Mappings$UniqueMappings.lIlIIIllIlI(iMapping = (IMapping)map2.get(TMapping))) {
            if (Mappings$UniqueMappings.lIlIIIllIll(iMapping.equals(TMapping2) ? 1 : 0)) {
                return true;
            }
            throw new Mappings$MappingConflictException(iMapping, TMapping2);
        }
        map2.put(TMapping, TMapping2);
        "".length();
        return false;
    }

    @Override
    public IMappingConsumer$MappingSet<MappingField> getFieldMappings(ObfuscationType obfuscationType) {
        return this.mappings.getFieldMappings(obfuscationType);
    }

    @Override
    public IMappingConsumer$MappingSet<MappingMethod> getMethodMappings(ObfuscationType obfuscationType) {
        return this.mappings.getMethodMappings(obfuscationType);
    }

    private static boolean lIlIIIllIlI(Object object) {
        return object != null;
    }

    private static boolean lIlIIIllIIl(Object object) {
        return object == null;
    }

    private static boolean lIlIIIllIll(int n) {
        return n != 0;
    }

    private static boolean lIlIIIllIII(int n) {
        return n == 0;
    }
}

