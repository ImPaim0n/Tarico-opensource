/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.Mappings$UniqueMappings;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet$Pair;

class Mappings
implements IMappingConsumer {
    private final Map<ObfuscationType, IMappingConsumer$MappingSet<MappingField>> fieldMappings = new HashMap<ObfuscationType, IMappingConsumer$MappingSet<MappingField>>();
    private final Map<ObfuscationType, IMappingConsumer$MappingSet<MappingMethod>> methodMappings = new HashMap<ObfuscationType, IMappingConsumer$MappingSet<MappingMethod>>();
    private Mappings$UniqueMappings unique;

    public Mappings() {
        this.init();
    }

    private void init() {
        Iterator<ObfuscationType> iterator = ObfuscationType.types().iterator();
        while (Mappings.lllllIIIlI(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            this.fieldMappings.put(obfuscationType, new IMappingConsumer$MappingSet());
            "".length();
            this.methodMappings.put(obfuscationType, new IMappingConsumer$MappingSet());
            "".length();
            "".length();
            if ("  ".length() > -" ".length()) continue;
            return;
        }
    }

    public IMappingConsumer asUnique() {
        if (Mappings.lllllIIIll(this.unique)) {
            this.unique = new Mappings$UniqueMappings(this);
        }
        return this.unique;
    }

    @Override
    public IMappingConsumer$MappingSet<MappingField> getFieldMappings(ObfuscationType obfuscationType) {
        IMappingConsumer$MappingSet<MappingField> iMappingConsumer$MappingSet;
        IMappingConsumer$MappingSet<MappingField> iMappingConsumer$MappingSet2 = this.fieldMappings.get(obfuscationType);
        if (Mappings.lllllIIlII(iMappingConsumer$MappingSet2)) {
            iMappingConsumer$MappingSet = iMappingConsumer$MappingSet2;
            "".length();
            if ("  ".length() < -" ".length()) {
                return null;
            }
        } else {
            iMappingConsumer$MappingSet = new IMappingConsumer$MappingSet<MappingField>();
        }
        return iMappingConsumer$MappingSet;
    }

    @Override
    public IMappingConsumer$MappingSet<MappingMethod> getMethodMappings(ObfuscationType obfuscationType) {
        IMappingConsumer$MappingSet<MappingMethod> iMappingConsumer$MappingSet;
        IMappingConsumer$MappingSet<MappingMethod> iMappingConsumer$MappingSet2 = this.methodMappings.get(obfuscationType);
        if (Mappings.lllllIIlII(iMappingConsumer$MappingSet2)) {
            iMappingConsumer$MappingSet = iMappingConsumer$MappingSet2;
            "".length();
            if (-"  ".length() >= 0) {
                return null;
            }
        } else {
            iMappingConsumer$MappingSet = new IMappingConsumer$MappingSet<MappingMethod>();
        }
        return iMappingConsumer$MappingSet;
    }

    @Override
    public void clear() {
        this.fieldMappings.clear();
        this.methodMappings.clear();
        if (Mappings.lllllIIlII(this.unique)) {
            this.unique.clearMaps();
        }
        this.init();
    }

    @Override
    public void addFieldMapping(ObfuscationType obfuscationType, MappingField mappingField, MappingField mappingField2) {
        IMappingConsumer$MappingSet<MappingField> iMappingConsumer$MappingSet = this.fieldMappings.get(obfuscationType);
        if (Mappings.lllllIIIll(iMappingConsumer$MappingSet)) {
            iMappingConsumer$MappingSet = new IMappingConsumer$MappingSet();
            this.fieldMappings.put(obfuscationType, iMappingConsumer$MappingSet);
            "".length();
        }
        iMappingConsumer$MappingSet.add(new IMappingConsumer$MappingSet$Pair<MappingField>(mappingField, mappingField2));
        "".length();
    }

    @Override
    public void addMethodMapping(ObfuscationType obfuscationType, MappingMethod mappingMethod, MappingMethod mappingMethod2) {
        IMappingConsumer$MappingSet<MappingMethod> iMappingConsumer$MappingSet = this.methodMappings.get(obfuscationType);
        if (Mappings.lllllIIIll(iMappingConsumer$MappingSet)) {
            iMappingConsumer$MappingSet = new IMappingConsumer$MappingSet();
            this.methodMappings.put(obfuscationType, iMappingConsumer$MappingSet);
            "".length();
        }
        iMappingConsumer$MappingSet.add(new IMappingConsumer$MappingSet$Pair<MappingMethod>(mappingMethod, mappingMethod2));
        "".length();
    }

    private static boolean lllllIIlII(Object object) {
        return object != null;
    }

    private static boolean lllllIIIll(Object object) {
        return object == null;
    }

    private static boolean lllllIIIlI(int n) {
        return n != 0;
    }
}

