/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import java.util.Set;
import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.RoundEnvironment;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.TypeElement;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.tools.obfuscation.AnnotatedMixins;
import org.spongepowered.tools.obfuscation.SupportedOptions;

public abstract class MixinObfuscationProcessor
extends AbstractProcessor {
    protected AnnotatedMixins mixins;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnvironment) {
        super.init(processingEnvironment);
        this.mixins = AnnotatedMixins.getMixinsForEnvironment(processingEnvironment);
    }

    protected void processMixins(RoundEnvironment roundEnvironment) {
        this.mixins.onPassStarted();
        Iterator<? extends Element> iterator = roundEnvironment.getElementsAnnotatedWith(Mixin.class).iterator();
        while (MixinObfuscationProcessor.llIlllIIIl(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            if (!MixinObfuscationProcessor.llIlllIIlI((Object)element.getKind(), (Object)ElementKind.CLASS) || MixinObfuscationProcessor.llIlllIIll((Object)element.getKind(), (Object)ElementKind.INTERFACE)) {
                this.mixins.registerMixin((TypeElement)element);
                "".length();
                if (((0x7D ^ 0x79) & ~(0x14 ^ 0x10)) != 0) {
                    return;
                }
            } else {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, "Found an @Mixin annotation on an element which is not a class or interface", element);
            }
            "".length();
            if (((0xEC ^ 0xBD ^ (0xDF ^ 0x9F)) & (0x4D ^ 0x5E ^ "  ".length() ^ -" ".length())) < "   ".length()) continue;
            return;
        }
    }

    protected void postProcess(RoundEnvironment roundEnvironment) {
        this.mixins.onPassCompleted(roundEnvironment);
    }

    @Override
    public SourceVersion getSupportedSourceVersion() {
        try {
            return SourceVersion.valueOf("RELEASE_8");
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return super.getSupportedSourceVersion();
        }
    }

    @Override
    public Set<String> getSupportedOptions() {
        return SupportedOptions.getAllOptions();
    }

    private static boolean llIlllIIlI(Object object, Object object2) {
        return object != object2;
    }

    private static boolean llIlllIIll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean llIlllIIIl(int n) {
        return n != 0;
    }
}

