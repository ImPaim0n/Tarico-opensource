/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import java.util.Set;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.tools.Diagnostic;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.tools.obfuscation.MixinObfuscationProcessor;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;

@SupportedAnnotationTypes(value={"org.spongepowered.asm.mixin.Mixin", "org.spongepowered.asm.mixin.Shadow", "org.spongepowered.asm.mixin.Overwrite", "org.spongepowered.asm.mixin.gen.Accessor", "org.spongepowered.asm.mixin.Implements"})
public class MixinObfuscationProcessorTargets
extends MixinObfuscationProcessor {
    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {
        if (MixinObfuscationProcessorTargets.lIIIIIIllIl(roundEnvironment.processingOver() ? 1 : 0)) {
            this.postProcess(roundEnvironment);
            return true;
        }
        this.processMixins(roundEnvironment);
        this.processShadows(roundEnvironment);
        this.processOverwrites(roundEnvironment);
        this.processAccessors(roundEnvironment);
        this.processInvokers(roundEnvironment);
        this.processImplements(roundEnvironment);
        this.postProcess(roundEnvironment);
        return true;
    }

    @Override
    protected void postProcess(RoundEnvironment roundEnvironment) {
        super.postProcess(roundEnvironment);
        try {
            this.mixins.writeReferences();
            this.mixins.writeMappings();
            "".length();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (-"   ".length() >= 0) {
            return;
        }
    }

    private void processShadows(RoundEnvironment roundEnvironment) {
        Iterator<? extends Element> iterator = roundEnvironment.getElementsAnnotatedWith(Shadow.class).iterator();
        while (MixinObfuscationProcessorTargets.lIIIIIIllIl(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            Element element2 = element.getEnclosingElement();
            if (MixinObfuscationProcessorTargets.lIIIIIIlllI(element2 instanceof TypeElement)) {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Unexpected parent with type ").append(TypeUtils.getElementType(element2))), element);
                "".length();
                if (-" ".length() < 0) continue;
                return;
            }
            AnnotationHandle annotationHandle = AnnotationHandle.of(element, Shadow.class);
            if (MixinObfuscationProcessorTargets.lIIIIIIllll((Object)element.getKind(), (Object)ElementKind.FIELD)) {
                this.mixins.registerShadow((TypeElement)element2, (VariableElement)element, annotationHandle);
                "".length();
                if (null != null) {
                    return;
                }
            } else if (MixinObfuscationProcessorTargets.lIIIIIIllll((Object)element.getKind(), (Object)ElementKind.METHOD)) {
                this.mixins.registerShadow((TypeElement)element2, (ExecutableElement)element, annotationHandle);
                "".length();
                if ((0xE ^ 0xA) == 0) {
                    return;
                }
            } else {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, "Element is not a method or field", element);
            }
            "".length();
            if ("  ".length() < (0x8B ^ 0x8F)) continue;
            return;
        }
    }

    private void processOverwrites(RoundEnvironment roundEnvironment) {
        Iterator<? extends Element> iterator = roundEnvironment.getElementsAnnotatedWith(Overwrite.class).iterator();
        while (MixinObfuscationProcessorTargets.lIIIIIIllIl(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            Element element2 = element.getEnclosingElement();
            if (MixinObfuscationProcessorTargets.lIIIIIIlllI(element2 instanceof TypeElement)) {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Unexpected parent with type ").append(TypeUtils.getElementType(element2))), element);
                "".length();
                if ("   ".length() > 0) continue;
                return;
            }
            if (MixinObfuscationProcessorTargets.lIIIIIIllll((Object)element.getKind(), (Object)ElementKind.METHOD)) {
                this.mixins.registerOverwrite((TypeElement)element2, (ExecutableElement)element);
                "".length();
                if ((0xB9 ^ 0xBD) != (1 ^ 5)) {
                    return;
                }
            } else {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, "Element is not a method", element);
            }
            "".length();
            if ((5 + 165 - 66 + 64 ^ 137 + 70 - 53 + 18) > ((0x59 ^ 0x19 ^ (0x53 ^ 0x16)) & (0x5D ^ 0 ^ (0x40 ^ 0x18) ^ -" ".length()))) continue;
            return;
        }
    }

    private void processAccessors(RoundEnvironment roundEnvironment) {
        Iterator<? extends Element> iterator = roundEnvironment.getElementsAnnotatedWith(Accessor.class).iterator();
        while (MixinObfuscationProcessorTargets.lIIIIIIllIl(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            Element element2 = element.getEnclosingElement();
            if (MixinObfuscationProcessorTargets.lIIIIIIlllI(element2 instanceof TypeElement)) {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Unexpected parent with type ").append(TypeUtils.getElementType(element2))), element);
                "".length();
                if (-" ".length() != "  ".length()) continue;
                return;
            }
            if (MixinObfuscationProcessorTargets.lIIIIIIllll((Object)element.getKind(), (Object)ElementKind.METHOD)) {
                this.mixins.registerAccessor((TypeElement)element2, (ExecutableElement)element);
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, "Element is not a method", element);
            }
            "".length();
            if (null == null) continue;
            return;
        }
    }

    private void processInvokers(RoundEnvironment roundEnvironment) {
        Iterator<? extends Element> iterator = roundEnvironment.getElementsAnnotatedWith(Invoker.class).iterator();
        while (MixinObfuscationProcessorTargets.lIIIIIIllIl(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            Element element2 = element.getEnclosingElement();
            if (MixinObfuscationProcessorTargets.lIIIIIIlllI(element2 instanceof TypeElement)) {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, String.valueOf(new StringBuilder().append("Unexpected parent with type ").append(TypeUtils.getElementType(element2))), element);
                "".length();
                if ((9 ^ 5 ^ (0x62 ^ 0x6A)) >= " ".length()) continue;
                return;
            }
            if (MixinObfuscationProcessorTargets.lIIIIIIllll((Object)element.getKind(), (Object)ElementKind.METHOD)) {
                this.mixins.registerInvoker((TypeElement)element2, (ExecutableElement)element);
                "".length();
                if (-"   ".length() > 0) {
                    return;
                }
            } else {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, "Element is not a method", element);
            }
            "".length();
            if (((15 + 70 - -8 + 152 ^ 32 + 33 - 42 + 147) & (0x1A ^ 0x5B ^ (0x8F ^ 0x91) ^ -" ".length())) >= ((0x33 ^ 0x12 ^ (0xBB ^ 0xBE)) & (0xEC ^ 0x9B ^ (0x35 ^ 0x66) ^ -" ".length()))) continue;
            return;
        }
    }

    private void processImplements(RoundEnvironment roundEnvironment) {
        Iterator<? extends Element> iterator = roundEnvironment.getElementsAnnotatedWith(Implements.class).iterator();
        while (MixinObfuscationProcessorTargets.lIIIIIIllIl(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            if (!MixinObfuscationProcessorTargets.lIIIIIlIIII((Object)element.getKind(), (Object)ElementKind.CLASS) || MixinObfuscationProcessorTargets.lIIIIIIllll((Object)element.getKind(), (Object)ElementKind.INTERFACE)) {
                AnnotationHandle annotationHandle = AnnotationHandle.of(element, Implements.class);
                this.mixins.registerSoftImplements((TypeElement)element, annotationHandle);
                "".length();
                if (null != null) {
                    return;
                }
            } else {
                this.mixins.printMessage(Diagnostic.Kind.ERROR, "Found an @Implements annotation on an element which is not a class or interface", element);
            }
            "".length();
            if ((0x8F ^ 0xAB ^ (0xA8 ^ 0x88)) >= 0) continue;
            return;
        }
    }

    private static boolean lIIIIIlIIII(Object object, Object object2) {
        return object != object2;
    }

    private static boolean lIIIIIIllll(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIIIIllIl(int n) {
        return n != 0;
    }

    private static boolean lIIIIIIlllI(int n) {
        return n == 0;
    }
}

