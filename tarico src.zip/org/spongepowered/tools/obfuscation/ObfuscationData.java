/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.spongepowered.tools.obfuscation.ObfuscationType;

public class ObfuscationData<T>
implements Iterable<ObfuscationType> {
    private final Map<ObfuscationType, T> data = new HashMap<ObfuscationType, T>();
    private final T defaultValue;

    public ObfuscationData() {
        this(null);
    }

    public ObfuscationData(T t) {
        this.defaultValue = t;
    }

    @Deprecated
    public void add(ObfuscationType obfuscationType, T t) {
        this.put(obfuscationType, t);
    }

    public void put(ObfuscationType obfuscationType, T t) {
        this.data.put(obfuscationType, t);
        "".length();
    }

    public boolean isEmpty() {
        return this.data.isEmpty();
    }

    public T get(ObfuscationType obfuscationType) {
        T t;
        T t2 = this.data.get(obfuscationType);
        if (ObfuscationData.lIIIlIIlIlII(t2)) {
            t = t2;
            "".length();
            if ((0x28 ^ 0x2C) < ((0x2D ^ 0x1B) & ~(0x6C ^ 0x5A))) {
                return null;
            }
        } else {
            t = this.defaultValue;
        }
        return t;
    }

    @Override
    public Iterator<ObfuscationType> iterator() {
        return this.data.keySet().iterator();
    }

    public String toString() {
        return String.format("ObfuscationData[%s,DEFAULT=%s]", this.listValues(), this.defaultValue);
    }

    public String values() {
        return String.valueOf(new StringBuilder().append("[").append(this.listValues()).append("]"));
    }

    private String listValues() {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        Iterator<ObfuscationType> iterator = this.data.keySet().iterator();
        while (ObfuscationData.lIIIlIIlIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            if (ObfuscationData.lIIIlIIlIlIl(n)) {
                stringBuilder.append(',');
                "".length();
            }
            stringBuilder.append(obfuscationType.getKey()).append('=').append(this.data.get(obfuscationType));
            "".length();
            n = 1;
            "".length();
            if (-" ".length() <= ((119 + 11 - 112 + 120 ^ 24 + 87 - -9 + 42) & (0x2B ^ 0xA ^ (0xA9 ^ 0xA0) ^ -" ".length()))) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    private static boolean lIIIlIIlIlII(Object object) {
        return object != null;
    }

    private static boolean lIIIlIIlIlIl(int n) {
        return n != 0;
    }
}

