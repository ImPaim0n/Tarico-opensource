/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import java.util.Iterator;
import java.util.List;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.asm.obfuscation.mapping.IMapping$Type;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.ObfuscationData;
import org.spongepowered.tools.obfuscation.ObfuscationEnvironment;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.interfaces.IMixinAnnotationProcessor;
import org.spongepowered.tools.obfuscation.interfaces.IObfuscationDataProvider;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

public class ObfuscationDataProvider
implements IObfuscationDataProvider {
    private final IMixinAnnotationProcessor ap;
    private final List<ObfuscationEnvironment> environments;

    public ObfuscationDataProvider(IMixinAnnotationProcessor iMixinAnnotationProcessor, List<ObfuscationEnvironment> list) {
        this.ap = iMixinAnnotationProcessor;
        this.environments = list;
    }

    @Override
    public <T> ObfuscationData<T> getObfEntryRecursive(MemberInfo memberInfo) {
        MemberInfo memberInfo2 = memberInfo;
        ObfuscationData<String> obfuscationData = this.getObfClass(memberInfo2.owner);
        ObfuscationData<T> obfuscationData2 = this.getObfEntry(memberInfo2);
        try {
            while (ObfuscationDataProvider.lIlIlllIlIl(obfuscationData2.isEmpty() ? 1 : 0)) {
                TypeHandle typeHandle = this.ap.getTypeProvider().getTypeHandle(memberInfo2.owner);
                if (ObfuscationDataProvider.lIlIlllIllI(typeHandle)) {
                    return obfuscationData2;
                }
                TypeHandle typeHandle2 = typeHandle.getSuperclass();
                obfuscationData2 = this.getObfEntryUsing(memberInfo2, typeHandle2);
                if (ObfuscationDataProvider.lIlIlllIlll(obfuscationData2.isEmpty() ? 1 : 0)) {
                    return ObfuscationDataProvider.applyParents(obfuscationData, obfuscationData2);
                }
                Iterator<TypeHandle> iterator = typeHandle.getInterfaces().iterator();
                while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
                    TypeHandle typeHandle3 = iterator.next();
                    obfuscationData2 = this.getObfEntryUsing(memberInfo2, typeHandle3);
                    if (ObfuscationDataProvider.lIlIlllIlll(obfuscationData2.isEmpty() ? 1 : 0)) {
                        return ObfuscationDataProvider.applyParents(obfuscationData, obfuscationData2);
                    }
                    "".length();
                    if (((0x48 ^ 0x1F) & ~(0xF8 ^ 0xAF)) == 0) continue;
                    return null;
                }
                if (ObfuscationDataProvider.lIlIlllIllI(typeHandle2)) {
                    "".length();
                    if (((0x34 ^ 0x7A ^ (0x52 ^ 0x28)) & (1 + 66 - 13 + 80 ^ 173 + 93 - 160 + 72 ^ -" ".length())) == 0) break;
                    return null;
                }
                memberInfo2 = memberInfo2.move(typeHandle2.getName());
                "".length();
                if ("   ".length() >= "   ".length()) continue;
                return null;
            }
            "".length();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return this.getObfEntry(memberInfo);
        }
        if ((0x3B ^ 0x72 ^ (0x2D ^ 0x60)) < "  ".length()) {
            return null;
        }
        return obfuscationData2;
    }

    private <T> ObfuscationData<T> getObfEntryUsing(MemberInfo memberInfo, TypeHandle typeHandle) {
        ObfuscationData obfuscationData;
        if (ObfuscationDataProvider.lIlIlllIllI(typeHandle)) {
            obfuscationData = new ObfuscationData();
            "".length();
            if (-" ".length() > 0) {
                return null;
            }
        } else {
            obfuscationData = this.getObfEntry(memberInfo.move(typeHandle.getName()));
        }
        return obfuscationData;
    }

    @Override
    public <T> ObfuscationData<T> getObfEntry(MemberInfo memberInfo) {
        if (ObfuscationDataProvider.lIlIlllIlIl(memberInfo.isField() ? 1 : 0)) {
            return this.getObfField(memberInfo);
        }
        return this.getObfMethod(memberInfo.asMethodMapping());
    }

    @Override
    public <T> ObfuscationData<T> getObfEntry(IMapping<T> iMapping) {
        if (ObfuscationDataProvider.lIlIllllIII(iMapping)) {
            if (ObfuscationDataProvider.lIlIllllIIl((Object)iMapping.getType(), (Object)IMapping$Type.FIELD)) {
                return this.getObfField((MappingField)iMapping);
            }
            if (ObfuscationDataProvider.lIlIllllIIl((Object)iMapping.getType(), (Object)IMapping$Type.METHOD)) {
                return this.getObfMethod((MappingMethod)iMapping);
            }
        }
        return new ObfuscationData();
    }

    @Override
    public ObfuscationData<MappingMethod> getObfMethodRecursive(MemberInfo memberInfo) {
        return this.getObfEntryRecursive(memberInfo);
    }

    @Override
    public ObfuscationData<MappingMethod> getObfMethod(MemberInfo memberInfo) {
        return this.getRemappedMethod(memberInfo, memberInfo.isConstructor());
    }

    @Override
    public ObfuscationData<MappingMethod> getRemappedMethod(MemberInfo memberInfo) {
        return this.getRemappedMethod(memberInfo, true);
    }

    private ObfuscationData<MappingMethod> getRemappedMethod(MemberInfo memberInfo, boolean bl) {
        ObfuscationData<MappingMethod> obfuscationData = new ObfuscationData<MappingMethod>();
        Iterator<ObfuscationEnvironment> iterator = this.environments.iterator();
        while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationEnvironment obfuscationEnvironment = iterator.next();
            MappingMethod mappingMethod = obfuscationEnvironment.getObfMethod(memberInfo);
            if (ObfuscationDataProvider.lIlIllllIII(mappingMethod)) {
                obfuscationData.put(obfuscationEnvironment.getType(), mappingMethod);
            }
            "".length();
            if (((0xEA ^ 0x9A ^ (0xED ^ 0xB1)) & (95 + 160 - 111 + 21 ^ 112 + 112 - 178 + 91 ^ -" ".length())) <= "  ".length()) continue;
            return null;
        }
        if (!ObfuscationDataProvider.lIlIlllIlIl(obfuscationData.isEmpty() ? 1 : 0) || ObfuscationDataProvider.lIlIlllIlll(bl ? 1 : 0)) {
            return obfuscationData;
        }
        return this.remapDescriptor(obfuscationData, memberInfo);
    }

    @Override
    public ObfuscationData<MappingMethod> getObfMethod(MappingMethod mappingMethod) {
        return this.getRemappedMethod(mappingMethod, mappingMethod.isConstructor());
    }

    @Override
    public ObfuscationData<MappingMethod> getRemappedMethod(MappingMethod mappingMethod) {
        return this.getRemappedMethod(mappingMethod, true);
    }

    private ObfuscationData<MappingMethod> getRemappedMethod(MappingMethod mappingMethod, boolean bl) {
        ObfuscationData<MappingMethod> obfuscationData = new ObfuscationData<MappingMethod>();
        Iterator<ObfuscationEnvironment> iterator = this.environments.iterator();
        while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationEnvironment obfuscationEnvironment = iterator.next();
            MappingMethod mappingMethod2 = obfuscationEnvironment.getObfMethod(mappingMethod);
            if (ObfuscationDataProvider.lIlIllllIII(mappingMethod2)) {
                obfuscationData.put(obfuscationEnvironment.getType(), mappingMethod2);
            }
            "".length();
            if (" ".length() >= -" ".length()) continue;
            return null;
        }
        if (!ObfuscationDataProvider.lIlIlllIlIl(obfuscationData.isEmpty() ? 1 : 0) || ObfuscationDataProvider.lIlIlllIlll(bl ? 1 : 0)) {
            return obfuscationData;
        }
        return this.remapDescriptor(obfuscationData, new MemberInfo(mappingMethod));
    }

    public ObfuscationData<MappingMethod> remapDescriptor(ObfuscationData<MappingMethod> obfuscationData, MemberInfo memberInfo) {
        Iterator<ObfuscationEnvironment> iterator = this.environments.iterator();
        while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationEnvironment obfuscationEnvironment = iterator.next();
            MemberInfo memberInfo2 = obfuscationEnvironment.remapDescriptor(memberInfo);
            if (ObfuscationDataProvider.lIlIllllIII(memberInfo2)) {
                obfuscationData.put(obfuscationEnvironment.getType(), memberInfo2.asMethodMapping());
            }
            "".length();
            if ("  ".length() != -" ".length()) continue;
            return null;
        }
        return obfuscationData;
    }

    @Override
    public ObfuscationData<MappingField> getObfFieldRecursive(MemberInfo memberInfo) {
        return this.getObfEntryRecursive(memberInfo);
    }

    @Override
    public ObfuscationData<MappingField> getObfField(MemberInfo memberInfo) {
        return this.getObfField(memberInfo.asFieldMapping());
    }

    @Override
    public ObfuscationData<MappingField> getObfField(MappingField mappingField) {
        ObfuscationData<MappingField> obfuscationData = new ObfuscationData<MappingField>();
        Iterator<ObfuscationEnvironment> iterator = this.environments.iterator();
        while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationEnvironment obfuscationEnvironment = iterator.next();
            MappingField mappingField2 = obfuscationEnvironment.getObfField(mappingField);
            if (ObfuscationDataProvider.lIlIllllIII(mappingField2)) {
                if (ObfuscationDataProvider.lIlIlllIllI(mappingField2.getDesc()) && ObfuscationDataProvider.lIlIllllIII(mappingField.getDesc())) {
                    mappingField2 = mappingField2.transform(obfuscationEnvironment.remapDescriptor(mappingField.getDesc()));
                }
                obfuscationData.put(obfuscationEnvironment.getType(), mappingField2);
            }
            "".length();
            if (" ".length() < (9 ^ 0x7A ^ (0x7B ^ 0xC))) continue;
            return null;
        }
        return obfuscationData;
    }

    @Override
    public ObfuscationData<String> getObfClass(TypeHandle typeHandle) {
        return this.getObfClass(typeHandle.getName());
    }

    @Override
    public ObfuscationData<String> getObfClass(String string) {
        ObfuscationData<String> obfuscationData = new ObfuscationData<String>(string);
        Iterator<ObfuscationEnvironment> iterator = this.environments.iterator();
        while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationEnvironment obfuscationEnvironment = iterator.next();
            String string2 = obfuscationEnvironment.getObfClass(string);
            if (ObfuscationDataProvider.lIlIllllIII(string2)) {
                obfuscationData.put(obfuscationEnvironment.getType(), string2);
            }
            "".length();
            if (-(0x7E ^ 0x4A ^ (0xBF ^ 0x8F)) < 0) continue;
            return null;
        }
        return obfuscationData;
    }

    private static <T> ObfuscationData<T> applyParents(ObfuscationData<String> obfuscationData, ObfuscationData<T> obfuscationData2) {
        Iterator<ObfuscationType> iterator = obfuscationData2.iterator();
        while (ObfuscationDataProvider.lIlIlllIlIl(iterator.hasNext() ? 1 : 0)) {
            ObfuscationType obfuscationType = iterator.next();
            String string = obfuscationData.get(obfuscationType);
            T t = obfuscationData2.get(obfuscationType);
            obfuscationData2.put(obfuscationType, MemberInfo.fromMapping((IMapping)t).move(string).asMapping());
            "".length();
            if (((0x1C ^ 0x23) & ~(0xAE ^ 0x91)) <= "   ".length()) continue;
            return null;
        }
        return obfuscationData2;
    }

    private static boolean lIlIllllIII(Object object) {
        return object != null;
    }

    private static boolean lIlIllllIIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIlIlllIllI(Object object) {
        return object == null;
    }

    private static boolean lIlIlllIlIl(int n) {
        return n != 0;
    }

    private static boolean lIlIlllIlll(int n) {
        return n == 0;
    }
}

