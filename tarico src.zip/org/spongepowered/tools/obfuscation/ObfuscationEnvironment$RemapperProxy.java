/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation;

import org.spongepowered.asm.util.ObfuscationUtil$IClassRemapper;
import org.spongepowered.tools.obfuscation.ObfuscationEnvironment;

final class ObfuscationEnvironment$RemapperProxy
implements ObfuscationUtil$IClassRemapper {
    final /* synthetic */ ObfuscationEnvironment this$0;

    ObfuscationEnvironment$RemapperProxy(ObfuscationEnvironment obfuscationEnvironment) {
        this.this$0 = obfuscationEnvironment;
    }

    @Override
    public String map(String string) {
        if (ObfuscationEnvironment$RemapperProxy.llIlIIIlII(this.this$0.mappingProvider)) {
            return null;
        }
        return this.this$0.mappingProvider.getClassMapping(string);
    }

    @Override
    public String unmap(String string) {
        if (ObfuscationEnvironment$RemapperProxy.llIlIIIlII(this.this$0.mappingProvider)) {
            return null;
        }
        return this.this$0.mappingProvider.getClassMapping(string);
    }

    private static boolean llIlIIIlII(Object object) {
        return object == null;
    }
}

