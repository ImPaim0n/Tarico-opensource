/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.interfaces;

public enum IMixinValidator$ValidationPass {
    EARLY,
    LATE,
    FINAL;

}

