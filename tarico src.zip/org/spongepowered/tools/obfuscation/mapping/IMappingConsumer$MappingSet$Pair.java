/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Objects
 */
package org.spongepowered.tools.obfuscation.mapping;

import com.google.common.base.Objects;
import org.spongepowered.asm.obfuscation.mapping.IMapping;

public class IMappingConsumer$MappingSet$Pair<TMapping extends IMapping<TMapping>> {
    public final TMapping from;
    public final TMapping to;

    public IMappingConsumer$MappingSet$Pair(TMapping TMapping, TMapping TMapping2) {
        this.from = TMapping;
        this.to = TMapping2;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (IMappingConsumer$MappingSet$Pair.llIlIllII(object instanceof IMappingConsumer$MappingSet$Pair)) {
            return false;
        }
        IMappingConsumer$MappingSet$Pair iMappingConsumer$MappingSet$Pair = (IMappingConsumer$MappingSet$Pair)object;
        if (IMappingConsumer$MappingSet$Pair.llIlIllIl(Objects.equal(this.from, iMappingConsumer$MappingSet$Pair.from) ? 1 : 0) && IMappingConsumer$MappingSet$Pair.llIlIllIl(Objects.equal(this.to, iMappingConsumer$MappingSet$Pair.to) ? 1 : 0)) {
            bl = true;
            "".length();
            if ("  ".length() == 0) {
                return ((202 + 180 - 318 + 189 ^ 11 + 85 - 55 + 147) & (2 ^ 0x58 ^ (0x43 ^ 0x58) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return Objects.hashCode((Object[])new Object[]{this.from, this.to});
    }

    public String toString() {
        return String.format("%s -> %s", this.from, this.to);
    }

    private static boolean llIlIllIl(int n) {
        return n != 0;
    }

    private static boolean llIlIllII(int n) {
        return n == 0;
    }
}

