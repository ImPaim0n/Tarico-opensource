/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mapping;

import java.util.LinkedHashSet;
import org.spongepowered.asm.obfuscation.mapping.IMapping;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet$Pair;

public class IMappingConsumer$MappingSet<TMapping extends IMapping<TMapping>>
extends LinkedHashSet<IMappingConsumer$MappingSet$Pair<TMapping>> {
    private static final long serialVersionUID = 1L;
}

