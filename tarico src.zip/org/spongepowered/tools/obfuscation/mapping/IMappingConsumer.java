/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mapping;

import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet;

public interface IMappingConsumer {
    public void clear();

    public void addFieldMapping(ObfuscationType var1, MappingField var2, MappingField var3);

    public void addMethodMapping(ObfuscationType var1, MappingMethod var2, MappingMethod var3);

    public IMappingConsumer$MappingSet<MappingField> getFieldMappings(ObfuscationType var1);

    public IMappingConsumer$MappingSet<MappingMethod> getMethodMappings(ObfuscationType var1);
}

