/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.BiMap
 *  com.google.common.collect.HashBiMap
 */
package org.spongepowered.tools.obfuscation.mapping.common;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.mapping.IMappingProvider;

public abstract class MappingProvider
implements IMappingProvider {
    protected final Messager messager;
    protected final Filer filer;
    protected final BiMap<String, String> packageMap = HashBiMap.create();
    protected final BiMap<String, String> classMap = HashBiMap.create();
    protected final BiMap<MappingField, MappingField> fieldMap = HashBiMap.create();
    protected final BiMap<MappingMethod, MappingMethod> methodMap = HashBiMap.create();

    public MappingProvider(Messager messager, Filer filer) {
        this.messager = messager;
        this.filer = filer;
    }

    @Override
    public void clear() {
        this.packageMap.clear();
        this.classMap.clear();
        this.fieldMap.clear();
        this.methodMap.clear();
    }

    @Override
    public boolean isEmpty() {
        boolean bl;
        if (MappingProvider.llIIIlllIIl(this.packageMap.isEmpty() ? 1 : 0) && MappingProvider.llIIIlllIIl(this.classMap.isEmpty() ? 1 : 0) && MappingProvider.llIIIlllIIl(this.fieldMap.isEmpty() ? 1 : 0) && MappingProvider.llIIIlllIIl(this.methodMap.isEmpty() ? 1 : 0)) {
            bl = true;
            "".length();
            if (((105 + 63 - 77 + 43 ^ 54 + 103 - 33 + 41) & ("  ".length() ^ (0x36 ^ 0x17) ^ -" ".length())) != 0) {
                return ((148 + 53 - 82 + 64 ^ 109 + 88 - 184 + 137) & (31 + 19 - -174 + 3 ^ 129 + 118 - 148 + 95 ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    @Override
    public MappingMethod getMethodMapping(MappingMethod mappingMethod) {
        return (MappingMethod)this.methodMap.get((Object)mappingMethod);
    }

    @Override
    public MappingField getFieldMapping(MappingField mappingField) {
        return (MappingField)this.fieldMap.get((Object)mappingField);
    }

    @Override
    public String getClassMapping(String string) {
        return (String)this.classMap.get((Object)string);
    }

    @Override
    public String getPackageMapping(String string) {
        return (String)this.packageMap.get((Object)string);
    }

    private static boolean llIIIlllIIl(int n) {
        return n != 0;
    }
}

