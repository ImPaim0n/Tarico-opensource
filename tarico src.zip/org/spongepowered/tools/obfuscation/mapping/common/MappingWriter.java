/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mapping.common;

import java.io.File;
import java.io.PrintWriter;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.lang.model.element.Element;
import javax.tools.Diagnostic;
import javax.tools.FileObject;
import javax.tools.StandardLocation;
import org.spongepowered.tools.obfuscation.mapping.IMappingWriter;

public abstract class MappingWriter
implements IMappingWriter {
    private final Messager messager;
    private final Filer filer;

    public MappingWriter(Messager messager, Filer filer) {
        this.messager = messager;
        this.filer = filer;
    }

    protected PrintWriter openFileWriter(String string, String string2) {
        if (MappingWriter.llIIllIlllI(string.matches("^.*[\\\\/:].*$") ? 1 : 0)) {
            File file = new File(string);
            file.getParentFile().mkdirs();
            "".length();
            this.messager.printMessage(Diagnostic.Kind.NOTE, String.valueOf(new StringBuilder().append("Writing ").append(string2).append(" to ").append(file.getAbsolutePath())));
            return new PrintWriter(file);
        }
        FileObject fileObject = this.filer.createResource(StandardLocation.CLASS_OUTPUT, "", string, new Element[0]);
        this.messager.printMessage(Diagnostic.Kind.NOTE, String.valueOf(new StringBuilder().append("Writing ").append(string2).append(" to ").append(new File(fileObject.toUri()).getAbsolutePath())));
        return new PrintWriter(fileObject.openWriter());
    }

    private static boolean llIIllIlllI(int n) {
        return n != 0;
    }
}

