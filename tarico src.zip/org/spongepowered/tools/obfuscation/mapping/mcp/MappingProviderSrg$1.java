/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  com.google.common.collect.BiMap
 *  com.google.common.io.LineProcessor
 */
package org.spongepowered.tools.obfuscation.mapping.mcp;

import com.google.common.base.Strings;
import com.google.common.collect.BiMap;
import com.google.common.io.LineProcessor;
import java.io.File;
import org.spongepowered.asm.mixin.throwables.MixinException;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.asm.obfuscation.mapping.mcp.MappingFieldSrg;
import org.spongepowered.tools.obfuscation.mapping.mcp.MappingProviderSrg;

class MappingProviderSrg$1
implements LineProcessor<String> {
    final /* synthetic */ BiMap val$packageMap;
    final /* synthetic */ BiMap val$classMap;
    final /* synthetic */ BiMap val$fieldMap;
    final /* synthetic */ BiMap val$methodMap;
    final /* synthetic */ File val$input;
    final /* synthetic */ MappingProviderSrg this$0;

    MappingProviderSrg$1(MappingProviderSrg mappingProviderSrg, BiMap biMap, BiMap biMap2, BiMap biMap3, BiMap biMap4, File file) {
        this.this$0 = mappingProviderSrg;
        this.val$packageMap = biMap;
        this.val$classMap = biMap2;
        this.val$fieldMap = biMap3;
        this.val$methodMap = biMap4;
        this.val$input = file;
    }

    public String getResult() {
        return null;
    }

    public boolean processLine(String string) {
        if (!MappingProviderSrg$1.lIIllllIIII(Strings.isNullOrEmpty((String)string) ? 1 : 0) || MappingProviderSrg$1.lIIllllIIIl(string.startsWith("#") ? 1 : 0)) {
            return true;
        }
        String string2 = string.substring(0, 2);
        String[] stringArray = string.substring(4).split(" ");
        if (MappingProviderSrg$1.lIIllllIIIl(string2.equals("PK") ? 1 : 0)) {
            this.val$packageMap.forcePut((Object)stringArray[0], (Object)stringArray[1]);
            "".length();
            "".length();
            if ("  ".length() <= 0) {
                return ((28 + 93 - 53 + 87 ^ 6 + 92 - 78 + 165) & (72 + 41 - 5 + 24 ^ 40 + 110 - 134 + 150 ^ -" ".length())) != 0;
            }
        } else if (MappingProviderSrg$1.lIIllllIIIl(string2.equals("CL") ? 1 : 0)) {
            this.val$classMap.forcePut((Object)stringArray[0], (Object)stringArray[1]);
            "".length();
            "".length();
            if (" ".length() == "   ".length()) {
                return ((81 + 126 - 11 + 23 ^ 38 + 40 - -4 + 72) & (74 + 95 - 26 + 68 ^ 71 + 85 - 155 + 145 ^ -" ".length())) != 0;
            }
        } else if (MappingProviderSrg$1.lIIllllIIIl(string2.equals("FD") ? 1 : 0)) {
            this.val$fieldMap.forcePut((Object)new MappingFieldSrg(stringArray[0]).copy(), (Object)new MappingFieldSrg(stringArray[1]).copy());
            "".length();
            "".length();
            if (-" ".length() > "  ".length()) {
                return ((168 + 132 - 110 + 9 ^ 12 + 95 - 42 + 90) & (0xE1 ^ 0xBB ^ (0xBD ^ 0xBB) ^ -" ".length())) != 0;
            }
        } else if (MappingProviderSrg$1.lIIllllIIIl(string2.equals("MD") ? 1 : 0)) {
            this.val$methodMap.forcePut((Object)new MappingMethod(stringArray[0], stringArray[1]), (Object)new MappingMethod(stringArray[2], stringArray[3]));
            "".length();
            "".length();
            if ("   ".length() >= (0x21 ^ 0x25)) {
                return ((0xC5 ^ 0xC2) & ~(0x67 ^ 0x60)) != 0;
            }
        } else {
            throw new MixinException(String.valueOf(new StringBuilder().append("Invalid SRG file: ").append(this.val$input)));
        }
        return true;
    }

    private static boolean lIIllllIIIl(int n) {
        return n != 0;
    }

    private static boolean lIIllllIIII(int n) {
        return n == 0;
    }
}

