/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mapping.mcp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import org.spongepowered.asm.obfuscation.mapping.common.MappingField;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.ObfuscationType;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet;
import org.spongepowered.tools.obfuscation.mapping.IMappingConsumer$MappingSet$Pair;
import org.spongepowered.tools.obfuscation.mapping.common.MappingWriter;

public class MappingWriterSrg
extends MappingWriter {
    public MappingWriterSrg(Messager messager, Filer filer) {
        super(messager, filer);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     */
    @Override
    public void write(String string, ObfuscationType obfuscationType, IMappingConsumer$MappingSet<MappingField> iMappingConsumer$MappingSet, IMappingConsumer$MappingSet<MappingMethod> iMappingConsumer$MappingSet2) {
        block16: {
            if (MappingWriterSrg.lIllIII(string)) {
                return;
            }
            PrintWriter printWriter = null;
            printWriter = this.openFileWriter(string, String.valueOf(new StringBuilder().append(obfuscationType).append(" output SRGs")));
            this.writeFieldMappings(printWriter, iMappingConsumer$MappingSet);
            this.writeMethodMappings(printWriter, iMappingConsumer$MappingSet2);
            if (!MappingWriterSrg.lIllIIl(printWriter)) break block16;
            try {
                printWriter.close();
                "".length();
            }
            catch (Exception exception) {
                "".length();
                if (null != null) {
                    return;
                }
                break block16;
            }
            if (-" ".length() > 0) {
                return;
            }
            break block16;
            catch (IOException iOException) {
                iOException.printStackTrace();
                {
                    "".length();
                }
                {
                    if (-" ".length() > 0) {
                        return;
                    }
                    break block16;
                }
            }
            finally {
                if (!MappingWriterSrg.lIllIIl(printWriter)) break block16;
                try {
                    printWriter.close();
                    "".length();
                }
                catch (Exception exception) {}
                if (" ".length() < 0) {
                    return;
                }
            }
        }
    }

    protected void writeFieldMappings(PrintWriter printWriter, IMappingConsumer$MappingSet<MappingField> iMappingConsumer$MappingSet) {
        Iterator iterator = iMappingConsumer$MappingSet.iterator();
        while (MappingWriterSrg.lIllIlI(iterator.hasNext() ? 1 : 0)) {
            IMappingConsumer$MappingSet$Pair iMappingConsumer$MappingSet$Pair = (IMappingConsumer$MappingSet$Pair)iterator.next();
            printWriter.println(this.formatFieldMapping(iMappingConsumer$MappingSet$Pair));
            "".length();
            if (-" ".length() <= 0) continue;
            return;
        }
    }

    protected void writeMethodMappings(PrintWriter printWriter, IMappingConsumer$MappingSet<MappingMethod> iMappingConsumer$MappingSet) {
        Iterator iterator = iMappingConsumer$MappingSet.iterator();
        while (MappingWriterSrg.lIllIlI(iterator.hasNext() ? 1 : 0)) {
            IMappingConsumer$MappingSet$Pair iMappingConsumer$MappingSet$Pair = (IMappingConsumer$MappingSet$Pair)iterator.next();
            printWriter.println(this.formatMethodMapping(iMappingConsumer$MappingSet$Pair));
            "".length();
            if (null == null) continue;
            return;
        }
    }

    protected String formatFieldMapping(IMappingConsumer$MappingSet$Pair<MappingField> iMappingConsumer$MappingSet$Pair) {
        return String.format("FD: %s/%s %s/%s", ((MappingField)iMappingConsumer$MappingSet$Pair.from).getOwner(), ((MappingField)iMappingConsumer$MappingSet$Pair.from).getName(), ((MappingField)iMappingConsumer$MappingSet$Pair.to).getOwner(), ((MappingField)iMappingConsumer$MappingSet$Pair.to).getName());
    }

    protected String formatMethodMapping(IMappingConsumer$MappingSet$Pair<MappingMethod> iMappingConsumer$MappingSet$Pair) {
        return String.format("MD: %s %s %s %s", ((MappingMethod)iMappingConsumer$MappingSet$Pair.from).getName(), ((MappingMethod)iMappingConsumer$MappingSet$Pair.from).getDesc(), ((MappingMethod)iMappingConsumer$MappingSet$Pair.to).getName(), ((MappingMethod)iMappingConsumer$MappingSet$Pair.to).getDesc());
    }

    private static boolean lIllIIl(Object object) {
        return object != null;
    }

    private static boolean lIllIII(Object object) {
        return object == null;
    }

    private static boolean lIllIlI(int n) {
        return n != 0;
    }
}

