/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package org.spongepowered.tools.obfuscation.mirror;

import com.google.common.collect.ImmutableList;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;

public final class AnnotationHandle {
    public static final AnnotationHandle MISSING = new AnnotationHandle(null);
    private final AnnotationMirror annotation;

    private AnnotationHandle(AnnotationMirror annotationMirror) {
        this.annotation = annotationMirror;
    }

    public AnnotationMirror asMirror() {
        return this.annotation;
    }

    public boolean exists() {
        boolean bl;
        if (AnnotationHandle.lIllIlIIlI(this.annotation)) {
            bl = true;
            "".length();
            if (((0x4D ^ 0x59) & ~(0x76 ^ 0x62)) != ((0x1E ^ 0x14) & ~(0x32 ^ 0x38))) {
                return ((0x57 ^ 0) & ~(0x62 ^ 0x35)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public String toString() {
        if (AnnotationHandle.lIllIlIIll(this.annotation)) {
            return "@{UnknownAnnotation}";
        }
        return String.valueOf(new StringBuilder().append("@").append((Object)this.annotation.getAnnotationType().asElement().getSimpleName()));
    }

    public <T> T getValue(String string, T t) {
        Object object;
        if (AnnotationHandle.lIllIlIIll(this.annotation)) {
            return t;
        }
        AnnotationValue annotationValue = this.getAnnotationValue(string);
        if (AnnotationHandle.lIllIlIlII(t instanceof Enum) && AnnotationHandle.lIllIlIIlI(annotationValue)) {
            VariableElement variableElement = (VariableElement)annotationValue.getValue();
            if (AnnotationHandle.lIllIlIIll(variableElement)) {
                return t;
            }
            return (T)Enum.valueOf(t.getClass(), variableElement.getSimpleName().toString());
        }
        if (AnnotationHandle.lIllIlIIlI(annotationValue)) {
            object = annotationValue.getValue();
            "".length();
            if (((0x8D ^ 0x9D) & ~(0xA4 ^ 0xB4)) != 0) {
                return null;
            }
        } else {
            object = t;
        }
        return object;
    }

    public <T> T getValue() {
        return this.getValue("value", null);
    }

    public <T> T getValue(String string) {
        return this.getValue(string, null);
    }

    public boolean getBoolean(String string, boolean bl) {
        return this.getValue(string, bl);
    }

    public AnnotationHandle getAnnotation(String string) {
        Object object;
        Object t = this.getValue(string);
        if (AnnotationHandle.lIllIlIlII(t instanceof AnnotationMirror)) {
            return AnnotationHandle.of((AnnotationMirror)t);
        }
        if (AnnotationHandle.lIllIlIlII(t instanceof AnnotationValue) && AnnotationHandle.lIllIlIlII((object = ((AnnotationValue)t).getValue()) instanceof AnnotationMirror)) {
            return AnnotationHandle.of((AnnotationMirror)object);
        }
        return null;
    }

    public <T> List<T> getList() {
        return this.getList("value");
    }

    public <T> List<T> getList(String string) {
        List<AnnotationValue> list = this.getValue(string, Collections.emptyList());
        return AnnotationHandle.unwrapAnnotationValueList(list);
    }

    public List<AnnotationHandle> getAnnotationList(String string) {
        Object var2_2 = this.getValue(string, null);
        if (AnnotationHandle.lIllIlIIll(var2_2)) {
            return Collections.emptyList();
        }
        if (AnnotationHandle.lIllIlIlII(var2_2 instanceof AnnotationMirror)) {
            return ImmutableList.of((Object)AnnotationHandle.of(var2_2));
        }
        List list = var2_2;
        ArrayList<AnnotationHandle> arrayList = new ArrayList<AnnotationHandle>(list.size());
        Iterator iterator = list.iterator();
        while (AnnotationHandle.lIllIlIlII(iterator.hasNext() ? 1 : 0)) {
            AnnotationValue annotationValue = (AnnotationValue)iterator.next();
            arrayList.add(new AnnotationHandle((AnnotationMirror)annotationValue.getValue()));
            "".length();
            "".length();
            if ((0x38 ^ 0x3C) > "   ".length()) continue;
            return null;
        }
        return Collections.unmodifiableList(arrayList);
    }

    protected AnnotationValue getAnnotationValue(String string) {
        Iterator<? extends ExecutableElement> iterator = this.annotation.getElementValues().keySet().iterator();
        while (AnnotationHandle.lIllIlIlII(iterator.hasNext() ? 1 : 0)) {
            ExecutableElement executableElement = iterator.next();
            if (AnnotationHandle.lIllIlIlII(executableElement.getSimpleName().contentEquals(string) ? 1 : 0)) {
                return this.annotation.getElementValues().get(executableElement);
            }
            "".length();
            if (-" ".length() <= "  ".length()) continue;
            return null;
        }
        return null;
    }

    protected static <T> List<T> unwrapAnnotationValueList(List<AnnotationValue> list) {
        if (AnnotationHandle.lIllIlIIll(list)) {
            return Collections.emptyList();
        }
        ArrayList<Object> arrayList = new ArrayList<Object>(list.size());
        Iterator<AnnotationValue> iterator = list.iterator();
        while (AnnotationHandle.lIllIlIlII(iterator.hasNext() ? 1 : 0)) {
            AnnotationValue annotationValue = iterator.next();
            arrayList.add(annotationValue.getValue());
            "".length();
            "".length();
            if (" ".length() <= "   ".length()) continue;
            return null;
        }
        return arrayList;
    }

    protected static AnnotationMirror getAnnotation(Element element, Class<? extends Annotation> clazz) {
        if (AnnotationHandle.lIllIlIIll(element)) {
            return null;
        }
        List<? extends AnnotationMirror> list = element.getAnnotationMirrors();
        if (AnnotationHandle.lIllIlIIll(list)) {
            return null;
        }
        Iterator<? extends AnnotationMirror> iterator = list.iterator();
        while (AnnotationHandle.lIllIlIlII(iterator.hasNext() ? 1 : 0)) {
            AnnotationMirror annotationMirror = iterator.next();
            Element element2 = annotationMirror.getAnnotationType().asElement();
            if (AnnotationHandle.lIllIlIlll(element2 instanceof TypeElement)) {
                "".length();
                if (((0x65 ^ 0x44) & ~(0x9E ^ 0xBF)) == 0) continue;
                return null;
            }
            TypeElement typeElement = (TypeElement)element2;
            if (AnnotationHandle.lIllIlIlII(typeElement.getQualifiedName().contentEquals(clazz.getName()) ? 1 : 0)) {
                return annotationMirror;
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        return null;
    }

    public static AnnotationHandle of(AnnotationMirror annotationMirror) {
        return new AnnotationHandle(annotationMirror);
    }

    public static AnnotationHandle of(Element element, Class<? extends Annotation> clazz) {
        return new AnnotationHandle(AnnotationHandle.getAnnotation(element, clazz));
    }

    private static boolean lIllIlIIlI(Object object) {
        return object != null;
    }

    private static boolean lIllIlIIll(Object object) {
        return object == null;
    }

    private static boolean lIllIlIlII(int n) {
        return n != 0;
    }

    private static boolean lIllIlIlll(int n) {
        return n == 0;
    }
}

