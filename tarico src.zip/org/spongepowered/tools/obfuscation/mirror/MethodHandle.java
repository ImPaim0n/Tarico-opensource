/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 */
package org.spongepowered.tools.obfuscation.mirror;

import com.google.common.base.Strings;
import javax.lang.model.element.ExecutableElement;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.mirror.MemberHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;
import org.spongepowered.tools.obfuscation.mirror.Visibility;
import org.spongepowered.tools.obfuscation.mirror.mapping.ResolvableMappingMethod;

public class MethodHandle
extends MemberHandle<MappingMethod> {
    private final ExecutableElement element;
    private final TypeHandle ownerHandle;

    public MethodHandle(TypeHandle typeHandle, ExecutableElement executableElement) {
        this(typeHandle, executableElement, TypeUtils.getName(executableElement), TypeUtils.getDescriptor(executableElement));
    }

    public MethodHandle(TypeHandle typeHandle, String string, String string2) {
        this(typeHandle, null, string, string2);
    }

    private MethodHandle(TypeHandle typeHandle, ExecutableElement executableElement, String string, String string2) {
        String string3;
        if (MethodHandle.lIIIIlIIIl(typeHandle)) {
            string3 = typeHandle.getName();
            "".length();
            if (-(0xBC ^ 0xB8) >= 0) {
                throw null;
            }
        } else {
            string3 = null;
        }
        super(string3, string, string2);
        this.element = executableElement;
        this.ownerHandle = typeHandle;
    }

    public boolean isImaginary() {
        boolean bl;
        if (MethodHandle.lIIIIlIIlI(this.element)) {
            bl = true;
            "".length();
            if (-" ".length() < -" ".length()) {
                return ((0x99 ^ 0x90) & ~(0x40 ^ 0x49)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public ExecutableElement getElement() {
        return this.element;
    }

    @Override
    public Visibility getVisibility() {
        return TypeUtils.getVisibility(this.element);
    }

    @Override
    public MappingMethod asMapping(boolean bl) {
        if (MethodHandle.lIIIIlIIll(bl ? 1 : 0)) {
            if (MethodHandle.lIIIIlIIIl(this.ownerHandle)) {
                return new ResolvableMappingMethod(this.ownerHandle, this.getName(), this.getDesc());
            }
            return new MappingMethod(this.getOwner(), this.getName(), this.getDesc());
        }
        return new MappingMethod(null, this.getName(), this.getDesc());
    }

    public String toString() {
        String string;
        if (MethodHandle.lIIIIlIIIl(this.getOwner())) {
            string = String.valueOf(new StringBuilder().append("L").append(this.getOwner()).append(";"));
            "".length();
            if ("   ".length() > (0x55 ^ 0x51)) {
                return null;
            }
        } else {
            string = "";
        }
        String string2 = string;
        String string3 = Strings.nullToEmpty((String)this.getName());
        String string4 = Strings.nullToEmpty((String)this.getDesc());
        return String.format("%s%s%s", string2, string3, string4);
    }

    private static boolean lIIIIlIIIl(Object object) {
        return object != null;
    }

    private static boolean lIIIIlIIlI(Object object) {
        return object == null;
    }

    private static boolean lIIIIlIIll(int n) {
        return n != 0;
    }
}

