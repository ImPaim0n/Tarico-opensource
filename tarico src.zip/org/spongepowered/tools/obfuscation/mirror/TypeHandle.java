/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 */
package org.spongepowered.tools.obfuscation.mirror;

import com.google.common.collect.ImmutableList;
import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.FieldHandle;
import org.spongepowered.tools.obfuscation.mirror.MethodHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeReference;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;
import org.spongepowered.tools.obfuscation.mirror.mapping.ResolvableMappingMethod;

public class TypeHandle {
    private final String name;
    private final PackageElement pkg;
    private final TypeElement element;
    private TypeReference reference;

    public TypeHandle(PackageElement packageElement, String string) {
        this.name = string.replace('.', '/');
        this.pkg = packageElement;
        this.element = null;
    }

    public TypeHandle(TypeElement typeElement) {
        this.pkg = TypeUtils.getPackage(typeElement);
        this.name = TypeUtils.getInternalName(typeElement);
        this.element = typeElement;
    }

    public TypeHandle(DeclaredType declaredType) {
        this((TypeElement)declaredType.asElement());
    }

    public final String toString() {
        return this.name.replace('/', '.');
    }

    public final String getName() {
        return this.name;
    }

    public final PackageElement getPackage() {
        return this.pkg;
    }

    public final TypeElement getElement() {
        return this.element;
    }

    protected TypeElement getTargetElement() {
        return this.element;
    }

    public AnnotationHandle getAnnotation(Class<? extends Annotation> clazz) {
        return AnnotationHandle.of(this.getTargetElement(), clazz);
    }

    public final List<? extends Element> getEnclosedElements() {
        return TypeHandle.getEnclosedElements(this.getTargetElement());
    }

    public <T extends Element> List<T> getEnclosedElements(ElementKind ... elementKindArray) {
        return TypeHandle.getEnclosedElements(this.getTargetElement(), elementKindArray);
    }

    public TypeMirror getType() {
        TypeMirror typeMirror;
        if (TypeHandle.lIIIIlIlll(this.getTargetElement())) {
            typeMirror = this.getTargetElement().asType();
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            typeMirror = null;
        }
        return typeMirror;
    }

    public TypeHandle getSuperclass() {
        TypeElement typeElement = this.getTargetElement();
        if (TypeHandle.lIIIIllIII(typeElement)) {
            return null;
        }
        TypeMirror typeMirror = typeElement.getSuperclass();
        if (!TypeHandle.lIIIIlIlll(typeMirror) || TypeHandle.lIIIIllIIl((Object)typeMirror.getKind(), (Object)TypeKind.NONE)) {
            return null;
        }
        return new TypeHandle((DeclaredType)typeMirror);
    }

    public List<TypeHandle> getInterfaces() {
        if (TypeHandle.lIIIIllIII(this.getTargetElement())) {
            return Collections.emptyList();
        }
        ImmutableList.Builder builder = ImmutableList.builder();
        Iterator<? extends TypeMirror> iterator = this.getTargetElement().getInterfaces().iterator();
        while (TypeHandle.lIIIIllIlI(iterator.hasNext() ? 1 : 0)) {
            TypeMirror typeMirror = iterator.next();
            builder.add((Object)new TypeHandle((DeclaredType)typeMirror));
            "".length();
            "".length();
            if (null == null) continue;
            return null;
        }
        return builder.build();
    }

    public boolean isPublic() {
        boolean bl;
        if (TypeHandle.lIIIIlIlll(this.getTargetElement()) && TypeHandle.lIIIIllIlI(this.getTargetElement().getModifiers().contains((Object)Modifier.PUBLIC) ? 1 : 0)) {
            bl = true;
            "".length();
            if (null != null) {
                return ((100 + 28 - -56 + 55 ^ 89 + 134 - 205 + 161) & (0xBA ^ 0xA7 ^ (0xE ^ 0x4F) ^ -" ".length())) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isImaginary() {
        boolean bl;
        if (TypeHandle.lIIIIllIII(this.getTargetElement())) {
            bl = true;
            "".length();
            if ("  ".length() == "   ".length()) {
                return ((0x34 ^ 0x65) & ~(0xED ^ 0xBC)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public boolean isSimulated() {
        return false;
    }

    public final TypeReference getReference() {
        if (TypeHandle.lIIIIllIII(this.reference)) {
            this.reference = new TypeReference(this);
        }
        return this.reference;
    }

    public MappingMethod getMappingMethod(String string, String string2) {
        return new ResolvableMappingMethod(this, string, string2);
    }

    public String findDescriptor(MemberInfo memberInfo) {
        String string = memberInfo.desc;
        if (TypeHandle.lIIIIllIII(string)) {
            Iterator iterator = this.getEnclosedElements(ElementKind.METHOD).iterator();
            while (TypeHandle.lIIIIllIlI(iterator.hasNext() ? 1 : 0)) {
                ExecutableElement executableElement = (ExecutableElement)iterator.next();
                if (TypeHandle.lIIIIllIlI(executableElement.getSimpleName().toString().equals(memberInfo.name) ? 1 : 0)) {
                    string = TypeUtils.getDescriptor(executableElement);
                    "".length();
                    if (-"   ".length() <= 0) break;
                    return null;
                }
                "".length();
                if (-(0xB5 ^ 0xBB ^ (0x36 ^ 0x3D)) < 0) continue;
                return null;
            }
        }
        return string;
    }

    public final FieldHandle findField(VariableElement variableElement) {
        return this.findField(variableElement, true);
    }

    public final FieldHandle findField(VariableElement variableElement, boolean bl) {
        return this.findField(variableElement.getSimpleName().toString(), TypeUtils.getTypeName(variableElement.asType()), bl);
    }

    public final FieldHandle findField(String string, String string2) {
        return this.findField(string, string2, true);
    }

    public FieldHandle findField(String string, String string2, boolean bl) {
        String string3 = TypeUtils.stripGenerics(string2);
        Iterator iterator = this.getEnclosedElements(ElementKind.FIELD).iterator();
        while (TypeHandle.lIIIIllIlI(iterator.hasNext() ? 1 : 0)) {
            VariableElement variableElement = (VariableElement)iterator.next();
            if (TypeHandle.lIIIIllIlI(TypeHandle.compareElement(variableElement, string, string2, bl) ? 1 : 0)) {
                return new FieldHandle(this.getTargetElement(), variableElement);
            }
            if (TypeHandle.lIIIIllIlI(TypeHandle.compareElement(variableElement, string, string3, bl) ? 1 : 0)) {
                return new FieldHandle(this.getTargetElement(), variableElement, true);
            }
            "".length();
            if (" ".length() > ((0xD4 ^ 0x94) & ~(0xDF ^ 0x9F))) continue;
            return null;
        }
        return null;
    }

    public final MethodHandle findMethod(ExecutableElement executableElement) {
        return this.findMethod(executableElement, true);
    }

    public final MethodHandle findMethod(ExecutableElement executableElement, boolean bl) {
        return this.findMethod(executableElement.getSimpleName().toString(), TypeUtils.getJavaSignature(executableElement), bl);
    }

    public final MethodHandle findMethod(String string, String string2) {
        return this.findMethod(string, string2, true);
    }

    public MethodHandle findMethod(String string, String string2, boolean bl) {
        String string3 = TypeUtils.stripGenerics(string2);
        return TypeHandle.findMethod(this, string, string2, string3, bl);
    }

    protected static MethodHandle findMethod(TypeHandle typeHandle, String string, String string2, String string3, boolean bl) {
        Iterator iterator = TypeHandle.getEnclosedElements(typeHandle.getTargetElement(), ElementKind.CONSTRUCTOR, ElementKind.METHOD).iterator();
        while (TypeHandle.lIIIIllIlI(iterator.hasNext() ? 1 : 0)) {
            ExecutableElement executableElement = (ExecutableElement)iterator.next();
            if (!TypeHandle.lIIIIlllll(TypeHandle.compareElement(executableElement, string, string2, bl) ? 1 : 0) || TypeHandle.lIIIIllIlI(TypeHandle.compareElement(executableElement, string, string3, bl) ? 1 : 0)) {
                return new MethodHandle(typeHandle, executableElement);
            }
            "".length();
            if (((0x54 ^ 0x7A) & ~(0xA7 ^ 0x89)) < " ".length()) continue;
            return null;
        }
        return null;
    }

    protected static boolean compareElement(Element element, String string, String string2, boolean bl) {
        try {
            boolean bl2;
            int n;
            int n2;
            String string3 = element.getSimpleName().toString();
            String string4 = TypeUtils.getJavaSignature(element);
            String string5 = TypeUtils.stripGenerics(string4);
            if (TypeHandle.lIIIIllIlI(bl ? 1 : 0)) {
                n2 = string.equals(string3);
                "".length();
                if (((0x75 ^ 0x15) & ~(0x45 ^ 0x25)) < 0) {
                    return ((0xB0 ^ 0x9C) & ~(0x46 ^ 0x6A)) != 0;
                }
            } else {
                n2 = string.equalsIgnoreCase(string3);
            }
            if (TypeHandle.lIIIIllIlI(n = n2) && (!TypeHandle.lIIIIllIlI(string2.length()) || !TypeHandle.lIIIIlllll(string2.equals(string4) ? 1 : 0) || TypeHandle.lIIIIllIlI(string2.equals(string5) ? 1 : 0))) {
                bl2 = true;
                "".length();
                if ("   ".length() != "   ".length()) {
                    return ((0x34 ^ 6) & ~(0xA2 ^ 0x90)) != 0;
                }
            } else {
                bl2 = false;
            }
            return bl2;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    protected static <T extends Element> List<T> getEnclosedElements(TypeElement typeElement, ElementKind ... elementKindArray) {
        if (!TypeHandle.lIIIIlIlll(elementKindArray) || TypeHandle.lIIIlIIIII(elementKindArray.length, 1)) {
            return TypeHandle.getEnclosedElements(typeElement);
        }
        if (TypeHandle.lIIIIllIII(typeElement)) {
            return Collections.emptyList();
        }
        ImmutableList.Builder builder = ImmutableList.builder();
        Iterator<? extends Element> iterator = typeElement.getEnclosedElements().iterator();
        while (TypeHandle.lIIIIllIlI(iterator.hasNext() ? 1 : 0)) {
            Element element = iterator.next();
            ElementKind[] elementKindArray2 = elementKindArray;
            int n = elementKindArray2.length;
            int n2 = 0;
            while (TypeHandle.lIIIlIIIII(n2, n)) {
                ElementKind elementKind = elementKindArray2[n2];
                if (TypeHandle.lIIIIllIIl((Object)element.getKind(), (Object)elementKind)) {
                    builder.add((Object)element);
                    "".length();
                    "".length();
                    if (((0x15 ^ 0x1E) & ~(0x7F ^ 0x74)) <= "  ".length()) break;
                    return null;
                }
                ++n2;
                "".length();
                if ("   ".length() != " ".length()) continue;
                return null;
            }
            "".length();
            if ("   ".length() >= 0) continue;
            return null;
        }
        return builder.build();
    }

    protected static List<? extends Element> getEnclosedElements(TypeElement typeElement) {
        List<Object> list;
        if (TypeHandle.lIIIIlIlll(typeElement)) {
            list = typeElement.getEnclosedElements();
            "".length();
            if (((0xB4 ^ 0x9F) & ~(0x5B ^ 0x70)) < ((0x62 ^ 0x58) & ~(0x75 ^ 0x4F))) {
                return null;
            }
        } else {
            list = Collections.emptyList();
        }
        return list;
    }

    private static boolean lIIIlIIIII(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIIlIlll(Object object) {
        return object != null;
    }

    private static boolean lIIIIllIIl(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIIIllIII(Object object) {
        return object == null;
    }

    private static boolean lIIIIllIlI(int n) {
        return n != 0;
    }

    private static boolean lIIIIlllll(int n) {
        return n == 0;
    }
}

