/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mirror;

import java.lang.annotation.Annotation;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import org.spongepowered.asm.mixin.injection.struct.MemberInfo;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.asm.util.SignaturePrinter;
import org.spongepowered.tools.obfuscation.mirror.AnnotationHandle;
import org.spongepowered.tools.obfuscation.mirror.FieldHandle;
import org.spongepowered.tools.obfuscation.mirror.MethodHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;

public class TypeHandleSimulated
extends TypeHandle {
    private final TypeElement simulatedType;

    public TypeHandleSimulated(String string, TypeMirror typeMirror) {
        this(TypeUtils.getPackage(typeMirror), string, typeMirror);
    }

    public TypeHandleSimulated(PackageElement packageElement, String string, TypeMirror typeMirror) {
        super(packageElement, string);
        this.simulatedType = (TypeElement)((DeclaredType)typeMirror).asElement();
    }

    @Override
    protected TypeElement getTargetElement() {
        return this.simulatedType;
    }

    @Override
    public boolean isPublic() {
        return true;
    }

    @Override
    public boolean isImaginary() {
        return false;
    }

    @Override
    public boolean isSimulated() {
        return true;
    }

    @Override
    public AnnotationHandle getAnnotation(Class<? extends Annotation> clazz) {
        return null;
    }

    @Override
    public TypeHandle getSuperclass() {
        return null;
    }

    @Override
    public String findDescriptor(MemberInfo memberInfo) {
        String string;
        if (TypeHandleSimulated.lIIllIIlIll(memberInfo)) {
            string = memberInfo.desc;
            "".length();
            if ((0x1E ^ 0x1A) < 0) {
                return null;
            }
        } else {
            string = null;
        }
        return string;
    }

    @Override
    public FieldHandle findField(String string, String string2, boolean bl) {
        return new FieldHandle(null, string, string2);
    }

    @Override
    public MethodHandle findMethod(String string, String string2, boolean bl) {
        return new MethodHandle(null, string, string2);
    }

    @Override
    public MappingMethod getMappingMethod(String string, String string2) {
        MappingMethod mappingMethod;
        String string3;
        String string4 = new SignaturePrinter(string, string2).setFullyQualified(true).toDescriptor();
        MethodHandle methodHandle = TypeHandleSimulated.findMethodRecursive(this, string, string4, string3 = TypeUtils.stripGenerics(string4), true);
        if (TypeHandleSimulated.lIIllIIlIll(methodHandle)) {
            mappingMethod = methodHandle.asMapping(true);
            "".length();
            if ((0x9F ^ 0x9B) < " ".length()) {
                return null;
            }
        } else {
            mappingMethod = super.getMappingMethod(string, string2);
        }
        return mappingMethod;
    }

    private static MethodHandle findMethodRecursive(TypeHandle typeHandle, String string, String string2, String string3, boolean bl) {
        TypeElement typeElement = typeHandle.getTargetElement();
        if (TypeHandleSimulated.lIIllIIllII(typeElement)) {
            return null;
        }
        MethodHandle methodHandle = TypeHandle.findMethod(typeHandle, string, string2, string3, bl);
        if (TypeHandleSimulated.lIIllIIlIll(methodHandle)) {
            return methodHandle;
        }
        Object object = typeElement.getInterfaces().iterator();
        while (TypeHandleSimulated.lIIllIIllIl(object.hasNext() ? 1 : 0)) {
            TypeMirror typeMirror = object.next();
            methodHandle = TypeHandleSimulated.findMethodRecursive(typeMirror, string, string2, string3, bl);
            if (TypeHandleSimulated.lIIllIIlIll(methodHandle)) {
                return methodHandle;
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        object = typeElement.getSuperclass();
        if (!TypeHandleSimulated.lIIllIIlIll(object) || TypeHandleSimulated.lIIllIIlllI((Object)object.getKind(), (Object)TypeKind.NONE)) {
            return null;
        }
        return TypeHandleSimulated.findMethodRecursive((TypeMirror)object, string, string2, string3, bl);
    }

    private static MethodHandle findMethodRecursive(TypeMirror typeMirror, String string, String string2, String string3, boolean bl) {
        if (TypeHandleSimulated.lIIllIIllll(typeMirror instanceof DeclaredType)) {
            return null;
        }
        TypeElement typeElement = (TypeElement)((DeclaredType)typeMirror).asElement();
        return TypeHandleSimulated.findMethodRecursive(new TypeHandle(typeElement), string, string2, string3, bl);
    }

    private static boolean lIIllIIlIll(Object object) {
        return object != null;
    }

    private static boolean lIIllIIlllI(Object object, Object object2) {
        return object == object2;
    }

    private static boolean lIIllIIllII(Object object) {
        return object == null;
    }

    private static boolean lIIllIIllIl(int n) {
        return n != 0;
    }

    private static boolean lIIllIIllll(int n) {
        return n == 0;
    }
}

