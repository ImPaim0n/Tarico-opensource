/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mirror;

import java.io.Serializable;
import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.element.TypeElement;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;

public class TypeReference
implements Serializable,
Comparable<TypeReference> {
    private static final long serialVersionUID = 1L;
    private final String name;
    private transient TypeHandle handle;

    public TypeReference(TypeHandle typeHandle) {
        this.name = typeHandle.getName();
        this.handle = typeHandle;
    }

    public TypeReference(String string) {
        this.name = string;
    }

    public String getName() {
        return this.name;
    }

    public String getClassName() {
        return this.name.replace('/', '.');
    }

    public TypeHandle getHandle(ProcessingEnvironment processingEnvironment) {
        if (TypeReference.lIIIIIllllll(this.handle)) {
            TypeElement typeElement = processingEnvironment.getElementUtils().getTypeElement(this.getClassName());
            try {
                this.handle = new TypeHandle(typeElement);
                "".length();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            if (((0x71 ^ 0x41 ^ (0xAC ^ 0x9B)) & (0xCE ^ 0xB3 ^ (0 ^ 0x7A) ^ -" ".length())) != 0) {
                return null;
            }
        }
        return this.handle;
    }

    public String toString() {
        return String.format("TypeReference[%s]", this.name);
    }

    @Override
    public int compareTo(TypeReference typeReference) {
        int n;
        if (TypeReference.lIIIIIllllll(typeReference)) {
            n = -1;
            "".length();
            if ("   ".length() < 0) {
                return (32 + 141 - 68 + 56 ^ 110 + 125 - 221 + 140) & (0x29 ^ 0x78 ^ (0x13 ^ 0x79) ^ -" ".length());
            }
        } else {
            n = this.name.compareTo(typeReference.name);
        }
        return n;
    }

    public boolean equals(Object object) {
        boolean bl;
        if (TypeReference.lIIIIlIIIIII(object instanceof TypeReference) && TypeReference.lIIIIlIIIIIl(this.compareTo((TypeReference)object))) {
            bl = true;
            "".length();
            if (((0xF1 ^ 0xB9) & ~(0x74 ^ 0x3C)) != ((0x42 ^ 0x66) & ~(0x4A ^ 0x6E))) {
                return ((0x47 ^ 0x65) & ~(0x5C ^ 0x7E)) != 0;
            }
        } else {
            bl = false;
        }
        return bl;
    }

    public int hashCode() {
        return this.name.hashCode();
    }

    private static boolean lIIIIIllllll(Object object) {
        return object == null;
    }

    private static boolean lIIIIlIIIIII(int n) {
        return n != 0;
    }

    private static boolean lIIIIlIIIIIl(int n) {
        return n == 0;
    }
}

