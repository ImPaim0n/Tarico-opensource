/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mirror;

import javax.lang.model.element.Modifier;
import javax.lang.model.type.TypeKind;

class TypeUtils$1 {
    static final /* synthetic */ int[] $SwitchMap$javax$lang$model$type$TypeKind;
    static final /* synthetic */ int[] $SwitchMap$javax$lang$model$element$Modifier;

    static {
        block34: {
            block48: {
                block47: {
                    block46: {
                        block45: {
                            block44: {
                                block43: {
                                    block42: {
                                        block41: {
                                            block40: {
                                                block39: {
                                                    block38: {
                                                        block37: {
                                                            block36: {
                                                                block35: {
                                                                    block33: {
                                                                        $SwitchMap$javax$lang$model$element$Modifier = new int[Modifier.values().length];
                                                                        try {
                                                                            TypeUtils$1.$SwitchMap$javax$lang$model$element$Modifier[Modifier.PUBLIC.ordinal()] = 1;
                                                                            "".length();
                                                                        }
                                                                        catch (NoSuchFieldError noSuchFieldError) {
                                                                            // empty catch block
                                                                        }
                                                                        if (-(0x9C ^ 0x98) < 0) break block33;
                                                                        break block34;
                                                                    }
                                                                    try {
                                                                        TypeUtils$1.$SwitchMap$javax$lang$model$element$Modifier[Modifier.PROTECTED.ordinal()] = 2;
                                                                        "".length();
                                                                    }
                                                                    catch (NoSuchFieldError noSuchFieldError) {
                                                                        // empty catch block
                                                                    }
                                                                    if ("   ".length() < (0xC9 ^ 0xAA ^ (0xD6 ^ 0xB1))) break block35;
                                                                    break block34;
                                                                }
                                                                try {
                                                                    TypeUtils$1.$SwitchMap$javax$lang$model$element$Modifier[Modifier.PRIVATE.ordinal()] = 3;
                                                                    "".length();
                                                                }
                                                                catch (NoSuchFieldError noSuchFieldError) {
                                                                    // empty catch block
                                                                }
                                                                if (null == null) break block36;
                                                                break block34;
                                                            }
                                                            $SwitchMap$javax$lang$model$type$TypeKind = new int[TypeKind.values().length];
                                                            try {
                                                                TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.ARRAY.ordinal()] = 1;
                                                                "".length();
                                                            }
                                                            catch (NoSuchFieldError noSuchFieldError) {
                                                                // empty catch block
                                                            }
                                                            if (((0x67 ^ 0x39) & ~(2 ^ 0x5C)) == 0) break block37;
                                                            break block34;
                                                        }
                                                        try {
                                                            TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.DECLARED.ordinal()] = 2;
                                                            "".length();
                                                        }
                                                        catch (NoSuchFieldError noSuchFieldError) {
                                                            // empty catch block
                                                        }
                                                        if (-"  ".length() <= 0) break block38;
                                                        break block34;
                                                    }
                                                    try {
                                                        TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.TYPEVAR.ordinal()] = 3;
                                                        "".length();
                                                    }
                                                    catch (NoSuchFieldError noSuchFieldError) {
                                                        // empty catch block
                                                    }
                                                    if ("   ".length() > 0) break block39;
                                                    break block34;
                                                }
                                                try {
                                                    TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.ERROR.ordinal()] = 4;
                                                    "".length();
                                                }
                                                catch (NoSuchFieldError noSuchFieldError) {
                                                    // empty catch block
                                                }
                                                if ("   ".length() != 0) break block40;
                                                break block34;
                                            }
                                            try {
                                                TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.BOOLEAN.ordinal()] = 5;
                                                "".length();
                                            }
                                            catch (NoSuchFieldError noSuchFieldError) {
                                                // empty catch block
                                            }
                                            if (-"   ".length() <= 0) break block41;
                                            break block34;
                                        }
                                        try {
                                            TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.BYTE.ordinal()] = 6;
                                            "".length();
                                        }
                                        catch (NoSuchFieldError noSuchFieldError) {
                                            // empty catch block
                                        }
                                        if (null == null) break block42;
                                        break block34;
                                    }
                                    try {
                                        TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.CHAR.ordinal()] = 7;
                                        "".length();
                                    }
                                    catch (NoSuchFieldError noSuchFieldError) {
                                        // empty catch block
                                    }
                                    if (null == null) break block43;
                                    break block34;
                                }
                                try {
                                    TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.DOUBLE.ordinal()] = 8;
                                    "".length();
                                }
                                catch (NoSuchFieldError noSuchFieldError) {
                                    // empty catch block
                                }
                                if (-" ".length() == -" ".length()) break block44;
                                break block34;
                            }
                            try {
                                TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.FLOAT.ordinal()] = 9;
                                "".length();
                            }
                            catch (NoSuchFieldError noSuchFieldError) {
                                // empty catch block
                            }
                            if (null == null) break block45;
                            break block34;
                        }
                        try {
                            TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.INT.ordinal()] = 10;
                            "".length();
                        }
                        catch (NoSuchFieldError noSuchFieldError) {
                            // empty catch block
                        }
                        if (null == null) break block46;
                        break block34;
                    }
                    try {
                        TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.LONG.ordinal()] = 11;
                        "".length();
                    }
                    catch (NoSuchFieldError noSuchFieldError) {
                        // empty catch block
                    }
                    if ("  ".length() >= 0) break block47;
                    break block34;
                }
                try {
                    TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.SHORT.ordinal()] = 12;
                    "".length();
                }
                catch (NoSuchFieldError noSuchFieldError) {
                    // empty catch block
                }
                if (" ".length() <= " ".length()) break block48;
                break block34;
            }
            try {
                TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[TypeKind.VOID.ordinal()] = 13;
                "".length();
            }
            catch (NoSuchFieldError noSuchFieldError) {
                // empty catch block
            }
            if ((0xF ^ 0x75 ^ 36 + 92 - 34 + 33) == 0) {
                // empty if block
            }
        }
    }
}

