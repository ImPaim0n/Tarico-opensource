/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mirror;

import java.util.Iterator;
import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.TypeParameterElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.ArrayType;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.type.TypeVariable;
import org.spongepowered.asm.util.SignaturePrinter;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils$1;
import org.spongepowered.tools.obfuscation.mirror.Visibility;

public abstract class TypeUtils {
    private static final int MAX_GENERIC_RECURSION_DEPTH = 5;
    private static final String OBJECT_SIG;
    private static final String OBJECT_REF;

    private TypeUtils() {
    }

    public static PackageElement getPackage(TypeMirror typeMirror) {
        if (TypeUtils.lIIIlIlllI(typeMirror instanceof DeclaredType)) {
            return null;
        }
        return TypeUtils.getPackage((TypeElement)((DeclaredType)typeMirror).asElement());
    }

    public static PackageElement getPackage(TypeElement typeElement) {
        Element element = typeElement.getEnclosingElement();
        while (TypeUtils.lIIIlIllll(element) && TypeUtils.lIIIlIlllI(element instanceof PackageElement)) {
            element = element.getEnclosingElement();
            "".length();
            if (" ".length() != 0) continue;
            return null;
        }
        return (PackageElement)element;
    }

    public static String getElementType(Element element) {
        if (TypeUtils.lIIIllIIII(element instanceof TypeElement)) {
            return "TypeElement";
        }
        if (TypeUtils.lIIIllIIII(element instanceof ExecutableElement)) {
            return "ExecutableElement";
        }
        if (TypeUtils.lIIIllIIII(element instanceof VariableElement)) {
            return "VariableElement";
        }
        if (TypeUtils.lIIIllIIII(element instanceof PackageElement)) {
            return "PackageElement";
        }
        if (TypeUtils.lIIIllIIII(element instanceof TypeParameterElement)) {
            return "TypeParameterElement";
        }
        return element.getClass().getSimpleName();
    }

    public static String stripGenerics(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        int n2 = 0;
        while (TypeUtils.lIIIllIIIl(n, string.length())) {
            char c = string.charAt(n);
            if (TypeUtils.lIIIllIIlI(c, 60)) {
                ++n2;
            }
            if (TypeUtils.lIIIlIlllI(n2)) {
                stringBuilder.append(c);
                "".length();
                "".length();
                if ("  ".length() > "  ".length()) {
                    return null;
                }
            } else if (TypeUtils.lIIIllIIlI(c, 62)) {
                --n2;
            }
            ++n;
            "".length();
            if ((0xA8 ^ 0x90 ^ (0xA6 ^ 0x9A)) == (0xEA ^ 0x9E ^ (5 ^ 0x75))) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    public static String getName(VariableElement variableElement) {
        String string;
        if (TypeUtils.lIIIlIllll(variableElement)) {
            string = variableElement.getSimpleName().toString();
            "".length();
            if (null != null) {
                return null;
            }
        } else {
            string = null;
        }
        return string;
    }

    public static String getName(ExecutableElement executableElement) {
        String string;
        if (TypeUtils.lIIIlIllll(executableElement)) {
            string = executableElement.getSimpleName().toString();
            "".length();
            if ("   ".length() < 0) {
                return null;
            }
        } else {
            string = null;
        }
        return string;
    }

    public static String getJavaSignature(Element element) {
        if (TypeUtils.lIIIllIIII(element instanceof ExecutableElement)) {
            ExecutableElement executableElement = (ExecutableElement)element;
            StringBuilder stringBuilder = new StringBuilder().append("(");
            int n = 0;
            Iterator<? extends VariableElement> iterator = executableElement.getParameters().iterator();
            while (TypeUtils.lIIIllIIII(iterator.hasNext() ? 1 : 0)) {
                VariableElement variableElement = iterator.next();
                if (TypeUtils.lIIIllIIII(n)) {
                    stringBuilder.append(',');
                    "".length();
                }
                stringBuilder.append(TypeUtils.getTypeName(variableElement.asType()));
                "".length();
                n = 1;
                "".length();
                if ("   ".length() > ((0x5C ^ 0x41) & ~(0x43 ^ 0x5E))) continue;
                return null;
            }
            stringBuilder.append(')').append(TypeUtils.getTypeName(executableElement.getReturnType()));
            "".length();
            return String.valueOf(stringBuilder);
        }
        return TypeUtils.getTypeName(element.asType());
    }

    public static String getJavaSignature(String string) {
        return new SignaturePrinter("", string).setFullyQualified(true).toDescriptor();
    }

    public static String getTypeName(TypeMirror typeMirror) {
        switch (TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[typeMirror.getKind().ordinal()]) {
            case 1: {
                return String.valueOf(new StringBuilder().append(TypeUtils.getTypeName(((ArrayType)typeMirror).getComponentType())).append("[]"));
            }
            case 2: {
                return TypeUtils.getTypeName((DeclaredType)typeMirror);
            }
            case 3: {
                return TypeUtils.getTypeName(TypeUtils.getUpperBound(typeMirror));
            }
            case 4: {
                return "java.lang.Object";
            }
        }
        return typeMirror.toString();
    }

    public static String getTypeName(DeclaredType declaredType) {
        if (TypeUtils.lIIIllIlII(declaredType)) {
            return "java.lang.Object";
        }
        return TypeUtils.getInternalName((TypeElement)declaredType.asElement()).replace('/', '.');
    }

    public static String getDescriptor(Element element) {
        if (TypeUtils.lIIIllIIII(element instanceof ExecutableElement)) {
            return TypeUtils.getDescriptor((ExecutableElement)element);
        }
        if (TypeUtils.lIIIllIIII(element instanceof VariableElement)) {
            return TypeUtils.getInternalName((VariableElement)element);
        }
        return TypeUtils.getInternalName(element.asType());
    }

    public static String getDescriptor(ExecutableElement executableElement) {
        if (TypeUtils.lIIIllIlII(executableElement)) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        Object object = executableElement.getParameters().iterator();
        while (TypeUtils.lIIIllIIII(object.hasNext() ? 1 : 0)) {
            VariableElement variableElement = object.next();
            stringBuilder.append(TypeUtils.getInternalName(variableElement));
            "".length();
            "".length();
            if (-" ".length() < "   ".length()) continue;
            return null;
        }
        object = TypeUtils.getInternalName(executableElement.getReturnType());
        return String.format("(%s)%s", stringBuilder, object);
    }

    public static String getInternalName(VariableElement variableElement) {
        if (TypeUtils.lIIIllIlII(variableElement)) {
            return null;
        }
        return TypeUtils.getInternalName(variableElement.asType());
    }

    public static String getInternalName(TypeMirror typeMirror) {
        switch (TypeUtils$1.$SwitchMap$javax$lang$model$type$TypeKind[typeMirror.getKind().ordinal()]) {
            case 1: {
                return String.valueOf(new StringBuilder().append("[").append(TypeUtils.getInternalName(((ArrayType)typeMirror).getComponentType())));
            }
            case 2: {
                return String.valueOf(new StringBuilder().append("L").append(TypeUtils.getInternalName((DeclaredType)typeMirror)).append(";"));
            }
            case 3: {
                return String.valueOf(new StringBuilder().append("L").append(TypeUtils.getInternalName(TypeUtils.getUpperBound(typeMirror))).append(";"));
            }
            case 5: {
                return "Z";
            }
            case 6: {
                return "B";
            }
            case 7: {
                return "C";
            }
            case 8: {
                return "D";
            }
            case 9: {
                return "F";
            }
            case 10: {
                return "I";
            }
            case 11: {
                return "J";
            }
            case 12: {
                return "S";
            }
            case 13: {
                return "V";
            }
            case 4: {
                return "Ljava/lang/Object;";
            }
        }
        throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Unable to parse type symbol ").append(typeMirror).append(" with ").append((Object)typeMirror.getKind()).append(" to equivalent bytecode type")));
    }

    public static String getInternalName(DeclaredType declaredType) {
        if (TypeUtils.lIIIllIlII(declaredType)) {
            return "java/lang/Object";
        }
        return TypeUtils.getInternalName((TypeElement)declaredType.asElement());
    }

    public static String getInternalName(TypeElement typeElement) {
        if (TypeUtils.lIIIllIlII(typeElement)) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(typeElement.getSimpleName());
        "".length();
        Element element = typeElement.getEnclosingElement();
        while (TypeUtils.lIIIlIllll(element)) {
            if (TypeUtils.lIIIllIIII(element instanceof TypeElement)) {
                stringBuilder.insert(0, "$").insert(0, element.getSimpleName());
                "".length();
                "".length();
                if ((0x26 ^ 0x22) <= ((0xB ^ 6) & ~(5 ^ 8))) {
                    return null;
                }
            } else if (TypeUtils.lIIIllIIII(element instanceof PackageElement)) {
                stringBuilder.insert(0, "/").insert(0, ((PackageElement)element).getQualifiedName().toString().replace('.', '/'));
                "".length();
            }
            element = element.getEnclosingElement();
            "".length();
            if (-" ".length() == -" ".length()) continue;
            return null;
        }
        return String.valueOf(stringBuilder);
    }

    private static DeclaredType getUpperBound(TypeMirror typeMirror) {
        try {
            return TypeUtils.getUpperBound0(typeMirror, 5);
        }
        catch (IllegalStateException illegalStateException) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Type symbol \"").append(typeMirror).append("\" is too complex")), illegalStateException);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Unable to compute upper bound of type symbol ").append(typeMirror)), illegalArgumentException);
        }
    }

    private static DeclaredType getUpperBound0(TypeMirror typeMirror, int n) {
        if (TypeUtils.lIIIlIlllI(n)) {
            throw new IllegalStateException(String.valueOf(new StringBuilder().append("Generic symbol \"").append(typeMirror).append("\" is too complex, exceeded ").append(5).append(" iterations attempting to determine upper bound")));
        }
        if (TypeUtils.lIIIllIIII(typeMirror instanceof DeclaredType)) {
            return (DeclaredType)typeMirror;
        }
        if (TypeUtils.lIIIllIIII(typeMirror instanceof TypeVariable)) {
            try {
                TypeMirror typeMirror2 = ((TypeVariable)typeMirror).getUpperBound();
                return TypeUtils.getUpperBound0(typeMirror2, --n);
            }
            catch (IllegalStateException illegalStateException) {
                throw illegalStateException;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                throw illegalArgumentException;
            }
            catch (Exception exception) {
                throw new IllegalArgumentException(String.valueOf(new StringBuilder().append("Unable to compute upper bound of type symbol ").append(typeMirror)));
            }
        }
        return null;
    }

    public static boolean isAssignable(ProcessingEnvironment processingEnvironment, TypeMirror typeMirror, TypeMirror typeMirror2) {
        boolean bl = processingEnvironment.getTypeUtils().isAssignable(typeMirror, typeMirror2);
        if (TypeUtils.lIIIlIlllI(bl ? 1 : 0) && TypeUtils.lIIIllIIII(typeMirror instanceof DeclaredType) && TypeUtils.lIIIllIIII(typeMirror2 instanceof DeclaredType)) {
            TypeMirror typeMirror3 = TypeUtils.toRawType(processingEnvironment, (DeclaredType)typeMirror);
            TypeMirror typeMirror4 = TypeUtils.toRawType(processingEnvironment, (DeclaredType)typeMirror2);
            return processingEnvironment.getTypeUtils().isAssignable(typeMirror3, typeMirror4);
        }
        return bl;
    }

    private static TypeMirror toRawType(ProcessingEnvironment processingEnvironment, DeclaredType declaredType) {
        return processingEnvironment.getElementUtils().getTypeElement(((TypeElement)declaredType.asElement()).getQualifiedName()).asType();
    }

    public static Visibility getVisibility(Element element) {
        if (TypeUtils.lIIIllIlII(element)) {
            return null;
        }
        Iterator<Modifier> iterator = element.getModifiers().iterator();
        while (TypeUtils.lIIIllIIII(iterator.hasNext() ? 1 : 0)) {
            Modifier modifier = iterator.next();
            switch (TypeUtils$1.$SwitchMap$javax$lang$model$element$Modifier[modifier.ordinal()]) {
                case 1: {
                    return Visibility.PUBLIC;
                }
                case 2: {
                    return Visibility.PROTECTED;
                }
                case 3: {
                    return Visibility.PRIVATE;
                }
            }
            "".length();
            if (-"   ".length() <= 0) continue;
            return null;
        }
        return Visibility.PACKAGE;
    }

    static {
        OBJECT_REF = "java/lang/Object";
        OBJECT_SIG = "java.lang.Object";
    }

    private static boolean lIIIllIIlI(int n, int n2) {
        return n == n2;
    }

    private static boolean lIIIllIIIl(int n, int n2) {
        return n < n2;
    }

    private static boolean lIIIlIllll(Object object) {
        return object != null;
    }

    private static boolean lIIIllIlII(Object object) {
        return object == null;
    }

    private static boolean lIIIllIIII(int n) {
        return n != 0;
    }

    private static boolean lIIIlIlllI(int n) {
        return n == 0;
    }
}

