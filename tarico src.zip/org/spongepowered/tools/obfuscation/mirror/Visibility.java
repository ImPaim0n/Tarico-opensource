/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mirror;

public enum Visibility {
    PRIVATE,
    PROTECTED,
    PACKAGE,
    PUBLIC;

}

