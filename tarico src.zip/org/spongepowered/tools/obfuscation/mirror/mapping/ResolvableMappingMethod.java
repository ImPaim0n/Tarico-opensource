/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.tools.obfuscation.mirror.mapping;

import java.util.Iterator;
import org.spongepowered.asm.obfuscation.mapping.common.MappingMethod;
import org.spongepowered.tools.obfuscation.mirror.TypeHandle;
import org.spongepowered.tools.obfuscation.mirror.TypeUtils;

public final class ResolvableMappingMethod
extends MappingMethod {
    private final TypeHandle ownerHandle;

    public ResolvableMappingMethod(TypeHandle typeHandle, String string, String string2) {
        super(typeHandle.getName(), string, string2);
        this.ownerHandle = typeHandle;
    }

    @Override
    public MappingMethod getSuper() {
        if (ResolvableMappingMethod.lIlllIIllII(this.ownerHandle)) {
            return super.getSuper();
        }
        String string = this.getSimpleName();
        String string2 = this.getDesc();
        String string3 = TypeUtils.getJavaSignature(string2);
        TypeHandle typeHandle = this.ownerHandle.getSuperclass();
        if (ResolvableMappingMethod.lIlllIIllIl(typeHandle) && ResolvableMappingMethod.lIlllIIllIl(typeHandle.findMethod(string, string3))) {
            return typeHandle.getMappingMethod(string, string2);
        }
        Iterator<TypeHandle> iterator = this.ownerHandle.getInterfaces().iterator();
        while (ResolvableMappingMethod.lIlllIIlllI(iterator.hasNext() ? 1 : 0)) {
            TypeHandle typeHandle2 = iterator.next();
            if (ResolvableMappingMethod.lIlllIIllIl(typeHandle2.findMethod(string, string3))) {
                return typeHandle2.getMappingMethod(string, string2);
            }
            "".length();
            if (null == null) continue;
            return null;
        }
        if (ResolvableMappingMethod.lIlllIIllIl(typeHandle)) {
            return typeHandle.getMappingMethod(string, string2).getSuper();
        }
        return super.getSuper();
    }

    public MappingMethod move(TypeHandle typeHandle) {
        return new ResolvableMappingMethod(typeHandle, this.getSimpleName(), this.getDesc());
    }

    @Override
    public MappingMethod remap(String string) {
        return new ResolvableMappingMethod(this.ownerHandle, string, this.getDesc());
    }

    @Override
    public MappingMethod transform(String string) {
        return new ResolvableMappingMethod(this.ownerHandle, this.getSimpleName(), string);
    }

    @Override
    public MappingMethod copy() {
        return new ResolvableMappingMethod(this.ownerHandle, this.getSimpleName(), this.getDesc());
    }

    private static boolean lIlllIIllIl(Object object) {
        return object != null;
    }

    private static boolean lIlllIIllII(Object object) {
        return object == null;
    }

    private static boolean lIlllIIlllI(int n) {
        return n != 0;
    }
}

